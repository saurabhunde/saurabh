/**
 * @ngdoc controller
 * @name Preferences.controller:PreferencesController
 * @element div
 *
 * @description
 * This Controller is responsible for all the operations done on the My profile page
 *
 * @requires AngularJS.$scope
 * @requires AngularJS.$http
 * @requires AngularJS.$timeout
 * @requires common.commonService
 * @requires Projects.LandingPageData
 * @requires Preferences.PreferencesController
 * 
 * @property {String} UserRoleName:String This property is user role of logged in user.
 * @property {Object} userInfo:Object  This property is object contains user details
 * @property {Object} pass:Object  This property is object contains old and new password details
 * @property {Array} otherLang:Array  This property is list of languages assigned to user.
 * @property {Array} preferenceList:Array  This property is list of notifications settings on notification tab.
 */
Preferences.controller('preferencesController', ['$scope', '$http', '$location', 'commonService', 'PreferencesService', 'LandingPageData', '$timeout', function ($scope, $http, $location, commonService, PreferencesService, LandingPageData, $timeout) {
    $scope.showLoader = false;
    $scope.userProfile = true;
    var notificationSettings = false;
    var passwordChange = false;
    $scope.pass = {};
    var otherLang = [];
    $scope.preferenceList = [];
    $scope.messageHeader = 'Message';
    $scope.UserRoleName = commonService.getLocalData('userDetails').UserRoles[0].UserRoleName;
    $scope.isFirstNameRequired = false
    $scope.isLastNameRequired = false;

    //set hashURL for GLMGR-1189
    sessionStorage.setItem('hashURL', null);

    /**
     * @ngdoc
     * @name changePassword
     * @methodOf Preferences.controller:PreferencesController
     * @description
     * This function is called on click of submit button on change password tab. This function is used to change the user password.
     * @returns {String} This method returns success/error message.
     */
    $scope.changePassword = function () {
        if (!$scope.pass.newPassword && !$scope.pass.oldPassword && !$scope.pass.confirmNewPassword) {
            $('#errorModal').modal('show');
            $scope.errorMessage = "Password fields should not be empty!";
            $scope.pass = {};
        } else if (!$scope.pass.oldPassword) {
            $('#errorModal').modal('show');
            $scope.errorMessage = "Please enter old password.";

        } else if (!$scope.pass.newPassword) {
            $('#errorModal').modal('show');
            $scope.errorMessage = "Please enter new password.";

        }
        else {
            var captitalLetter = /[A-Z]/.test($scope.pass.newPassword);
            var digit = /[0-9]/.test($scope.pass.newPassword);
            var specialCharacter = /[@~`!#$%\^&*+=\-\[\]\\';,/_{}()\\:<>\?]/g.test($scope.pass.newPassword);
            var passlength = $scope.pass.newPassword.length;
            if (!$scope.pass) {
                $('#errorModal').modal('show');
                $scope.errorMessage = "Please enter new password.";
                $scope.pass = {};
            }
            else if ($scope.pass.newPassword.localeCompare(commonService.getLocalData('userDetails').UserName) == 0) {
                $('#errorModal').modal('show');
                $scope.errorMessage = "Password cannot be same as Username!";
                $scope.pass = {};
            }
            else if ($scope.pass.newPassword.localeCompare($scope.pass.confirmNewPassword) != 0) {
                $('#errorModal').modal('show');
                $scope.errorMessage = "New Password does not match confirm password!";

                $scope.pass = {};
            }
            else if (!captitalLetter) {
                $('#errorModal').modal('show');
                $scope.errorMessage = "New Password must contain a capital letter!";

                $scope.pass = {};

            }
            else if (!digit) {
                $('#errorModal').modal('show');
                $scope.errorMessage = "New Password must contain a digit.";

                $scope.pass = {};
            }
            else if (!specialCharacter) {
                $('#errorModal').modal('show');
                $scope.errorMessage = "New Password must contain a Special Character.";

                $scope.pass = {};
            }
            else if (passlength < 8) {
                $('#errorModal').modal('show');
                $scope.errorMessage = "New Password must be of minimum 8 characters length.";

                $scope.pass = {};
            }
            else {
                $scope.pass['userId'] = commonService.getLocalData('userDetails').UserId;

                if ($scope.adminUser) {
                    $scope.pass['OriginalUserId'] = $scope.adminUser.UserId;
                } else {
                    $scope.pass['OriginalUserId'] = null;
                }

                PreferencesService.changePassword($scope.pass, function (data) {
                    $('#errorModal').modal('show');
                    $scope.messageHeader = 'UPDATE SUCCESSFUL';
                    $scope.errorMessage = data;
                    $scope.pass = {};
                });
            }
        }
    };

    $scope.specialCharacterList = function () {
        $('#specialCharList').modal('show');
    };

    /**
     * @ngdoc
     * @name toggle
     * @methodOf Preferences.controller:PreferencesController
     * @description
     * This function is called on click of tabs on profile page . This function is used to change tabs on profile page
     * @returns {Undefined} This method does not return.
     */
    var toggle = function (header) {
        if (header == 'profile') {
            $scope.userProfile = true;
            notificationSettings = false;
            passwordChange = false;

            $("#profile").addClass("aTagClicked");
            $("#settings").removeClass("aTagClicked");
            $("#changePassword").removeClass("aTagClicked");
            $("#profile").addClass("selected-user-profile-tab");
            $("#settings").removeClass("selected-user-profile-tab");
            $("#changePassword").removeClass("selected-user-profile-tab");
        }
        else if (header == 'settings') {
            $scope.userProfile = false;
            notificationSettings = true;
            passwordChange = false;
            $("#profile").removeClass("aTagClicked");
            $("#settings").addClass("aTagClicked");
            $("#changePassword").removeClass("aTagClicked");
            $("#profile").removeClass("selected-user-profile-tab");
            $("#settings").addClass("selected-user-profile-tab");
            $("#changePassword").removeClass("selected-user-profile-tab");
        }
        else {
            $scope.userProfile = false;
            notificationSettings = false;
            passwordChange = true;
            $("#profile").removeClass("aTagClicked");
            $("#settings").removeClass("aTagClicked");
            $("#changePassword").addClass("aTagClicked");
            $("#profile").removeClass("selected-user-profile-tab");
            $("#settings").removeClass("selected-user-profile-tab");
            $("#changePassword").addClass("selected-user-profile-tab");
        }
    };

     /**
     * @ngdoc
     * @name saveSettings
     * @methodOf Preferences.controller:PreferencesController
     * @description
     * This function is called on click of save button on notification tab. This function is used to save user notification settings.
     * @returns {Undefined} This method does not return.
     */
    $scope.saveSettings = function () {
        var Notification = [];
        var OriginalUserId;
        if ($scope.adminUser) {
            OriginalUserId = $scope.adminUser.UserId;
        } else {
            OriginalUserId = null;
        }
        for (var i = 0; i < $scope.preferenceList.length; i++) {
            var tempObject = {};
            tempObject['UserEmailNotificationId'] = $scope.preferenceList[i].UserEmailNotificationId;
            tempObject['NotificationId'] = $scope.preferenceList[i].NotificationId;
            tempObject['NotificationName'] = null;
            tempObject['IsActive'] = $scope.preferenceList[i].IsActive;
            tempObject['UserId'] = commonService.getLocalData('userDetails').UserId;
            tempObject['OriginalUserId'] = OriginalUserId;
            Notification.push(tempObject);
        }
        var data = {};
        data['Notification'] = Notification;

        if ($scope.adminUser) {
            data['OriginalUserId'] = $scope.adminUser.UserId;
        } else {
            data['OriginalUserId'] = null;
        }

        $scope.showLoader = true;
        PreferencesService.saveEmailNotification(data, function (success) {
            PreferencesService.getUserEmailNotification(commonService.getLocalData('userDetails').UserId, function (preferenceList) {
                if (commonService.getLocalData('userDetails').UserRoles[0].UserRoleName === "Approver") {
                    for (var i = 0; i < preferenceList.length; i++) {
                        if (preferenceList[i].NotificationName === "Notify me when section is ready for translation/section is complete") {
                            preferenceList[i].NotificationName = "Notify me when section is ready for translation/section is complete (applicable only for approver as translator)";
                        }
                    }
                }
                if (preferenceList.accessRes) {
                    if (preferenceList.accessRes == "AccessDenied") {
                        commonService.deniedRedirect();
                    }
                }
                else {
                    $scope.showLoader = false;
                    $('#errorModal').modal('show');
                    $scope.messageHeader = 'UPDATE SUCCESSFUL';
                    $scope.errorMessage = 'Settings Saved';
                    $scope.preferenceList = preferenceList;
                }
            });
        });
    };

     /**
     * @ngdoc
     * @name cancelSettings
     * @methodOf Preferences.controller:PreferencesController
     * @description
     * This function is called on click of cancel button. This function is used to cancel the popup.
     * @returns {Undefined} This method does not return.
     */
    $scope.cancelSettings = function () {
        PreferencesService.getUserEmailNotification(commonService.getLocalData('userDetails').UserId, function (preferenceList) {
            if (commonService.getLocalData('userDetails').UserRoles[0].UserRoleName === "Approver") {
                for (var i = 0; i < preferenceList.length; i++) {
                    if (preferenceList[i].NotificationName === "Notify me when section is ready for translation/section is complete") {
                        preferenceList[i].NotificationName = "Notify me when section is ready for translation/section is complete (applicable only for approver as translator)";
                    }
                }
            }
            if (preferenceList.accessRes) {
                if (preferenceList.accessRes == "AccessDenied") {
                    commonService.deniedRedirect();
                }
            }
            else {
                $scope.preferenceList = preferenceList;
            }
        });
    };

     /**
     * @ngdoc
     * @name rememberAutoTranslation
     * @methodOf Preferences.controller:PreferencesController
     * @param {Boolean} IsRememberUserNextTime This is Remember translation popup checkbox value.
     * @param {Boolean} IsSectionCompleteReminder This is section complete reminder checkbox value.
     * @description
     * This function is called on click of save button. This function is used to save user information with section complete reminder info and auto translation remember info.
     * @returns {Undefined} This method does not return.
     */
    $scope.rememberAutoTranslation = function (IsRememberUserNextTime, IsSectionCompleteReminder) {
        if (!IsRememberUserNextTime) {
            IsRememberUserNextTime = false;
        }
        if (!IsSectionCompleteReminder) {
            IsSectionCompleteReminder = false;
        }

        var data = {};
        data['IsRememberUserNextTime'] = IsRememberUserNextTime;
        data['IsSectionCompleteReminder'] = IsSectionCompleteReminder;

        data['UserId'] = commonService.getLocalData('userDetails').UserId;

        if ($scope.adminUser) {
            data['OriginalUserId'] = $scope.adminUser.UserId;
        } else {
            data['OriginalUserId'] = null;
        }
        data['FirstName'] = $scope.userInfo.UserInfo.FirstName;
        data['LastName'] = $scope.userInfo.UserInfo.LastName;

        if ($scope.userInfo.UserInfo.FirstName && $scope.userInfo.UserInfo.LastName) {
            $scope.showLoader = true;
            PreferencesService.updateUserConfirmationForNextTime(data, function (success) {
                $scope.showLoader = false;
                $('#SuccessMsgDiv').css('display', 'block');
                $timeout(function () { $('#SuccessMsgDiv').css('display', 'none') }, 3000);
            });
        } else {
            $scope.checkValidations();
        }

    };

     /**
     * @ngdoc
     * @name checkValidations
     * @methodOf Preferences.controller:PreferencesController
     * @description
     * This function is called on blur of input fields on my profile page. This function is used for validation.
     * @returns {Undefined} This method does not return.
     */
    $scope.checkValidations = function () {
        if (!$scope.userInfo.UserInfo.FirstName) {
            $scope.isFirstNameRequired = true;
        } else {
            $scope.isFirstNameRequired = false;
        }
        if (!$scope.userInfo.UserInfo.LastName) {
            $scope.isLastNameRequired = true;
        } else {
            $scope.isLastNameRequired = false;
        }
    };

    /**
     * @ngdoc
     * @name init
     * @methodOf Preferences.controller:PreferencesController
     * @description
     * This function is called initially when page is loaded. This function is used for initialisation of the variables on page load.
     * @returns {undefined} This method does not return.
     */
    var init = function () {
        $scope.showLoader = true;
        var resorceIdx = 0;
        sessionStorage.setItem('resourcePageId', JSON.stringify(resorceIdx));
        LandingPageData.getUserInfo(function (userinfo) {
            $scope.userInfo = userinfo;
            var n = $scope.userInfo.UserInfo.Email.indexOf("@");
            $scope.clientNameGlossary = $scope.userInfo.UserInfo.Email.slice(0, n);

            if ($scope.userInfo.UserInfo) {
                if ($scope.userInfo.UserInfo.IsSectionCompleteReminder === null) {
                    $scope.userInfo.UserInfo.IsSectionCompleteReminder = true;
                }
            }

            for (var i = 0; i < $scope.userInfo.UserDetailInfo.UserLanguages.length; i++) {
                if ($scope.userInfo.UserDetailInfo.UserLanguages[i].IsNative == true) {
                    $scope.nativeLang = $scope.userInfo.UserDetailInfo.UserLanguages[i].LanguageName;
                }
                else {
                    otherLang.push($scope.userInfo.UserDetailInfo.UserLanguages[i].LanguageName);
                }
            }
            PreferencesService.getUserEmailNotification(commonService.getLocalData('userDetails').UserId, function (preferenceList) {
                console.log("1---", commonService.getLocalData('userDetails').UserRoles[0].UserRoleName);
                if (commonService.getLocalData('userDetails').UserRoles[0].UserRoleName === "Approver") {
                    for (var i = 0; i < preferenceList.length; i++) {
                        if (preferenceList[i].NotificationName === "Notify me when section is ready for translation/section is complete") {
                            preferenceList[i].NotificationName = "Notify me when section is ready for translation/section is complete (applicable only for approver as translator)";
                        }
                    }
                }
                if (preferenceList.accessRes) {
                    if (preferenceList.accessRes == "AccessDenied") {
                        commonService.deniedRedirect();
                    }
                }
                else {
                    $scope.preferenceList = preferenceList;
                }
            });

            var textarea = document.getElementById("other_lang_textarea");
            textarea.value = otherLang.join("\n");
            $scope.showLoader = false;
            $("#profile").addClass("aTagClicked");
            $("#profile").addClass("selected-user-profile-tab");
            dynamicScreenHeight();
        })
    };
    init();
}]);