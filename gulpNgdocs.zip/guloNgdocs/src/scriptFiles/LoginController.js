﻿/**
 * @ngdoc controller
 * @name Login.controller:LoginController
 * @element div
 *
 * @description
 * This Controller is responsible for showing Login page and handling requests made on Login page 
 *
 * @requires AngularJS.$scope
 * @requires AngularJS.$http
 * @requires AngularJS.$location 
 * @requires Users.UserAuthorizationService
 * @requires Users.UserAuthenticateService 
 * 
 * @property {string} LoginErrorMessage:String  This property is string used to show error message when username password don’t match with database entries
 * @property {object} userDetails:Object This is object stores the user details received from backend when user is logged in 
 * 
 */
angular.module('Login', ['ngRoute', 'gmUsersModule']).controller('LoginController', 
['$scope', '$http', '$location', 'UserAuthenticateService', 'UserAuthorizationService',
    function ($scope, $http, $location, UserAuthenticateService, UserAuthorizationService) {
        localStorage.setItem('time', new Date());
        if (JSON.parse(sessionStorage.getItem('fromForgotPasswordPage'))) {
            $scope.isTermspage = true;
            sessionStorage.setItem('fromForgotPasswordPage', false);
        } else {
            $scope.isTermspage = false;
        }
        
        $scope.invalidUser;
        var userDetails = {};
        $scope.showLoader = false;
        $scope.LoginAttempt = false;
        $scope.LoginErrorMessage = ''
        
        if (JSON.parse(sessionStorage.getItem('termsPage')) === false && window.location.hash === "#terms") {
            sessionStorage.setItem('termsPage', null);
            window.location = '/';
        }

        if (JSON.parse(sessionStorage.getItem('termsPage')) === null && window.location.hash === "#terms") {
            sessionStorage.setItem('termsPage', null);
            window.location = '/';
        }

        /*
        */
             /**
     * @ngdoc
     * @name onhashchange
     * @methodOf Login.controller:LoginController
     *
     * @description
     * ng-show is used to show terms page on hash change function tracks hash url value in session storage
     * 
     */
        window.onhashchange = function () {
            if (JSON.parse(sessionStorage.getItem('termsPage')) && window.location.hash === "#terms") {
                sessionStorage.setItem('termsPage', false);
                $scope.isTermspage = true;
            } else {
                window.location = '/';
            }
        }

    /**
     * @ngdoc
     * @name authenticateUser
     * @methodOf Login.controller:LoginController
     *
     * @description
     * This function is called when Login button is clicked.
       It checks weather username and pass is valid or not.
     *
     * @returns {boolean} The response is false when password/username field is empty
     */
        $scope.authenticateUser = function () {
            $scope.showLoader = true;
            $scope.LoginAttempt = true;
            if (!$scope.password) {
                $scope.LoginErrorMessage = 'Password should not be empty!';
                $scope.invalidUser = true;
                $scope.LoginAttempt = false;
                $scope.showLoader = false;
                return false;
            }
            if (!$scope.username) {
                $scope.LoginErrorMessage = 'Username should not be empty!';
                $scope.invalidUser = true;
                $scope.LoginAttempt = false;
                $scope.showLoader = false;
                return false;
            }
            /*This service methos checks whether combination of email and pass is present in DB and accordingly send response*/
            UserAuthenticateService.getUserAuthenticate($scope.username, $scope.password,
                function (data, status, headers, config) {
                    if (data.Criteria === false) {
                        $scope.showLoader = false;
                        localStorage.setItem('ResetUserId', JSON.stringify(data.UserId));
                        localStorage.setItem('ResetUserName', JSON.stringify(data.UserName));
                        $('#securityCriteriaChanged').modal('show');

                    }
                    else if (data === true) {
                        $scope.getUserDetails($scope.username);
                    } else {
                        if (data === 1) {
                            $scope.LoginErrorMessage = 'Wrong Password. Please try again!'
                        } else if (data === 2) {
                            $scope.LoginErrorMessage = 'Please note: After 3 failed attempts for password, you will be locked out for 10 minutes. You are at your 2nd failed attempt. If you are unsure what your password is, please try using the forgot my password option';
                        } else if (data === 3) {
                            $scope.LoginErrorMessage = 'Please note: You have exceeded 3 failed password attempts. Your account will now be locked out for 10 minutes. Please try again in 10 minutes. If you are unsure what your password is, please use the forgot my password option.';
                        } else if (data === 4) {
                            $scope.LoginErrorMessage = 'Email/password combo does not match what we have in our records. Please try again or contact the support team';
                        };
                        $scope.invalidUser = true;
                        $scope.LoginAttempt = false;
                        $scope.showLoader = false;
                    }
                }
            )
        };

        //close the security criteria popup
        $scope.redirectPassReset = function () {
            $('#securityCriteriaChanged').modal('hide');
            $('.modal-backdrop.fade.in').remove();

            $location.path("/resets");
        };

     /**
     * @ngdoc
     * @name getUserDetails
     * @methodOf Login.controller:LoginController
     * @param {string} userName The username entered by user on Login form.
     * @description
     *This method is used to get user details if username and password entered are valid.
     *
     */
        $scope.getUserDetails = function (userName) {
            var x = 0;
            sessionStorage.setItem('resourcePageId', JSON.stringify(x));
            UserAuthorizationService.getUserAuthorization(userName,
            function (data, status, headers, config) {
                userDetails = data;
                localStorage.setItem('userDetails', JSON.stringify(userDetails));
                if (userDetails.IsTermAccepted) {
                    sessionStorage.setItem('termsPage', true);
                    $location.hash('terms');
                } else {
                    sessionStorage.setItem('termsPage', true);
                    $location.hash('terms');
                }
            },
            function (data, status, headers, config) {

            })
        };

    /**
     * @ngdoc
     * @name forgetPasswordEmail
     * @methodOf Login.controller:LoginController
     * 
     * @description
     *This method is used to send email of password reset link to user.
     *
     */
        $scope.forgetPasswordEmail = function () {
            $http({
                method: 'POST',
                url: "Users/ForgotPassword",
                data: $scope.userLogin
            })
            .success(function (data) {
                if (data === 'Email has been sent to your registered Mail Id') {
                    $scope.errorMessage = data;
                    $('#forgot-password').modal('hide');
                    $('#errorSuccessModal').modal('show');
                    $scope.userLogin = '';
                }
                else {
                    $('#errorModal').show();
                    $scope.errorMessage = data;
                }
            })
            .error(function (e) {

            })
        };

    /**
     * @ngdoc
     * @name AcceptDeclineHandler
     * @methodOf Login.controller:LoginController
     * 
     * @param {string} status The status is 'accept' when user clicks on accept button or it is 'decline' when user clicks decline on terms and condition page 
     * 
     * @description
     *This method is called when terms and conditions on terms page are accepted/declined.
     *
     */
        $scope.AcceptDeclineHandler = function (status) {
            switch (status) {
                case 'accept':
                    var localStorageUser = JSON.parse(localStorage.getItem('userDetails'));
                    UserAuthorizationService.updateUserTermAccepted(localStorageUser.UserId,
                        function (data, status, headers, config) {
                            localStorageUser.IsTermAccepted = data;
                            localStorage.setItem('HomeValue', 'List'); // for GLMGR-656
                            localStorage.setItem('userDetails', JSON.stringify(localStorageUser));
                            localStorage.setItem('adminUser', null);
                            localStorage.setItem('isUserImpersonated', null);
                            localStorage.setItem('impersonateLogout', null);
                            window.location = '/Projects';
                        },
                    function (data, status, headers, config) {
                    });
                    break;

                case 'decline':
                    sessionStorage.setItem('termsPage', null);
                    window.location = '/';
                    break;
            }
        };
    }
]);