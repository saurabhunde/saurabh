/**
 * @ngdoc controller
 * @name Projects.controller:ProjectsController
 * @element div
 *
 * @description
 * This Controller is responsible for showing project landing page and showing all the project deatils on particular projects page.
 *
 * @requires AngularJS.$scope
 * @requires AngularJS.$http
 * @requires AngularJS.$route
 * @requires AngularJS.$interval
 * @requires AngularJS.$location
 * @requires common
 * @requires common.commonService
 * @requires Projects.LandingPageData
 * @requires Projects.Glossary
 * 
 * @property {string} currentProjectId:String  This property is encrypted project id of current project.
 * @property {string} currentUserRoleName:String  This property is logged in user's role name (eg. Admin, Super Admin etc.).
 * @property {number} currentUserId:Number  This property is user id of logged in user.
 * @property {Array} CorousalData:Array  This property is list of all projects assigned to user. Value of this array changes  with according to view(carousal/list view) selected by user.
 * @property {object} userDetails:Object This is object stores the user details received from backend when user is logged in 
 * @property {boolean} projectListVertical:Boolean This property is boolean value. If user selects list view it is true else it is false. 
 * @property {boolean} uploadFileWizard:Boolean This property is boolean value. Used to show/hide upload knp wizard. 
 * @property {boolean} columnMapping:Boolean This property is used to toggle the view.
 * @property {boolean} projectListVertical:Boolean This property is boolean value. Used to show/hide column mapping wizard.
 * @property {boolean} sourcePreview:Boolean This property is boolean value. Used to show/hide preview of knp preview.
 * 
 */

angular.module('projects', ['ngRoute', 'common', 'gmProjectsModule', 'ngGrid', 'ui.bootstrap', 'mgcrea.ngStrap', 'ngTable', 'ngTableResizableColumns', 'ui.sortable', 'angularUtils.directives.dirPagination', 'ui.grid', 'ui.grid.resizeColumns', 'ngImgCrop'])
.controller('projectsController', ['$scope', '$route', '$http', '$location', '$interval', 'LandingPageData', 'commonService', 'Glossary', 'ProjectIdService', '$rootScope', 'dirPaginateDirective', function ($scope, $route, $http, $location, $interval, LandingPageData, commonService, Glossary, ProjectIdService, $rootScope, dirPaginateDirective) {
    var currentProjectId;
    var currentUserId = commonService.getLocalData('userDetails').UserId;
    var currentUserRoleName = commonService.getLocalData('userDetails').UserRoles[0].UserRoleName;
    $scope.currentUserRoleName = currentUserRoleName;
    var CorousalData;
    var ProjectLangList;
    var corousalarrayIndex;
    var lang_str;
    var brandSelect = 0;
    var GlossaryLangCheck;
    $scope.showProjectImage = true;
    $scope.projectListVertical = true;
    $scope.projectListTitle = 'Display As Carousel';
    $scope.newIndex = 10;
    $scope.excludeNTL_FD = true;

    //values to pass for service after filter applied
    var UserId;
    var ClientIdFilter;
    var BrandIdFilter;
    var UserRole;
    var InputTextFilter;
    var ProjectStateFilterActive;
    var IsOwnerOfProjectFilter;
    sessionStorage.setItem('navigateToAllGlossary', 'false');
    
    //set hashURL for GLMGR-1189
    sessionStorage.setItem('hashURL', null);

    //GLMGR-1573 Import KNP netflix
    var index = 0;
    var attachedFiles = [];
    var fileName;
    var isAccepted = false;
    var columnMppingObj = {};
    $scope.afterPre = false;
    $scope.uploadFileWizard = true;
    $scope.columnMapping = false;
    $scope.sourcePreview = false;
    $scope.importSuccess = false;
    //GLMGR-1574 column Mapping 
    //button labels
    $scope.addinfoLabel = "Select catagories column(s)";
    $scope.sectionLabel = "Select Section column";
    $scope.sourcetermLabel = "Select Source Term column";
    $scope.langLabel = "Select Language column(s)";
    //making differenr arrys for addinfo, section, sourceterm and languages in simple array of strings format
    var addInfoColumns = [];
    var sectionColumns = "";
    var sourcetermColumns = "";
    var langColumns = [];

    //validation variables
    $scope.isSectionValid = false;
    $scope.isSourceTermValid = false;
    $scope.isLangValid = false;

    //declaring arrays of directive for addinfo,section,sourceterm,lang
    $scope.additionalInfoCols = [];
    $scope.sectionCols = [];
    $scope.sourceTermCols = [];
    $scope.languageCols = [];

     /**
   * @ngdoc
   * @name userAccessReport
   * @methodOf Projects.controller:ProjectsController
   * @description
   * This method is used to open export report popup. This function is used to get user access report.
   * @return {undefined} This method does not return.
   */
    $scope.userAccessReport = function () {
        $scope.exportPass = "";
        $scope.passValidation = false;
        $('#passwordForUserReport').modal({ backdrop: 'static', keyboard: false });
        $('#passwordForUserReport').modal('show');
    };

    $("#showHide").click(function () {
        if ($(".exp-password").attr("type") == "password") {
            $(".exp-password").attr("type", "text");

        } else {
            $(".exp-password").attr("type", "password");
        }
    });

 /**
 * @ngdoc
 * @name exportUserAccessReport
 * @methodOf Projects.controller:ProjectsController
 * @description
 * This method is used to export the access report.
 * @return {undefined} This method does not return.
 */
    $scope.exportUserAccessReport = function () {
        if ($scope.exportPass !=="") {
            var exportReportInputs = {};
            exportReportInputs.ProjectId = currentProjectId;
            exportReportInputs.UserId = currentUserId
            exportReportInputs.Password = $scope.exportPass;
            LandingPageData.accessUserReport(exportReportInputs, function (status) {
                $('#passwordForUserReport').modal('hide');
            });

        } else {
            $scope.passValidation = true;
        }
       
    }

     /**
    * @ngdoc
    * @name limitAccess
    * @methodOf Projects.controller:ProjectsController
    * @description
    * This method is used to limit access of admin users to the current project.This method opens opup and give backend call to get list of all admins
    * @return {undefined} This method does not return.
    */
    $scope.limitAccess = function () {
        $scope.searchInAllUserList = "";
        $scope.searchInSelectedUserList = "";
        var OwnersAndCreatorsList = {};
        OwnersAndCreatorsList.ProjectId = currentProjectId;
        OwnersAndCreatorsList.ProjectCreatorId = $scope.Project.LandingProjectModel.CreatedById
        var ownerEmailList= [] ;
        for (var i = 0; i < $scope.Project.LandingProjectModel.Owners.length; i++) {
            ownerEmailList.push($scope.Project.LandingProjectModel.Owners[i].OwnerMailId);
        }

        OwnersAndCreatorsList.OwnerEmailId = ownerEmailList;
        LandingPageData.getLimitAccessAllAdmin(OwnersAndCreatorsList, function (AdminUsersData) {
            $scope.unAssignedAdmins = AdminUsersData.LimitAccessUnAssignedUsers;
            $scope.alreadyAssignedAdmins = AdminUsersData.LimitAccessAssignedUsers;
            $('#limitAccessPopup').modal({ backdrop: 'static', keyboard: false });
            $('#limitAccessPopup').modal('show');
        });
    }

     /**
    * @ngdoc
    * @name moveUsersToRight
    * @methodOf Projects.controller:ProjectsController
    * @param {object} selectedAdmins This is selected admin user
    * @description
    * This method is used to move admin user from left to right select box
    * @return {undefined} This method does not return.
    */
    $scope.moveUsersToRight = function (selectedAdmins) {
        for (var i = 0; i < selectedAdmins.length; i++) {
            for (var j = 0 ; j < $scope.unAssignedAdmins.length; j++) {
                if (selectedAdmins[i].UserId === $scope.unAssignedAdmins[j].UserId) {
                    $scope.unAssignedAdmins.splice(j, 1);
                }
            }
            $scope.alreadyAssignedAdmins.push(selectedAdmins[i]);
        }
    }

     /**
    * @ngdoc
    * @name moveUsersToLeft
    * @methodOf Projects.controller:ProjectsController
    * @param {object} deselectedAdmins This is selected admin user to remove
    * @description
    * This method is used to move admin user from right to left select box
    * @return {undefined} This method does not return.
    */
    $scope.moveUsersToLeft = function (deselectedAdmins) {
       // $scope.alreadyAssignedAdmins = selectedAdmins;
        for (var i = 0; i < deselectedAdmins.length; i++) {
            for (var j = 0 ; j < $scope.alreadyAssignedAdmins.length; j++) {
                if (deselectedAdmins[i].UserId === $scope.alreadyAssignedAdmins[j].UserId) {
                    $scope.alreadyAssignedAdmins.splice(j, 1);
                }
            }
            $scope.unAssignedAdmins.push(deselectedAdmins[i]);
        }
        
    }

     /**
    * @ngdoc
    * @name limitAccesForSelectedAdmins
    * @methodOf Projects.controller:ProjectsController
    * @description
    * This method is used to limit access of admin users to the current project.This method is called on click of save button on limit access popup
    * @return {undefined} This method does not return.
    */
    $scope.limitAccesForSelectedAdmins = function () {
        var assignedAdminList = {};
        assignedAdminList.ProjectId = currentProjectId;
        assignedAdminList.UserId = currentUserId;
        if ($scope.adminUser) {
            assignedAdminList.OriginalUserId= $scope.adminUser.UserId;
        } else {
            assignedAdminList.OriginalUserId= null;
        }
        assignedAdminList.LimitAccessAssignedUsers = $scope.alreadyAssignedAdmins;

        LandingPageData.saveLimitAccessAdminUsers(assignedAdminList, function (data) {
            $('#limitAccessPopup').modal('hide');
        });
    }

     /**
     * @ngdoc
     * @name UploadAttachments
     * @methodOf Projects.controller:ProjectsController
     * @description
     *This method is used to upload excel file in Netflix KNP wizard.
     *@return {undefined} This method does not return.
     */
    $scope.UploadAttachments = function () {
        if (attachedFiles && attachedFiles.length !== 0) {
            //making all selected array blank before selection
            $scope.additionalInfoCols.length = 0;
            $scope.sectionCols.length = 0;
            $scope.sourceTermCols.length = 0;
            $scope.languageCols.length = 0;

            $scope.addinfoLabel = "Select catagories column(s)";
            $scope.sectionLabel = "Select Section column";
            $scope.sourcetermLabel = "Select Source Term column";
            $scope.langLabel = "Select Language column(s)";

            //making aaray of object for directive used for dropdown, Adding array in that object
            if ($scope.fileAllColumnList && $scope.fileAllColumnList.length > 0) {
                $scope.fileAllColumnList = [];
            }
            if ($scope.fileAllLanguageList && $scope.fileAllLanguageList.length > 0) {
                $scope.fileAllLanguageList = [];
            }

            //all validation variables to false
            $scope.isSectionValid = false;
            $scope.isSourceTermValid = false;
            $scope.isLangValid = false;

            var uploadFile = {};
            uploadFile['ProjectId'] = currentProjectId;
            uploadFile['Files'] = attachedFiles;
            uploadFile['UserId'] = currentUserId;
            $scope.showLoader = true;
            LandingPageData.uploadScriptDB(uploadFile, function (data) {
                $scope.uploadFileWizard = false;
                $scope.columnMapping = true;
                $scope.showLoader = false;
                //making aaray of object for directive used for dropdown, Adding array in that object
                $scope.fileAllColumnList = [];
                $scope.fileAllLanguageList = [];
                console.log("data--", data);
                if (data.FileAllColumnList) {
                    for (var i = 0; i < data.FileAllColumnList.length; i++) {
                        var obj = { };
                            obj.addInfoColumnNames = data.FileAllColumnList[i];
                            obj.sectionColumnName = data.FileAllColumnList[i];
                            obj.sourceTermColumnName = data.FileAllColumnList[i];
                            obj.languageColumnNames = data.FileAllColumnList[i];
                        $scope.fileAllColumnList.push(obj);
                    }
                }

                if (data.NetflixKNPLanguageList) {
                    for (var i = 0; i < data.NetflixKNPLanguageList.length; i++) {
                       
                        var obj = { };
                            obj.addInfoColumnNames = data.NetflixKNPLanguageList[i];
                            obj.sectionColumnName = data.NetflixKNPLanguageList[i];
                            obj.sourceTermColumnName = data.NetflixKNPLanguageList[i];
                            obj.languageColumnNames = data.NetflixKNPLanguageList[i];
                        $scope.fileAllLanguageList.push(obj);
                    }
                }
                if (data.DisplayMessage) {
                    if (data.DisplayMessage.includes("column conatains the blank cell") ) {
                        $('#importError1').modal({ backdrop: 'static', keyboard: false });
                        $('#importError1 .modal-body').html(data.DisplayMessage);
                        $('#importError1 .modal-title').html('Empty Column Data Warning');
                        $('#importError1').modal('show');
                    } else if (data.DisplayMessage.includes('Please upload document with single sheet') || data.DisplayMessage.includes("contains duplicate column name") || data.DisplayMessage.includes('Uploaded document is empty') || data.DisplayMessage.includes('File is invalid')) {
                        $('#importError2').modal({ backdrop: 'static', keyboard: false });
                        $('#importError2 .modal-body').html(data.DisplayMessage);
                        $('#importError2 .modal-title').html('File Data Error');
                        $('#importError2').modal('show');
                    } else if (data.DisplayMessage.includes('Name') || data.DisplayMessage.includes('Type')) {
                        $('#importError3').modal({ backdrop: 'static', keyboard: false });
                        $('#importError3 .modal-body').html(data.DisplayMessage);
                        $('#importError3 .modal-title').html('Column Data Error');
                        $('#importError3').modal('show');
                    }
                    else if (data.DisplayMessage.includes('Frequency and Source Term')) {
                        $('#importError').modal({ backdrop: 'static', keyboard: false });
                        $('#importError .modal-body').html(data.DisplayMessage);
                        $('#importError .modal-title').html('Column Data Error');
                        $('#importError').modal('show');
                    } 
                } else {
                    $('#importError3').modal({ backdrop: 'static', keyboard: false });
                    $('#importError3 .modal-body').html('Something went wrong !! please try again later');
                    $('#importError3 .modal-title').html('Server Error');
                    $('#importError3').modal('show');
                }
               

            });
        }
        else {
            $('#importError .modal-body').html('File not selected for upload !');
            $('#importError .modal-title').html('File not selected');
            $('#importError').modal('show');
        }
    };

    
     /**
     * @ngdoc
     * @name resetButtonLabels
     * @methodOf Projects.controller:ProjectsController
     * @param {string} prop The name of dropdowns whose value needs to be change is passed as parameter.
     * @description
     *This method is used to reset dropdown button labels of Netflix knp wizard .
     *@return {undefined} This method does not return.
     */
    $scope.resetButtonLabels = function (prop) {
        if (!$scope.additionalInfoCols || $scope.additionalInfoCols.length === 0) {
            $scope.addinfoLabel = "Select catagories column(s)";
        }
        
        if (!$scope.sectionCols || $scope.sectionCols.length === 0) {
            $scope.sectionLabel = "Select Section column";
            if (prop === "sectionColumnName") {
                $scope.isSectionValid = true;
            }
        } else {
            if (prop === "sectionColumnName") {
                $scope.isSectionValid = false;
            }
        }

        if (!$scope.sourceTermCols || $scope.sourceTermCols.length === 0) {
            $scope.sourcetermLabel = "Select Source Term column";
            if (prop === "sourceTermColumnName") {
                $scope.isSourceTermValid = true;
            }
        } else {
            if (prop === "sourceTermColumnName") {
                $scope.isSourceTermValid = false;
            }
        }

        if (!$scope.languageCols || $scope.languageCols.length === 0) {
            $scope.langLabel = "Select Language column(s)";
            if (prop === "languageColumnNames") {
                $scope.isLangValid = true;
            }
        }else{
            if (prop === "languageColumnNames") {
                $scope.isLangValid = false;
            }
        }

    }

   /**
     * @ngdoc
     * @name isValidForPreview
     * @methodOf Projects.controller:ProjectsController
     * @description
     *This method is used for validation before preview is prepared.
     *@return {undefined} This method does not return.
     */
    
    var isValidForPreview = function () {
        var allValid = true;
        if (!$scope.sectionCols || $scope.sectionCols.length === 0) {
            $scope.isSectionValid = true;
            allValid = false
        }
        if (!$scope.sourceTermCols || $scope.sourceTermCols.length === 0) {
            $scope.isSourceTermValid = true;
            allValid = false
        }
        if (!$scope.languageCols || $scope.languageCols.length === 0) {
            $scope.isLangValid = true;
            allValid = false
        }
        return allValid;

    };

     /**
     * @ngdoc
     * @name isAlreadySelected
     * @methodOf Projects.controller:ProjectsController
     * @param {string} prop The name of dropdowns whose value needs to be change is passed as parameter.
     * @param {object} item The Object of selected option from dropdown.
     * @description
     *This method is used to check if selected option from drop down is already selected in any other drop down.
     *@return {boolean} This method return true / false. If selected option from dropdown is already selected then true else false.
     */
    $scope.isAlreadySelected = function(item,prop){
        var isFound = false;
        $scope.dropdownName = "";
        $scope.chosenOption = item.addInfoColumnNames;
        //check if selected option is already selected from other two drop downs

        switch (prop) {
            case "addInfoColumnNames":
                //checking in  sections column dropdown
                for (var i = 0; i < $scope.sectionCols.length; i++) {
                    if (angular.equals($scope.sectionCols[i], item)) {
                        isFound = true;
                        $scope.dropdownName = "Sections";
                        break;
                    }
                }
               
                //checking in  source term column dropdown
                for (var i = 0; i < $scope.sourceTermCols.length; i++) {
                    if (angular.equals($scope.sourceTermCols[i], item)) {
                        isFound = true;
                        $scope.dropdownName = "Source Term";
                        break;
                    }
                }

                //checking in language column dropdown
                for (var i = 0; i < $scope.languageCols.length; i++) {
                    if (angular.equals($scope.languageCols[i], item)) {
                        isFound = true;
                        $scope.dropdownName = "Language";
                        break;
                    }
                }

                break;
            case "sectionColumnName":
                //checking in  addinfo column dropdown
                for (var i = 0; i < $scope.additionalInfoCols.length; i++) {
                    if (angular.equals($scope.additionalInfoCols[i], item)) {
                        isFound = true;
                        $scope.dropdownName = "Additional Info Options";
                        break;
                    }
                }

                //checking in  source term column dropdown
                for (var i = 0; i < $scope.sourceTermCols.length; i++) {
                    if (angular.equals($scope.sourceTermCols[i], item)) {
                        isFound = true;
                        $scope.dropdownName = "Source Term";
                        break;
                    }
                }

                //checking in language column dropdown
                for (var i = 0; i < $scope.languageCols.length; i++) {
                    if (angular.equals($scope.languageCols[i], item)) {
                        isFound = true;
                        $scope.dropdownName = "Language";
                        break;
                    }
                }
                break;

            case "sourceTermColumnName":
                //checking in  addinfo column dropdown
                for (var i = 0; i < $scope.additionalInfoCols.length; i++) {
                    if (angular.equals($scope.additionalInfoCols[i], item)) {
                        isFound = true;
                        $scope.dropdownName = "Additional Info Options";
                        break;
                    }
                }

                //checking in  section  column dropdown
                for (var i = 0; i < $scope.sectionCols.length; i++) {
                    if (angular.equals($scope.sectionCols[i], item)) {
                        isFound = true;
                        $scope.dropdownName = "Sections";
                        break;
                    }
                }

                //checking in language column dropdown
                for (var i = 0; i < $scope.languageCols.length; i++) {
                    if (angular.equals($scope.languageCols[i], item)) {
                        isFound = true;
                        $scope.dropdownName = "Language";
                        break;
                    }
                }
                break;

            case "languageColumnNames":
                //checking in  addinfo column dropdown
                for (var i = 0; i < $scope.additionalInfoCols.length; i++) {
                    if (angular.equals($scope.additionalInfoCols[i], item)) {
                        isFound = true;
                        $scope.dropdownName = "Additional Info Options";
                        break;
                    }
                }

                //checking in  section  column dropdown
                for (var i = 0; i < $scope.sectionCols.length; i++) {
                    if (angular.equals($scope.sectionCols[i], item)) {
                        isFound = true;
                        $scope.dropdownName = "Sections";
                        break;
                    }
                }

                //checking in  source term column dropdown
                for (var i = 0; i < $scope.sourceTermCols.length; i++) {
                    if (angular.equals($scope.sourceTermCols[i], item)) {
                        isFound = true;
                        $scope.dropdownName = "Source Term";
                        break;
                    }
                }
                break;
            default:
        }
        
        if (isFound) {
            $('#duplicateOptionSelected').modal({ backdrop: 'static', keyboard: false });
            $('#duplicateOptionSelected .modal-title').html('Option Already Selected');
            $('#duplicateOptionSelected').modal('show');
            return false;
        }

    };

     /**
     * @ngdoc
     * @name selectAllClicked
     * @methodOf Projects.controller:ProjectsController
     * @param {string} prop The name of dropdowns whose value needs to be change is passed as parameter.
     * @param {object} item The Object of selected option from dropdown.
     * @description
     * This function is called if user checks select all option from additional info column dropdown,
     * It checks if selected option is already checked(ticked) in other dropdowns. If yes, then it will skip those options and those will not be ticked.
     *@return {array} This method returns array of objects with only those options which are not already ticked in other dropdowns
     */
    $scope.selectAllClicked = function (items,prop) {
        //create new array to remove refrences of items from directive
        var newItems = [];
        angular.copy(items, newItems);
        var selectedColumns = "";
        //checking in  source term column dropdown
        for (var i = 0; i < $scope.sourceTermCols.length; i++) {
            for (var j = 0; j < newItems.length; j++) {
                if (angular.equals($scope.sourceTermCols[i], newItems[j])) {
                    if (selectedColumns .length !==0 ) {
                        selectedColumns += ",";
                        selectedColumns += newItems[j].addInfoColumnNames;
                    } else {
                        selectedColumns = newItems[j].addInfoColumnNames;
                    }
                    newItems.splice(j, 1);
                }
            }
        }

        //checking in  section column dropdown
        for (var i = 0; i < $scope.sectionCols.length; i++) {
            for (var j = 0; j < newItems.length; j++) {
                if (angular.equals($scope.sectionCols[i], newItems[j])) {
                    if (selectedColumns.length !== 0) {
                        selectedColumns += ",";
                        selectedColumns += newItems[j].addInfoColumnNames;
                    } else {
                        selectedColumns = newItems[j].addInfoColumnNames;
                    }

                    newItems.splice(j, 1)
                }
            }
        }

        if (prop === "addInfoColumnNames") {
            //checking for language column dropdown
            for (var i = 0; i < $scope.languageCols.length; i++) {
                for (var j = 0; j < newItems.length; j++) {
                    if (angular.equals($scope.languageCols[i], newItems[j])) {
                        if (selectedColumns.length !== 0) {
                            selectedColumns += ",";
                            selectedColumns += newItems[j].addInfoColumnNames;
                        } else {
                            selectedColumns = newItems[j].addInfoColumnNames;
                        }
                        newItems.splice(j, 1)
                    }
                }
            }
            if (selectedColumns.length !== 0) {
                $('#importError').modal({ backdrop: 'static', keyboard: false });
                if (selectedColumns.split(",").length > 4) {
                    $('#importError .modal-body').html('Some of the columns are not selected because they are already selected in other dropdowns!');
                } else {
                    $('#importError .modal-body').html("<b>" + selectedColumns + "</b>" + ' these columns are not selected because they are already selected in other dropdowns!');
                }
                $('#importError .modal-title').html('Column selection warning !!!');
                $('#importError').modal('show');
            }
        } else if (prop === "languageColumnNames") {
            //checking for addinfo column dropdown
            for (var i = 0; i < $scope.additionalInfoCols.length; i++) {
                for (var j = 0; j < newItems.length; j++) {
                    if (angular.equals($scope.additionalInfoCols[i], newItems[j])) {
                        if (selectedColumns.length !== 0) {
                            selectedColumns += ",";
                            selectedColumns += newItems[j].addInfoColumnNames;
                        } else {
                            selectedColumns = newItems[j].addInfoColumnNames;
                        }
                        newItems.splice(j, 1)
                    }
                }
            }
            if (selectedColumns.length !== 0) {
                $('#importError').modal({ backdrop: 'static', keyboard: false });
                if (selectedColumns.split(",").length > 4 ) {
                    $('#importError .modal-body').html('Some of the columns are not selected because they are already selected in other dropdowns!');
                } else {
                    $('#importError .modal-body').html("<b>" + selectedColumns + "</b>" + ' these columns are not selected because they are already selected in other dropdowns!');
                }
                $('#importError .modal-title').html('Column selection warning !!!');
                $('#importError').modal('show');
            }
        }
       
                return newItems;
    };

     /**
     * @ngdoc
     * @name preeview
     * @methodOf Projects.controller:ProjectsController
     * @description
     * This function is to show preview of column mapping in import knp wizard
     *@return {undefined} This method doed not return.
     */
    $scope.preeview = function () { 
        if (isValidForPreview()) {
            //empty all arrays whenever preview is pressed
            addInfoColumns = [];
            sectionColumns = [];
            sourcetermColumns = [];
            langColumns = [];

            //for addinfo columns
            for (var i = 0; i < $scope.additionalInfoCols.length; i++) {
                addInfoColumns.push($scope.additionalInfoCols[i].addInfoColumnNames);
            }

            //for section columns
            sectionColumns = $scope.sectionCols[0].sectionColumnName;

            //for source term columns
            sourcetermColumns = $scope.sourceTermCols[0].sourceTermColumnName;

            //for language columns
            for (var i = 0; i < $scope.languageCols.length; i++) {
                langColumns.push($scope.languageCols[i].languageColumnNames);
            }

            columnMppingObj.NetflixAdditionalInfoColumnList = addInfoColumns;
            columnMppingObj.NetflixSectionColumnsName = sectionColumns;
            columnMppingObj.NetflixSourceTermColumnName = sourcetermColumns;
            columnMppingObj.NetflixKNPLanguageList = langColumns;
            columnMppingObj.FileName = fileName;
            columnMppingObj.ProjectId = currentProjectId;
            columnMppingObj.UserId = currentUserId;
            columnMppingObj.Accepted = isAccepted;
            $scope.showLoader = true;
            LandingPageData.importNetflixDataCommit(columnMppingObj, function (data) {
                $scope.showLoader = false;
                if (data.ErrorMessage !== undefined) {
                    if (data.ErrorMessage === "Invalid column mapping, Please check the column mapping.") {
                        $('#importError').modal({ backdrop: 'static', keyboard: false });
                        $('#importError .modal-body').html(data.ErrorMessage);
                        $('#importError .modal-title').html('Invalid column mapping');
                        $('#importError').modal('show');
                    } else if (data.ErrorMessage.includes('language notes')) {
                        $('#importError3').modal({ backdrop: 'static', keyboard: false });
                        $('#importError3 .modal-body').html(data.ErrorMessage);
                        $('#importError3 .modal-title').html('Language notes column missing');
                        $('#importError3').modal('show');
                    } else {
                        if (data.ErrorMessage.includes('Duplicate terms')) {
                            $('#importError').modal({ backdrop: 'static', keyboard: false });
                            $('#importError .modal-body').html(data.ErrorMessage);
                            $('#importError .modal-title').html('Column Data Warning');
                            $('#importError').modal('show');
                        }
                        $scope.previewData = data;
                        $scope.columnMapping = false;
                        $scope.sourcePreview = true;
                    }
                } else {
                    $('#importError3').modal({ backdrop: 'static', keyboard: false });
                    $('#importError3 .modal-body').html('Something went wrong !! please try again later');
                    $('#importError3 .modal-title').html('Server Error');
                    $('#importError3').modal('show');
                }
               
            });
        }
    };

    $scope.isAcceptedFunc = function () {
        isAccepted = true;
        $('#importError1').modal('hide');
    };

     /**
     * @ngdoc
     * @name commitScript
     * @methodOf Projects.controller:ProjectsController
     * @description
     * This function is called on final submit button on import knp wizard on preview page.
     *@return {undefined} This method doed not return.
     */
    $scope.commitScript = function () {
        columnMppingObj.index = index;
        if ($scope.adminUser) {
            columnMppingObj['OriginalUserId'] = $scope.adminUser.UserId;
        } else {
            columnMppingObj['OriginalUserId'] = null;
        }

        $scope.uploadFileWizard = false;
        $scope.columnMapping = false;
        $scope.sourcePreview = false;
        $scope.showLoader = true;
        LandingPageData.importNetflixKNPFileDataCommit(columnMppingObj, function (data) {
            console.log("data---", data);
            $scope.showLoader = false;
            $('#importError').modal({ backdrop: 'static', keyboard: false });
            $('#importError .modal-body').html(data.ErrorMessage);
            $('#importError .modal-title').html('File Upload Complete');
            $('#importError').modal('show');
            $scope.importSuccess = true;
            sessionStorage.setItem('unEncriptedProjectId',null);
        });
    };

    $scope.FinalCommit = function () {
        isAccepted = true;
        $scope.commitScript();
    };

  /**
     * @ngdoc
     * @name getBackToHomepage
     * @methodOf Projects.controller:ProjectsController
     * @description
     * This function is called on cancel of import knp file upload wizard.
     *@return {undefined} This method doed not return.
     */
    $scope.getBackToHomepage = function () {
        $('#importError').modal('hide');
        $('.modal-backdrop').css({ 'display': 'none' });
        $location.path('/');
    };
  
    /**
     * @ngdoc
     * @name backFromPreview
     * @methodOf Projects.controller:ProjectsController
     * @description
     * This function is called on back button on preview page of import knp file upload wizard.
     *@return {undefined} This method doed not return.
     */
    $scope.backFromPreview = function () {
        $scope.uploadFileWizard = false;
        $scope.columnMapping = true;
        $scope.sourcePreview = false;
    };
    
    /**
     * @ngdoc
     * @name getBacktoFileUpload
     * @methodOf Projects.controller:ProjectsController
     * @description
     * This function is called on back button on column mapping page of import knp file upload wizard.
     *@return {undefined} This method doed not return.
     */
    $scope.getBacktoFileUpload = function(){
    deleteFile('1');
            $scope.uploadFileWizard = true;
            $scope.columnMapping = false;
            $scope.sourcePreview = false;
            $('#importError1').modal('hide');
            $('#importError2').modal('hide');
            $('#importError3').modal('hide');
            $scope.showLoader = false;
    };

      /**
     * @ngdoc
     * @name cancelScriptUpload
     * @methodOf Projects.controller:ProjectsController
     * @description
     * This function is called on cancel button on file upload page of import knp file upload wizard.
     *@return {undefined} This method doed not return.
     */
    $scope.cancelScriptUpload = function () {
        var uploadFile = {};
        uploadFile['ProjectId'] = currentProjectId;
        uploadFile['Files'] = attachedFiles;
        uploadFile['UserId'] = currentUserId;
        LandingPageData.deleteExistingFileOnServer(uploadFile, function (data) {
            deleteFile('1');
            $scope.uploadFileWizard = true;
            $scope.columnMapping = false;
            $scope.sourcePreview = false;
            $('#importError1').modal('hide');
            $('#importError2').modal('hide');
            $scope.showLoader = false;
        });
    };

      /**
     * @ngdoc
     * @name deleteFile
     * @methodOf Projects.controller:ProjectsController
     * @description
     * This function is called on delete button on file upload page of import knp file upload wizard.
     *@return {undefined} This method doed not return.
     */
    deleteFile = function (fileId) {
        for (i = 0; i < attachedFiles.length; i++) {
            if (attachedFiles[i].filename === $scope['attachedFile' + fileId]) {
                $scope.index = i;
                break;
            }
        }
        attachedFiles.splice($scope.index, 1);
        $scope['attachedFile' + fileId] = '';
        $('#' + fileId).html($scope['attachedFile' + fileId]);

    };

    $scope.$on('addedFileDetails', function (event, myData, fileid) {
        fileName = myData[0].filename;
        var index = myData[0].filename.lastIndexOf(".");
        var validateFilename = myData[0].filename.substring(index, myData[0].filename.length);
        if (validateFilename === '.xlsx') {
            $scope['attachedFile' + fileid] = myData[0].filename;
            $('#' + fileid).html($scope['attachedFile' + fileid]).css('color', '#333');
            attachedFiles.push(myData[0]);
        
            } else if (validateFilename === '.xls') {
                $('#importError .modal-body').html('Please upload file with .xlsx extension only. To do so, re-save the .xls file in MS Excel as xlsx!');
                $('#importError .modal-title').html('File Type error');
                $('#importError').modal('show');
                attachedFiles.length = 0;
            } 
        else {
            $('#importError .modal-body').html('This file is incorrect. Please upload excel files only!');
            $('#importError .modal-title').html('File Type error');
            $('#importError').modal('show');
            attachedFiles.length = 0;
        }

    });

     /**
     * @ngdoc
     * @name changeView
     * @methodOf Projects.controller:ProjectsController
     * @param {string} new_path The Name of the view bound with element on which this fuction is called.

     * @description
     * This function is called to change views and loads respective html page.Below are some views
     * Glossary, Source Setup, Add project, Edit Project,Project Permissions,Project Info
     * @returns {undefined} This method does not return.
     */
    $scope.changeView = function (new_path) {
        switch (new_path) {
            case "glossary":
                if ($scope.Project.IsAllSectionInActive === true) {
                    $('#noGlossaryData').modal().show();
                    break;
                } else {
                    $location.path('/glossary');
                }
                break;

            case "sourceSetup":
                sessionStorage.setItem('ActiveSectionType', "1");
                sessionStorage.setItem('SourceSetupActiveSection', '');
                sessionStorage.setItem('isShowRemovedTermsFlag', '0');
                sessionStorage.setItem('hideInfoColumns', '0');
                sessionStorage.setItem('hideTermUniqueID', '0');
                sessionStorage.setItem('hideStarred', '0');
                sessionStorage.setItem('ishideStarred', '0');
                $location.path('/sourceSetup');
                break;

            case "addTranslation":
                $location.path('/addTranslation');
                break;

            case "editProject":
                $location.path('/editProject');
                break;

            case "addProject":
                $location.path('/addProject');
                break;

            case "projectPermissions":
                $location.path('/projectPermissions');
                break;

            case "approveGlossary":
                $location.path('/approveGlossary');
                break;

            case "projectInfo":
                $location.path('/projectInfo');
                break;
            
            case "netflixImport":
                $location.path('/netflixImport');
                break;


        }
    };

    $(".searchProject").keyup(function (e) {
        if (e.keyCode === 13) {
            $scope.textFilterSearch();
        }
    });

    $scope.refreshHomePage = function () {
        location.reload();
    };

     /**
     * @ngdoc
     * @name ownerFilter
     * @methodOf Projects.controller:ProjectsController
     * @description
     * This function is called on change of project owner filter((My Projects/All Projects).Project list changes accordingly.
     *@return {undefined} This method doed not return.
     */
    $scope.ownerFilter = function () {
        $scope.ProjectStatus = "2";
        $scope.ClientName = null;
        $scope.BrandName = null;
        $scope.searchProject = null;
        $scope.showLoader = true;

        //values to pass for service
        UserId = currentUserId;
        ClientIdFilter = 0;
        BrandIdFilter = 0;
        UserRole = currentUserRoleName;
        InputTextFilter = null;
        ProjectStateFilterActive = '2';
        IsOwnerOfProjectFilter = JSON.parse($scope.isOwner);

        LandingPageData.carosalProjectListFilter(UserId, ClientIdFilter, BrandIdFilter, UserRole, InputTextFilter, ProjectStateFilterActive, IsOwnerOfProjectFilter, function (CorousalInfo) {
            CorousalData = CorousalInfo.ProjectListForCarosal;
            $scope.showLoader = false;
            var count = CorousalData.length;
            $scope.mainArray = [];
            var j = 4;
            var k = 0;
            if (count > 4) {
                for (var i = 0; i < count; i = i + 4) {
                    $scope.mainArray.push(CorousalData.slice(i, j));
                    j = j + 4;
                }
            }
            else {
                $scope.mainArray.push(CorousalData.slice(0, count));
            }

            if (count === 0) {
                $('.project-list').hide();
                $('.recent-projects').hide();
                $('.no-project').show();
                $('.no-project').html('There is no Project available.');
                $scope.projectListVertical = false;
                dynamicScreenHeight();
            }
            else {
                if ($scope.projectListVertical === true) {
                    $('.no-project').hide();
                    ProjectLangList(CorousalData);
                    $scope.corousalarray = CorousalData;
                    corousalarrayIndex = $scope.corousalarray.length;
                    if (!$scope.$$phase) {
                        $scope.$apply();
                    }
                } else {
                    $scope.carouselImageClick(CorousalData[0].ProjectEncriptValue, CorousalData[0].ProjectId);
                    ProjectLangList(CorousalData);
                    $scope.corousalarray = CorousalData;
                    corousalarrayIndex = $scope.corousalarray.length;
                    if (!$scope.$$phase) {
                        $scope.$apply();
                    }
                    $('.project-list').show();
                    $('.recent-projects').show();
                    $('.no-project').hide();
                }
            }
        });
    };
    
    /**
     * @ngdoc
     * @name projectActiveFilter
     * @methodOf Projects.controller:ProjectsController
     * @description
     * This function is called on change of project status(Active/Inactive/All) filter.Project list changes accordingly.
     *@return {undefined} This method doed not return.
     */
    $scope.projectActiveFilter = function () {
        $scope.ClientName = null;
        $scope.BrandName = null;
        $scope.searchProject = null;
        $scope.brandList = [];
        $scope.showLoader = true;

        //values to pass for service
        UserId = currentUserId;
        ClientIdFilter = 0;
        BrandIdFilter = 0;
        UserRole = currentUserRoleName;
        InputTextFilter = null;
        ProjectStateFilterActive = $scope.ProjectStatus;
        IsOwnerOfProjectFilter = JSON.parse($scope.isOwner);

        LandingPageData.carosalProjectListFilter(UserId, ClientIdFilter, BrandIdFilter, UserRole, InputTextFilter, ProjectStateFilterActive, IsOwnerOfProjectFilter, function (CorousalInfo) {
            $scope.ClientList = CorousalInfo.Clients;
            $scope.brandList = CorousalInfo.BrandList;
            CorousalData = CorousalInfo.ProjectListForCarosal;
            $scope.showLoader = false;
            var count = CorousalData.length;
            $scope.mainArray = [];
            var j = 4;
            var k = 0;
            if (count > 4) {
                for (var i = 0; i < count; i = i + 4) {
                    $scope.mainArray.push(CorousalData.slice(i, j));
                    j = j + 4;
                }
            }
            else {
                $scope.mainArray.push(CorousalData.slice(0, count));
            }

            if (count == 0) {
                $('.project-list').hide();
                $('.recent-projects').hide();
                $('.no-project').show();
                $('.no-project').html('There is no Project available.');
                $scope.projectListVertical = false;
                dynamicScreenHeight();
            }
            else {
                if ($scope.projectListVertical === true) {
                    $('.no-project').hide();
                    ProjectLangList(CorousalData);
                    $scope.corousalarray = CorousalData;
                    corousalarrayIndex = $scope.corousalarray.length;
                    if (!$scope.$$phase) {
                        $scope.$apply();
                    }
                } else {
                    $scope.carouselImageClick(CorousalData[0].ProjectEncriptValue, CorousalData[0].ProjectId);
                    ProjectLangList(CorousalData);
                    $scope.corousalarray = CorousalData;
                    corousalarrayIndex = $scope.corousalarray.length;
                    if (!$scope.$$phase) {
                        $scope.$apply();
                    }
                    $('.project-list').show();
                    $('.recent-projects').show();
                    $('.no-project').hide();
                }
            }
        });
    };

    /**
     * @ngdoc
     * @name clientFilter
     * @methodOf Projects.controller:ProjectsController
     * @description
     * This function is called on change of project client filter.Project list changes accordingly.
     *@return {undefined} This method doed not return.
     */
    $scope.clientFilter = function (Client) {
        $scope.BrandName = null;
        $scope.brandList = [];
        $scope.showLoader = true;

        //values to pass for service
        UserId = currentUserId;
        ClientIdFilter = parseInt(Client);
        BrandIdFilter = 0;
        UserRole = currentUserRoleName;
        InputTextFilter = null;
        ProjectStateFilterActive = $scope.ProjectStatus;
        IsOwnerOfProjectFilter = JSON.parse($scope.isOwner);

        LandingPageData.carosalProjectListFilter(UserId, ClientIdFilter, BrandIdFilter, UserRole, InputTextFilter, ProjectStateFilterActive, IsOwnerOfProjectFilter, function (CorousalInfo) {
            $scope.showLoader = false;
            if (CorousalInfo.ProjectListForCarosal.length < 1) {
                $scope.Project = null;
                $scope.owner_str = null;
                $scope.client_str = null;
                $scope.showProjectImage = false;
                $('.project-list').hide();
                $('.slider').hide();
                $('.recent-projects').hide();
                $('.no-project').show();
                $('.no-project').html('No results found');
                $scope.projectListVertical = false;
                dynamicScreenHeight();
            } else {
                $('.slider').show();
                $('.recent-projects').show();
                $('.project-list').show();
                $scope.brandList = CorousalInfo.BrandList;
                CorousalData = CorousalInfo.ProjectListForCarosal;
                var count = CorousalData.length;
                $scope.mainArray = [];
                var j = 4;
                var k = 0;
                if (count > 4) {
                    for (var i = 0; i < count; i = i + 4) {
                        $scope.mainArray.push(CorousalData.slice(i, j));
                        j = j + 4;
                    }

                }
                else {
                    $scope.mainArray.push(CorousalData.slice(0, count));
                }

                if ($scope.projectListVertical === true) {
                    $('.no-project').hide();
                    ProjectLangList(CorousalData);
                    $scope.corousalarray = CorousalData;
                    corousalarrayIndex = $scope.corousalarray.length;
                    if (!$scope.$$phase) {
                        $scope.$apply();
                    }
                } else {
                    $scope.carouselImageClick(CorousalData[0].ProjectEncriptValue, CorousalData[0].ProjectId);
                    ProjectLangList(CorousalData);
                    $scope.corousalarray = CorousalData;
                    corousalarrayIndex = $scope.corousalarray.length;
                    if (!$scope.$$phase) {
                        $scope.$apply();
                    }
                    $('.project-list').show();
                    $('.recent-projects').show();
                    $('.no-project').hide();
                }
            }
        });
    };

    /**
     * @ngdoc
     * @name brandFilter
     * @methodOf Projects.controller:ProjectsController
     * @description
     * This function is called on change of project client filter.Project list changes accordingly.
     *@return {undefined} This method doed not return.
     */
    $scope.brandFilter = function (Brand) {
        $scope.showLoader = true;

        if (Brand) {
            if (!$scope.searchProject) {
                $scope.searchProject = null;
            }

            //values to pass for service
            UserId = currentUserId;
            BrandIdFilter = parseInt(Brand);
            UserRole = currentUserRoleName;
            InputTextFilter = $scope.searchProject;
            ProjectStateFilterActive = $scope.ProjectStatus;
            IsOwnerOfProjectFilter = JSON.parse($scope.isOwner);

            LandingPageData.carosalProjectListFilter(UserId, ClientIdFilter, BrandIdFilter, UserRole, InputTextFilter, ProjectStateFilterActive, IsOwnerOfProjectFilter, function (CorousalInfo) {
                CorousalData = CorousalInfo.ProjectListForCarosal;
                $scope.showLoader = false;
                var count = CorousalData.length;
                $scope.mainArray = [];
                var j = 4;
                var k = 0;
                if (count > 4) {
                    for (var i = 0; i < count; i = i + 4) {
                        $scope.mainArray.push(CorousalData.slice(i, j));
                        j = j + 4;
                    }
                }
                else {
                    $scope.mainArray.push(CorousalData.slice(0, count));
                }

                if (count === 0) {
                    $('.project-list').hide();
                    $('.recent-projects').hide();
                    $('.no-project').show();
                    $('.no-project').html('There is no Project available.');
                    $scope.projectListVertical = false;
                    dynamicScreenHeight();
                } else {
                    if ($scope.projectListVertical === true) {
                        $('.no-project').hide();
                        ProjectLangList(CorousalData);
                        $scope.corousalarray = CorousalData;
                        corousalarrayIndex = $scope.corousalarray.length;
                        if (!$scope.$$phase) {
                            $scope.$apply();
                        }
                    } else {
                        $scope.carouselImageClick(CorousalData[0].ProjectEncriptValue, CorousalData[0].ProjectId);
                        ProjectLangList(CorousalData);
                        $scope.corousalarray = CorousalData;
                        corousalarrayIndex = $scope.corousalarray.length;
                        if (!$scope.$$phase) {
                            $scope.$apply();
                        }
                        $('.project-list').show();
                        $('.recent-projects').show();
                        $('.no-project').hide();
                    }
                }
                if (!CorousalData[0]) {
                    $scope.Project = null;
                    $scope.owner_str = null;
                    $scope.client_str = null;
                    $scope.showProjectImage = false;
                }
            });
        }
    };

      /**
     * @ngdoc
     * @name textFilterSearch
     * @methodOf Projects.controller:ProjectsController
     * @description
     * This function is used to search the project .Project list changes accordingly.
     *@return {undefined} This method doed not return.
     */
    $scope.textFilterSearch = function () {
        $scope.showLoader = true;

        //values to pass for service
        UserId = currentUserId;
        UserRole = currentUserRoleName;
        InputTextFilter = $scope.searchProject;
        ProjectStateFilterActive = $scope.ProjectStatus;
        IsOwnerOfProjectFilter = JSON.parse($scope.isOwner);

        LandingPageData.carosalProjectListFilter(UserId, ClientIdFilter, BrandIdFilter, UserRole, InputTextFilter, ProjectStateFilterActive, IsOwnerOfProjectFilter, function (CorousalInfo) {
            $scope.showLoader = false;
            CorousalData = CorousalInfo.ProjectListForCarosal;
            var count = CorousalData.length;
            $scope.mainArray = [];
            var j = 4;
            var k = 0;
            if (count === 0) {
                $('.project-list').hide();
                $('.recent-projects').hide();
                $('.no-project').show();
                $('.no-project').html('There is no Project available.');
                $scope.projectListVertical = false;
                dynamicScreenHeight();
                return false;
            }
            if (count > 4) {
                for (var i = 0; i < count; i = i + 4) {
                    $scope.mainArray.push(CorousalData.slice(i, j));
                    j = j + 4;
                }
            }
            else {
                $scope.mainArray.push(CorousalData.slice(0, count));
            }

            if (!CorousalData[0]) {
                $scope.Project = null;
                $scope.owner_str = null;
                $scope.client_str = null;
                $scope.showProjectImage = false;
            }
            else {
                if ($scope.projectListVertical === true) {
                    $('.no-project').hide();
                    ProjectLangList(CorousalData);
                    $scope.corousalarray = CorousalData;
                    corousalarrayIndex = $scope.corousalarray.length;
                    if (!$scope.$$phase) {
                        $scope.$apply();
                    }
                } else {
                    $scope.carouselImageClick(CorousalData[0].ProjectEncriptValue, CorousalData[0].ProjectId);
                    $('.project-list').show();
                    $('.recent-projects').show();
                    $('.no-project').hide();
                    ProjectLangList(CorousalData);
                    $scope.corousalarray = CorousalData;
                    corousalarrayIndex = $scope.corousalarray.length;
                    if (!$scope.$$phase) {
                        $scope.$apply();
                    }
                }
            }
        });
    };

    // function to get the keys out of JSON object
    $scope.getKeys = function (obj) {
        var keys = [], name;
        for (name in obj) {
            if (obj.hasOwnProperty(name)) {
                keys.push(name);
            }
        }
        // since first element is 'heading' we can remove it
        keys.splice(0, 1);
        return keys;
    };

    
      /**
     * @ngdoc
     * @name callAllGlossaryPage
     * @methodOf Projects.controller:ProjectsController
     * @param {object} projectDetails This is object which contains all the project details eg: project languages.
     * @param {string} status This is approval status of master glossaries(A(Approved)/P(Pending)/R(Rejected)). 
     * @description
     * This function is used to redirect to All glossary page of respective project.This functionality is available on Approval status column on project landing page.
     *@return {undefined} This method doed not return.
     */
    $scope.callAllGlossaryPage = function (projectDetails, status) {
        sessionStorage.setItem('navigateToAllGlossary', 'true');
        if (!$scope.excludeNTL_FD) {
            $scope.excludeNTL_FD = false;
        }
        sessionStorage.setItem('excludeNTL_FD', $scope.excludeNTL_FD);
        var languages = [];
        languages.push(projectDetails.ProjectLanguageId)
        sessionStorage.setItem('AllglossaryLangList', JSON.stringify(languages));
        sessionStorage.setItem('AllsectionProjectTitle', JSON.stringify($scope.Project.LandingProjectModel.ProjectTitle));
        sessionStorage.setItem('AllsectionSecureTitle', JSON.stringify($scope.Project.LandingProjectModel.SecureTitle));

        if (status === 'Approved') {
            sessionStorage.setItem("approvedFilter", "1");
        } else if (status === 'Rejected') {
            sessionStorage.setItem("rejectedFilter", "1");
        } else {
            sessionStorage.setItem("pendingApprovalsFilter", "1");
        }

        $scope.changeView("glossary");
    };

    
      /**
     * @ngdoc
     * @name init
     * @methodOf Projects.controller:ProjectsController
     * @description
     * This function is used for initialisation of variables to display on page load.
     *@return {undefined} This method doed not return.
     */
    var init = function () {
        var isRedirectedFromSearch = JSON.parse(sessionStorage.getItem('SearchToProjects'));
        var isNewproject = JSON.parse(sessionStorage.getItem('isNewProject')); 
        var sessionProjects = JSON.parse(sessionStorage.getItem('sessionProjects'));

        $('.no-project').hide();
        $('.container-header, .navbar-default, .glossary-header-wrapper, footer').show();
        $scope.showLoader = true;
        var resorceIdx = 0;
        sessionStorage.setItem('resourcePageId', JSON.stringify(resorceIdx));
        sessionStorage.setItem("filterStatus", "undefined");
        sessionStorage.setItem("filterImage", "undefined");
        sessionStorage.setItem("pendingTranslationsFilter", "0");
        sessionStorage.setItem("pendingApprovalsFilter", "0");
        sessionStorage.setItem("approvedFilter", "0");
        sessionStorage.setItem("rejectedFilter", "0");
        sessionStorage.setItem("filterOnStatus", "0");

        //client object to string
        $scope.owner_str = '';
        $scope.client_str = '';
        $scope.brand_str = '';

        if (!commonService.getLocalData('userDetails')) {
            commonService.deniedRedirect();
        } else {
            $scope.userDetails = commonService.getLocalData('userDetails');
        }

        //if import knp is clicked, skip backend call and set values which are set in seeion for $scope.project
        if (window.location.hash === "#/netflixImport") {
            $scope.Project = sessionProjects;
            currentProjectId = JSON.parse(sessionStorage.getItem('projectIBreadCrumb'));
            dynamicScreenHeight();
            $scope.showLoader = false;
            return;
        }


        var antiForgeryTokenTrimmed = $scope.antiForgeryToken.trim();
        //Calling Service to get the carousel data   
        LandingPageData.getCorousalData(currentUserId, 0, 0, currentUserRoleName, antiForgeryTokenTrimmed, function (corousalarray) {
            $scope.adminUser = commonService.getImpersonateSessionData('adminUser'); //impersonate feature
            $scope.corousalarray = corousalarray;
            corousalarrayIndex = $scope.corousalarray.length;

            if (corousalarray.length === 0) {
                $('.project-list').hide();
                $('.recent-projects').hide();
                $('.no-project').show();
                $('.no-project').html('There is no Project available.');
                $scope.projectListVertical = false;
                dynamicScreenHeight();
                $scope.showLoader = false;
            }
            else {
                CorousalData = corousalarray;
                var count = CorousalData.length;
                $scope.mainArray = [];
                var j = 4;
                var k = 0;
                if (count > 4) {
                    for (var i = 0; i < count; i = i + 4) {
                        $scope.mainArray.push(CorousalData.slice(i, j));
                        j = j + 4;
                    }

                }
                else {
                    $scope.mainArray.push(CorousalData.slice(0, count));
                }
                dynamicScreenHeight();
                rowFreeze();

                
                if (isRedirectedFromSearch) {
                    var projectid = JSON.parse(sessionStorage.getItem('projectId'));
                    var unencripted = sessionStorage.getItem('unEncriptedProjectId');
                    $scope.carouselImageClick(projectid, unencripted);
                    sessionStorage.setItem('SearchToProjects', false);
                    return;
                } else {
                    if (!sessionStorage.getItem('unEncriptedProjectId') || isNewproject === true) {
                        sessionStorage.setItem('isNewProject', false);
                        $scope.carouselImageClick(CorousalData[0].ProjectEncriptValue, CorousalData[0].ProjectId);
                    } else if (JSON.parse(sessionStorage.getItem('unEncriptedProjectId')) == null) {
                        $scope.showLoader = false;
                        return;
                    }else {
                        var projectid = JSON.parse(sessionStorage.getItem('projectId'));
                        var unencripted = sessionStorage.getItem('unEncriptedProjectId');
                        $scope.carouselImageClick(projectid, unencripted);
                        }
                }

                LandingPageData.getClientList(currentUserId, 0, 0, currentUserRoleName, function (clientlist) {
                    $scope.ClientList = clientlist;
                });

                if (corousalarray.length >= 5 && localStorage.getItem('HomeValue') === 'List') { //&& localStorage.getItem('HomeValue') === 'List' for GLMGR-656
                    $scope.projectListVertical = true;
                    $scope.projectListTitle = 'Display As Carousel';
                }
                else {
                    $scope.projectListVertical = false;
                    $scope.projectListTitle = 'Display As List';
                }
                localStorage.setItem('HomeValue', 'Carousel');

                var lang_count = 0;
                for (var j = 0; j < CorousalData.length; j++) {
                    lang_str = '';
                    for (var i = 0; i < CorousalData[j].Languages.length; i++) {
                        lang_str = lang_str + CorousalData[j].Languages[i].LanguageName + ', ';
                        lang_count = lang_count + 1;
                    }
                    lang_str = lang_str.slice(0, -2);
                    CorousalData[j].langList = lang_str + '=' + lang_count;
                    lang_count = 0;
                }
            }
        });

       
    };

     /**
     * @ngdoc
     * @name ProjectLangList
     * @methodOf Projects.controller:ProjectsController
     * @description
     * This function is used to show comma separated list of all languages assinged to project in languages column on list view of landing page.
     *@return {undefined} This method doed not return.
     */
    var ProjectLangList = function (CorousalData) {
        var lang_count = 0;
        for (var j = 0; j < CorousalData.length; j++) {
            lang_str = '';
            for (var i = 0; i < CorousalData[j].Languages.length; i++) {
                lang_str = lang_str + CorousalData[j].Languages[i].LanguageName + ', ';
                lang_count = lang_count + 1;
            }
            lang_str = lang_str.slice(0, -2);
            CorousalData[j].langList = lang_str + '=' + lang_count;
            lang_count = 0;
        }
    };

    $scope.trimMenuItemNames = function (menu_item) {
        menu_item = menu_item.slice(4, menu_item.length);
        return menu_item;
    };

       /**
     * @ngdoc
     * @name carouselImageClick
     * @methodOf Projects.controller:ProjectsController
     * @param {string} projectid This is encrypted project id of selected project.
     * @param {number} unencripted This is unencrypted project id of selected project.
     * @description
     * This function is called onclick of image on project list carousel at bottom of project landing page carousal view.
     * This function sets both  the project ids in session storage of browser and calls the service to get the project wise page information
     *@return {undefined} This method doed not return.
     */
    $scope.carouselImageClick = function (projectid, unencripted) {
        $scope.showProjectImage = false;
        //set the project id in the service
        ProjectIdService.setProjectId(projectid);
        sessionStorage.setItem('unEncriptedProjectId', unencripted);
        sessionStorage.setItem('projectIBreadCrumb', JSON.stringify(projectid));

        //get project id from the service
        currentProjectId = projectid;
        $scope.showLoader = true;
        $('.forOtherUser').hide();
        $('.forAdminUser').hide();
        $('.forNonSuperUser').hide();
        $('.forSuperAdminUser').hide();
        var i,
            tags = $("#myCarousel img");
        total = tags.length;
        for (i = 0; i < total; i++) {
            tags[i].style.opacity = .5;
        }

        //calling service to get the project wise page information
        LandingPageData.getPageData(currentProjectId, currentUserId, $scope.excludeNTL_FD, function (projects) {
            $scope.Project = projects;
            sessionStorage.setItem('sessionProjects', JSON.stringify(projects));
            if (projects) {
                $('.no-project').hide();
                $('.project-list').show();
                $('.recent-projects').show();
                sessionStorage.setItem('projectId', JSON.stringify(projectid));
                sessionStorage.setItem('ProjectTitle', JSON.stringify(Project.LandingProjectModel.ProjectTitle));
                sessionStorage.setItem('SecureTitle', JSON.stringify(Project.LandingProjectModel.SecureTitle));
                sessionStorage.setItem('Client', JSON.stringify(Project.LandingProjectModel.Client));
                sessionStorage.setItem('HasWritePrivilege', JSON.stringify(projects.HasWritePrivilege));


                //get Project Status
                if ($scope.Project.LandingProjectModel.IsActive === true) {
                    sessionStorage.setItem($scope.IsActive, 'Active');
                    $scope.IsActive = 'Active';
                } else {
                    sessionStorage.setItem($scope.IsActive, 'Inactive');
                    $scope.IsActive = 'Inactive';
                }

                //enable/disable project status
                if (currentUserRoleName === 'Client Admin' || currentUserRoleName === 'Admin' || currentUserRoleName === 'Super Admin') {
                    $('.forOtherUser').hide();
                    $('.forAdminUser').show();
                    $('.project-state').removeClass('project-state-disabled');
                } else {
                    $('.forAdminUser').hide();
                    $('.forOtherUser').show();
                    $('.project-state').addClass('project-state-disabled');
                }

                //get Project LockStatus
                if ($scope.Project.LandingProjectModel.IsLocked === true) {
                    sessionStorage.setItem($scope.IsLocked, 'Unlocked');
                    $scope.IsLocked = 'Locked';
                } else {
                    sessionStorage.setItem($scope.IsLocked, 'Locked');
                    $scope.IsLocked = 'Unlocked';
                }

                //Unlock/Lock project status
                if (currentUserRoleName === 'Super Admin') {
                    $('.forNonSuperUser').hide();
                    $('.forSuperAdminUser').show();
                    $('.project-lock-state').removeClass('project-lock-state-disabled');
                } else {
                    $('.forSuperAdminUser').hide();
                    $('.forNonSuperUser').show();
                    $('.project-lock-state').addClass('project-lock-state-disabled');
                }

                //brand object to string; client object to string
                if ($scope.Project.LandingProjectModel.Owners.length > 0) {
                    $scope.owner_str = '';
                    for (var i = 0; i < $scope.Project.LandingProjectModel.Owners.length; i++) {
                        $scope.owner_str = $scope.owner_str + $scope.Project.LandingProjectModel.Owners[i].OwnerName + ', ';
                    }
                    $scope.owner_str = $scope.owner_str.slice(0, -2);
                }
                else {
                    $scope.owner_str = null;
                }

                $scope.client_str = '';
                for (var i = 0; i < $scope.Project.LandingProjectModel.Clientlist.length; i++) {
                    $scope.client_str = $scope.client_str + $scope.Project.LandingProjectModel.Clientlist[i].ClientName + ', ';
                }
                $scope.client_str = $scope.client_str.slice(0, -2);

                $scope.brand_str = '';
                for (var i = 0; i < $scope.Project.LandingProjectModel.ProjectBrands.length; i++) {
                    $scope.brand_str = $scope.brand_str + $scope.Project.LandingProjectModel.ProjectBrands[i].BrandName + ', ';
                }
                $scope.brand_str = $scope.brand_str.slice(0, -2);


                $('.project-home').scrollTop(0);
                $scope.showLoader = false;
                $scope.showProjectImage = true;
                $('#' + currentProjectId).fadeTo('fast', 1);
            }
            else {
                alert("No Data Availaible for the selected project");
                $scope.showLoader = false;
            }
        });
        $scope.projectListVertical = false;
    };

    //Toggle Active/Deactive state: Admin Only
    $('.alert-success').hide();
    
     /**
     * @ngdoc
     * @name changeStatusClick
     * @methodOf Projects.controller:ProjectsController
     * @description
     * This function is used to change  the status of project (Active/Inactive).This feature is available on project landing page carousel view.
     *@return {undefined} This method doed not return.
     */
    $scope.changeStatusClick = function () {
        var projStatus = {};

        if ($scope.IsActive === 'Inactive') {
            $scope.IsActive = 'Active';
            projStatus['Status'] = true;
        } else {
            $scope.IsActive = 'Inactive';
            projStatus['Status'] = false;
        }
        $('.alert-success').show();
        $scope.changeMessage = 'Project is changed to ' + $scope.IsActive;

        $('#statusMessage').delay(3000).fadeOut();

        projStatus['ProjectId'] = currentProjectId;
        projStatus['UserId'] = currentUserId;

        if ($scope.adminUser) {
            projStatus['OriginalUserId'] = $scope.adminUser.UserId;
        } else {
            projStatus['OriginalUserId'] = null;
        }

        LandingPageData.changeProjectStatus(projStatus, function () {
            $route.reload();
        });

    };

    //Toggle Unlock/Lock state: Super Admin only
    $('.alert-lock-success').hide();
      /**
     * @ngdoc
     * @name changeLockStatusClick
     * @methodOf Projects.controller:ProjectsController
     * @description
     * This function is used to change  the lock status of project (Locked/Unlocked).This feature is available on project landing page carousel view.
     *@return {undefined} This method doed not return.
     */
    $scope.changeLockStatusClick = function () {
        var projLockStatus = {};
        if ($scope.IsLocked === 'Unlocked') {
            $scope.IsLocked = 'Locked';
            projLockStatus['IsLocked'] = true;
        } else {
            $scope.IsLocked = 'Unlocked';
            projLockStatus['IsLocked'] = false;
        }
        $('.alert-lock-success').show();
        $scope.changeLockMessage = 'Project is ' + $scope.IsLocked + ' for Editing.';

        $('#lockStatusMessage').delay(3000).fadeOut();

        projLockStatus['projectId'] = currentProjectId;
        projLockStatus['userId'] = currentUserId;

        if ($scope.adminUser) {
            projLockStatus['OriginalUserId'] = $scope.adminUser.UserId;
        } else {
            projLockStatus['OriginalUserId'] = null;
        }

        LandingPageData.changeProjectLockStatus(projLockStatus, function () {
            $route.reload();
        });

    };

     /**
     * @ngdoc
     * @name toggleProjectListClick
     * @methodOf Projects.controller:ProjectsController
     * @description
     *This method is used to toggle view - List and carousel view.
     *
     */
    $scope.toggleProjectListClick = function () {
        if ($scope.projectListVertical) {
            $scope.projectListVertical = false;
            $scope.projectListTitle = 'Display As List';
        }
        else {
            $scope.projectListTitle = 'Display As Carousel';
            if (CorousalData.length === 0) {
                $scope.projectListVertical = false;
            } else {
                $scope.projectListVertical = true;
            }
        }
    };

    $scope.sort = function (keyname) {
        $scope.sortKey = keyname;   //set the sortKey to the param passed
        $scope.reverse = !$scope.reverse; //if true make it false and vice versa
    };

     /**
     * @ngdoc
     * @name navSorceSetup
     * @methodOf Projects.controller:ProjectsController
     * @description
     *This method is used to navigate to source setup page.This function is called on click of Open source setup page button on the project landing page carousel view.
     *
     */
    $scope.navSorceSetup = function () {
        GlossaryLangCheck = {};

        GlossaryLangCheck.UserId = currentUserId;
        GlossaryLangCheck.PageId = 4;
        GlossaryLangCheck.ResourceId = commonService.getSessionData('projectIBreadCrumb');;
        GlossaryLangCheck.SessionId = null;

        commonService.checkSourceSetup(GlossaryLangCheck, function (status) {
            if (status === "error") {
                $('#serverError').modal('show');
            }
            else if (status.IsLocked === true) {
                $('#multipleSourceSetupUser').modal('show');

            } else {
                $scope.changeView('sourceSetup');
            }

        });
    };

    $scope.continueToSourceSetup = function () {
        $('.modal-backdrop.fade.in').css('display', 'none');
        $('#multipleSourceSetupUser').modal('hide');
        $scope.changeView('sourceSetup');
    };

    $scope.cancelSourceSetup = function () {
        var resorceIdx = 0;
        sessionStorage.setItem('resourcePageId', JSON.stringify(resorceIdx));
        var userDetails = commonService.getLocalData('userDetails');
    };

    /**
     * @ngdoc
     * @name navSorceSetup
     * @methodOf Projects.controller:ProjectsController
     * @description
     *This method is used to to exclude NTL/FD count from translation status.This function is called on check of Exclude NTL/FD checkbox in translation status column on project page.
     *
     */
    $scope.excludeNTL_FD_Count = function () {
        if (!$scope.excludeNTL_FD) {
            $scope.excludeNTL_FD = false;
        }
        LandingPageData.getPageData(currentProjectId, currentUserId, $scope.excludeNTL_FD, function (projects) {
            $scope.Project = projects;
        });
    };

    //document.getElementById("projList").addEventListener("wheel", lazyLoadingProjects);
    var el = document.getElementById("projList");
    if (el) {
        el.addEventListener("wheel", lazyLoadingProjects);
        el.addEventListener("mousewheel", lazyLoadingProjects);
    };


    function lazyLoadingProjects(e) {
        $scope.newIndex = $scope.newIndex + 10;
        $scope.$apply();
    };


    $scope.getTimeStamp = function () {
        return Math.floor(Date.now() / 1000);
    };

    init();

}]);