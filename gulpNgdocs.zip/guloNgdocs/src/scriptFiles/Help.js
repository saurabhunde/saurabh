/**
 * @ngdoc object
 * @name Help
 * @element html
 * 
 * @requires AngularJS.$routeProvider
 * @requires AngularJS.$locationProvider
 * @requires AngularJS.ngRoute
 * @requires common
 * 
 * @description
 * This is Help module, which will contain controller for help page. 
 * 
 */
var Help = angular.module('help', ['ngRoute','common']);

Help.config(['$routeProvider', '$locationProvider', '$httpProvider', function ($routeProvider, $locationProvider, $httpProvider) {
    $httpProvider.interceptors.push('myInterceptor');
    $routeProvider

  .when('/', {
      templateUrl: "HelpController/Content/ngviews/Help.html",
      controller: "helpController"
  })


}]);

Help.factory('myInterceptor', function () {
    var requestInterceptor = {
        request: function (config) {
            localStorage.setItem('time', new Date());
            return config;
        }
    };

    return requestInterceptor;
});