/**
 * @ngdoc controller
 * @name Projects.controller:GlossaryAllSectionController
 * @element div
 *
 * @description
 * This Controller is responsible for showing content on project all glossary page.
 *
 * @requires AngularJS.$scope
 * @requires AngularJS.$rootScope
 * @requires AngularJS.$http
 * @requires AngularJS.$location
 * @requires AngularJS.$route
 * @requires AngularJS.$timeout
 * @requires common.commonService
 * @requires Projects.LandingPageData
 * @requires Projects.Glossary
 * 
 * @property {Object} userDetails:Object This is object stores the user details received from backend when user is logged in. 
 * @property {Object} glossaryData:Object This is object stores all glossary data.
 * @property {Array} headerList:Array This is array stores all section list
 * @property {Object} gridOptions1:Object This is object store UI grid configuration
 * @property {Array} facdata:Array This is array of objects contains data property of gridOptions 
 * @property {Array} defdata:Array This is array of objects column definitions for UI grid column set as columnDefs property in gridOptions
 * @property {Boolean} hideAddInfoCols:Boolean This property stores the boolean value of hide additional info column checkbox.
 * @property {Boolean} hideEmptyAddInfoCols:Boolean This property stores the boolean value of hide empty additional info column checkbox.
 * @property {Boolean} pendingSuggFilterOnGrid:Boolean This property stores the boolean value of source term pending suggestions checkbox.
 * @property {Boolean} hideColors:Boolean This property stores the boolean value of hide color checkbox.
 * @property {Boolean} hideImage:Boolean This property stores the boolean value of hide image checkbox.
 * @property {Boolean} hideStatus:Boolean This property stores the boolean value of hide status checkbox.
 * @property {String} filterValue:String This property string entered in search box.
 *
 * 
 */
Projects.controller('glossaryAllSectionController', ['$scope', '$rootScope', '$http', '$location', 'Glossary', 'commonService', '$routeParams', 'ProjectIdService', 'saveBlob', '$compile', '$parse', 'LandingPageData', 'uiGridConstants', function ($scope, $rootScope, $http, $location, Glossary, commonService, $routeParams, ProjectIdService, saveBlob, $compile, $parse, LandingPageData, uiGridConstants) {
    $scope.showPendingSuggOnGrid = true;
    $scope.langSelected = false;
    var statusFilter = false;
    $scope.hideColors = false;
    $scope.colorText = 'Hide Color';
    $scope.hideImage = false;
    $scope.imageText = 'Hide Image';
    var hideStatus = false;
    $scope.statusText = 'Hide Status';
    $scope.phoneticsText = 'Hide Phonetics/Plural';
    $scope.searchResult = false;
    $scope.allglossaryLanguages = {};
    $scope.allglossaryLanguages.status = false;
    var isVisible = false;
    var winHt = window.innerHeight; 
    var winOutHt = window.outerHeight;
    var emailRegex = new RegExp("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$");
    $rootScope.headerId = "";
    $rootScope.languageSelected = "";
    $scope.facdata = [];
    $scope.defdata = [];
    var headerList = [];
    $('.letter-c').css("color", "red");
    $('.letter-o').css("color", "green");
    $('.letter-l').css("color", "darkblue");
    $('.letter-r').css("color", "darkyellow");

 //set hashURL for GLMGR-1189
    sessionStorage.setItem('hashURL', null);

    //GLMGR-763
    $scope.sectionTypeDropdown = [{ name: "Show All Sections", value: 0 },
                         { name: "Show Default Sections", value: 1 },
                         { name: "Show NTL/FD Sections", value: 2 }];

    $scope.sectionTypeSelected = $scope.sectionTypeDropdown[0];
    var srirachaSauce = 1;
    var customSortFn = function (a, b, rowA, rowB, direction) {
        if (!b && !a) return 0;
        if (a && !b) return -1;
        if (b && !a) return srirachaSauce;
        if (b.termText === "" && a.termText === "") return 0;
        if (b.termText === "" && a.termText !== "") return -1;
        if (b.termText !== "" && a.termText === "") return srirachaSauce;
            if (a.termText == b.termText) return 0;
            if (a.termText < b.termText) return -1;
            return srirachaSauce;
        

    };
    $scope.gridOptions1 = {
        enableSorting: true,
        enableColumnResizing: true,
        enableGridMenu: true,
        width:300,
        rowHeight: 100,
        onRegisterApi: function (gridApi) {
            $scope.gridApi = gridApi;
            $scope.gridApi.grid.registerRowsProcessor($scope.singleFilter, 200);
            $scope.gridApi.colResizable.on.columnSizeChanged($scope, function (colDef, deltaChange) {
                //To gradually reduce the size of the image upto a limit on column resize
                //on stop resizing
                var max_size = 110;
                $(".width100per").each(function (i) {
                    x = $(this).width();
                    console.log(x);
                    $(".ngCellTextMasterTerm").each(function (i) {

                        var h = max_size;
                        var w = Math.ceil(x - 120);
                        console.log(w);
                        $(this).css({ height: h + 'px', width: w + 'px' });
                    });
                });
            });
        }
    };
    $scope.gridOptions1.columnDefs = $scope.defdata;
    $scope.gridOptions1.data = $scope.facdata;

    /**
     * @ngdoc
     * @name clearSearch
     * @methodOf Projects.controller:GlossaryAllSectionController
     * @description
     * This function is called on clear search button. This function is used to clear search box.
     * @returns {undefined} This method does not return.
     */
    $scope.clearSearch = function () {
        $scope.filterValue = '';
        $scope.filter();
    };

    /* search filter  Starts */
      /**
     * @ngdoc
     * @name filter
     * @methodOf Projects.controller:GlossaryAllSectionController
     * @description
     * This function is called on search button. This function is used to filter glossary data depending on search text entered.
     * @returns {undefined} This method does not return.
     */
    $scope.filter = function () {
        if ($scope.filterValue) {
            $scope.filterValue = $scope.filterValue.toLowerCase();
        }
        $scope.gridApi.grid.refresh();

    };
 
     /**
     * @ngdoc
     * @name singleFilter
     * @methodOf Projects.controller:GlossaryAllSectionController
     * @param {Array} renderableRows This is array of all rows in all glossary page
     * @description
     * This function is called in UI grid row processor function . This function is used to render row in UI grid.
     * @returns {undefined} This method does not return.
     */
    $scope.singleFilter = function (renderableRows) {
        var matcher = new RegExp($scope.filterValue);
        renderableRows.forEach(function (row) {
            var match = false;
            headerList.forEach(function (field) {
                if (row.entity[field]) {
                    if ((row.entity[field].termText.toLowerCase()).match(matcher)) {
                        match = true;
                    }
                }
            });
            if (!match) {
                row.visible = false;
            }
        });
        return renderableRows;
    };

    /* search filter  ends */

    /**
     * @ngdoc
     * @name changeView
     * @methodOf Projects.controller:GlossaryAllSectionController
     * @param {string} new_path The Name of the view bound with element on which this function is called.
     * @description
     * This function is called to change views and loads respective html page.Below are some views
     * translation, language history , approve translation, Glossary All sections,
     * @returns {undefined} This method does not return.
     */
    $scope.changeView = function (new_path) {
        //GLMGR-1239 uncheck hide add info col on view change
        sessionStorage.setItem('hideAddInfoCols', false);
        switch (new_path) {
            case "languageHistory":
                if (commonService.getSessionData('languageSelected').LanguageName.ProjectLanguageId) {
                    $location.path('/glossary/languageHistory');
                    $scope.clearFilterOptions();
                }
                break;
            case "translation":
                $location.search('projectlanguageid', $scope.translationProjectLanguageId);
                //$location.search('projectlanguageid', $scope.projectlanguageid); projectid
                $location.path('/glossary/translation');
                break;

            case "approve":
                $location.search('projectlanguageid', $scope.approveProjectLanguageId);
                $location.path('/glossary/approve');
                break;

            case "GlossaryAllsection":
                $location.search('Section', $scope.sectionLength);
                $location.path('/glossaryAllSection');
                break;

        }

    };

    $scope.refresh = function () {
        location.reload();
    };

    /**
     * @ngdoc
     * @name checkColors
     * @methodOf Projects.controller:GlossaryAllSectionController
     * @description
     * This function is called on hide color checkbox. This is used to show/hide colors in table.
     * @returns {undefined} This method does not return.
     */
    $scope.checkColors = function () {
        if ($scope.hideColors == false) {
            $scope.hideColors = true;
        } else {
            $scope.hideColors = false;
        }
    };

    /**
     * @ngdoc
     * @name checkImage
     * @methodOf Projects.controller:GlossaryAllSectionController
     * @description
     * This function is called on hide image checkbox. This is used to show/hide term image in table.
     * @returns {undefined} This method does not return.
     */
    $scope.checkImage = function () {
        if ($scope.hideImage == false) {
            $scope.hideImage = true;
        } else {
            $scope.hideImage = false;
        }

    };

   /**
     * @ngdoc
     * @name checkStatus
     * @methodOf Projects.controller:GlossaryAllSectionController
     * @description
     * This function is called on hide status checkbox. This is used to show/hide status column in table.
     * @returns {undefined} This method does not return.
     */
    $scope.checkStatus = function () {
        if (hideStatus == false) {
            for (var i = 0; i < $scope.gridOptions1.columnDefs.length; i++) {
                //GLMGR-885 chnaged Status to Approval Status
                if ($scope.gridOptions1.columnDefs[i].displayName == 'Approval Status') {
                    $scope.gridOptions1.columnDefs[i].visible = false;
                }
            }
            $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
            hideStatus = true;
        } else {
            for (var i = 0; i < $scope.gridOptions1.columnDefs.length; i++) {
                if ($scope.gridOptions1.columnDefs[i].displayName == 'Approval Status') {
                    $scope.gridOptions1.columnDefs[i].visible = true;
                }
            }
            $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
            hideStatus = false;
        }
    };

    
   /**
     * @ngdoc
     * @name checkPhoneticsClick
     * @methodOf Projects.controller:GlossaryAllSectionController
     * @description
     * This function is called on hide phonetics checkbox. This is used to set session variable 'hidePhoneticPluralCols' and call checkPhonetics function
     * @returns {undefined} This method does not return.
     */
    $scope.checkPhoneticsClick = function () {
        if (sessionStorage.getItem('hidePhoneticPluralCols') == '' || sessionStorage.getItem('hidePhoneticPluralCols') == undefined || sessionStorage.getItem('hidePhoneticPluralCols') === 'false') {
            sessionStorage.setItem('hidePhoneticPluralCols', 'true');
        } else {
            sessionStorage.setItem('hidePhoneticPluralCols', 'false');
        }
        $scope.checkPhonetics();
    };

        
   /**
     * @ngdoc
     * @name checkPhonetics
     * @methodOf Projects.controller:GlossaryAllSectionController
     * @description
     * This function is called inside checkPhoneticsClick function. This is used to show/hide phonetics column in table.
     * @returns {undefined} This method does not return.
     */
    $scope.checkPhonetics = function () {
        if (sessionStorage.getItem('hidePhoneticPluralCols') === 'true') {
            for (var i = 0; i < $scope.gridOptions1.columnDefs.length; i++) {
                if ($scope.gridOptions1.columnDefs[i].displayName == 'Phonetics') {
                    $scope.gridOptions1.columnDefs[i].visible = false;
                    $scope.gridOptions1.columnDefs[i + 1].visible = false;
                }
            }
            $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
        } else {
            for (var i = 0; i < $scope.gridOptions1.columnDefs.length; i++) {
                if ($scope.gridOptions1.columnDefs[i].displayName == 'Phonetics') {
                    $scope.gridOptions1.columnDefs[i].visible = true;
                    $scope.gridOptions1.columnDefs[i+1].visible = true;
                }
            }
            $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
        }
    };

    /**
     * @ngdoc
     * @name AllSection
     * @methodOf Projects.controller:GlossaryAllSectionController
     * @description
     * This function is called on click of language options button.This is used to open allglossary popup to select languages.
     * @returns {undefined} This method does not return.
     */
    $scope.AllSection = function () {
        if ($scope.AllLangList.length > 1) {
            $('#allGlossary').modal('show');
        } else {
           alert("There is no other language aasigned to you")
        }

    };

     /**
     * @ngdoc
     * @name allglossaryRedirect
     * @methodOf Projects.controller:GlossaryAllSectionController
     * @description
     * This function is called on click of ok button on allglossary popup. This is used show glossary of selected language on allglossary page. 
     * @returns {undefined} This method does not return.
     */
    $scope.allglossaryRedirect = function () {
        var languages = [];
        $('.allglossaryLanguage:checked').each(function (id, value) {
            languages.push(this.value);

        });
        $scope.clearFilterOptions();

        $('.modal-backdrop.fade.in').css('display', 'none');
        $('#allGlossary').modal('hide');
        $scope.showLoader = true;
        sessionStorage.setItem('AllglossaryLangList', JSON.stringify(languages));
        location.reload();
    };

    $scope.checkAllglossaryLanguageStatus = function () {
        var count = 0;
        $('.allglossaryLanguage:not(:checked)').each(function (id, value) {
            count++;
        });
        if (count > 0) {
            $scope.allglossaryLanguages.status = false;
        } else {
            $scope.allglossaryLanguages.status = true;
        }
    };

     /**
     * @ngdoc
     * @name allLanguagesglossary
     * @methodOf Projects.controller:GlossaryAllSectionController
     * @description
     * This function is called on all languages option on language option popup. This is used to select all languages.
     * @returns {undefined} This method does not return.
     */
    $scope.allLanguagesglossary = function () {
        if ($scope.allglossaryLanguages.status == true) {
            $('.allglossaryLanguage:not(:checked)').each(function (id, value) {
                $(this).prop('checked', true);
            });
        } else {
            $('.allglossaryLanguage:checked').each(function (id, value) {
                $(this).prop('checked', false);
            });
        }
    };

    $scope.allglossaryCancel = function () {
        location.reload();
    };
    /* Langauge change filter ends */

    //Filter according to term status.
    /**
     * @ngdoc
     * @name selectAllLangFilters
     * @methodOf Projects.controller:GlossaryAllSectionController
     * @description
     * This function is called on select/unselect all option on filter popup. This is used to check/uncheck all checkboxes below.
     * @returns {undefined} This method does not return.
     */
    $scope.selectAllLangFilters = function () {
        if ($('#selectAll:checkbox:checked').length > 0) {
            $('#pendingTranslationsFilter').prop('checked', true);
            $('#pendingApprovalsFilter').prop('checked', true);
            $('#approvedFilter').prop('checked', true);
            $('#rejectedFilter').prop('checked', true);
        } else {
            $('#pendingTranslationsFilter').prop('checked', false);
            $('#pendingApprovalsFilter').prop('checked', false);
            $('#approvedFilter').prop('checked', false);
            $('#rejectedFilter').prop('checked', false);
        }
    };

      /**
     * @ngdoc
     * @name filterOptions
     * @methodOf Projects.controller:GlossaryAllSectionController
     * @description
     * This function is called on Save filter settings button on filters popup.This is used to set filters on glossary data.
     * @returns {undefined} This method does not return.
     */
    $scope.filterOptions = function () {
        //GLMGR-1227 Enable/Disable check box on ng-grid(Source Term pending suggestions)
        if ($('#pendingTranslationsFilter:checkbox:checked').length > 0 || $('#approvedFilter:checkbox:checked').length > 0 || $('#rejectedFilter:checkbox:checked').length > 0 || $('#pendingApprovalsFilter:checkbox:checked').length > 0 || $('#pendingSuggFilter:checkbox:checked').length > 0) {
            $scope.showPendingSuggOnGrid = false;
        }

        $('#filterOption').modal('hide');
        $scope.showLoader = true;
        $scope.glossaryCopy = {};
        var count = 0;
        var langModel = {
            GlossaryTranslationId: 0,
            IsEditable: true,
            LanguageId: 0,
            LanguageName: "",
            ProjectId: 0,
            ProjectLanguageId: 0,
            rowHeight: 110,
            PhoneticTerm: "",
            PluralTerm: "",
            TermStatus: "",
            TranslatedTerm: "Translation Pending",
            Version: ""
        };
        angular.copy($scope.glossaryData, $scope.glossaryCopy);
        for (var i = 0; i < $scope.glossaryCopy.ProjectAllMasterGlossary.length; i++) {
            $scope.glossaryCopy.ProjectAllMasterGlossary[i].ProjectLanguages = [];
        }
        $('.filter-checkboxes:checked').each(function (id, value) {
            count++;

        });

        if ($scope.FilterLang) {
            if (count > 0) {
                $('#filterOptionsButton').css("border-style", "ridge");
                $('#filterOptionsButton').css("border-color", "red");

                $('#filterOptionsButton').css("background-image", "url('../../../Content/Common/Assets/Images/download_pdf_s.png')");
                $('#filterOptionsButton').css("color", "red");

                var islangStatusSet = false;

                if ($('#pendingTranslationsFilter:checkbox:checked').length > 0) {
                    var islangStatusSet = true;
                    for (var i = 0; i < $scope.glossaryData.ProjectAllMasterGlossary.length; i++) {
                        if ($scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages.length == 0) {
                            if ($('#pendingSuggFilter:checkbox:checked').length > 0) {
                                if ($scope.glossaryData.ProjectAllMasterGlossary[i].IsSuggestionExist === false) {
                                    $scope.glossaryCopy.ProjectAllMasterGlossary[i].ProjectLanguages.push(langModel);
                                }
                            } else {
                                $scope.glossaryCopy.ProjectAllMasterGlossary[i].ProjectLanguages.push(langModel);
                            }
                        }
                        
                    }
                    statusFilter = true;
                }

                if ($('#approvedFilter:checkbox:checked').length > 0) {
                    var islangStatusSet = true;
                    for (var i = 0; i < $scope.glossaryData.ProjectAllMasterGlossary.length; i++) {
                        var flag = false;
                        for (var k = 0; k < $scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages.length; k++) {
                            if ($scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k].ProjectLanguageId == $scope.FilterLang.ProjectLanguageId) {
                                if ($('#pendingSuggFilter:checkbox:checked').length > 0) {
                                    if (($scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'APPROVER_APPROVED' || $scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'CLIENT_APPROVED') && $scope.glossaryData.ProjectAllMasterGlossary[i].IsSuggestionExist === false) {
                                        $scope.glossaryCopy.ProjectAllMasterGlossary[i].ProjectLanguages.push($scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k]);
                                    }
                                }
                                else {
                                    if ($scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'APPROVER_APPROVED' || $scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'CLIENT_APPROVED') {
                                        $scope.glossaryCopy.ProjectAllMasterGlossary[i].ProjectLanguages.push($scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k]);
                                    }
                                }
                            }
                        }
                    }
                    statusFilter = true;
                }
                if ($('#rejectedFilter:checkbox:checked').length > 0) {
                    var islangStatusSet = true;
                    for (var i = 0; i < $scope.glossaryData.ProjectAllMasterGlossary.length; i++) {
                        var flag = false;
                        for (var k = 0; k < $scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages.length; k++) {
                            if ($scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k].ProjectLanguageId == $scope.FilterLang.ProjectLanguageId) {
                                if ($('#pendingSuggFilter:checkbox:checked').length > 0) {
                                    if (($scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'APPROVER_REJECTED' || $scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'CLIENT_REJECTED') && $scope.glossaryData.ProjectAllMasterGlossary[i].IsSuggestionExist === false) {
                                        $scope.glossaryCopy.ProjectAllMasterGlossary[i].ProjectLanguages.push($scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k]);
                                    }
                                }
                                else {
                                    if ($scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'APPROVER_REJECTED' || $scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'CLIENT_REJECTED') {
                                        $scope.glossaryCopy.ProjectAllMasterGlossary[i].ProjectLanguages.push($scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k]);
                                    }
                                }
                            }
                        }
                    }
                    statusFilter = true;
                }
                if ($('#pendingApprovalsFilter:checkbox:checked').length > 0) {
                    var islangStatusSet = true;
                    for (var i = 0; i < $scope.glossaryData.ProjectAllMasterGlossary.length; i++) {
                        var flag = false;
                        for (var k = 0; k < $scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages.length; k++) {
                            if ($scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k].ProjectLanguageId == $scope.FilterLang.ProjectLanguageId) {
                                if ($('#pendingSuggFilter:checkbox:checked').length > 0) {
                                    if (($scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'TRANSLATION_COMPLETED' || $scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'APPROVER_APPROVED_IN_PROGRESS' || $scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'APPROVER_REJECTED_IN_PROGRESS' || $scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'CLIENT_APPROVER_IN_PROGRESS' || $scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'CLIENT_REJECTED_IN_PROGRESS') && $scope.glossaryData.ProjectAllMasterGlossary[i].IsSuggestionExist === false) {
                                        $scope.glossaryCopy.ProjectAllMasterGlossary[i].ProjectLanguages.push($scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k]);
                                    }
                                }
                                else {
                                    if ($scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'TRANSLATION_COMPLETED' || $scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'APPROVER_APPROVED_IN_PROGRESS' || $scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'APPROVER_REJECTED_IN_PROGRESS' || $scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'CLIENT_APPROVER_IN_PROGRESS' || $scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'CLIENT_REJECTED_IN_PROGRESS') {
                                        $scope.glossaryCopy.ProjectAllMasterGlossary[i].ProjectLanguages.push($scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k]);
                                    }
                                }
                                
                            }
                        }
                    }
                    statusFilter = true;
                }
                
                //GLMGR-1227 filter for Source Term pending suggestions in filter options
                if (!islangStatusSet) {
                    if ($('#pendingSuggFilter:checkbox:checked').length > 0) {
                        for (var i = 0; i < $scope.glossaryData.ProjectAllMasterGlossary.length; i++) {
                            var flag = false;
                            for (var k = 0; k < $scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages.length; k++) {
                                if ($scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k].ProjectLanguageId == $scope.FilterLang.ProjectLanguageId) {
                                    if ($scope.glossaryData.ProjectAllMasterGlossary[i].IsSuggestionExist === false) {
                                        $scope.glossaryCopy.ProjectAllMasterGlossary[i].ProjectLanguages.push($scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k]);
                                    }
                                }
                            }
                        }
                        statusFilter = true;
                    }
                }
                for (var k = 0; k < $scope.glossaryCopy.ProjectAllMasterGlossary.length; k++) {
                    if ($scope.glossaryCopy.ProjectAllMasterGlossary[k].ProjectLanguages.length < 1) {
                        $scope.glossaryCopy.ProjectAllMasterGlossary.splice(k, 1);
                        k--;
                    }
                }
               
                /*Image filter 'withImage' for  terms with image 'withoutImage' for terms without terms . Here filter is applied on glossaryCopy after other filters is applied*/
                if ($scope.filterImage == 'withImage') {
                    statusFilter = true;
                    for (var k = 0; k < $scope.glossaryCopy.ProjectAllMasterGlossary.length; k++) {
                        if ($scope.glossaryCopy.ProjectAllMasterGlossary[k].MasterGlossaryImageUrl == null) {
                            $scope.glossaryCopy.ProjectAllMasterGlossary.splice(k, 1);
                            k--;
                        }
                    }
                }
                if ($scope.filterImage == 'withoutImage') {
                    statusFilter = true;
                    for (var k = 0; k < $scope.glossaryCopy.ProjectAllMasterGlossary.length; k++) {
                        if ($scope.glossaryCopy.ProjectAllMasterGlossary[k].MasterGlossaryImageUrl != null) {
                            $scope.glossaryCopy.ProjectAllMasterGlossary.splice(k, 1);
                            k--;
                        }
                    }
                }

                sessionStorage.setItem('glossaryFilterLang', JSON.stringify($scope.FilterLang));
                sessionStorage.setItem("filterStatus", statusFilter);
                sessionStorage.setItem("filterImage", $scope.filterImage);
                sessionStorage.setItem("pendingTranslationsFilter", $('#pendingTranslationsFilter:checkbox:checked').length);
                sessionStorage.setItem("pendingApprovalsFilter", $('#pendingApprovalsFilter:checkbox:checked').length);
                sessionStorage.setItem("approvedFilter", $('#approvedFilter:checkbox:checked').length);
                sessionStorage.setItem("rejectedFilter", $('#rejectedFilter:checkbox:checked').length);
                sessionStorage.setItem("pendingSuggFilter", $('#pendingSuggFilter:checkbox:checked').length);
                sessionStorage.setItem("filterOnStatus", "1");
                $scope.showLoader = false;
                $scope.facdata = [];
                $scope.defdata = [];
                GlossaryUIGrid($scope.glossaryCopy);
   
            }
                // if no filter checkboxes are checked but language is selected
            else {
                if ($scope.filterImage) {
                    $('#filterOptionsButton').css("border-style", "ridge");
                    $('#filterOptionsButton').css("border-color", "red");
                    $('#filterOptionsButton').css("background-image", "url('../../../Content/Common/Assets/Images/download_pdf_s.png')");
                    $('#filterOptionsButton').css("color", "red");
                    $scope.filter = true;
                    for (var i = 0; i < $scope.glossaryData.ProjectAllMasterGlossary.length; i++) {
                        for (var k = 0; k < $scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages.length; k++) {
                            if ($scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k].ProjectLanguageId == $scope.FilterLang.ProjectLanguageId) {

                                $scope.glossaryCopy.ProjectAllMasterGlossary[i].ProjectLanguages.push($scope.glossaryData.ProjectAllMasterGlossary[i].ProjectLanguages[k]);

                                break;
                            }
                        }
                    }
                    /*Image filter 'withImage' for  terms with image 'withoutImage' for terms without terms . Here filter is applied on glossaryCopy after other filters is applied*/
                    if ($scope.filterImage == 'withImage') {
                        for (var k = 0; k < $scope.glossaryCopy.ProjectAllMasterGlossary.length; k++) {
                            if ($scope.glossaryCopy.ProjectAllMasterGlossary[k].MasterGlossaryImageUrl == null) {
                                $scope.glossaryCopy.ProjectAllMasterGlossary.splice(k, 1);
                                k--;
                            }
                        }
                    }
                    if ($scope.filterImage == 'withoutImage') {
                        for (var k = 0; k < $scope.glossaryCopy.ProjectAllMasterGlossary.length; k++) {
                            if ($scope.glossaryCopy.ProjectAllMasterGlossary[k].MasterGlossaryImageUrl != null) {
                                $scope.glossaryCopy.ProjectAllMasterGlossary.splice(k, 1);
                                k--;
                            }
                        }
                    }
                    $('#filterOption').modal('hide');
                    sessionStorage.setItem('glossaryFilterLang', JSON.stringify($scope.FilterLang));
                    sessionStorage.setItem("filterStatus",  statusFilter);
                    sessionStorage.setItem("filterImage", $scope.filterImage);
                    sessionStorage.setItem("pendingTranslationsFilter", $('#pendingTranslationsFilter:checkbox:checked').length);
                    sessionStorage.setItem("pendingApprovalsFilter", $('#pendingApprovalsFilter:checkbox:checked').length);
                    sessionStorage.setItem("approvedFilter", $('#approvedFilter:checkbox:checked').length);
                    sessionStorage.setItem("rejectedFilter", $('#rejectedFilter:checkbox:checked').length);
                    sessionStorage.setItem("pendingSuggFilter", $('#pendingSuggFilter:checkbox:checked').length);
                    sessionStorage.setItem("filterOnStatus", "1");
                    $scope.showLoader = false;
                    $scope.facdata = [];
                    $scope.defdata = [];
                    GlossaryUIGrid($scope.glossaryCopy);
                    $(window).resize();
                } else {
                    $('#filterOptionsButton').css("border-style", "none");
                    $('#filterOptionsButton').css("border-color", "none");
                    $('#filterOptionsButton').css("background-image", "url('../../../Content/Common/Assets/Images/download_pdf_n.png')");
                    $('#filterOptionsButton').css("color", "white");
                    $('#filterOption').modal('hide');
                    $scope.filter = false;
                    sessionStorage.setItem("filterStatus", "undefined");
                    sessionStorage.setItem("filterImage", "undefined");
                    sessionStorage.setItem("pendingTranslationsFilter", "0");
                    sessionStorage.setItem("pendingApprovalsFilter", "0");
                    sessionStorage.setItem("approvedFilter", "0");
                    sessionStorage.setItem("rejectedFilter", "0"); 
                    sessionStorage.setItem("pendingSuggFilter", "0");
                    sessionStorage.setItem("filterOnStatus", "0");
                    alert('No filter Selected');
                    $scope.facdata = [];
                    $scope.defdata = [];
                    $scope.showLoader = false;
                    GlossaryUIGrid($scope.glossaryData);
                    $(window).resize();
                }

            }


        }
        else {
            $scope.showLoader = false;
            alert('Please Select Language');
        }

        if (sessionStorage.getItem("filterOnStatus") === "1") {
            $scope.showPendingSuggOnGrid = false;
        }

        $scope.checkPhonetics();

    };

    /**
     * @ngdoc
     * @name showFilter
     * @methodOf Projects.controller:GlossaryAllSectionController
     * @description
     * This function is called on filters button.This is used to open filters popup.
     * @returns {undefined} This method does not return.
     */
    $scope.showFilter = function () {
        $('#filterOption').modal({ backdrop: 'static', keyboard: false })
        $('#filterOption').modal('show');
    };
    
    /**
     * @ngdoc
     * @name clearFilterOptions
     * @methodOf Projects.controller:GlossaryAllSectionController
     * @description
     * This function is called on clear filter button on filters poup.This is used to clear all filters.
     * @returns {undefined} This method does not return.
     */
    $scope.clearFilterOptions = function () {
        //GLMGR-622 start
        sessionStorage.setItem("filterStatus", "undefined");
        sessionStorage.setItem("filterImage", "undefined");
        sessionStorage.setItem("pendingTranslationsFilter", "0");
        sessionStorage.setItem("pendingApprovalsFilter", "0");
        sessionStorage.setItem("approvedFilter", "0");
        sessionStorage.setItem("rejectedFilter", "0");
        sessionStorage.setItem("pendingSuggFilter", "0");
        sessionStorage.setItem("filterOnStatus", "0");
        
        $('#filterOptionsButton').css("border-style", "none");
        $('#filterOptionsButton').css("border-color", "none");
        $('#filterOptionsButton').css("background-image", "url('../../../Content/Common/Assets/Images/download_pdf_n.png')");
        $('#filterOptionsButton').css("color", "white");
        //GLMGR-622 end
        location.reload();
    };

    /**
     * @ngdoc
     * @name hideAddInfoColumns
     * @methodOf Projects.controller:GlossaryAllSectionController
     * @description
     * This function is called on hide add info column checkbox.This is used to hide/show additional info columns
     * @returns {undefined} This method does not return.
     */
    $scope.hideAddInfoColumns = function () {
        $scope.isCheckedEmptyInfoCols = true;
        $scope.hideEmptyAddInfoCols = true;
        sessionStorage.setItem('hideAddInfoCols', $scope.hideAddInfoCols);

        //GLMGR-1227 check if pending sug checkbox is checked
        if ($scope.pendingSuggFilterOnGrid) {
            $scope.sourceTermPendingSugg()
            $scope.showLoader = false;
        }
        else {
            if (statusFilter == true) {
                $scope.filterOptions();
                $scope.checkPhonetics();
                $scope.showLoader = false;
            } else {
                $scope.facdata = [];
                $scope.defdata = [];
                $scope.showLoader = true;
                GlossaryUIGrid($scope.glossaryData);
                $scope.checkPhonetics();
                $scope.showLoader = false;
            }
        }
       
    };

     /**
     * @ngdoc
     * @name hideEmptyColumns
     * @methodOf Projects.controller:GlossaryAllSectionController
     * @description
     * This function is called on hide empty  add info column checkbox.This is used to hide/show empty additional info columns
     * @returns {undefined} This method does not return.
     */
    $scope.hideEmptyColumns = function () {
        //GLMGR-1227 check if pending sug checkbox is checked
        if ($scope.pendingSuggFilterOnGrid) {
            $scope.sourceTermPendingSugg()
        }
        else {
            if (statusFilter == true) {
                $scope.filterOptions();
                $scope.checkPhonetics();
            } else {
                $scope.facdata = [];
                $scope.defdata = [];
                GlossaryUIGrid($scope.glossaryData);
                $scope.checkPhonetics();
            }
        }
    };

    /**
     * @ngdoc
     * @name GlossaryUIGrid
     * @methodOf Projects.controller:GlossaryAllSectionController
     * @param {Object} glossaryTerms This is object contains all glossary data to be shown in table.
     * @description
     * This function is called on page load.This is used to generate all glossary table.
     * @returns {undefined} This method does not return.
     */
    var GlossaryUIGrid = function (glossaryTerms) {
        var staticName = 'cat';
        var langList = glossaryTerms.ProjectAllLanguages;
        if (statusFilter == true) {
            langList = [];

            langList.push($scope.FilterLang);

        }

        //column defn for categories.
        $scope.defdata.push({ field: 'Section', displayName: 'Section', width: 250, sortingAlgorithm: customSortFn, cellTemplate: '<div class="ui-grid-cell-contents" >{{grid.getCellValue(row, col).termText}}</div>' });
        headerList.push('Section');

        //hide add info columns check box if checkbox is checked
        if (!$scope.hideAddInfoCols) {
            for (var i = 0; i < glossaryTerms.ProjectAllCategories.length; i++) {
                //check if hide empty add info checkbox is checked
                if ($scope.hideEmptyAddInfoCols) {
                    if (glossaryTerms.ProjectAllCategories[i].IsCategoryEmpty) {
                        continue;
                    }
                }
               
                var str = glossaryTerms.ProjectAllCategories[i].CategoryId.toString();
                if (glossaryTerms.ProjectAllCategories[i].CategoryName == 'English Description') {

                    $scope.defdata.push({ field: staticName.concat(str), displayName: glossaryTerms.ProjectAllCategories[i].CategoryName, width: 400, sortingAlgorithm: customSortFn, cellTemplate: '<div class="ui-grid-cell-contents" >{{grid.getCellValue(row, col).termText}}</div>' });
                } else {
                    $scope.defdata.push({ field: staticName.concat(str), displayName: glossaryTerms.ProjectAllCategories[i].CategoryName, width: 150, sortingAlgorithm: customSortFn, cellTemplate: '<div class="ui-grid-cell-contents" >{{grid.getCellValue(row, col).termText}}</div>' });
                }
                headerList.push(staticName.concat(str));
            }
        }

        $scope.defdata.push({ field: 'Master', displayName: 'Source Term', width: 300, sortingAlgorithm: customSortFn, cellTemplate: '<div class="pull-left width100per"><div class="ui-grid-cell-contents pull-left ngCellTextMasterTerm" >{{grid.getCellValue(row, col).termText}}</div> <div class="pull-right termImgDiv"  ng-hide="grid.getCellValue(row, col).MasterGlossaryImageUrl == null || grid.appScope.hideImage"> <img src="{{grid.getCellValue(row, col).MasterGlossaryImageUrl}}" class="termImg"/> </div></div>' });
        headerList.push('Master');

        $scope.defdata.push({ field: 'uuid', displayName: 'English Unique Id', width: 150, sortingAlgorithm: customSortFn, cellTemplate: '<div class="ui-grid-cell-contents" >{{grid.getCellValue(row, col).termText}}</div>' });
        headerList.push('uuid');
       
        for (var j = 0; j < langList.length; j++) {
            var str2 = langList[j].LanguageName;
            str2 = str2.replace(/[^A-Z0-9]/ig, "");
            if (langList[j].IsRightToLeft == true) {
                $scope.defdata.push({ field: str2, displayName: langList[j].LanguageName, width: 400, sortingAlgorithm: customSortFn, enableHiding: false, gridMenuShowHideColumns: false, cellTemplate: '<div class="ui-grid-cell-contents" ng-class="{ Pending : grid.getCellValue(row, col).color == \'Pending\'&&!grid.appScope.hideColors, Approved : grid.getCellValue(row, col).color == \'Approved\'&&!grid.appScope.hideColors, Rejected : grid.getCellValue(row, col).color == \'Rejected\'&&!grid.appScope.hideColors}" >{{grid.getCellValue(row, col).termText}}</div>', cellClass: 'langg' });
                $scope.defdata.push({ field: 'Phonetics' + str2, displayName: 'Phonetics', width: 200, enableSorting: false, enableHiding: false, gridMenuShowHideColumns: false, visible: true, cellTemplate: '<div class="ui-grid-cell-contents" >{{grid.getCellValue(row, col).termText}}</div>', cellClass: 'langg' });
                $scope.defdata.push({ field: 'Plurals' + str2, displayName: 'Plurals', width: 200, enableSorting: false, enableHiding: false, gridMenuShowHideColumns: false, visible: true, cellTemplate: '<div class="ui-grid-cell-contents" >{{grid.getCellValue(row, col).termText}}</div>', cellClass: 'langg' });
            } else {
                $scope.defdata.push({ field: str2, displayName: langList[j].LanguageName, width: 400, sortingAlgorithm: customSortFn, enableHiding: false, gridMenuShowHideColumns: false, cellTemplate: '<div class="ui-grid-cell-contents" ng-class="{ Pending : grid.getCellValue(row, col).color == \'Pending\'&&!grid.appScope.hideColors, Approved : grid.getCellValue(row, col).color == \'Approved\'&&!grid.appScope.hideColors, Rejected : grid.getCellValue(row, col).color == \'Rejected\'&&!grid.appScope.hideColors}" >{{grid.getCellValue(row, col).termText}}</div>' });
                $scope.defdata.push({ field: 'Phonetics' + str2, displayName: 'Phonetics', width: 200, enableSorting: false, enableHiding: false, gridMenuShowHideColumns: false, visible: true, cellTemplate: '<div class="ui-grid-cell-contents" >{{grid.getCellValue(row, col).termText}}</div>' });
                $scope.defdata.push({ field: 'Plurals' + str2, displayName: 'Plurals', width: 200, enableSorting: false, enableHiding: false, gridMenuShowHideColumns: false, visible: true, cellTemplate: '<div class="ui-grid-cell-contents" >{{grid.getCellValue(row, col).termText}}</div>' });
            }
            headerList.push(str2);
            var tempString1 = 'Phonetics' + str2;
            headerList.push(tempString1);
            var tempString2 = 'Plurals' + str2;
            headerList.push(tempString2);

            $scope.defdata.push({ field: 'Status' + str2, displayName: 'Approval Status', width: 200, sortingAlgorithm: customSortFn, enableHiding: false, gridMenuShowHideColumns: false, visible: true, cellTemplate: '<div class="ui-grid-cell-contents" >{{grid.getCellValue(row, col).termText}}</div>' });
            var tempString3 = 'Status' + str2;
            headerList.push(tempString3);
        }

        //data in the grid
        $scope.facdata = [];
       
        for (var i = 0; i < glossaryTerms.ProjectAllMasterGlossary.length; i++) {
            $scope.data = {};
            var tempObj = {};
            tempObj['termText'] = glossaryTerms.ProjectAllMasterGlossary[i].GroupName;
            $scope.data['Section'] = tempObj;
            for (var j = 0; j < glossaryTerms.ProjectAllMasterGlossary[i].ProjectCategories.length; j++) {
                var str = glossaryTerms.ProjectAllMasterGlossary[i].ProjectCategories[j].CategoryId.toString();
                var tempObj = {};
                tempObj['termText'] = glossaryTerms.ProjectAllMasterGlossary[i].ProjectCategories[j].CategoryText;
                $scope.data[staticName.concat(str)] = tempObj;
            }
            var tempObj = {};
            tempObj['termText'] = glossaryTerms.ProjectAllMasterGlossary[i].MasterText;
            tempObj['MasterGlossaryImageUrl'] = glossaryTerms.ProjectAllMasterGlossary[i].MasterGlossaryImageUrl;
            $scope.data['Master'] = tempObj;
            var tempObj = {};
            tempObj['termText'] = glossaryTerms.ProjectAllMasterGlossary[i].MasterGlossaryId.toString();
            $scope.data['uuid'] = tempObj;

            for (var k = 0; k < glossaryTerms.ProjectAllMasterGlossary[i].ProjectLanguages.length; k++) {
                var str4 = glossaryTerms.ProjectAllMasterGlossary[i].ProjectLanguages[k].LanguageName;
                str4 = str4.replace(/ +/g, "");
                var tempObj = {};
                var tempObj1 = {};
                var tempObj2 = {};
                var tempObj3 = {};
                tempObj['termText'] = glossaryTerms.ProjectAllMasterGlossary[i].ProjectLanguages[k].TranslatedTerm;
                if (glossaryTerms.ProjectAllMasterGlossary[i].ProjectLanguages[k].PhoneticTerm == null) {
                    tempObj2['termText'] = '';
                } else {
                    tempObj2['termText'] = glossaryTerms.ProjectAllMasterGlossary[i].ProjectLanguages[k].PhoneticTerm;
                }
                if (glossaryTerms.ProjectAllMasterGlossary[i].ProjectLanguages[k].PluralTerm == null) {
                    tempObj3['termText'] = '';
                } else {
                    tempObj3['termText'] = glossaryTerms.ProjectAllMasterGlossary[i].ProjectLanguages[k].PluralTerm;
                }
                
                
                $scope.data['Phonetics' + str4] = tempObj2;
                $scope.data['Plurals' + str4] = tempObj3;
                if (glossaryTerms.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'TRANSLATION_COMPLETED' || glossaryTerms.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'APPROVER_APPROVED_IN_PROGRESS' || glossaryTerms.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'APPROVER_REJECTED_IN_PROGRESS' || glossaryTerms.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'CLIENT_APPROVER_IN_PROGRESS' || glossaryTerms.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'CLIENT_REJECTED_IN_PROGRESS') {
                  
                    tempObj1['termText'] = 'P';
                    tempObj1['color'] = 'Pending';
                    $scope.data['Status' + str4] = tempObj1;
                } else if (glossaryTerms.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'APPROVER_APPROVED' || glossaryTerms.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'CLIENT_APPROVED' ) {
                
                    tempObj1['termText'] = 'A';
                    tempObj1['color'] = 'Approved';
                    $scope.data['Status' + str4] = tempObj1;
                } else if (glossaryTerms.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'APPROVER_REJECTED' || glossaryTerms.ProjectAllMasterGlossary[i].ProjectLanguages[k].TermStatus == 'CLIENT_REJECTED') {
              
                    tempObj1['termText'] = 'R';
                    tempObj1['color'] = 'Rejected';
                    $scope.data['Status' + str4] = tempObj1;
                }
                tempObj['color'] = tempObj1['color'];
                $scope.data[str4] = tempObj;
            }
            $scope.facdata.push($scope.data);
            
        }
        $scope.gridOptions1.columnDefs = $scope.defdata;
        $scope.gridOptions1.data = $scope.facdata;
        if (statusFilter == true) {
            $scope.clearSearch();
        }
    };

     /**
     * @ngdoc
     * @name filterBySectionType
     * @methodOf Projects.controller:GlossaryAllSectionController
     * @param {Object} sectionType This is object selected sections details .
     * @description
     * This function is called on change of dropdown value of section dropdown. This is used to filter glossary data by selected section type. 
     * @returns {undefined} This method does not return.
     */
    $scope.filterBySectionType = function(sectionType){
        $scope.sectionTypeSelected = sectionType;
        $scope.facdata = [];
        $scope.defdata = [];
        init();
    };

    //GLMGR-1227
    /**
     * @ngdoc
     * @name sourceTermPendingSugg
     * @methodOf Projects.controller:GlossaryAllSectionController
     * @description
     * This function is called on Source Term pending suggestions checkbox. This is used to show only those terms with pending suggestions 
     * @returns {undefined} This method does not return.
     */
    $scope.sourceTermPendingSugg = function () {
            if ($scope.pendingSuggFilterOnGrid) {
                $('#pendingSuggFilter').prop('checked', true);
                $scope.glossaryCopy1 = angular.copy($scope.glossaryData);
                $scope.glossaryCopy1.ProjectAllMasterGlossary = [];
                for (var i = 0; i < $scope.glossaryData.ProjectAllMasterGlossary.length; i++) {
                    if ($scope.glossaryData.ProjectAllMasterGlossary[i].IsSuggestionExist === false) {
                        $scope.glossaryCopy1.ProjectAllMasterGlossary.push($scope.glossaryData.ProjectAllMasterGlossary[i]);
                    }
                }
                $scope.facdata = [];
                $scope.defdata = [];
                GlossaryUIGrid($scope.glossaryCopy1);
                $scope.checkPhonetics();
            }
            else {
                $('#pendingSuggFilter').prop('checked', false);
                $scope.facdata = [];
                $scope.defdata = [];
                GlossaryUIGrid($scope.glossaryData)
                $scope.checkPhonetics();
            }
    };
        
     /**
     * @ngdoc
     * @name init
     * @methodOf Projects.controller:GlossaryAllSectionController
     * 
     * @description
     * This function is used for initialisation of the variables on page load
     * @return {undefined} This method does not return.
     */
    var init = function () {
        //GLMGR-231 navigated from Project landing page
        if (sessionStorage.getItem('navigateToAllGlossary') === 'true') {
            sessionStorage.setItem('hideAddInfoCols', 'true');
            sessionStorage.setItem('hidePhoneticPluralCols', 'true');
            if (sessionStorage.getItem('excludeNTL_FD') === 'true') {
                sessionStorage.setItem('excludeNTL_FD', '');
                $scope.sectionTypeSelected = $scope.sectionTypeDropdown[1];
            } else if (sessionStorage.getItem('excludeNTL_FD') === 'false') {
                sessionStorage.setItem('excludeNTL_FD', '');
                $scope.sectionTypeSelected = $scope.sectionTypeDropdown[0];
            }
            sessionStorage.setItem('navigateToAllGlossary', 'false');
        }

        //GLMGR-1239 Retain hide Add info column checkbox on refresh 
        $scope.isCheckedAddInfoCols = JSON.parse(sessionStorage.getItem('hideAddInfoCols'));
        $scope.hideAddInfoCols = $scope.isCheckedAddInfoCols;
        if (JSON.parse(sessionStorage.getItem('hidePhoneticPluralCols')) == '' || JSON.parse(sessionStorage.getItem('hidePhoneticPluralCols')) == undefined) {
            sessionStorage.setItem('hidePhoneticPluralCols', 'false');
        } else {
            $scope.hidePhoneticPluralCols = JSON.parse(sessionStorage.getItem('hidePhoneticPluralCols'));
        }
        

        //hide empty add info column checked by default
        $scope.hideEmptyAddInfoCols = true;
        $scope.isCheckedEmptyInfoCols = true;

        //hide source term sugg checkbox
        if (sessionStorage.getItem("filterOnStatus") === "1") {
            $scope.showPendingSuggOnGrid = false;
        }

        $scope.showGlossaryPage = false;
        $scope.showSaveButton = false;
        $scope.projectId = commonService.getSessionData('projectIBreadCrumb');
        $scope.ProjectTitle = commonService.getSessionData('AllsectionProjectTitle');
        $scope.SecureTitle = commonService.getSessionData('AllsectionSecureTitle');
        $scope.ClientName_str = commonService.getSessionData('AllsectionClientName');
        $scope.LangList = commonService.getSessionData('AllglossaryLangList');
        $scope.AllLangList = commonService.getSessionData('AllsectionAllLanguages');
        $scope.showLoader = true;     

        var catEmpty = {
            CategoryId: 0,
            CategoryName: '',
            CategoryText: ''
        };

        var langEmpty = {
            LanguageId: 0,
            LanguageName: '',
            LanguageText: '',
            ProjectLangaugeId: ''
        };
        $scope.glossaryView = true;

        var initData = {};
        initData['ProjectId'] = $scope.projectId;
        initData['UserId'] = commonService.getLocalData('userDetails').UserId;
        initData['ProjectLanguages'] = $scope.LangList;
        initData['SectionType'] = $scope.sectionTypeSelected.value; //GLMGR-763
        Glossary.getAllsection(initData, function (glossaryTerms) {
            $scope.showLoader = false;
            $scope.glossaryData = glossaryTerms;
            if (glossaryTerms.ProjectAllLanguages.length > 0) {
                $scope.langSelected = true;
                $scope.FilterLanglist = glossaryTerms.ProjectAllLanguages;
            }

            $scope.showLoader = false;

            //GLMGR-622 start

            $scope.pendingTranslationsFilterValue = sessionStorage.getItem("pendingTranslationsFilter");
            $scope.pendingApprovalsFilterValue = sessionStorage.getItem("pendingApprovalsFilter");
            $scope.approvedFilterValue = sessionStorage.getItem("approvedFilter");
            $scope.rejectedFilterValue = sessionStorage.getItem("rejectedFilter");
            $scope.pendingSuggFilterValue = sessionStorage.getItem("pendingSuggFilter");


            if (sessionStorage.getItem("filterOnStatus") === "1") {
                if ($scope.glossaryData.ProjectAllLanguages.length = 1) {

                    $scope.FilterLang = $scope.FilterLanglist[0];
                }
                if (sessionStorage.getItem("filterImage") !== 'undefined') {
                    $scope.filterImage = sessionStorage.getItem("filterImage");
                }
                ($scope.pendingTranslationsFilterValue > 0) ? ($('#pendingTranslationsFilter').attr('checked', 'checked')) : ($('#pendingTranslationsFilter').attr('checked', false));
                ($scope.pendingApprovalsFilterValue > 0) ? ($('#pendingApprovalsFilter').attr('checked', 'checked')) : ($('#pendingApprovalsFilter').attr('checked', false));
                ($scope.approvedFilterValue > 0) ? ($('#approvedFilter').attr('checked', 'checked')) : ($('#approvedFilter').attr('checked', false));
                ($scope.rejectedFilterValue > 0) ? ($('#rejectedFilter').attr('checked', 'checked')) : ($('#rejectedFilter').attr('checked', false));
                ($scope.pendingSuggFilterValue > 0) ? ($('#pendingSuggFilter').attr('checked', 'checked')) : ($('#pendingSuggFilter').attr('checked', false));
                $scope.filterOptions();
                $scope.checkPhonetics();
            } else {
                GlossaryUIGrid(glossaryTerms);
                $scope.checkPhonetics();
            }

            dynamicScreenHeight();
            //GLMGR-622 end

            // timeout function for auto refresh
            setTimeout(function () {
                location.reload();
            }, 300000);

            $scope.hideAddInfoColumns(); //GLMGR-231
        });
    };
    init();
 
}]);