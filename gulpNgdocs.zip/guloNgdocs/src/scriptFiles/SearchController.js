/**
 * @ngdoc controller
 * @name Search.controller:SearchController
 * @element div
 *
 * @description
 * This Controller is responsible for search term with different criteria.
 *
 * @requires AngularJS.$scope
 * @requires AngularJS.$http
 * @requires AngularJS.$route
 * @requires AngularJS.$location
 * @requires common.commonService
 * @requires Search.SearchTermService
 * 
 * @property {string} currentUserRoleName:String  This property is logged in user's role name (eg. Admin, Super Admin etc.).
 * @property {number} currentUserId:Number  This property is user id of logged in user.
 * @property {String} DisplayAsTitle:String  This property is title shown on toggle button.
 * @property {object} userDetails:Object This is object stores the user deatails received from backend when user is logged in 
 * @property {boolean} isListview:Boolean This property is boolean value. If current view is list view it's true else false. 
 * @property {Array} listViewResult:Array This property is array which contains result in list view .
 * @property {Array} gridViewResult:Array This property is array which contains result in grid view .
 * @property {Array} searchTypeList:Array This property is array which contains search type data.
 * @property {Array} translationStatusList:Array This property is array which contains translation status list.
 * @property {Array} searchTermBrandData:Array This property is array which contains all brands received from db.
 * @property {Array} searchTermProjectData:Array This property is array which contains all projects received from db.
 * @property {Array} langDropList:Array This property is array which contains all languages received from db.
 * @property {Object} InputSearchClientData:Object This property is object which contains all the applied search data. 
 * @property {boolean} listViewHeading:Boolean This property is boolean value. Used to show/hide heading in the list view
 * @property {boolean} hideApproverStatus:Boolean This property is boolean value. Used to show/hide approval status dropdown.
 * @property {String} clientLable:String This property is used to display label on client dropdown
 * @property {String} brnadLable:String This property is used to display label on brand dropdown
 * @property {String} projectLable:String This property is used to display label on project dropdown
 * @property {String} languageLable:String This property is used to display label on language dropdown
 * @property {String} statusLable:String This property is used to display label on status dropdown
 * @property {boolean} showBackButton:Boolean This property is boolean value. Used to show/hide back button on grid view..
 * @property {Object} searchValidObj:Object This property is object used for validation of search filters.
 * 
 */

Search.controller('searchController', ['$scope', '$http', '$location', 'SearchTermService', 'commonService', function ($scope, $http, $location, SearchTermService, commonService) {
    $scope.showBrands = false;
    var currentUserRoleName = commonService.getLocalData('userDetails').UserRoles[0].UserRoleName;
    var currentUserId = commonService.getLocalData('userDetails').UserId;
    //search feature GLMGR-678
    $scope.DisplayAsTitle = "Display As List";
    $scope.isListview = false;
    $scope.listViewResult = [];
    $scope.gridViewResult = [];
    $scope.searchTypeList = [];
    $scope.translationStatusList = [];
    $scope.searchTermBrandData = [];
    $scope.searchTermProjectData = [];
    $scope.langDropList = [];
    $scope.ProjectList = [];
    $scope.approvalStatus = [];
    $scope.LanguageLists = [];
    var InputSearchClientData = {};
    InputSearchClientData.ClientIds = [];
    InputSearchClientData.BrandIds = [];
    InputSearchClientData.ProjectIds = [];
    InputSearchClientData.UserId = currentUserId;
    InputSearchClientData.Role = currentUserRoleName;
    InputSearchClientData.Inconsistencies = false;
    InputSearchClientData.Translation = false;
    $scope.transLangColumns = [];
    $scope.listViewHeading = false;
    $scope.searchTextNotRequired = true;
    $scope.hideApproverStatus = true;
    $scope.showLoader = false;
    $scope.searchWord = "";

    $scope.clientLable = "Select Client(s)";
    $scope.brnadLable = "Select Brand(s)";
    $scope.projectLable = "Select Project(s)";
    $scope.languageLable = "Select Language(s)";
    $scope.statusLable = "Select Status";
    $scope.noDataAvailable = false;
    $scope.showBackButton = false;

    //validation object
    $scope.searchValidObj = {
        "isSearchTypeRequired": false,
        "isClientRequired": false,
        "isSearchTextRequired": false,
        "isisLanguageRequired": false
    };
    var SearchInputInfoDetails = {};

    //set hashURL for GLMGR-1189
    sessionStorage.setItem('hashURL', null);

    /**
     * @ngdoc
     * @name toggleSearchView
     * @methodOf Search.controller:SearchController
     * @description
     * This function is called toggle button on search page. This function is used to toggle search view list/grid
     * @returns {undefined} This method does not return.
     */
    $scope.toggleSearchView = function () {
        $scope.showBackButton = false;
        if ($scope.isListview) {
            $scope.isListview = false;
            $scope.hideApproverStatus = true;
            $scope.DisplayAsTitle = "Display As List";
        } else {
            $scope.isListview = true;
            $scope.hideApproverStatus = false;
            $scope.DisplayAsTitle = "Display As Grid";
        }
        if (!_.isEmpty(SearchInputInfoDetails)) {
            SearchInputInfoDetails.IsListView = $scope.isListview;
            $scope.listViewResult = [];
            $scope.gridViewResult = [];
            $scope.showLoader = true;
            SearchTermService.searchButtonMethod(SearchInputInfoDetails, function (data) {
                $scope.listViewResult = data;
                if ($scope.listViewResult.length === 0 || ($scope.listViewResult[0].ProjectMasterGlossaries && $scope.listViewResult[0].ProjectMasterGlossaries.length === 0)) {
                    $scope.noDataAvailable = true;
                } else {
                    $scope.noDataAvailable = false;
                }
                if ($scope.isListview) {
                    $scope.searchWord = SearchInputInfoDetails.Term;
                    $scope.projectCount = $scope.listViewResult.length;
                    $scope.listViewHeading = true;
                    $scope.hideApproverStatus = false;
                    $scope.showLoader = false;
                }
                //language column count
                if (!$scope.isListview) {
                    $scope.gridViewResult = $scope.listViewResult[0].ProjectMasterGlossaries;
                    //creating distinct langs for <th>
                    for (var i = 0; i < $scope.gridViewResult.length; i++) {
                        if ($scope.gridViewResult[i].TranslationDetails && $scope.gridViewResult[i].TranslationDetails.length > 0) {
                            for (var j = 0; j < $scope.gridViewResult[i].TranslationDetails.length; j++) {
                                if ($scope.transLangColumns.filter(function (e) { return e.LanguageId == $scope.gridViewResult[i].TranslationDetails[j].LanguageId; }).length > 0) {
                                    continue;
                                } else {
                                    $scope.transLangColumns.push($scope.gridViewResult[i].TranslationDetails[j]);
                                }
                            }
                        }
                    }
                    $scope.showLoader = false;
                }
                setTimeout(function () { dynamicScreenHeight(); }, 500); // to set height of tbody
            });
        }
    };

    /**
     * @ngdoc
     * @name isSearchValid
     * @methodOf Search.controller:SearchController
     * @param {String} field This is field which need to validated.
     * @description
     * This function is called on search function. This function is used to validated before performing search operation.
     * @returns {Boolean} This method return boolean true/false , if all filters applied are ok then true else false.
     */
    $scope.isSearchValid = function (field) {
        var isSearchTypeValid = true;
        var isSearchTextValid = true;
        var isClientValid = true;
        var isLanguageValid = true;
        var isAllvalid = true;
        if (!$scope.searchType) {
            $scope.searchValidObj.isSearchTypeRequired = true;
            isSearchTypeValid = false;
            if (field === 'searchType') {
                return;
            }

        } else {
            if ($scope.searchType.SearchText === "Inconsistencies") {
                $scope.searchTextNotRequired = false;
            } else {
                $scope.searchTextNotRequired = true;
            }
            $scope.searchValidObj.isSearchTypeRequired = false;
            isSearchTypeValid = true;
            if (field === 'searchType') {
                return;
            }


            if ($scope.searchType.SearchText !== "Inconsistencies") {
                if (!$scope.searchText) {
                    $scope.numberRequired = false;
                    $scope.searchValidObj.isSearchTextRequired = true;
                    isSearchTextValid = false;
                    if (field === 'searchText') {
                        return;
                    }
                } else {
                    if ($scope.searchType.SearchText === "UniqueId") {
                        if (!(/^\d+$/.test($scope.searchText))) {
                            $scope.searchValidObj.isSearchTextRequired = false;
                            $scope.numberRequired = true;
                            isSearchTextValid = false;
                        } else {
                            $scope.searchValidObj.isSearchTextRequired = false;
                            $scope.numberRequired = false;
                            isSearchTextValid = true;
                        }
                    } else {
                        $scope.numberRequired = false;
                        $scope.searchValidObj.isSearchTextRequired = false;
                        isSearchTextValid = true;
                    }
                    if (field === 'searchText') {
                        return;
                    }
                }
            } else {
                $scope.searchValidObj.isSearchTextRequired = false;
                isSearchTextValid = true;
                if (field === 'searchText') {
                    return;
                }
            }

            if (!$scope.ClientLists || $scope.ClientLists.length === 0) {
                $scope.searchValidObj.isClientRequired = true;
                isClientValid = false;
                if (field === 'client') {
                    return;
                }
            } else {
                $scope.searchValidObj.isClientRequired = false;
                isClientValid = true;
                if (field === 'client') {
                    return;
                }
            }

            if (!$scope.LanguageLists || $scope.LanguageLists.length === 0) {
                $scope.searchValidObj.isisLanguageRequired = true;
                isLanguageValid = false;
            } else {
                $scope.searchValidObj.isisLanguageRequired = false;
                isLanguageValid = true;
            }
        }


        if (isSearchTypeValid && isSearchTextValid && isClientValid && isLanguageValid) {
            isAllvalid = true;
        } else {
            isAllvalid = false;
        }
        return isAllvalid;
    };

    /**
     * @ngdoc
     * @name search
     * @methodOf Search.controller:SearchController
     * @description
     * This function is called search button on search page. This function is used to perform search operation after applying all filters.
     * @returns {undefined} This method does not return.
     */
    $scope.search = function (btn) {
        if (btn === 'back') {
            $scope.showBackButton = false;
            $scope.isListview = true;
        }
        if ($scope.isSearchValid("")) {
            $scope.showBackButton = false;
            //make trasnlation columns empty for gridview 
            $scope.transLangColumns = [];
            //search button info details
            SearchInputInfoDetails.UserId = currentUserId;
            SearchInputInfoDetails.Role = currentUserRoleName;
            SearchInputInfoDetails.ClientIdlist = [];
            SearchInputInfoDetails.LanguageId = [];
            SearchInputInfoDetails.ProjectId = [];
            SearchInputInfoDetails.BrandIdList = [];
            SearchInputInfoDetails.ProjectIdList = [];
            SearchInputInfoDetails.TranslationStatusId = [];
            SearchInputInfoDetails.Term = $scope.searchText;
            SearchInputInfoDetails.SerachType = $scope.searchType.SearchText;
            SearchInputInfoDetails.IsListView = $scope.isListview;
            SearchInputInfoDetails.IsHavingPermission = true;


            //set MasterGlossaryId
            if ($scope.searchType.SearchText === "UniqueId") {
                SearchInputInfoDetails.MasterGlossaryId = $scope.searchText;
            } else {
                SearchInputInfoDetails.MasterGlossaryId = 0;
            }

            //set ismastersearch
            if ($scope.LanguageLists) {
                if ($scope.LanguageLists.length == 1 && $scope.LanguageLists[0].LanguageName === "English") {
                    SearchInputInfoDetails.IsMasterSearch = true;
                } else {
                    SearchInputInfoDetails.IsMasterSearch = false;
                }
            } else {
                SearchInputInfoDetails.IsMasterSearch = false;
            }

            //client ids
            for (var i = 0; i < $scope.ClientLists.length; i++) {
                SearchInputInfoDetails.ClientIdlist.push($scope.ClientLists[i].ClientId);
            }

            //brand ids
            if ($scope.BrandList) {
                for (var i = 0; i < $scope.BrandList.length; i++) {
                    SearchInputInfoDetails.BrandIdList.push($scope.BrandList[i].BrandId);
                }
            }

            //project ids
            if ($scope.ProjectList && $scope.ProjectList.length > 0) {
                for (var i = 0; i < $scope.ProjectList.length; i++) {
                    SearchInputInfoDetails.ProjectId.push($scope.ProjectList[i].ProjectEncriptValue);
                }
            } else {
                for (var i = 0; i < $scope.searchTermProjectData.length; i++) {
                    SearchInputInfoDetails.ProjectId.push($scope.searchTermProjectData[i].ProjectEncriptValue);
                }
            }

            //lang ids

            if ($scope.LanguageLists) {
                for (var i = 0; i < $scope.LanguageLists.length; i++) {
                    SearchInputInfoDetails.LanguageId.push($scope.LanguageLists[i].Id);
                }
            }


            //trasn status
            if ($scope.approvalStatus && $scope.approvalStatus.length !== 0) {
                for (var i = 0; i < $scope.approvalStatus.length; i++) {
                    SearchInputInfoDetails.TranslationStatusId.push($scope.approvalStatus[i].TranslationStatusValue)
                }
            } else if (!$scope.approvalStatus || $scope.approvalStatus.length == 0) {
                for (var i = 0; i < $scope.translationStatusList.length; i++) {
                    SearchInputInfoDetails.TranslationStatusId.push($scope.translationStatusList[i].TranslationStatusValue)
                }
            }

            //for inconsistencies send all language ids and trans status ids
            if ($scope.searchType.SearchText === "Inconsistencies") {
                if (!$scope.LanguageLists || $scope.LanguageLists.length == 0) {
                    SearchInputInfoDetails.LanguageId = [];
                    for (var i = 0; i < $scope.langDropList.length; i++) {
                        SearchInputInfoDetails.LanguageId.push($scope.langDropList[i].Id);
                    }
                }

                if (!$scope.approvalStatus || $scope.approvalStatus.length == 0) {
                    SearchInputInfoDetails.TranslationStatusId = [];
                    for (var i = 0; i < $scope.translationStatusList.length; i++) {
                        SearchInputInfoDetails.TranslationStatusId.push($scope.translationStatusList[i].TranslationStatusValue)
                    }
                }
            }
            $scope.listViewResult = [];
            $scope.gridViewResult = [];
            $scope.showLoader = true;
            SearchTermService.searchButtonMethod(SearchInputInfoDetails, function (data) {
                console.log("data--", data);
                $scope.listViewResult = data;
                if ($scope.listViewResult.length === 0 || ($scope.listViewResult[0].ProjectMasterGlossaries && $scope.listViewResult[0].ProjectMasterGlossaries.length === 0)) {
                    $scope.noDataAvailable = true;
                } else {
                    $scope.noDataAvailable = false;
                }
                if ($scope.isListview) {
                    $scope.searchWord = SearchInputInfoDetails.Term;
                    $scope.projectCount = $scope.listViewResult.length;
                    $scope.listViewHeading = true;
                    $scope.hideApproverStatus = false;
                    $scope.showLoader = false;
                }
                //language column count
                if (!$scope.isListview) {
                    $scope.gridViewResult = $scope.listViewResult[0].ProjectMasterGlossaries;
                    //creating distinct langs for <th>
                    for (var i = 0; i < $scope.gridViewResult.length; i++) {
                        if ($scope.gridViewResult[i].TranslationDetails && $scope.gridViewResult[i].TranslationDetails.length > 0) {
                            for (var j = 0; j < $scope.gridViewResult[i].TranslationDetails.length; j++) {
                                if ($scope.transLangColumns.filter(function (e) { return e.LanguageId == $scope.gridViewResult[i].TranslationDetails[j].LanguageId; }).length > 0) {
                                    continue;
                                } else {
                                    $scope.transLangColumns.push($scope.gridViewResult[i].TranslationDetails[j]);
                                }
                            }
                        }
                    }
                    $scope.showLoader = false;
                }
                setTimeout(function () { dynamicScreenHeight(); }, 500); // to set height of tbody
            });
        }

    };

      /**
     * @ngdoc
     * @name resetOnChange
     * @methodOf Search.controller:SearchController
     * @description
     * This function is called onChange function of search type dropdown to reset all other applied filters.
     * @returns {undefined} This method does not return.
     */
    $scope.resetOnChange = function () {
        $scope.listViewResult = [];
        $scope.gridViewResult = [];
        $scope.searchText = "";
        $scope.ClientLists.length = 0;
        $scope.BrandList.length = 0;
        $scope.ProjectList.length = 0;
        $scope.LanguageLists.length = 0;
        $scope.approvalStatus.length = 0;

        $scope.clientLable = "Select Client(s)";
        $scope.brnadLable = "Select Brand(s)";
        $scope.projectLable = "Select Project(s)";
        $scope.languageLable = "Select Language(s)";
        $scope.statusLable = "Select Status";
    };

    //onselect of status
    $scope.onSelectStatus = function () {
        resetButtonLabel();
    };

   /**
     * @ngdoc
     * @name onSelectLangauge
     * @methodOf Search.controller:SearchController
     * @description
     * This function is called when language is selected from language filter.This is used to set selected languages  name as label of dropdown
     * @returns {undefined} This method does not return.
     */
    $scope.onSelectLangauge = function () {
        $scope.approvalStatus.length = 0;
        resetButtonLabel();

        $scope.isSearchValid("");
        if (($scope.searchType.SearchText === "UniqueId" || $scope.searchType.SearchText === "Term") && $scope.LanguageLists && $scope.LanguageLists.length === 1 && $scope.LanguageLists[0].LanguageName === "English") {
            $scope.hideApproverStatus = false;
        }
    };

     /**
     * @ngdoc
     * @name resetButtonLabel
     * @methodOf Search.controller:SearchController
     * @description
     * This function is called onChange function of search type dropdown to reset all other applied filters.
     * @returns {undefined} This method does not return.
     */
    var resetButtonLabel = function () {
        //set button labels
        if (!$scope.ClientLists || $scope.ClientLists.length === 0) {
            $scope.clientLable = "Select Client(s)";
        }
        if (!$scope.BrandList || $scope.BrandList.length === 0) {
            $scope.brnadLable = "Select Brand(s)";
        }
        if (!$scope.ProjectList || $scope.ProjectList.length === 0) {
            $scope.projectLable = "Select Project(s)";
        }
        if (!$scope.LanguageLists || $scope.LanguageLists.length === 0) {
            $scope.languageLable = "Select Language(s)";
        }
        if (!$scope.approvalStatus || $scope.approvalStatus.length === 0) {
            $scope.statusLable = "Select Status";
        }
    };

    /**
     * @ngdoc
     * @name onSelectClient
     * @methodOf Search.controller:SearchController
     * @description
     * This function is called onChange function of client dropdown to populate brands and projects assigned to that client.
     * @returns {undefined} This method does not return.
     */
    $scope.onSelectClient = function () {
        $scope.isSearchValid("client");

        //reset other dropdowns
        $scope.BrandList.length = 0;
        $scope.ProjectList.length = 0;
        $scope.LanguageLists.length = 0;
        $scope.approvalStatus.length = 0;

        resetButtonLabel();

        InputSearchClientData.ClientIds = [];
        InputSearchClientData.BrandIds = [];
        InputSearchClientData.ProjectIds = [];


        //isConsistence check
        if ($scope.searchType.SearchText === "Inconsistencies") {
            InputSearchClientData.Inconsistencies = true;
        } else {
            InputSearchClientData.Inconsistencies = false;
        }

        //is translation check
        if ($scope.searchType.SearchText === "Translation") {
            InputSearchClientData.Translation = true;
        } else {
            InputSearchClientData.Translation = false;
        }

        //client ids
        for (var i = 0; i < $scope.ClientLists.length; i++) {
            InputSearchClientData.ClientIds.push($scope.ClientLists[i].ClientId);
        }
        InputSearchClientData.BrandIds = [];
        InputSearchClientData.ProjectIds = [];

        SearchTermService.searchClientsBrandProjectLanguagePopulatedData(InputSearchClientData, function (data) {
            $scope.searchTermBrandData = data.ClientBrandList;
            $scope.searchTermProjectData = data.ClientUserProjectList;
            $scope.langDropList = data.ClientUserLanguageList;

        });
    };

   /**
     * @ngdoc
     * @name onSelectBrands
     * @methodOf Search.controller:SearchController
     * @description
     * This function is called onChange function of brand dropdown to populate projects assigned to selected client and of selected brand.
     * @returns {undefined} This method does not return.
     */
    $scope.onSelectBrands = function () {
        //reset other dropdowns
        $scope.ProjectList.length = 0;
        $scope.LanguageLists.length = 0;
        $scope.approvalStatus.length = 0;

        resetButtonLabel();

        InputSearchClientData.ClientIds = [];
        InputSearchClientData.BrandIds = [];
        InputSearchClientData.ProjectIds = [];

        //isConsistence check
        if ($scope.searchType.SearchText === "Inconsistencies") {
            InputSearchClientData.Inconsistencies = true;
        } else {
            InputSearchClientData.Inconsistencies = false;
        }

        //isTranslation check
        if ($scope.searchType.SearchText === "Translation") {
            InputSearchClientData.Translation = true;
        } else {
            InputSearchClientData.Translation = false;
        }

        for (var i = 0; i < $scope.ClientLists.length; i++) {
            InputSearchClientData.ClientIds.push($scope.ClientLists[i].ClientId);
        }

        for (var i = 0; i < $scope.BrandList.length; i++) {
            InputSearchClientData.BrandIds.push($scope.BrandList[i].BrandId);
        }
        InputSearchClientData.ProjectIds = [];
        SearchTermService.searchBrandsProjectLanguagePopulatedData(InputSearchClientData, function (data) {
            $scope.searchTermProjectData = data.ClientUserProjectList;
            $scope.langDropList = data.ClientUserLanguageList;
        });
    };

    /**
     * @ngdoc
     * @name onSelectBrands
     * @methodOf Search.controller:SearchController
     * @description
     * This function is called onChange function of projects dropdown, This is used to select projects from dropdown and set selected project name as label of dropdown.
     * @returns {undefined} This method does not return.
     */
    $scope.onSelectProject = function () {
        $scope.LanguageLists.length = 0;
        $scope.approvalStatus.length = 0;

        resetButtonLabel();

        InputSearchClientData.ClientIds = [];
        InputSearchClientData.BrandIds = [];
        InputSearchClientData.ProjectIds = [];

        //isConsistence check
        if ($scope.searchType.SearchText === "Inconsistencies") {
            InputSearchClientData.Inconsistencies = true;
        } else {
            InputSearchClientData.Inconsistencies = false;
        }

        //isTranslation check
        if ($scope.searchType.SearchText === "Translation") {
            InputSearchClientData.Translation = true;
        } else {
            InputSearchClientData.Translation = false;
        }

        for (var i = 0; i < $scope.ClientLists.length; i++) {
            InputSearchClientData.ClientIds.push($scope.ClientLists[i].ClientId);
        }

        if ($scope.BrandList) {
            for (var i = 0; i < $scope.BrandList.length; i++) {
                InputSearchClientData.BrandIds.push($scope.BrandList[i].BrandId);
            }
        }

        for (var i = 0; i < $scope.ProjectList.length; i++) {
            InputSearchClientData.ProjectIds.push($scope.ProjectList[i].ProjectEncriptValue);
        }
        SearchTermService.searchProjectsLanguagePopulatedData(InputSearchClientData, function (data) {
            $scope.langDropList = data.ClientUserLanguageList;
        });
    };

    /**
     * @ngdoc
     * @name projectResultClick
     * @methodOf Search.controller:SearchController
     * @param {Object} project This is object contains all the details of selected project.
     * @description
     * This function is called on click of project title in list view search result. This function is used to show grid view of selected project
     * @returns {undefined} This method does not return.
     */
    $scope.projectResultClick = function (project) {
        if ($scope.searchType.SearchText === "Inconsistencies" || $scope.searchType.SearchText === "Translation") {
            SearchInputInfoDetails.IsListView = false;
            SearchInputInfoDetails.ProjectId = [];
            SearchInputInfoDetails.ProjectId.push(project.ProjectIdEncrypted);
            SearchTermService.searchDetailsOnProjectClick(SearchInputInfoDetails, function (data) {
                $scope.gridViewResult = data[0].ProjectMasterGlossaries;
                for (var i = 0; i < $scope.gridViewResult.length; i++) {
                    if ($scope.gridViewResult[i].TranslationDetails && $scope.gridViewResult[i].TranslationDetails.length > 0) {
                        for (var j = 0; j < $scope.gridViewResult[i].TranslationDetails.length; j++) {
                            if ($scope.transLangColumns.filter(function (e) { return e.LanguageId == $scope.gridViewResult[i].TranslationDetails[j].LanguageId; }).length > 0) {
                                continue;
                            } else {
                                $scope.transLangColumns.push($scope.gridViewResult[i].TranslationDetails[j]);
                            }
                        }
                    }
                }
                $scope.isListview = false;
                $scope.showBackButton = true;
            });
        } else {
            if (project.IsSelectedLanguagePresent || SearchInputInfoDetails.IsMasterSearch) {
                SearchInputInfoDetails.IsListView = false;
                SearchInputInfoDetails.ProjectId = [];
                SearchInputInfoDetails.ProjectId.push(project.ProjectIdEncrypted);
                SearchTermService.searchDetailsOnProjectClick(SearchInputInfoDetails, function (data) {
                    $scope.gridViewResult = data[0].ProjectMasterGlossaries;
                    for (var i = 0; i < $scope.gridViewResult.length; i++) {
                        if ($scope.gridViewResult[i].TranslationDetails && $scope.gridViewResult[i].TranslationDetails.length > 0) {
                            for (var j = 0; j < $scope.gridViewResult[i].TranslationDetails.length; j++) {
                                if ($scope.transLangColumns.filter(function (e) { return e.LanguageId == $scope.gridViewResult[i].TranslationDetails[j].LanguageId; }).length > 0) {
                                    continue;
                                } else {
                                    $scope.transLangColumns.push($scope.gridViewResult[i].TranslationDetails[j]);
                                }
                            }
                        }
                    }
                    $scope.isListview = false;
                    $scope.showBackButton = true;
                });
            } else {
                $('#listViewNoLanguage').modal('show');
            }
        }
    };

    /**
     * @ngdoc
     * @name gridResultClick
     * @methodOf Search.controller:SearchController
     * @param {Object} colData This is object contains all the details of selected column in search result table.
     * @param {Object} rowData This is object contains all the details of selected row in search result table.
     * @description
     * This function is called on click of fields in grid search result. This function is used to redirect to particular page. eg when clicked on project title, page is redirected to project info page. 
     * @returns {undefined} This method does not return.
     */
    $scope.gridResultClick = function (colData, rowData) {
        sessionStorage.setItem('projectIBreadCrumb', JSON.stringify(rowData.ProjectIdEncrypted));
        sessionStorage.setItem('unEncriptedProjectId', JSON.stringify(rowData.ProjectId));
        sessionStorage.setItem('projectId', JSON.stringify(rowData.ProjectIdEncrypted));
        sessionStorage.setItem('headerId', JSON.stringify(rowData.GroupId));
        sessionStorage.setItem('HasWritePrivilege', JSON.stringify(rowData.IsHavingProjectLevelPermission));
        sessionStorage.setItem('PrivilegeIdInDb', JSON.stringify(colData.PrivilegeIdInDB));
        //GlossarySection of session
        var Glossarysection = {};
        Glossarysection.GlossaryGroupHeader = rowData.GroupName;
        Glossarysection.GlossaryGroupRowVersion = [];
        Glossarysection.Id = rowData.GroupId;
        Glossarysection.IsSecret = false; //has to come from backend
        Glossarysection.IsSectionComplete = true; //has to come from backend
        Glossarysection.ProjectId = rowData.ProjectId;
        Glossarysection.SectionId = rowData.GroupId;
        sessionStorage.setItem('GlossarySection', JSON.stringify(Glossarysection));
        sessionStorage.setItem('InstanceSettingProjectId', JSON.stringify(commonService.getSessionData('unEncriptedProjectId')));

        //set section type in session
        var temp;
        if (rowData.SectionType === 1) {
            temp = 'default';
        } else if (rowData.SectionType === 2) {
            temp = 'ntl';
        }
        sessionStorage.setItem('glossaryTab', JSON.stringify(temp));
        if (!colData) {
            return;
        }
        //clicked on translation
        if (colData !== 'section' && colData !== 'source_term' && colData !== 'project_title') {
            if ('LanguageId' in colData) {
                sessionStorage.setItem('translationProjectLanguageId', JSON.stringify(colData.ProjectLanguageId));
                sessionStorage.setItem('glossaryNewLang', JSON.stringify(colData));
                sessionStorage.setItem('SearchToTranslation', true);
                window.location = "Projects#/glossary";
            }
        }


        //clicked on section or source term
        if (colData === 'section' || colData === 'source_term') {
            window.location = "Projects#/glossary";
        }

        //clicked on project title
        if (colData === 'project_title') {
            sessionStorage.setItem('SearchToProjects', true);
            window.location = "Projects#/";
        }

    };

     /**
     * @ngdoc
     * @name init
     * @methodOf Search.controller:SearchController
     * @description
     * This function is called initially when page is loaded. This function is used for initialisation of the variables on page load.
     * @returns {undefined} This method does not return.
     */
    var init = function () {
        $scope.projectId = commonService.getSessionData('projectIBreadCrumb');

        $scope.HasWritePrivilege = commonService.getSessionData('HasWritePrivilege');

        var resorceIdx = 0;
        sessionStorage.setItem('resourcePageId', JSON.stringify(resorceIdx));
        sessionStorage.setItem("filterStatus", "undefined");
        sessionStorage.setItem("filterImage", "undefined");
        sessionStorage.setItem("pendingTranslationsFilter", "0");
        sessionStorage.setItem("pendingApprovalsFilter", "0");
        sessionStorage.setItem("approvedFilter", "0");
        sessionStorage.setItem("rejectedFilter", "0");
        sessionStorage.setItem("filterOnStatus", "0");

        //GLMGR-678 SearchTypePopulatedData service on page load
        SearchTermService.searchTypePopulatedData(function (searchTypeData) {
            $scope.searchTypeList = searchTypeData;
        });

        //GLMGR-678 Approval status data on page load
        SearchTermService.searchTranslationStatusPopulatedData(function (translationStatusData) {
            $scope.translationStatusList = translationStatusData;
        });

        SearchTermService.getSearchTermPrePopulatedData(currentUserId, currentUserRoleName, function (initialdata) {
            hideColors = false;
            $scope.searchTermInitialData = initialdata;
            dynamicScreenHeight();
        });

        dynamicScreenHeight();

    };

    init();
}]);