/**
 * @ngdoc service
 * @name common.commonService 
 * @requires AngularJS.$http
 * 
 * @description
 * This is a common service used by all controllers in application.This service contains all the common functions eg.gerUserGuide method is used to download help document. 
 *  
**/

angular.module('common', ['projectIdService', 'ng-breadcrumbs'])
.service('commonService', ['$http', function ($http) {
    var return_data = {

        /**
        * @ngdoc function
        * @name common.commonService#getExpirationTime
        * @methodOf common.commonService
        * @description
        * This service is used to get session expiration  timeout
        * @returns {Number}  This method returns date and time for cookie.
        */
        getExpirationTime: function (callback) {
            $http({
                method: "get",
                url: 'Login/GetExpirationTimeOut'
            })
            .success(function (expTime) {
                callback(expTime);
            })
           .error(function (e) { 
               callback("error");
           })
        },

         /**
        * @ngdoc function
        * @name common.commonService#getUserRecordDeleted
        * @param {Number} userId This is user id of logged in user.
        * @param {Number} pageId This is page id of page.
        * @methodOf common.commonService
        * @description
        * This service is used for deleting record other than provided pageID for locking resources
        * @returns {Boolean}  This method returns true/false.
        */
        getUserRecordDeleted: function (userId, pageId, callback) {
            $http.get('Login/DeleteLockRecords/' + userId + '/' + pageId)
            .success(function (status) {
                callback(status);
            })
           .error(function (e) {
                callback("error");
           })
        },

        deleteLockRecordsForPageResources: function (data, callback) {
            $http({
                method: 'POST',
                url: "Login/DeleteLockRecordsForPageResources",
                data: data
            })
            .success(function (status) {
                callback(status);
            })
            .error(function (e) {
                callback("error");
            });
        },

        /**
        * @ngdoc function
        * @name common.commonService#extendSessionTiming
        * @param {String} userName This is user name of logged in user.
        * @param {Number} userId This is user id of logged in user.
        * @param {Number} resourceId This is page id of page.
        * @methodOf common.commonService
        * @description
        * This service is used to get user details
        * @returns {Object}  This method returns object of user details
        */
        extendSessionTiming: function (userName, userId, resourceId, callbackGood, callbackBad) {
            $http({
                method: "post",
                url: "Login/GetUserDetails",
                data: {
                    UserName: userName,
                    UserId: userId,
                    PageId: resourceId
                }
            })
            .success(function (data, status, headers, config) {
                _userdetails = data;
                callbackGood(data, status, headers, config);
            })
            .error(function (data, status, headers, config) {
                callbackBad(data, status, headers, config)
            })
        },

        getLocalData: function (localkey) {
            var data = JSON.parse(localStorage.getItem(localkey));
            return data;
        },

        getSessionData: function (localkey) {
            var data = JSON.parse(sessionStorage.getItem(localkey));
            return data;
        },

        //impersonate feature
        getImpersonateSessionData: function (localkey) {
            if (JSON.parse(localStorage.getItem('adminUser'))) {
                var data = JSON.parse(localStorage.getItem(localkey));
                return data;
            }
        },

         /**
        * @ngdoc function
        * @name common.commonService#impersonateLogout
        * @param {Object} AdminUserObj This is impersonated admin user details object.
        * @methodOf common.commonService
        * @description
        * This service is used to logout impersonated user
        * @returns {Boolean}  This method returns true/false.
        */
        impersonateLogout: function (AdminUserObj, callback) {
            this.getToken(function (token) {
                forgerytoken = token;

                $http({
                    method: 'POST',
                    url: "Login/LogOutImpersonateUser",
                    data: AdminUserObj
                })
                .success(function (status) {
                    callback(status);
                })
                .error(function (e) {
                    callback("error");
                });
            });
        },

        /**
        * @ngdoc function
        * @name common.commonService#impersonateUser
        * @param {Object} UserImpersonateInfo This is impersonated user details object.
        * @methodOf common.commonService
        * @description
        * This service is used to Check whether impersonated User exist in DB or not
        * @returns {Object}  This method returns objects of impersonated user's details.
        */
        impersonateUser: function (UserImpersonateInfo, callback) {
            this.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "Users/ImpersonateUser",
                    data: UserImpersonateInfo,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
               .success(function (UserDetails) {
                   callback(UserDetails);
               })
               .error(function (e) { 
                    callback("error");
               })
            });
        },

        /**
        * @ngdoc function
        * @name common.commonService#checkSourceSetup
        * @param {Object} data This is input object contains uerid,pageid and projectid
        * @methodOf common.commonService
        * @description
        * This service is used for checking locks of resources
        * @returns {Object}  This method returns object of resources lock status
        */
        checkSourceSetup: function (data, callback) {
            var adminUser = JSON.parse(localStorage.getItem('adminUser'));
            if (adminUser) {
                data.OriginalUserId = adminUser.UserId;
            } else {
                data.OriginalUserId = null;
            }
            $http({
                method: 'POST',
                url: "Login/CheckResourceLocking",
                data: data
            })
            .success(function (status) {
                callback(status);
            })
            .error(function (e) {
                callback("error");
            });
        },
        
        /**
        * @ngdoc function
        * @name common.commonService#setTimeInSourceSetupCall
        * @param {Object} data This is input object contains session data,uerid,pageid and projectid
        * @methodOf common.commonService
        * @description
        * This service is used for updating lock records for resources
        * @returns {Object}  This method returns object of resources lock status
        */
        setTimeInSourceSetupCall: function (data,callback) {
            if (data) {
            var adminUser=JSON.parse(localStorage.getItem('adminUser'));
                if (adminUser) {
                    data.OriginalUserId = adminUser.UserId;
                } else {
                    data.OriginalUserId = null;
                }
                $http({
                    method: 'POST',
                    url: "Login/UpdateUserLockingTime",
                    data: data
                })
                .success(function (timechecked) {
                    callback(timechecked);
                })
                .error(function (e) {
                    callback("error");
                });
            }
        },

         /**
        * @ngdoc function
        * @name common.commonService#getUserGuide
        * @methodOf common.commonService
        * @description
        * This service is used get help huides
        * @returns {Object}  This method returns object of userguide
        */
        getUserGuide: function (callback) {
            $http({
                method: "get",
                url: 'Help/ShowUserGuides'
            })
            .success(function (userGuides) {
                callback(userGuides);
            })
            .error(function (e) {
                callback("error");
            })
        },

        deniedRedirect: function () {
            window.location = '/';
        },
        
        /**
        * @ngdoc function
        * @name common.commonService#getToken
        * @methodOf common.commonService
        * @description
        * This service is used get antiforgery token 
        * @returns {String}  This method returns antiforgery token.
        */
        getToken: function (callback) {
            $http({
                method: "get",
                url: 'Login/GetToken'
            })
            .success(function (token) {
                callback(token);
            })
            .error(function (e) { 
                console.log(e) 
            })
        },
    }

    return return_data;
}]);