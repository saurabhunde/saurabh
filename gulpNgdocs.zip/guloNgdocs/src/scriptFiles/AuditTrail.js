/**
 * @ngdoc object
 * @name AuditTrail
 * @element html
 * 
 * @requires AngularJS.$routeProvider
 * @requires AngularJS.$locationProvider
 * @requires AngularJS.ngRoute
 * @requires common
 * 
 * @description
 * This is Audit Trail module, which will contain controller for Audit Trail page. 
 * 
 */
var AuditTrail = angular.module('auditTrail', ['ngRoute', 'common', 'ui.bootstrap','gmAuditTrailModule','angularUtils.directives.dirPagination']);

AuditTrail.config(['$routeProvider', '$locationProvider', '$httpProvider', function ($routeProvider, $locationProvider, $httpProvider) {
    $httpProvider.interceptors.push('myInterceptor');
    $routeProvider

  .when('/', {
      templateUrl: "AuditTrailController/Content/ngviews/AuditTrail.html",
      controller: "auditTrailController"
  })

 
}])

AuditTrail.factory('myInterceptor', function () {
    var requestInterceptor = {
        request: function (config) {
            localStorage.setItem('time', new Date());
            return config;
        }
    };

    return requestInterceptor;
});