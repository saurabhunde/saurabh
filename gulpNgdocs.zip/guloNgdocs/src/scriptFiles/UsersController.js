
/**
 * @ngdoc controller
 * @name Users.controller:UsersController
 * @element div
 *
 * @description
 * This Controller is responsible for showing users on users page and all the operations done on users page.
 *
 * @requires AngularJS.$scope
 * @requires AngularJS.$route
 * @requires AngularJS.$location
 * @requires AngularJS.$timeout
 * @requires common.commonService
 * @requires Users.UserList
 * 
 * @property {string} currentUserEmailID:String  This property is current email id of user before editing.
 * @property {string} OldFirstNameLastName:String  This property is current First and Last name of user before editing.
 * @property {number} currentUserId:Number  This property is user id of logged in user.
 * @property {Array} role:Array  This property is list of user roles.
 * @property {Array} ClientRoles:Array This property is list of all clients.
 * @property {Array} unSelectLang:Array This property is list of languages on left select box on add/edit user popup for approver/editorial staff.
 * @property {Array} selectLang:Array This property is list of languages on right select box on add/edit user popup for approver/editorial staff.
 * @property {Array} myDataClients:Array This property is list of all selected clients in clients dropdown on add/edit user popup.
 * @property {Array} myDataProjects:Array This property is list of all selected projects in projects dropdown on add/edit user popup.
 * @property {Array} listOfProjects:Array This property is list of all projects in projects dropdown on add/edit user popup.
 * @property {Array} ForNativeLang:Array This property is list of native languages.
 * @property {Array} availableUserNames:Array This property is list of email ids of all existing users.
 * @property {Array} UserLanguages:Array This property is list of all languages assigned to user.
 * @property {Array} EnabledNotificationApprover:Array This property is list of default enabled notifications for approver
 * @property {Array} EnabledNotificationAdmin:Array This property is list of default enabled notifications for admin
 * @property {Array} EnabledNotificationSuperAdmin:Array This property is list of default enabled notifications for super admin
 * @property {Array} EnabledNotificationClientAdmin:Array This property is list of default enabled notifications for client admin
 * @property {Array} EnabledNotificationClientUser:Array This property is list of default enabled notifications for client user
 * @property {Array} EnabledNotificationEditorial:Array This property is list of default enabled notifications for editorial staff 
 * @property {object} EmailCopiedForComparison:Object This is object stores copy of user object for comparison 
 * @property {object} User:Object This is object stores selected user details.
 * @property {object} UserEditInfo:Object This is object stores all details on the edit user popup.
 * @property {object} isRequired:Object This is validation object for add user.
 * @property {object} editFormIsRequired:Object This is validation object for edit user.
 * @property {boolean} isActive:Boolean This property is boolean value.This is true user is inactive else false.
 * @property {boolean} isInactive:Boolean This property is boolean value.This is true user is active else false.
 * @property {boolean} disableSaveBtn:Boolean This property is used to disable save button on add users popup.
 * @property {boolean} disableUpdateBtn:Boolean This property is used to disable save button on edit users popup.
 * @property {boolean} addEditUserTab:Boolean This property is boolean value. Used to toggle between notification tab and add users tab on add/edit users.
 * @property {boolean} notificationTab:Boolean This property is boolean value. Used to show/hide preview of knp preview.
 * 
 */
Users.controller('usersController', ['$scope', '$location', 'UserList', 'commonService', '$route', '$timeout', function ($scope, $location, UserList, commonService, $route, $timeout) {
    //Declaring variables
    $scope.role = [];
    var currentUserEmailID;
    var OldFirstNameLastName;
    var edituserOn = false;
    var createNewButtonClicked = false;
    $scope.ClientRoles = [];
    var EditNativeLanguageModelCopy = {};
    EmailCopiedForComparison = {};
    $scope.User = {};
    $scope.unSelectLang = [];
    $scope.myDataClients = [];
    $scope.myDataProjects = [];
    $scope.listOfProjects = [];
    $scope.selectLang = [];
    $scope.newUserName;
    $scope.availableUserNames = [];
    $scope.ForNativeLang = [];
    var UserLanguagesList = [];
    $scope.UserLanguages = [];
    $scope.UserLangList = [];
    var UserDetails = {};
    var UserEditInfo = {
        UserInfo: { Role: {} },
        AssignedClientIdList: [],
        UserLanguages: []
    };
    var UserClientAdminEditInfo = {};
    $scope.uselectedLanguagesEdit = [];
    $scope.copyOfUnselectedLang = [];
    $scope.isInActive = false;
    $scope.deleteValidationMsg = "";
    $scope.isActive = true;
    $scope.isInactive = false;
    $scope.isAll = false;
    $scope.showLoader = false;
    $scope.disableUpdateBtn = false;
    $scope.disableSaveBtn = false;
    $scope.showClientAdmin = true;
    var ClientSelectedForClientAdmin = false;
    var editUserClientSelected = false;
    var ClientInitialForClientAdmin = true;

    $scope.ClientAdminReadonlyEdit = false;
    $scope.ClientAdminReadonly = false;

    //GLMGR-803
    $scope.ClientAdminAccessAllEdit = false;
    $scope.ClientAdminAccessAll = false;
    var myDataProjectsArray = [];

    //GLMGR-704
    $scope.addEditProject = false;
    $scope.fullPermission = false;
    $scope.langPermission = false;
    $scope.editorialPermission = false;
    $scope.addEditUser = false;
    $scope.addEditTranslator = false;
    $scope.addEditSourceSetup = false;
    $scope.addEditTranslation = false;
    $scope.addEditApproval = false;
    UserDetails.UserPermissionList = {};
    $scope.showAddUserPermissionButton = false;
    $scope.addEditUserTab = true;
    $scope.notificationTab = false;
    //GLMGR-128
    $scope.noUserAvailable = true;
    $scope.forApproverEditorialStaff = false;

    //set hashURL for GLMGR-1189
    sessionStorage.setItem('hashURL', null);

    /**
     * @ngdoc
     * @name showAddUserTab
     * @methodOf Users.controller:UsersController
     * @description
     * This function is used to show add user tab
     * @returns {undefined} This method does not return.
     */
    $scope.showAddUserTab = function () {
        $scope.notificationTab = false;
        $scope.addEditUserTab = true;
    };

    /**
     * @ngdoc
     * @name showNotificationTab
     * @methodOf Users.controller:UsersController
     * @description
     * This function is used to show notification settings tab
     * @returns {undefined} This method does not return.
     */
    $scope.showNotificationTab = function () {
        $scope.notificationTab = true;
        $scope.addEditUserTab = false;
    };

    //original userID
    if ($scope.adminUser) {
        $scope.originalUserId = $scope.adminUser.UserId;
    } else {
        $scope.originalUserId = null;
    }

    //ID array for notifications which are by default enabled
    var EnabledNotificationApprover = ["Notify me when translation is completed", "Notify me when assigned to a project", "Notify me when section is ready for translation/section is complete (applicable only for approver as translator)", "Notify me when a suggestion is made to source (ie. English) term", "Notify me when a suggestion is approved/rejected on source (ie. English) term"];//[4,11,12,13,14,21,22,17,18,25,26,29,30];
    var EnabledNotificationAdmin = ["Notify me when section is ready for translation/section is complete", "Notify me when a inconsistence translation is added in glossary"];
    var EnabledNotificationSuperAdmin = ["Notify me when section is ready for translation/section is complete", "Notify me when a inconsistence translation is added in glossary"];
    var EnabledNotificationClientAdmin = ["Notify me when section is ready for translation/section is complete", "Notify me when a inconsistence translation is added in glossary"];
    var EnabledNotificationClientUser = ["Notify me when section is ready for translation/section is complete", "Notify me when a inconsistence translation is added in glossary"];
    var EnabledNotificationEditorial = ["Notify me when section is ready for translation/section is complete"];
    $scope.notifications = [];
    $scope.EditUserNotifications = [];

    //For validation purpose
    $scope.isRequired = {
        "requiredUserRole": false,
        "requiredUsername": false,
        "requiredFirstName": false,
        "requiredLastName": false,
        "requiredNativeLanguage": false,
        "requiredClients": false,
        "invalidUsername": false,
        "requiredClientAdminClients": false,
        "requiredProjects": false
    };

    $scope.editFormIsRequired = {
        "requiredUserRole": false,
        "requiredUsername": false,
        "requiredFirstName": false,
        "requiredLastName": false,
        "requiredNativeLanguage": false,
        "requiredClients": false,
        "invalidUsername": false,
        "requiredClientAdminClients": false,
        "requiredProjects": false
    };
    var emailRegex = new RegExp("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$");

     /**
     * @ngdoc
     * @name changeUserRole
     * @methodOf Users.controller:UsersController
     * @param {String} roleName This is selected role name.
     * @description
     * This function is used to set notification settings options on change of user role in user role dropdown.
     * @returns {undefined} This method does not return.
     */
    $scope.changeUserRole = function (roleName) {

        switch (roleName) {
            case 'Admin':
                UserList.getAddUserEmialNotificationInfo(roleName, function (notifications) {
                    //adding new property IsActive to object in obj array
                    for (var i = 0; i < notifications.length; i++) {
                        notifications[i].IsActive = false;
                    }
                    //setting IsActive property to true for only those notifications which are by default set to true
                    for (var i = 0; i < notifications.length; i++) {
                        for (var j = 0; j < EnabledNotificationAdmin.length; j++) {
                            if (notifications[i].NotificationName === EnabledNotificationAdmin[j]) {
                                notifications[i].IsActive = true;
                            }
                        }
                    }
                    $scope.notifications = notifications;
                });
                break;
            case 'Super Admin':
                UserList.getAddUserEmialNotificationInfo(roleName, function (notifications) {
                    //adding new property IsActive to object in obj array
                    for (var i = 0; i < notifications.length; i++) {
                        notifications[i].IsActive = false;
                    }
                    //setting IsActive property to true for only those notifications which are by default set to true
                    for (var i = 0; i < notifications.length; i++) {
                        for (var j = 0; j < EnabledNotificationSuperAdmin.length; j++) {
                            if (notifications[i].NotificationName === EnabledNotificationSuperAdmin[j]) {
                                notifications[i].IsActive = true;
                            }
                        }
                    }
                    $scope.notifications = notifications;
                });
                break;

            case 'Client Admin':
                UserList.getAddUserEmialNotificationInfo(roleName, function (notifications) {
                    //adding new property IsActive to object in obj array
                    for (var i = 0; i < notifications.length; i++) {
                        notifications[i].IsActive = false;
                    }
                    //setting IsActive property to true for only those notifications which are by default set to true
                    for (var i = 0; i < notifications.length; i++) {
                        for (var j = 0; j < EnabledNotificationClientAdmin.length; j++) {
                            if (notifications[i].NotificationName === EnabledNotificationClientAdmin[j]) {
                                notifications[i].IsActive = true;
                            }
                        }
                    }
                    $scope.notifications = notifications;
                });
                break;

            case 'Client User':
                UserList.getAddUserEmialNotificationInfo(roleName, function (notifications) {
                    //adding new property IsActive to object in obj array
                    for (var i = 0; i < notifications.length; i++) {
                        notifications[i].IsActive = false;
                    }
                    //setting IsActive property to true for only those notifications which are by default set to true
                    for (var i = 0; i < notifications.length; i++) {
                        for (var j = 0; j < EnabledNotificationClientUser.length; j++) {
                            if (notifications[i].NotificationName === EnabledNotificationClientUser[j]) {
                                notifications[i].IsActive = true;
                            }
                        }
                    }
                    $scope.notifications = notifications;
                });
                break;

            case 'Editorial Staff':
                UserList.getAddUserEmialNotificationInfo(roleName, function (notifications) {
                    //adding new property IsActive to object in obj array
                    for (var i = 0; i < notifications.length; i++) {
                        notifications[i].IsActive = false;
                    }
                    //setting IsActive property to true for only those notifications which are by default set to true
                    for (var i = 0; i < notifications.length; i++) {
                        for (var j = 0; j < EnabledNotificationEditorial.length; j++) {
                            if (notifications[i].NotificationName === EnabledNotificationEditorial[j]) {
                                notifications[i].IsActive = true;
                            }
                        }
                    }
                    $scope.notifications = notifications;
                });
                break;

            case 'Approver':
                UserList.getAddUserEmialNotificationInfo(roleName, function (notifications) {
                    for (var i = 0; i < notifications.length; i++) {
                        if (notifications[i].NotificationName === "Notify me when section is ready for translation/section is complete") {
                            notifications[i].NotificationName = "Notify me when section is ready for translation/section is complete (applicable only for approver as translator)"
                        }
                    }
                    //adding new property IsActive to object in obj array
                    for (var i = 0; i < notifications.length; i++) {
                        notifications[i].IsActive = false;
                    }
                    //setting IsActive property to true for only those notifications which are by default set to true
                    for (var i = 0; i < notifications.length; i++) {
                        for (var j = 0; j < EnabledNotificationApprover.length; j++) {
                            if (notifications[i].NotificationName === EnabledNotificationApprover[j]) {
                                notifications[i].IsActive = true;
                            }
                        }
                    }
                    $scope.notifications = notifications;
                });
                break;
        }

    };

     /**
     * @ngdoc
     * @name showStatusWiseUserList
     * @methodOf Users.controller:UsersController
     * @param {String} UserStatus This is selected status from filter dropdown.
     * @description
     * This function is used to filter users list according to status.
     * @returns {undefined} This method does not return.
     */
    $scope.showStatusWiseUserList = function (UserStatus) {
        switch (UserStatus) {
            //If the selected status is inactive then make the inactive flag true
            case 'inactive':
                $scope.isActive = false;
                $scope.isInactive = true;
                $scope.isAll = false;
                userSelection('inactive');
                break;

            //If the selected status is all then make the all flag true
            case 'all':
                $scope.isActive = false;
                $scope.isInactive = false;
                $scope.isAll = true;
                userSelection('all');
                break;

            //else display by default only the active users by making the active flag true
            default: $scope.isActive = true;
                $scope.isInactive = false;
                $scope.isAll = false;
                userSelection('active');
                break;

        }
    }

    /**
     * @ngdoc
     * @name activateUser
     * @methodOf Users.controller:UsersController
     * @param {Object} user This is object contains all the details of selected user from list.
     * @description
     * This function is used to make inactive user as active.
     * @returns {undefined} This method does not return.
     */
    $scope.activateUser = function (user) {
        UserList.activateUserInformation(user.UserId, $scope.CurrentUserId, user.Role.RoleId, function (isActivated) {
            if (isActivated) {
                $scope.deleteValidationMsg = "The selected user is activated";
                $('#deleteValidationMsgDiv').css('display', 'block');
                $timeout(function () { $('#deleteValidationMsgDiv').css('display', 'none') }, 3000);
                init();
            }
            else {
                $scope.deleteValidationMsg = "The selected user could not be activated";
            }
            dynamicScreenHeight();
        });
    }

    /* Close the popup*/
    $scope.dissmissPopup = function () {
        $route.reload();
        $('.modal-backdrop.fade.in').css('display', 'none');
    }
    /* End of close popup */

      /**
     * @ngdoc
     * @name createNewUser
     * @methodOf Users.controller:UsersController
     * @description
     * This function is used to open add new user popup.
     * @returns {undefined} This method does not return.
     */
    $scope.createNewUser = function () {
        //on icon press set tab to add/ edit user 
        $scope.addEditUserTab = true;
        $scope.notificationTab = false;

        // GLMGR-1349 Call service to get notifications settings for admin 
        UserList.getAddUserEmialNotificationInfo("Admin", function (notifications) {
            //adding new property IsActive to object in obj array
            for (var i = 0; i < notifications.length; i++) {
                notifications[i].IsActive = false;
            }

            //setting IsActive property to true for only those notifications which are by default set to true
            for (var i = 0; i < notifications.length; i++) {
                for (var j = 0; j < EnabledNotificationAdmin.length; j++) {
                    if (notifications[i].NotificationName == EnabledNotificationAdmin[j]) {
                        notifications[i].IsActive = true;
                    }
                }
            }
            $scope.notifications = notifications;
        });

        UserDetails = {};
        $scope.UserRole = $scope.role[0];
        $scope.afterFirstSelection = false;
        $('#newUser').modal({ backdrop: 'static', keyboard: false })
        $('#newUser').modal('show');
        //GLMGR-803
        $scope.ClientAdminAccessAll = true;

        $scope.ObjectId = [];
        $scope.ObjectId1 = [];
        $scope.client_str = '';
        $scope.project_str = '';
        $('.client_str').html('Select Client(s)');
        $('.client_str').attr('title', 'Select Client(s)');
        $('.project_str').html('Select Project(s)');
        $('.project_str').attr('title', 'Select Project(s)');

    }

     /**
     * @ngdoc
     * @name saveNewAdminAndClientAdmin
     * @methodOf Users.controller:UsersController
     * @description
     * This function is used to save newly added admin and client admin.
     * @returns {undefined} This method does not return.
     */
    $scope.saveNewAdminAndClientAdmin = function () {
        if ($scope.maxLenErrorUsername || $scope.maxLenErrorFname || $scope.maxLenErrorLname) {
            return false
        }
        createNewButtonClicked = true;
        UserDetails.CurrentUserId = $scope.CurrentUserId;
        UserDetails.FirstName = $scope.NewFirstName;
        UserDetails.LastName = $scope.NewLastName;
        UserDetails.Email = $scope.newUserName;
        UserDetails.RoleId = $scope.UserRole.RoleId;
        UserDetails.isStarred = $scope.StarredTermNew;
        UserDetails.UserPermissionList = {};
        //create notifications settings array with required properties GLMGR-1349
        var notificationArray = [];
        for (var i = 0; i < $scope.notifications.length; i++) {
            var NotificationObj = {};
            NotificationObj.UserEmailNotificationId = 0;
            NotificationObj.UserId = 0;
            NotificationObj.NotificationId = $scope.notifications[i].Id;
            NotificationObj.NotificationName = $scope.notifications[i].NotificationName;
            NotificationObj.IsActive = $scope.notifications[i].IsActive;
            NotificationObj.OriginalUserId = $scope.originalUserId;
            NotificationObj.LoggedInUserId = commonService.getLocalData('userDetails').UserId;

            notificationArray.push(NotificationObj);
        }
        UserDetails.UserEmailNotificationList = notificationArray;

        $scope.disableSaveBtn = true;
        //Calling Service to save User Information
        if ($scope.UserRole.RoleName === 'Client Admin') {
            if (!mandatoryValidation('ClientAdminClientUser')) {
                $scope.notificationTab = false;
                $scope.addEditUserTab = true
                return false;
            }

            UserDetails.ClientList = $scope.myDataClients;
            //GLMGR-803
            if ($scope.ClientAdminAccessAll == true) {
                UserDetails.myDataProjects = [];
            }

            $('#newUser').modal('hide');
            $('.modal-backdrop.fade.in').css('display', 'none');
            $scope.showLoader = true;

            UserList.saveClientAdminInformation(UserDetails, $scope.myDataProjects, $scope.ClientAdminReadonly, $scope.ClientAdminAccessAll, function (isSaved) {
                $route.reload();
            });
        }
        else if ($scope.UserRole.RoleName === 'Admin' || $scope.UserRole.RoleName === 'Super Admin') {
            if (!mandatoryValidation('AdminSuperAdmin')) {
                $scope.notificationTab = false;
                $scope.addEditUserTab = true
                return false;
            }
            $('#newUser').modal('hide');
            $('.modal-backdrop.fade.in').css('display', 'none');
            $scope.showLoader = true;
            //GLMGR-704
            UserDetails.UserPermissionList.AddEditProject = $scope.addEditProject;
            UserDetails.UserPermissionList.FullPermission = $scope.fullPermission;
            UserDetails.UserPermissionList.LangPermission = $scope.langPermission;
            UserDetails.UserPermissionList.EditorialPermission = $scope.editorialPermission;
            UserDetails.UserPermissionList.AddEditUser = $scope.addEditUser;
            UserDetails.UserPermissionList.AddEditTranslator = $scope.addEditTranslator;
            UserDetails.UserPermissionList.AddEditSourceSetup = $scope.addEditSourceSetup;
            UserDetails.UserPermissionList.AddEditTranslation = $scope.addEditTranslation;
            UserDetails.UserPermissionList.AddEditApproval = $scope.addEditApproval;

            UserList.saveUserInformation(UserDetails, function (isSaved) {
                UserDetails = {};
                $route.reload();
            });
        }
    };

    /**
     * @ngdoc
     * @name saveNewApproverClientUser
     * @methodOf Users.controller:UsersController
     * @description
     * This function is used to save newly approver and client user.
     * @returns {undefined} This method does not return.
     */
    $scope.saveNewApproverClientUser = function () {
        if ($scope.maxLenErrorUsername || $scope.maxLenErrorFname || $scope.maxLenErrorLname) {
            return false;
        }
        createNewButtonClicked = true;
        UserDetails.CurrentUserId = $scope.CurrentUserId;
        UserDetails.FirstName = $scope.NewFirstName;
        UserDetails.LastName = $scope.NewLastName;
        UserDetails.Email = $scope.newUserName;
        UserDetails.RoleId = $scope.UserRole.RoleId;
        UserDetails.ClientList = [];

        //create notifications settings array with required properties GLMGR-1349
        var notificationArray = [];
        for (var i = 0; i < $scope.notifications.length; i++) {
            var NotificationObj = {};
            NotificationObj.UserEmailNotificationId = 0;
            NotificationObj.UserId = 0;
            NotificationObj.NotificationId = $scope.notifications[i].Id;
            NotificationObj.NotificationName = $scope.notifications[i].NotificationName;
            NotificationObj.IsActive = $scope.notifications[i].IsActive;
            NotificationObj.OriginalUserId = $scope.originalUserId;
            NotificationObj.LoggedInUserId = commonService.getLocalData('userDetails').UserId;

            notificationArray.push(NotificationObj);
        }
        if (UserDetails.RoleId === 3) {
            for (var i = 0; i < notificationArray.length; i++) {
                if (notificationArray[i].NotificationName === "Notify me when section is ready for translation/section is complete (applicable only for approver as translator)") {
                    notificationArray[i].NotificationName === "Notify me when section is ready for translation/section is complete";
                }
            }
        }
        UserDetails.UserEmailNotificationList = notificationArray;

        $scope.disableSaveBtn = true;
        if ($scope.UserRole.RoleName === 'Client User') {
            var isMandatory = mandatoryValidation('ClientAdminClientUser');
            if (!isMandatory) {
                $scope.notificationTab = false;
                $scope.addEditUserTab = true
                return false;
            }
            UserDetails.ClientList = $scope.myDataClients;


            //reset project list using html5 data attributes; as project multiselect dropdown does not update on change in client dropdown
            $('.UserProjectDropdownLi .icon-ok.pull-right').each(function () {
                myDataProjectsArray.push($(this).attr('data-pid'));
            });
            UserDetails.AssignedProjectIdList = _.uniq(myDataProjectsArray);
            if (myDataProjectsArray.length < 1) {
                $scope.isRequired.requiredProjects = true;
                return true;
            }

            $('#newUser').modal('hide');
            $('.modal-backdrop.fade.in').css('display', 'none');
            $scope.showLoader = true;

            //Calling Service to save User Information
            UserList.saveClientUserInformation(UserDetails, UserDetails.AssignedProjectIdList, function (isSaved) {
                $route.reload();
                UserDetails = {};
            });
        }
        else if ($scope.UserRole.RoleName === 'Approver' || $scope.UserRole.RoleName === 'Editorial Staff') {

            var isMandatory = mandatoryValidation('ApproverEditorial');
            if (!isMandatory) {
                $scope.notificationTab = false;
                $scope.addEditUserTab = true
                return false;
            }
            angular.copy($scope.ForNativeLang, UserLanguagesList);
            $scope.nativeLanguage.IsNative = true;
            UserLanguagesList.push($scope.nativeLanguage);
            //Creating JSON for saving in DB
            UserDetails.ClientList = $scope.myDataClients;
            UserDetails.UserLanguagesList = UserLanguagesList;
            UserDetails.isStarred = $scope.StarredTermNew;
            $('#newUser').modal('hide');
            $('.modal-backdrop.fade.in').css('display', 'none');
            $scope.showLoader = true;
            UserList.saveUserInformation(UserDetails, function (isSaved) {
                $route.reload();
                UserDetails = {};
            });
        }
    };

    //For Client Multi select dropdown
    $scope.$on('selectedModel', function (event, myData) {
        $scope.myDataClients = myData;
        //multiselect dropdown: show values of selected items
        if ($scope.mandatoryValidationOnChange('ClientAdmin')) {

            ClientSelectedForClientAdmin = false;
            ClientInitialForClientAdmin = false;
            editUserClientSelected = false;
            $scope.client_str = '';
            for (j = 0; j < $scope.myDataClients.length; j++) {
                for (i = 0; i < $scope.UserData.ClientList.length; i++) {
                    if ($scope.UserData.ClientList[i].ClientId == $scope.myDataClients[j]) {
                        if ($scope.client_str != '') {
                            $scope.client_str = $scope.client_str + ', ' + $scope.UserData.ClientList[i].ClientName;
                        } else {
                            $scope.client_str = $scope.client_str + $scope.UserData.ClientList[i].ClientName;
                        }
                        $('.client_str').html($scope.client_str);
                        $('.client_str').attr('title', $scope.client_str);
                    }
                }
            }
        }
        else {
            ClientInitialForClientAdmin = true;
            ClientSelectedForClientAdmin = true;
            editUserClientSelected = true;
            $('.client_str').html('Select Client(s)');
            $('.client_str').attr('title', 'Select Client(s)');
            $('.project_str').html('Select Project(s)');
            $('.project_str').attr('title', 'Select Project(s)');
        }

        showCommmonProjects(myData);

    });

    $scope.$on('translaorSelectedModel', function (event, myData) {
        $scope.myTranslatorClients = myData;
    });

    /**
     * @ngdoc
     * @name showCommmonProjects
     * @methodOf Users.controller:UsersController
     * @param {object} myData This is selected client list from dropdown.
     * @description
     * This function is used to create array for projects respective to clients
     * @returns {undefined} This method does not return.
     */
    var showCommmonProjects = function (myData) {
        var ClientIdList = [];
        ClientIdList = myData;
        UserList.showCommonProjects(ClientIdList, $scope.userDetails.UserId, $scope.userDetails.UserRoles[0].UserRoleName, function (projectlist) {
            if (projectlist.accessRes) {
                if (projectlist.accessRes == "AccessDenied") {
                    commonService.deniedRedirect();
                }
            }
            else {
                var projectList = [];
                hideColors = false;

                projectList = projectlist;
                $scope.listOfProjects = projectList;
                $scope.projects = { listOfProjects: [] };
                if (edituserOn == false) {
                    $scope.ObjectId = [];
                }
            }
        });
        //var selected = [];
    };

    $scope.$on('projectselectedModel', function (event, myData) {
        $scope.myDataProjects = myData;
        //multiselect dropdown: show values of selected items
        if ($scope.mandatoryValidationOnChange('Projects')) {
            $scope.project_str = '';
            for (j = 0; j < $scope.myDataProjects.length; j++) {
                for (i = 0; i < $scope.listOfProjects.length; i++) {
                    if ($scope.listOfProjects[i].ProjectId == $scope.myDataProjects[j]) {
                        if ($scope.project_str != '') {
                            $scope.project_str = $scope.project_str + ', ' + $scope.listOfProjects[i].ClientProjectName;
                        } else {
                            $scope.project_str = $scope.project_str + $scope.listOfProjects[i].ClientProjectName;
                        }
                        $('.project_str').html($scope.project_str);
                        $('.project_str').attr('title', $scope.project_str);
                    }
                }
            }
        }
        else {
            $('.project_str').html('Select Project(s)');
            $('.project_str').attr('title', 'Select Project(s)');
        }
    });


    /**
     * @ngdoc
     * @name deleteUser
     * @methodOf Users.controller:UsersController
     * @param {Object} user This is object contains all the details of selected user from list.
     * @description
     * This function is used to open delete user confirmation popup
     * @returns {undefined} This method does not return.
     */
    $scope.deleteUser = function (user) {
        $scope.Username = user.Email;
        $scope.deletedUserObj = user;
        $('#deleteModal').modal('show');
    };

        /**
     * @ngdoc
     * @name confirmDeleteUserButton
     * @methodOf Users.controller:UsersController
     * @description
     * This function is used delete user after clicking on yes button of delete popup
     * @returns {undefined} This method does not return.
     */
    $scope.confirmDeleteUserButton = function () {
        UserList.deleteUserInformation($scope.deletedUserObj.UserId, $scope.CurrentUserId, function (isDeleted) {
            if (isDeleted) {
                $scope.deleteValidationMsg = "The selected user is deleted";
                $('#deleteValidationMsgDiv').css('display', 'block');
                $timeout(function () { $('#deleteValidationMsgDiv').css('display', 'none') }, 3000);
                init();
            }
            else {
                $scope.deleteValidationMsg = "The selected user could not be deleted";
            }
            dynamicScreenHeight();
        });
    };

    //for removing the default selected native language
    $scope.disableFirstoption = function () {
        $scope.preSelectedNativeLang = true;
    };

      /**
     * @ngdoc
     * @name editUser
     * @methodOf Users.controller:UsersController
     * @param {Object} user This is object contains all the details of selected user from list.
     * @description
     * This function is used to open edit user popup with all the user details.
     * @returns {undefined} This method does not return.
     */
    $scope.editUser = function (user) {
        //on icon press set tab to add/ edit user 
        $scope.addEditUserTab = true;
        $scope.notificationTab = false;
        currentUserEmailID = user.Email;
        OldFirstNameLastName = user.FirstName + " " + user.LastName;
        $scope.User = user;
        edituserOn = true;
        $scope.preSelectedNativeLang = false;
        $scope.ObjectId = [];
        $scope.ObjectId1 = [];
        $scope.myDataClients = $scope.ObjectId1;
        $scope.myDataProjects = $scope.ObjectId;
        $scope.UserLanguages = [];
        $scope.FirstName = user.FirstName;
        $scope.LastName = user.LastName;
        $scope.EmailId = user.Email;
        angular.copy(user, EmailCopiedForComparison);
        $scope.Roles = user.Roles;
        $scope.client_str = '';
        $scope.project_str = '';
        UserDetails.UserPermissionList = {};

        UserList.getUserEditInfo(user.UserId, $scope.userDetails.UserId, $scope.userDetails.UserRoles[0].UserRoleName, function (projectEditInfo) {
            $scope.projectEditInfoList = projectEditInfo;
            $scope.ClientAdminReadonlyEdit = projectEditInfo.IsReadOnly;
            $scope.ClientAdminAccessAllEdit = projectEditInfo.UserPermissionList.AccessAllClients; //GLMGR-803
            angular.copy($scope.projectEditInfoList.unselectedLanguageInfo, $scope.uselectedLanguagesEdit);
            angular.copy(projectEditInfo.UserLanguages, $scope.UserLanguages);

            //GLMGR-1349 Email Notification settings checkboxes
            if (user.Role.RoleId === 3) {
                for (var i = 0; i < projectEditInfo.userEmailNotificationViewModel.length; i++) {
                    if (projectEditInfo.userEmailNotificationViewModel[i].NotificationName === "Notify me when section is ready for translation/section is complete") {
                        projectEditInfo.userEmailNotificationViewModel[i].NotificationName = "Notify me when section is ready for translation/section is complete (applicable only for approver as translator)"
                    }
                }
            }
            $scope.EditUserNotifications = projectEditInfo.userEmailNotificationViewModel;

            //GLMGR-704
            if (projectEditInfo.UserPermissionList == null && ($scope.userDetails.UserRoles[0].UserRoleName === 'Admin' || $scope.userDetails.UserRoles[0].UserRoleName === 'Super Admin')) {
                $scope.addEditProject = true;
                $scope.fullPermission = true;
                $scope.addEditUser = true;
                $scope.addEditTranslator = true;
                $scope.addEditSourceSetup = true;
                $scope.addEditTranslation = true;
                $scope.addEditApproval = true;
            } else {
                $scope.addEditProject = projectEditInfo.UserPermissionList.AddEditProject;
                $scope.fullPermission = projectEditInfo.UserPermissionList.FullPermission;
                $scope.langPermission = projectEditInfo.UserPermissionList.LangPermission;
                $scope.editorialPermission = projectEditInfo.UserPermissionList.EditorialPermission;
                $scope.addEditUser = projectEditInfo.UserPermissionList.AddEditUser;
                $scope.addEditTranslator = projectEditInfo.UserPermissionList.AddEditTranslator;
                $scope.addEditSourceSetup = projectEditInfo.UserPermissionList.AddEditSourceSetup;
                $scope.addEditTranslation = projectEditInfo.UserPermissionList.AddEditTranslation;
                $scope.addEditApproval = projectEditInfo.UserPermissionList.AddEditApproval;
            }

            if (projectEditInfo.AssignedClientList[0]) {
                $scope.EditClientName = projectEditInfo.AssignedClientList[0].ClientId;
            }

            for (var i = 0; i < projectEditInfo.ProjectClientList.length; i++) {
                $scope.ObjectId.push(projectEditInfo.ProjectClientList[i].ProjectId);
                $scope.project_str = $scope.project_str + projectEditInfo.ProjectClientList[i].ClientProjectName + ', ';
            }
            $scope.project_str = $scope.project_str.slice(0, -2);
            if (projectEditInfo.ProjectClientList.length > 0) {
                $('.project_str').html($scope.project_str);
                $('.project_str').attr('title', $scope.project_str);
            } else {
                $('.project_str').html('Select Project(s)');
                $('.project_str').attr('title', 'Select Project(s)');
            }

            for (var i = 0; i < projectEditInfo.AssignedClientList.length; i++) {
                $scope.ObjectId1.push(projectEditInfo.AssignedClientList[i].ClientId);
                $scope.client_str = $scope.client_str + projectEditInfo.AssignedClientList[i].ClientName + ', ';
            }
            $scope.client_str = $scope.client_str.slice(0, -2);
            if (projectEditInfo.AssignedClientList.length > 0) {
                $('.client_str').html($scope.client_str);
                $('.client_str').attr('title', $scope.client_str);
            } else {
                $('.client_str').html('Select Client(s)');
                $('.client_str').attr('title', 'Select Client(s)');
            }
            //Checking and changing the native language as per the selection from the dropdown
            if ($scope.UserLanguages.length > 0) {
                for (var i = 0; i < $scope.UserLanguages.length; i++) {
                    if ($scope.UserLanguages[i].IsNative) {
                        $scope.EditNativeLanguage = $scope.UserLanguages[i];
                        angular.copy($scope.EditNativeLanguage, EditNativeLanguageModelCopy);
                    }
                }
            }

            //Remove the selected native language from the right side other languages list
            for (var i = 0; i < $scope.UserLanguages.length; i++) {
                if ($scope.UserLanguages[i].LanguageId == $scope.EditNativeLanguage.LanguageId) {
                    $scope.UserLanguages.splice(i, 1);
                }
            }

            UserList.getClientProjectString($scope.ObjectId1, $scope.userDetails.UserId, $scope.userDetails.UserRoles[0].UserRoleName, function (projectlist) {
                var projectList = [];
                hideColors = false;
                projectList = projectlist;
                $scope.listOfProjects = projectList;
                $scope.projects = { listOfProjects: [] };
            });
        });
        //Adding a default role to the select dropdown as per the selected User from the Table
        $scope.EditUserRole = user.Role;
        $('#editUser').modal({ backdrop: 'static', keyboard: false });
        //Open the Modal Popup of Edit User
        $('#editUser').modal('show');
        //Save Information on click of the Update button
    }

    
      /**
     * @ngdoc
     * @name updateApproverClientUserInfo
     * @methodOf Users.controller:UsersController
     * @description
     * This function is used to update client user and approver from edit user popup.
     * @returns {undefined} This method does not return.
     */
    $scope.updateApproverClientUserInfo = function () {
        if ($scope.maxLenErrorUsernameEdit || $scope.maxLenErrorFnameEdit || $scope.maxLenErrorLnameEdit) {
            return false;
        }
        $scope.disableUpdateBtn = true;
        //Creating the JSON for saving the data
        if ($scope.EditUserRole.RoleName === 'Client User') {
            if (!mandatoryValidationForEditUser('ClientAdminClientUser')) {
                $scope.notificationTab = false;
                $scope.addEditUserTab = true
                return false;
            }
            UserClientAdminEditInfo.CurrentUserId = $scope.CurrentUserId;
            UserClientAdminEditInfo.FirstName = $scope.FirstName;
            UserClientAdminEditInfo.LastName = $scope.LastName;
            UserClientAdminEditInfo.Email = $scope.EmailId;
            UserClientAdminEditInfo.RoleName = $scope.EditUserRole.RoleName;
            UserClientAdminEditInfo.Role = $scope.User.Role.RoleId;
            UserClientAdminEditInfo.UserId = $scope.User.UserId;
            UserClientAdminEditInfo.IsActive = $scope.User.IsActive;
            UserClientAdminEditInfo.AssignedClientIdList = $scope.myDataClients;
            UserClientAdminEditInfo.AssignedProjectIdList = $scope.myDataProjects;

            //create notifications settings array with required properties GLMGR-1349
            var notificationArray = [];
            for (var i = 0; i < $scope.EditUserNotifications.length; i++) {
                var NotificationObj = {};
                NotificationObj.UserEmailNotificationId = $scope.EditUserNotifications[i].UserEmailNotificationId;
                NotificationObj.UserId = UserClientAdminEditInfo.UserId;
                NotificationObj.NotificationId = $scope.EditUserNotifications[i].NotificationId;
                NotificationObj.NotificationName = $scope.EditUserNotifications[i].NotificationName;
                NotificationObj.IsActive = $scope.EditUserNotifications[i].IsActive;
                NotificationObj.OriginalUserId = $scope.originalUserId;
                NotificationObj.LoggedInUserId = commonService.getLocalData('userDetails').UserId;

                notificationArray.push(NotificationObj);
            }

            UserClientAdminEditInfo.UserEmailNotificationList = notificationArray;

            //reset project list using html5 data attributes; as project multiselect dropdown does not update on change in client dropdown
            $('.UserProjectDropdownLi .icon-ok.pull-right').each(function () {
                myDataProjectsArray.push($(this).attr('data-pid'));
            });
            UserClientAdminEditInfo.AssignedProjectIdList = _.uniq(myDataProjectsArray);
            if (myDataProjectsArray.length < 1) {
                $scope.editFormIsRequired.requiredProjects = true;
                return true;
            }

            $('#editUser').modal('hide');
            $('.modal-backdrop.fade.in').css('display', 'none');
            UserClientAdminEditInfo.OldEmailId = currentUserEmailID;
            UserClientAdminEditInfo.OldFirstNameLastName = OldFirstNameLastName;
            $scope.showLoader = true;
            //Calling Service in order to save the data
            UserList.updateClientUserInformation(UserClientAdminEditInfo, function (isUpdated) {
                $scope.disableUpdateBtn = false;
                $route.reload();
            });
        }
        if ($scope.EditUserRole.RoleName == 'Approver' || $scope.EditUserRole.RoleName == 'Editorial Staff') {
            if (!mandatoryValidationForEditUser('ApproverEditorial')) {
                $scope.notificationTab = false;
                $scope.addEditUserTab = true
                return false;
            }
            angular.copy($scope.UserLanguages, $scope.UserLangList);
            $scope.UserLangList.push($scope.EditNativeLanguage);
            UserEditInfo.CurrentUserId = $scope.CurrentUserId;
            UserEditInfo.UserInfo.FirstName = $scope.FirstName;
            UserEditInfo.UserInfo.LastName = $scope.LastName;
            UserEditInfo.UserInfo.Email = $scope.EmailId;
            UserEditInfo.UserInfo.Role.RoleName = $scope.EditUserRole.RoleName;
            UserEditInfo.UserInfo.Role.RoleId = $scope.EditUserRole.RoleId;
            UserEditInfo.UserInfo.IsActive = $scope.User.IsActive;
            UserEditInfo.UserInfo.UserId = $scope.User.UserId;
            UserEditInfo.UserLanguages = $scope.UserLangList;
            UserEditInfo.AssignedClientIdList = $scope.myDataClients;

            //create notifications settings array with required properties GLMGR-1349
            var notificationArray = [];
            for (var i = 0; i < $scope.EditUserNotifications.length; i++) {
                var NotificationObj = {};
                NotificationObj.UserEmailNotificationId = $scope.EditUserNotifications[i].UserEmailNotificationId;
                NotificationObj.UserId = UserEditInfo.UserInfo.UserId;
                NotificationObj.NotificationId = $scope.EditUserNotifications[i].NotificationId;
                NotificationObj.NotificationName = $scope.EditUserNotifications[i].NotificationName;
                NotificationObj.IsActive = $scope.EditUserNotifications[i].IsActive;
                NotificationObj.OriginalUserId = $scope.originalUserId;
                NotificationObj.LoggedInUserId = commonService.getLocalData('userDetails').UserId;

                notificationArray.push(NotificationObj);
            }
            if ($scope.EditUserRole.RoleId === 3) {
                for (var i = 0; i < notificationArray.length; i++) {
                    if (notificationArray[i].NotificationName === "Notify me when section is ready for translation/section is complete (applicable only for approver as translator)") {
                        notificationArray[i].NotificationName === "Notify me when section is ready for translation/section is complete";
                    }
                }
            }
            UserEditInfo.UserEmailNotificationList = notificationArray;
            UserEditInfo.OldEmailId = currentUserEmailID;
            UserEditInfo.OldFirstNameLastName = OldFirstNameLastName;
            $('#editUser').modal('hide');
            $('.modal-backdrop.fade.in').css('display', 'none');
            $scope.showLoader = true;
            //Calling Service in order to save the data
            UserList.updateUserInformation(UserEditInfo, function (isUpdated) {
                $scope.disableUpdateBtn = false;
                $route.reload();
            });
        }
    };

    /**
     * @ngdoc
     * @name updateAdminAndClientAdminInfo
     * @methodOf Users.controller:UsersController
     * @description
     * This function is used to update client admin and admin from edit user popup.
     * @returns {undefined} This method does not return.
     */
    $scope.updateAdminAndClientAdminInfo = function () {
        if ($scope.maxLenErrorUsernameEdit || $scope.maxLenErrorFnameEdit || $scope.maxLenErrorLnameEdit) {
            return false;
        }
        $scope.disableUpdateBtn = true;
        UserClientAdminEditInfo.CurrentUserId = $scope.CurrentUserId;
        UserClientAdminEditInfo.FirstName = $scope.FirstName;
        UserClientAdminEditInfo.LastName = $scope.LastName;
        UserClientAdminEditInfo.Email = $scope.EmailId;
        UserClientAdminEditInfo.RoleName = $scope.EditUserRole.RoleName;
        UserClientAdminEditInfo.Role = $scope.User.Role.RoleId;
        UserClientAdminEditInfo.UserId = $scope.User.UserId;
        UserClientAdminEditInfo.IsActive = $scope.User.IsActive;
        UserClientAdminEditInfo.AssignedClientIdList = [];
        UserClientAdminEditInfo.AccessAllClients = $scope.ClientAdminAccessAllEdit; //GLMGR-803

        //create notifications settings array with required properties GLMGR-1349
        var notificationArray = [];
        for (var i = 0; i < $scope.EditUserNotifications.length; i++) {
            var NotificationObj = {};
            NotificationObj.UserEmailNotificationId = $scope.EditUserNotifications[i].UserEmailNotificationId;
            NotificationObj.UserId = UserClientAdminEditInfo.UserId;
            NotificationObj.NotificationId = $scope.EditUserNotifications[i].NotificationId;
            NotificationObj.NotificationName = $scope.EditUserNotifications[i].NotificationName;
            NotificationObj.IsActive = $scope.EditUserNotifications[i].IsActive;
            NotificationObj.OriginalUserId = $scope.originalUserId;
            NotificationObj.LoggedInUserId = commonService.getLocalData('userDetails').UserId;
            notificationArray.push(NotificationObj);
        }
        UserClientAdminEditInfo.UserEmailNotificationList = notificationArray;

        if ($scope.EditUserRole.RoleName == 'Client Admin') {
            if (!mandatoryValidationForEditUser('ClientAdminClientUser')) {
                $scope.notificationTab = false;
                $scope.addEditUserTab = true
                return false;
            }

            //Creating the JSON for saving the data for client admin
            //GLMGR-803
            UserClientAdminEditInfo.AssignedClientIdList = $scope.myDataClients;
            if ($scope.ClientAdminAccessAllEdit == true) {
                //UserClientAdminEditInfo.AssignedClientIdList = [];
                UserClientAdminEditInfo.AssignedProjectIdList = [];
            } else {
                UserClientAdminEditInfo.AssignedProjectIdList = $scope.myDataProjects;
            }


            UserClientAdminEditInfo.IsReadOnly = $scope.ClientAdminReadonlyEdit;
            $('#editUser').modal('hide');
            $('.modal-backdrop.fade.in').css('display', 'none');
            $scope.showLoader = true;
            UserClientAdminEditInfo.OldEmailId = currentUserEmailID;
            UserClientAdminEditInfo.OldFirstNameLastName = OldFirstNameLastName;
            UserList.updateClientAdminInformation(UserClientAdminEditInfo, function (isUpdated) {
                $scope.disableUpdateBtn = false;
                $route.reload();
            },
                function (e) {
                    $('.modal-backdrop.fade.in').css('display', 'none');

                    $scope.disableUpdateBtn = false;
                    $scope.listOfProjects = [];
                    $('.modal-backdrop.fade.in').css('display', 'none');
                });
        }
        else {
            if (!mandatoryValidationForEditUser('AdminSuperAdmin')) {
                $scope.notificationTab = false;
                $scope.addEditUserTab = true
                return false;
            }
            UserEditInfo = {
                UserInfo: { Role: {} },
                AssignedClientIdList: [],
                UserLanguages: [],
                UserPermissionList: {}
            };
            UserEditInfo.CurrentUserId = $scope.CurrentUserId;
            UserEditInfo.UserInfo.FirstName = $scope.FirstName;
            UserEditInfo.UserInfo.LastName = $scope.LastName;
            UserEditInfo.UserInfo.Email = $scope.EmailId;
            UserEditInfo.UserInfo.Role.RoleName = $scope.EditUserRole.RoleName;
            UserEditInfo.UserInfo.Role.RoleId = $scope.EditUserRole.RoleId;
            UserEditInfo.UserInfo.IsActive = $scope.User.IsActive;
            UserEditInfo.UserInfo.UserId = $scope.User.UserId;

            //GLMGR-704
            UserEditInfo.UserPermissionList.AddEditProject = $scope.addEditProject;
            UserEditInfo.UserPermissionList.FullPermission = $scope.fullPermission;
            UserEditInfo.UserPermissionList.LangPermission = $scope.langPermission;
            UserEditInfo.UserPermissionList.EditorialPermission = $scope.editorialPermission;
            UserEditInfo.UserPermissionList.AddEditUser = $scope.addEditUser;
            UserEditInfo.UserPermissionList.AddEditTranslator = $scope.addEditTranslator;
            UserEditInfo.UserPermissionList.AddEditSourceSetup = $scope.addEditSourceSetup;
            UserEditInfo.UserPermissionList.AddEditTranslation = $scope.addEditTranslation;
            UserEditInfo.UserPermissionList.AddEditApproval = $scope.addEditApproval;

            //create notifications settings array with required properties GLMGR-1349
            var notificationArray = [];
            for (var i = 0; i < $scope.EditUserNotifications.length; i++) {
                var NotificationObj = {};
                NotificationObj.UserEmailNotificationId = $scope.EditUserNotifications[i].UserEmailNotificationId;
                NotificationObj.UserId = UserEditInfo.UserInfo.UserId;
                NotificationObj.NotificationId = $scope.EditUserNotifications[i].NotificationId;
                NotificationObj.NotificationName = $scope.EditUserNotifications[i].NotificationName;
                NotificationObj.IsActive = $scope.EditUserNotifications[i].IsActive;
                NotificationObj.OriginalUserId = $scope.originalUserId;
                NotificationObj.LoggedInUserId = commonService.getLocalData('userDetails').UserId;

                notificationArray.push(NotificationObj);
            }
            UserEditInfo.UserEmailNotificationList = notificationArray;
            UserEditInfo.OldEmailId = currentUserEmailID;
            UserEditInfo.OldFirstNameLastName = OldFirstNameLastName;
            $('#editUser').modal('hide');
            $('.modal-backdrop.fade.in').css('display', 'none');
            $scope.showLoader = true;
            UserList.updateUserInformation(UserEditInfo, function (isUpdated) {
                $scope.disableUpdateBtn = false;
                $route.reload();
            },
                function (e) {
                    $('.modal-backdrop.fade.in').css('display', 'none');
                    $scope.disableUpdateBtn = false;
                    $scope.listOfProjects = [];
                    $('.modal-backdrop.fade.in').css('display', 'none');
                });
        }
    }

    $scope.cancelEdit = function () {
        $scope.disableUpdateBtn = false;
        $scope.listOfProjects = [];
        $('.modal-backdrop.fade.in').css('display', 'none');
        $route.reload();
    }

      /**
     * @ngdoc
     * @name checkForDuplicateUsername
     * @methodOf Users.controller:UsersController
     * @param {String} newUserName This is username passed for comparison .
     * @description
     * This function is used to check for duplicate username.
     * @returns {undefined} This method does not return.
     */
    $scope.checkForDuplicateUsername = function (newUserName) {
        if (EmailCopiedForComparison.Email) {
            if (newUserName.toLowerCase() != EmailCopiedForComparison.Email.toLowerCase()) {
                for (var i = 0; i < $scope.availableUserNames.length; i++) {
                    if (newUserName.toLowerCase() == $scope.availableUserNames[i].toLowerCase()) {
                        $scope.isAvailable = true;
                        break;
                    }
                    else {
                        $('#saveUserInfoBtn').show();
                        $scope.isAvailable = false;
                    }
                }
            }
            else {
                $scope.isAvailable = false;
                $('#saveTranslatorBtn').show();
            }
        } else {
            for (var i = 0; i < $scope.availableUserNames.length; i++) {
                if (newUserName.toLowerCase() == $scope.availableUserNames[i].toLowerCase()) {
                    $scope.isAvailable = true;
                    break;
                }
                else {
                    $('#saveUserInfoBtn').show();
                    $scope.isAvailable = false;
                }
            }
        }

    }

     /**
     * @ngdoc
     * @name selectLangClick
     * @methodOf Users.controller:UsersController
     * @param {Object} selectedLang This is object containing all the details about selected language from select box.
     * @description
     * This function is used for selecting languages and pushing to the right side of the list from left side.
     * @returns {undefined} This method does not return.
     */
    $scope.selectLangClick = function (selectedLang) {
        //Add all the selected languages to the Native Language dropdown array
        for (var i = 0; i < selectedLang.length; i++) {
            $scope.ForNativeLang.push(selectedLang[i]);
        }
        //Adding the selected languages to the left side of the List
        for (var i = 0; i < selectedLang.length; i++) {
            $scope.selectLang.push(selectedLang[i]);
            var index = $scope.unSelectLang.indexOf(selectedLang[i]);
            if (index > -1) {
                $scope.unSelectLang.splice(index, 1);
            }
        }
    };

     /**
     * @ngdoc
     * @name UnSelectLangClick
     * @methodOf Users.controller:UsersController
     * @param {Object} unSelectedLang This is object containing all the details about selected language from select box.
     * @description
     * This function is used for deselecting selected languages and pushing to the left side of the list from right side
     * @returns {undefined} This method does not return.
     */
    $scope.UnSelectLangClick = function (unSelectedLang) {
        //Removing all the deselected items from the Native Language Array
        for (var i = 0; i < unSelectedLang.length; i++) {
            var spliceIndex = $scope.ForNativeLang.indexOf(unSelectedLang[i]);
            if (spliceIndex > -1) {
                $scope.ForNativeLang.splice(spliceIndex, 1);
            }
        }
        //Adding data to the right side of the array
        for (var i = 0; i < unSelectedLang.length; i++) {
            $scope.unSelectLang.push(unSelectedLang[i]);
            var index = $scope.selectLang.indexOf(unSelectedLang[i]);
            if (index > -1) {
                $scope.selectLang.splice(index, 1);
            }
        }
    };


   /**
     * @ngdoc
     * @name selectEditLangClick
     * @methodOf Users.controller:UsersController
     * @param {Object} selectedLang This is object containing all the details about selected language from select box on edit user popup.
     * @description
     * This function is used for selecting languages and pushing to the right side of the list from left side.
     * @returns {undefined} This method does not return.
     */
    $scope.selectEditLangClick = function (selectedLang) {
        for (var i = 0; i < selectedLang.length; i++) {
            $scope.UserLanguages.push(selectedLang[i]);
            var index = $scope.uselectedLanguagesEdit.indexOf(selectedLang[i]);
            if (index > -1) {
                $scope.uselectedLanguagesEdit.splice(index, 1);
            }
        }
    };

   /**
     * @ngdoc
     * @name UnSelectEditLangClick
     * @methodOf Users.controller:UsersController
     * @param {Object} unSelectedLang This is object containing all the details about selected language from select box on edit user popup.
     * @description
     * This function is used for deselecting selected languages and pushing to the left side of the list from right side
     * @returns {undefined} This method does not return.
     */
    $scope.UnSelectEditLangClick = function (unSelectedLang) {
        for (var i = 0; i < unSelectedLang.length; i++) {
            $scope.uselectedLanguagesEdit.push(unSelectedLang[i]);
            var index = $scope.UserLanguages.indexOf(unSelectedLang[i]);
            if (index > -1) {
                $scope.UserLanguages.splice(index, 1);
            }
        }
    };

    /**
     * @ngdoc
     * @name checkIsNativeLanguageForEdit
     * @methodOf Users.controller:UsersController
     * @description
     * This function is used to select native language for user and accordingly set to the appropriate boolean values as per the selection
     * @returns {undefined} This method does not return.
     */
    $scope.checkIsNativeLanguageForEdit = function () {
        //Validates the form fields
        if (!$scope.mandatoryValidationOnChange('NativeLanguage')) {
            return false;
        }
        //remove language from the right side list if it has same languages as the selected native language
        if ($scope.UserLanguages.length > 0) {
            for (var i = 0; i < $scope.UserLanguages.length; i++) {
                if ($scope.UserLanguages[i].IsNative) {
                    $scope.UserLanguages[i].IsNative = false;
                }
                if ($scope.EditNativeLanguage.LanguageId == $scope.UserLanguages[i].LanguageId) {
                    $scope.UserLanguages.splice(i, 1);
                    if ($scope.oldValue) {
                        $scope.oldValue.IsNative = false;
                        $scope.uselectedLanguagesEdit.push($scope.oldValue);
                    }
                }
            }
        }
        $scope.EditNativeLanguage.IsNative = true;
        //remove language from the left side list if it has same languages as the selected native language
        if ($scope.uselectedLanguagesEdit.length > 0) {
            for (var i = 0; i < $scope.uselectedLanguagesEdit.length; i++) {
                if ($scope.uselectedLanguagesEdit[i].IsNative) {
                    $scope.uselectedLanguagesEdit[i].IsNative = false;
                }
                if ($scope.EditNativeLanguage.LanguageId == $scope.uselectedLanguagesEdit[i].LanguageId) {
                    $scope.uselectedLanguagesEdit.splice(i, 1);
                    if ($scope.oldValue) {
                        $scope.oldValue.IsNative = false;
                        $scope.uselectedLanguagesEdit.push($scope.oldValue);
                    }
                }
            }
        }
        //checking if there are same selected languages with the main list of languages
        for (var i = 0; i < $scope.uselectedLanguagesEdit.length; i++) {
            for (var j = 0; j < $scope.UserLanguages.length; j++) {
                if ($scope.uselectedLanguagesEdit[i].LanguageId == $scope.UserLanguages[j].LanguageId) {
                    $scope.uselectedLanguagesEdit.splice(i, 1);
                }
            }
        }
    };

    /**
     * @ngdoc
     * @name changeOtherLanguagesAsPerNativeLanguage
     * @methodOf Users.controller:UsersController
     * @param {Object} oldValue old value of native language.
     * @description
     * This function is used to change the other languages list according to the selected native language
     * @returns {undefined} This method does not return.
     */
    var changeOtherLanguagesAsPerNativeLanguage = function (oldValue) {
        $scope.nativeLanguage.IsNative = true;
        $scope.afterFirstSelection = true;
        //this block checks for language same as that of selected native language from the right list of languages
        if ($scope.selectLang.length > 0) {
            for (var i = 0; i < $scope.selectLang.length; i++) {
                //reset all the IsNative flags to be false
                if ($scope.selectLang[i].IsNative) {
                    $scope.selectLang[i].IsNative = false;
                }
                //remove the selected native language from the right list
                if ($scope.nativeLanguage.LanguageId == $scope.selectLang[i].LanguageId) {
                    $scope.selectLang.splice(i, 1);
                    if (oldValue) {
                        oldValue.IsNative = false;
                        $scope.unSelectLang.push(oldValue);
                    }
                }
            }
        }
        //this block checks for language same as that of selected native language from the left list of languages
        if ($scope.unSelectLang.length > 0) {
            //var len = $scope.unSelectLang.length;
            for (var i = 0; i < $scope.unSelectLang.length; i++) {
                if ($scope.unSelectLang[i].IsNative) {
                    $scope.unSelectLang[i].IsNative = false;
                }
                if ($scope.nativeLanguage.LanguageId == $scope.unSelectLang[i].LanguageId) {
                    $scope.unSelectLang.splice(i, 1);
                    if (oldValue) {
                        oldValue.IsNative = false;
                        $scope.unSelectLang.push(oldValue);
                    }
                    //len = len - 1;
                    //i = i - 1;
                }
            }
        }
        //checking if there are same selected languages with the main list of languages
        if ($scope.unSelectLang.length > 0 && $scope.selectLang.length > 0) {
            var unselectedLanLength = $scope.unSelectLang.length;
            var selectedLanLength = $scope.selectLang.length;
            for (var i = 0; i < unselectedLanLength; i++) {
                for (var j = 0; j < selectedLanLength; j++) {
                    if ($scope.unSelectLang[i].LanguageId === $scope.selectLang[j].LanguageId) {
                        $scope.unSelectLang.splice(i, 1);
                        j = j - 1;
                        selectedLanLength = selectedLanLength - 1;
                    }
                }
            }
        }
    };

    /**
     * @ngdoc
     * @name checkIsNativeLanguage
     * @methodOf Users.controller:UsersController
     * @param {Object} oldValue old value of native language.
     * @description
     * This function is used to check whether the selected language is Native Language or not
     * @returns {undefined} This method does not return.
     */
    $scope.checkIsNativeLanguage = function (oldValue) {
        if (createNewButtonClicked) {
            if (!$scope.mandatoryValidationOnChange("NativeLanguage")) {
                return false;
            }
            changeOtherLanguagesAsPerNativeLanguage(oldValue);
        }
        else {
            changeOtherLanguagesAsPerNativeLanguage(oldValue);
        }
    };

    $scope.trimMenuItemNames = function (menu_item) {
        menu_item = menu_item.slice(4, menu_item.length);
        return menu_item;
    };

    /**
     * @ngdoc
     * @name sort
     * @methodOf Users.controller:UsersController
     * @param {String} keyname This is column name of column which is need to be sorted
     * @description
     * This function is used to sort list of users.
     * @returns {undefined} This method does not return.
     */
    $scope.sort = function (keyname) {
        $scope.sortKey = keyname;   //set the sortKey to the param passed
        $scope.reverse = !$scope.reverse; //if true make it false and vice versa
    };

    //reset pagination
    var userSelection = function (UserStatus) {
        $scope.UsersInformationActive = {};
        $scope.noUserAvailable = true;
        if (!UserStatus || UserStatus === 'active') {
            var UserActive = [];
            for (i = 0; i < $scope.UserData.UsersInformation.length; i++) {
                if ($scope.UserData.UsersInformation[i].IsActive == true)
                    UserActive.push($scope.UserData.UsersInformation[i]);
            }
            $scope.UsersInformationActive['UserActive'] = UserActive;
        } else if (UserStatus === 'inactive') {
            var UserInActive = [];
            for (i = 0; i < $scope.UserData.UsersInformation.length; i++) {
                if ($scope.UserData.UsersInformation[i].IsActive == false)
                    UserInActive.push($scope.UserData.UsersInformation[i]);
            }
            $scope.UsersInformationActive['UserInActive'] = UserInActive;
        } else {
            $scope.UsersInformationActive['all'] = $scope.UserData.UsersInformation;
        }

        setTimeout(function () { dynamicScreenHeight(); }, 500);
    }


     /**
     * @ngdoc
     * @name showRoleWiseUserList
     * @methodOf Users.controller:UsersController
     * @param {String} UserStatus This is user status active/inactive
     * @param {Number} selectedRoleId This is selected user role id. 
     * @description
     * This function is used to sort list of users role wise.This is role filter functionality.
     * @returns {undefined} This method does not return.
     */
    $scope.showRoleWiseUserList = function (UserStatus, selectedRoleId) {
        //call to reset $scope.UsersInformationActive list
        userSelection(UserStatus);

        //store into $scope for later use
        $scope.selectedRoleId__ = selectedRoleId;

        //check username to show-hide languages dropdown
        for (var i = 0; i < $scope.UserData.RoleList.length; i++) {
            if ($scope.UserData.RoleList[i].RoleId === selectedRoleId) {
                if ($scope.UserData.RoleList[i].RoleName === 'Approver' || $scope.UserData.RoleList[i].RoleName === 'Editorial Staff') {
                    $scope.forApproverEditorialStaff = true;
                    break;
                }
            } else {
                $scope.forApproverEditorialStaff = false;
            }
        }

        // filter list according to selected user role
        if (selectedRoleId !== null) {
            if (!UserStatus || UserStatus === 'active') {
                var UserActive = [];
                for (var i = 0; i < $scope.UsersInformationActive.UserActive.length; i++) {
                    if ($scope.UsersInformationActive.UserActive[i].Role.RoleId == selectedRoleId) {
                        UserActive.push($scope.UsersInformationActive.UserActive[i]);
                    }
                }
                $scope.UsersInformationActive = {};
                $scope.UsersInformationActive['UserActive'] = UserActive;
                if ($scope.UsersInformationActive['UserActive'].length > 0) {
                    $scope.noUserAvailable = true;
                } else {
                    $scope.noUserAvailable = false;
                }
            } else if (UserStatus === 'inactive') {
                var UserInActive = [];
                for (var i = 0; i < $scope.UsersInformationActive.UserInActive.length; i++) {
                    if ($scope.UsersInformationActive.UserInActive[i].Role.RoleId == selectedRoleId) {
                        UserInActive.push($scope.UsersInformationActive.UserInActive[i]);
                    }
                }
                $scope.UsersInformationActive = {};
                $scope.UsersInformationActive['UserInActive'] = UserInActive;
                if ($scope.UsersInformationActive['UserInActive'].length > 0) {
                    $scope.noUserAvailable = true;
                } else {
                    $scope.noUserAvailable = false;
                }
            } else {
                var all = [];
                for (var i = 0; i < $scope.UsersInformationActive.all.length; i++) {
                    if ($scope.UsersInformationActive.all[i].Role.RoleId == selectedRoleId) {
                        all.push($scope.UsersInformationActive.all[i]);
                    }
                }
                $scope.UsersInformationActive = {};
                $scope.UsersInformationActive['all'] = all;
                if ($scope.UsersInformationActive['all'].length > 0) {
                    $scope.noUserAvailable = true;
                } else {
                    $scope.noUserAvailable = false;
                }
            }
        }
    };

     /**
     * @ngdoc
     * @name showStatusLanguageWiseUserList
     * @methodOf Users.controller:UsersController
     * @param {String} UserStatus This is user status active/inactive
     * @param {Number} selectedLanguageId This is selected language id. 
     * @description
     * This function is used to sort list of approver/editorial staff users language wise.
     * @returns {undefined} This method does not return.
     */
    $scope.showStatusLanguageWiseUserList = function (UserStatus, selectedLanguageId) {

        //call to reset $scope.UsersInformationActive list
        $scope.showRoleWiseUserList(UserStatus, $scope.selectedRoleId__);

        // filter list according to selected language
        if (selectedLanguageId !== null) {
            if (!UserStatus || UserStatus === 'active') {
                var UserActive = [];
                for (var i = 0; i < $scope.UsersInformationActive.UserActive.length; i++) {
                    for (var j = 0; j < $scope.UsersInformationActive.UserActive[i].LanguageList.length; j++) {
                        if ($scope.UsersInformationActive.UserActive[i].LanguageList[j].LanguageId == selectedLanguageId) {
                            UserActive.push($scope.UsersInformationActive.UserActive[i]);
                        }
                    }
                }
                $scope.UsersInformationActive = {};
                $scope.UsersInformationActive['UserActive'] = UserActive;
                if ($scope.UsersInformationActive['UserActive'].length > 0) {
                    $scope.noUserAvailable = true;
                } else {
                    $scope.noUserAvailable = false;
                }
            } else if (UserStatus === 'inactive') {
                var UserInActive = [];
                for (var i = 0; i < $scope.UsersInformationActive.UserInActive.length; i++) {
                    for (var j = 0; j < $scope.UsersInformationActive.UserInActive[i].LanguageList.length; j++) {
                        if ($scope.UsersInformationActive.UserInActive[i].LanguageList[j].LanguageId == selectedLanguageId) {
                            UserInActive.push($scope.UsersInformationActive.UserInActive[i]);
                        }
                    }
                }
                $scope.UsersInformationActive = {};
                $scope.UsersInformationActive['UserInActive'] = UserInActive;
                if ($scope.UsersInformationActive['UserInActive'].length > 0) {
                    $scope.noUserAvailable = true;
                } else {
                    $scope.noUserAvailable = false;
                }
            } else {
                var all = [];
                for (var i = 0; i < $scope.UsersInformationActive.all.length; i++) {
                    for (var j = 0; j < $scope.UsersInformationActive.all[i].LanguageList.length; j++) {
                        if ($scope.UsersInformationActive.all[i].LanguageList[j].LanguageId == selectedLanguageId) {
                            all.push($scope.UsersInformationActive.all[i]);
                        }
                    }
                }
                $scope.UsersInformationActive = {};
                $scope.UsersInformationActive['all'] = all;
                if ($scope.UsersInformationActive['all'].length > 0) {
                    $scope.noUserAvailable = true;
                } else {
                    $scope.noUserAvailable = false;
                }
            }
        }
    };

    $scope.resetRoleDropdown = function () {
        $scope.selectedRoleId = $scope.UserData.RoleList[-1];
    };

    $scope.resetLanguageDropdown = function () {
        $scope.selectedLanguageId = $scope.UserData.LanguageList[-1];
    };

    $scope.reloadPage = function () {
        $route.reload();
    };
    //Role Language filter: GLMGR-128 end

    $scope.dynamicScreenHeightCall = function () {
        dynamicScreenHeight();
    }

    /**
     * @ngdoc
     * @name mandatoryValidation
     * @methodOf Users.controller:UsersController
     * @param {String} userType This is user role
     * @description
     * This function is used to validate add user form.
     * @returns {undefined} This method does not return.
     */
    var mandatoryValidation = function (userType) {
        //common code to validate fields like first name, last name, user name
        // if ($scope.newUserName == undefined || $scope.NewFirstName == undefined || $scope.NewLastName == undefined) {
        if (!$scope.newUserName) {
            $scope.isRequired.requiredUsername = true;
        }
        else {
            if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($scope.newUserName))) {
                $scope.isRequired.invalidUsername = true;
            }
            else {
                $scope.isRequired.invalidUsername = false;
            }
        }
        if (!$scope.NewFirstName) {
            $scope.isRequired.requiredFirstName = true;
        }
        if (!$scope.NewLastName) {
            $scope.isRequired.requiredLastName = true;
        }
        //}

        //For Approver and Editorial Staff
        if (userType === 'ApproverEditorial' && (!$scope.UserRole || !$scope.nativeLanguage || $scope.myDataClients.length < 1)) {
            if (!$scope.nativeLanguage) {
                $scope.isRequired.requiredNativeLanguage = true;
            }
            if ($scope.myDataClients.length < 1) {
                $scope.isRequired.requiredClientAdminClients = true;
            }
            return false;
        }
        //For Client Admin and Client User
        if (userType === 'ClientAdminClientUser' && ($scope.myDataClients.length < 1 || ($scope.myDataProjects.length < 1 && !$scope.ClientAdminAccessAll))) {
            if ($scope.myDataClients.length < 1) {
                $scope.isRequired.requiredClientAdminClients = true;
            }
            if ($scope.myDataProjects.length < 1 && !$scope.ClientAdminAccessAll) {
                $scope.isRequired.requiredProjects = true;
            }
            return false;
        }
        //if the user name is not null or it is not duplicate
        else if ($scope.newUserName && $scope.isAvailable) {
            return false;
        }
        else if ($scope.isRequired.requiredFirstName || $scope.isRequired.requiredLastName || $scope.isRequired.invalidUsername || $scope.isRequired.requiredUsername || $scope.isRequired.requiredNativeLanguage || $scope.isRequired.requiredClients) {
            return false;
        }
        else {
            $scope.isRequired.requiredUsername = false;
            $scope.isRequired.requiredFirstName = false;
            $scope.isRequired.requiredLastName = false;
            $scope.isRequired.requiredNativeLanguage = false;
            $scope.isRequired.requiredClients = false;
            $scope.isRequired.invalidUsername = false;
            $scope.isRequired.requiredClientAdminClients = false;
            $scope.isRequired.requiredProjects = false;
            return true;
        }
    };

    /**
     * @ngdoc
     * @name mandatoryValidationForEditUser
     * @methodOf Users.controller:UsersController
     * @param {String} userType This is user role
     * @description
     * This function is used to validate edit user form.
     * @returns {undefined} This method does not return.
     */
    mandatoryValidationForEditUser = function (userType) {
        //common code to validate fields like first name, last name, user name
        //if ($scope.EmailId == undefined || $scope.FirstName == undefined || $scope.LastName == undefined) {
        if (!$scope.EmailId) {
            $scope.isRequired.requiredUsername = true;
        }
        else {
            if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($scope.EmailId))) {
                $scope.editFormIsRequired.invalidUsername = true;
            }
            else {
                $scope.editFormIsRequired.invalidUsername = false;
            }
        }
        if (!$scope.FirstName) {
            $scope.editFormIsRequired.requiredFirstName = true;
        }
        if (!$scope.LastName) {
            $scope.editFormIsRequired.requiredLastName = true;
        }
        //}

        //For Approver and Editorial Staff
        if (userType === 'ApproverEditorial' && (!$scope.EditNativeLanguage || $scope.myDataClients.length < 1)) {
            if (!$scope.EditNativeLanguage) {
                $scope.editFormIsRequired.requiredNativeLanguage = true;
            }
            if ($scope.myDataClients.length < 1) {
                $scope.editFormIsRequired.requiredClientAdminClients = true;
            }
            return false;
        }
        //For Client Admin and Client User
        if (userType === 'ClientAdminClientUser' && ($scope.myDataClients.length < 1 || ($scope.myDataProjects.length < 1 && !$scope.ClientAdminAccessAllEdit))) {
            if ($scope.myDataClients.length < 1) {
                $scope.editFormIsRequired.requiredClientAdminClients = true;
            }
            if ($scope.myDataProjects.length < 1 && !$scope.ClientAdminAccessAllEdit) {
                $scope.editFormIsRequired.requiredProjects = true;
            }
            return false;
        }
        //if the user name is not null or it is not duplicate
        else if ($scope.EmailId && $scope.isAvailable) {
            return false;
        }
        else if ($scope.editFormIsRequired.requiredFirstName || $scope.editFormIsRequired.requiredLastName || $scope.editFormIsRequired.invalidUsername || $scope.editFormIsRequired.requiredUsername || $scope.editFormIsRequired.requiredNativeLanguage || $scope.editFormIsRequired.requiredClients) {
            return false;
        }
        else {
            $scope.editFormIsRequired.requiredUsername = false;
            $scope.editFormIsRequired.requiredFirstName = false;
            $scope.editFormIsRequired.requiredLastName = false;
            $scope.editFormIsRequired.requiredNativeLanguage = false;
            $scope.editFormIsRequired.requiredClients = false;
            $scope.editFormIsRequired.invalidUsername = false;
            $scope.editFormIsRequired.requiredClientAdminClients = false;
            $scope.editFormIsRequired.requiredProjects = false;
            return true;
        }
    };

    //Toggle Full permission with language and Editorial- GLMGR-169
    $scope.toggleLangEditorial = function () {
        if ($scope.fullPermission) {
            $scope.langPermission = false;
            $scope.editorialPermission = false;
        }
    };

    /**
     * @ngdoc
     * @name checkMaxLen
     * @methodOf Users.controller:UsersController
     * @param {String} field This is textbox in add/edit user form to check for max character length 
     * @description
     * This function is used to validate add/edit user form textboxes for maximum length.
     * @returns {undefined} This method does not return.
     */
    $scope.checkMaxLen = function (field) {
        switch (field) {
            case 'username':
                if ($scope.newUserName && $scope.newUserName.length > 150) {
                    $scope.maxLenErrorUsername = true;
                } else if ($scope.newUserName && $scope.newUserName.length <= 150) {
                    $scope.maxLenErrorUsername = false;
                }

                if ($scope.EmailId && $scope.EmailId.length > 150) {
                    $scope.maxLenErrorUsernameEdit = true
                    $('#usernameEdit').attr('style', 'display: block !important');
                } else if ($scope.EmailId && $scope.EmailId.length <= 150) {
                    $scope.maxLenErrorUsernameEdit = false
                    $('#usernameEdit').attr('style', 'display: none !important');
                }
                break;

            case 'fname':
                if ($scope.NewFirstName && $scope.NewFirstName.length > 35) {
                    $scope.maxLenErrorFname = true;

                } else if ($scope.NewFirstName && $scope.NewFirstName.length <= 35) {
                    $scope.maxLenErrorFname = false;
                }
                if ($scope.FirstName && $scope.FirstName.length > 35) {
                    $scope.maxLenErrorFnameEdit = true;
                    $('#fnameEdit').attr('style', 'display: block !important');
                } else if ($scope.FirstName && $scope.FirstName.length <= 35) {
                    $('#fnameEdit').attr('style', 'display: none !important');
                    $scope.maxLenErrorFnameEdit = false;
                }
                break;

            case 'lname':
                if ($scope.NewLastName && $scope.NewLastName.length > 35) {
                    $scope.maxLenErrorLname = true;
                } else if ($scope.NewLastName && $scope.NewLastName.length <= 35) {
                    $scope.maxLenErrorLname = false;
                }
                if ($scope.LastName && $scope.LastName.length > 35) {
                    $scope.maxLenErrorLnameEdit = true;
                    $('#lnameEdit').attr('style', 'display: block !important');
                } else if ($scope.LastName && $scope.LastName.length <= 35) {
                    $scope.maxLenErrorLnameEdit = false;
                    $('#lnameEdit').attr('style', 'display: none !important');
                }
                break;
        }
    };

    /**
     * @ngdoc
     * @name mandatoryValidationOnChange
     * @methodOf Users.controller:UsersController
     * @param {String} model This is input field name
     * @description
     * This function is for validation on change in the input fields of the Add/Edit User popup
     * @returns {undefined} This method does not return.
     */
    $scope.mandatoryValidationOnChange = function (model) {
        switch (model) {
            case 'Email':
                if (createNewButtonClicked) {
                    if ($scope.newUserName != '') {
                        $scope.isRequired.requiredUsername = false;
                        if (!$scope.maxLenErrorUsername && !(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($scope.newUserName))) {
                            $scope.isRequired.invalidUsername = true;
                            return false;
                        }
                        else {
                            $scope.isRequired.invalidUsername = false;
                        }
                        return true;
                    }
                    else {
                        $scope.isRequired.requiredUsername = true;
                        $scope.isRequired.invalidUsername = false;
                        return false;
                    }
                }
                else {
                    if ($scope.EmailId) {
                        $scope.editFormIsRequired.requiredUsername = false;
                        if (!$scope.maxLenErrorUsernameEdit && !(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($scope.EmailId))) {
                            $scope.editFormIsRequired.invalidUsername = true;
                            return false;
                        }
                        else {
                            $scope.editFormIsRequired.invalidUsername = false;
                        }
                        return true;
                    }
                    else {
                        $scope.editFormIsRequired.requiredUsername = true;
                        $scope.editFormIsRequired.invalidUsername = false;
                        return false;
                    }
                }
                break;
            case 'FirstName':
                if (createNewButtonClicked) {
                    if ($scope.NewFirstName) {
                        $scope.isRequired.requiredFirstName = false;
                        return true;
                    }
                    else {
                        $scope.isRequired.requiredFirstName = true;
                        return false;
                    }
                }
                else {
                    if ($scope.FirstName) {
                        $scope.editFormIsRequired.requiredFirstName = false;
                        return true;
                    }
                    else {
                        $scope.editFormIsRequired.requiredFirstName = true;
                        return false;
                    }
                }
                break;

            case 'LastName':
                if (createNewButtonClicked) {
                    if ($scope.NewLastName) {
                        $scope.isRequired.requiredLastName = false;
                        return true;
                    }
                    else {
                        $scope.isRequired.requiredLastName = true;
                        return false;
                    }
                }
                else {
                    if ($scope.LastName) {
                        $scope.editFormIsRequired.requiredLastName = false;
                        return true;
                    }
                    else {
                        $scope.editFormIsRequired.requiredLastName = true;
                        return false;
                    }
                }
                break;
            case 'NativeLanguage':
                if (createNewButtonClicked) {
                    if ($scope.nativeLanguage) {
                        $scope.isRequired.requiredNativeLanguage = false;
                        return true;
                    }
                    else {
                        $scope.isRequired.requiredNativeLanguage = true;
                        return false;
                    }
                }
                else {
                    if ($scope.EditNativeLanguage) {
                        $scope.editFormIsRequired.requiredNativeLanguage = false;
                        return true;
                    }
                    else {
                        $scope.editFormIsRequired.requiredNativeLanguage = true;
                        return false;
                    }

                }
                break;

            case 'Clients':
                if (createNewButtonClicked) {
                    if ($scope.ClientName) {
                        $scope.isRequired.requiredClients = false;
                        return true;
                    }
                    else {
                        $scope.isRequired.requiredClients = true;
                        return false;
                    }
                }
                else {
                    if ($scope.EditClientName) {
                        $scope.editFormIsRequired.requiredClients = false;
                        return true;
                    }
                    else {
                        $scope.editFormIsRequired.requiredClients = true;
                        return false;
                    }
                }
                break;

            case 'ClientAdmin':
                if (createNewButtonClicked) {
                    if ($scope.myDataClients.length > 0) {
                        $scope.isRequired.requiredClientAdminClients = false;
                        return true;
                    }
                    else {
                        $scope.isRequired.requiredClientAdminClients = true;
                        return false;
                    }
                }
                else {
                    if ($scope.myDataClients.length > 0) {
                        $scope.editFormIsRequired.requiredClientAdminClients = false;
                        return true;
                    }
                    else {
                        $scope.editFormIsRequired.requiredClientAdminClients = true;
                        return false;
                    }
                }
                break;

            case 'Projects':
                if (createNewButtonClicked) {
                    if ($scope.myDataProjects.length > 0) {
                        $scope.isRequired.requiredProjects = false;
                        return true;
                    }
                    else {
                        $scope.isRequired.requiredProjects = true;
                        return false;
                    }
                }
                else {
                    if ($scope.myDataProjects.length > 0) {
                        $scope.editFormIsRequired.requiredProjects = false;
                        return true;
                    }
                    else {
                        $scope.editFormIsRequired.requiredProjects = true;
                        return false;
                    }
                }
                break;
        }
    };

       /**
     * @ngdoc
     * @name imPersonate
     * @methodOf Users.controller:UsersController
     * @param {Object} user This is object containing selected users details to impersonate.
     * @description
     * This function is called on impersonation icon on users page. This function is used to impersonate user. 
     * @returns {undefined} This method does not return.
     */
    $scope.imPersonate = function (user) {
        if (!(user.Role.RoleName === 'Admin' || user.Role.RoleName === 'Super Admin')) {
            var UserImpersonateInfo = {};
            UserImpersonateInfo.UserName = user.Email;

            localStorage.setItem('adminUser', JSON.stringify(commonService.getLocalData('userDetails'))); // save original user to $scope.adminUser in CommonService impersonate feature

            UserImpersonateInfo.OriginalUserName = JSON.parse(localStorage.getItem('adminUser')).UserName;
            UserList.getUserAuthenticateImpersonate(UserImpersonateInfo.UserName,
                function (data, status, headers, config) {
                    getUserDetails(UserImpersonateInfo);
                });
        }
    }

    /**
     * @ngdoc
     * @name getUserDetails
     * @methodOf Users.controller:UsersController
     * @param {Object} UserImpersonateInfo This is object containing selected user's email id.
     * @description
     * This function is called inside imPersonate function. This is used to get selected user's user details. This is used to set local storage variables. 
     * @returns {undefined} This method does not return.
     */
    var getUserDetails = function (UserImpersonateInfo) {
        UserList.impersonateUser(UserImpersonateInfo, function (userDetails) {
            localStorage.setItem('isUserImpersonated', true);
            var localStorageUser = userDetails;
            localStorageUser.IsTermAccepted = true;
            localStorage.setItem('HomeValue', 'List');
            localStorage.setItem('userDetails', JSON.stringify(localStorageUser));
            window.location = '/Projects';
        });
    }

     /**
     * @ngdoc
     * @name init
     * @methodOf Users.controller:UsersController
     * @description
     * This function is called initially when page is loaded. This function is used for initialisation of the variables on page load.
     * @returns {undefined} This method does not return.
     */
    var init = function () {
        $scope.showLoader = true;
        //Get Logged In User details
        var userDetails = commonService.getLocalData('userDetails');
        $scope.userDetails = userDetails;
        $scope.CurrentUserId = $scope.userDetails.UserId;
        var resorceIdx = 0;
        sessionStorage.setItem('resourcePageId', JSON.stringify(resorceIdx));
        //commonService.getUserRecordDeleted(commonService.getLocalData('userDetails').UserId, resorceIdx, function (status) {});
        //Calling the service to get the Data for all the users on load
        UserList.getUserList(function (userlist) {
            if (userlist) {
                $scope.UserData = userlist;
                //GLMGR-619
                if (userDetails.UserRoles[0].UserRoleName === 'Admin' && $scope.UserData.UserPermissionList == null) {
                    $scope.showAddUserPermissionButton = true;
                }
                else {
                    if (userDetails.UserRoles[0].UserRoleName === 'Admin' && $scope.UserData.UserPermissionList.AddEditUser === false) {
                        $scope.showAddUserPermissionButton = false;
                    }
                    else {
                        $scope.showAddUserPermissionButton = true;
                    }
                }

                angular.copy(userlist.LanguageList, $scope.unSelectLang);
                //Copying for the native language reference
                angular.copy($scope.unSelectLang, $scope.copyOfUnselectedLang);
                //Copying for unselected languages in the edit mode
                angular.copy(userlist.EmailIds, $scope.availableUserNames);
                $scope.role = userlist.RoleList;
                angular.copy(userlist.UsersInformation, $scope.UserInfo);
                $scope.showLoader = false;

                $scope.ClientRoles = $scope.UserData.ClientList;
                $scope.member = { ClientRoles: [] };
                $scope.ObjectId1 = [];
                if ($scope.isActive == true) {
                    userSelection('active');
                }
                else if ($scope.isAll == true) {
                    userSelection('all');
                }
                else {
                    userSelection('inactive');
                }


                $scope.ObjectId2 = [];
                $scope.resetRoleDropdown();
                $scope.resetLanguageDropdown();
            }

            dynamicScreenHeight();
        });
    };
    init();
    /* Functionalities end */
}]);