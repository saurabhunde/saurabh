/**
 * @ngdoc controller
 * @name Translators.controller:TranslatorsController
 * @element div
 *
 * @description
 * This Controller is responsible for showing users on users page and all the operations done on users page.
 *
 * @requires AngularJS.$scope
 * @requires AngularJS.$route
 * @requires AngularJS.$location
 * @requires AngularJS.$timeout
 * @requires common.commonService
 * @requires Translators.TranslatorData
 * 
 * @property {string} currentEmailId:String  This property is current emaild of translator before editing.
 * @property {string} OldFirstNameLastName:String  This property is current First and Last name of translator before editing.
 * @property {number} currentUserId:Number  This property is user id of loggin in user.
 * @property {Array} ClientRoles:Array This property is list of all clients.
 * @property {Array} unSelectLang:Array This property is list of languages on left select box on add/edit translator popup for translator.
 * @property {Array} selectLang:Array This property is list of languages on right select box on add/edit translator popup for translator.
 * @property {Array} myDataClients:Array This property is list of all selected clients in clients dropdown on add/edit translator popup.
 * @property {Array} ForNativeLang:Array This property is list of native languages.
 * @property {Array} availableUserNames:Array This property is list of email ids of all existing translators.
 * @property {Array} UserLanguages:Array This property is list of all languages assigned to translator.
 * @property {Array} EnabledNotificationNames:Array This property is list of default enabled notifications for translators
 * @property {object} EmailCopiedForComparison:Object This is object stores copy of translator object for comparison 
 * @property {object} isRequired:Object This is validation object for add translator.
 * @property {object} editFormIsRequired:Object This is validation object for edit translator.
 * @property {object} NewTranslator:Object This is new translator object.
 * @property {object} TranslatorEditInfo:Object This is edit translator object.
 * @property {object} TranslatorDetails:Object This object contains all the details about translator 
 * @property {boolean} isActive:Boolean This property is boolean value.This is true translator is inactive else false.
 * @property {boolean} isInactive:Boolean This property is boolean value.This is true translator is active else false.
 * @property {boolean} addEditTraslatorTab:Boolean This property is boolean value. Used to toggle between notification tab and add translators tab on add/edit translator.
 * @property {boolean} notificationTab:Boolean This property is boolean value. Used to show/hide preview of knp preview.
 * 
 */
Translators.controller('translatorsController', ['$scope', '$http', '$location', 'TranslatorData', 'commonService', '$route', 'dirPaginateDirective', '$timeout', function ($scope, $http, $location, TranslatorData, commonService, $route, dirPaginateDirective, $timeout) {
    //Declaring variables
    var currentEmailId;
    var OldFirstNameLastName;
    $scope.unSelectLang = [];
    $scope.ClientRoles = [];
    $scope.ObjectId1 = [];
    $scope.uselectedLanguagesEditCopy = [];
    $scope.EditNativeLanguageModelCopy = {};
    $scope.isActive = true;
    $scope.isInactive = false;
    $scope.isAll = false;
    $scope.showLoader = false;
    $scope.enableOtherLangs = false;
    var createNewButtonClicked = false;
    $scope.selectLang = [];
    var availableUserNames = [];
    var ForNativeLang = [];
    var ForNativeLangEdit = [];
    var UserLanguagesList = [];
    $scope.UserLanguages = [];
    var UserLangList = [];
    $scope.copyOfUnselectedLang = [];
    $scope.UserLanguagesExp = [];
    $scope.UserLanguagesExpEdit = [];
    var myDataClients = [];
    $scope.TranslatorEditExperience = [];
    $scope.TranslatorViewExperience = [];
    var EmailCopiedForComparison = {};
    var ClientAddNewTranslatorSelected = false;
    var ClientAddNewTranslatorInitialSelected = true;
    var ClientEditTranslatorSelected = false;
    $scope.ViewUserLanguages = [];
    $scope.deleteValidationMsg = "";
    $scope.TranslatorEditInfo = { transInfo: { FirstName: "", LastName: "", Email: "" }, AssignedClientIds: [], TranslatorExperiences: [] };
    $scope.uselectedLanguagesEdit = [];
    $scope.TranslatorDetails = {};
    $scope.NewTranslator = {
        TranslatorDetails: {
            FirstName: "",
            LastName: "",
            Email: "",
        }
    };
    $scope.NewTranslator.TranslatorDetails.CurrentUserId = $scope.CurrentUserId;
    $scope.NewTranslator.TranslatorDetails.RoleId = '2';
    $scope.TranslatorExperience = [
        {
            Title: "",
            LanguageId: 0,
            Notes: ""
        }
    ];
    $scope.isRequired = {
        "requiredUsername": false,
        "requiredFirstName": false,
        "requiredLastName": false,
        "requiredNativeLanguage": false,
        "requiredClients": false,
        "invalidUsername": false
    };
    $scope.editFormIsRequired = {
        "requiredUsername": false,
        "requiredFirstName": false,
        "requiredLastName": false,
        "requiredNativeLanguage": false,
        "requiredClients": false,
        "invalidUsername": false
    };

    $scope.isMaxLen = {
        "fname": false,
        "laname": false,
        "username": false
    };

    $scope.isMaxLenEdit = {
        "fname": false,
        "laname": false,
        "username": false
    };
    //original userID
    if ($scope.adminUser) {
        $scope.originalUserId = $scope.adminUser.UserId;
    } else {
        $scope.originalUserId = null;
    }

    $scope.showAddUserPermissionButton = false;
    var emailRegex = new RegExp("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$");

    //GLMGR-131
    $scope.noUserAvailable = true;

    //ID array for notifications which are by default enabled
    var EnabledNotificationNames = ["Notify me when assigned to a project", "Notify me when section is ready for translation/section is complete", "Notify me when translation is completed", "Notify me when translation is rejected"];//[1,2,7,8,9,10];
    $scope.addEditTraslatorTab = true;
    $scope.notificationTab = false;

    //set hashURL for GLMGR-1189
    sessionStorage.setItem('hashURL', null);

      /**
     * @ngdoc
     * @name showAddUserTab
     * @methodOf Translators.controller:TranslatorsController
     * @description
     * This function is used to show add translator tab
     * @returns {undefined} This method does not return.
     */
    $scope.showAddUserTab = function () {
        $scope.notificationTab = false;
        $scope.addEditTraslatorTab = true;
    };

     /**
     * @ngdoc
     * @name showNotificationTab
     * @methodOf Translators.controller:TranslatorsController
     * @description
     * This function is used to show notification settings tab
     * @returns {undefined} This method does not return.
     */
    $scope.showNotificationTab = function () {
        $scope.notificationTab = true;
        $scope.addEditTraslatorTab = false;
    };
    /* Functionalities start */

    $scope.$on('selectedModel', function (event, myData) {
        myDataClients = myData;
        if (myDataClients.length > 0) {
            ClientAddNewTranslatorSelected = false;
            ClientAddNewTranslatorInitialSelected = false;
            ClientEditTranslatorSelected = false;
            $scope.editFormIsRequired.requiredClients = false;
            $scope.isRequired.requiredClients = false;
            $scope.client_str = '';
            for (j = 0; j < myDataClients.length; j++) {
                for (i = 0; i < $scope.TranslatorList.ClientList.length; i++) {
                    if ($scope.TranslatorList.ClientList[i].ClientId === myDataClients[j]) {
                        if ($scope.client_str != '') {
                            $scope.client_str = $scope.client_str + ', ' + $scope.TranslatorList.ClientList[i].ClientName;
                        } else {
                            $scope.client_str = $scope.client_str + $scope.TranslatorList.ClientList[i].ClientName;
                        }
                        $('.client_str').html($scope.client_str);
                        $('.client_str').attr('title', $scope.client_str);
                    }
                }
            }
        }
        else {
            $scope.editFormIsRequired.requiredClients = true;
            $scope.isRequired.requiredClients = true;
            ClientAddNewTranslatorSelected = true;
            ClientAddNewTranslatorInitialSelected = true;
            ClientEditTranslatorSelected = true;
            $('.client_str').html('Select Client(s)');
            $('.client_str').attr('title', 'Select Client(s)');
            return false;
        }
    });


    /**
     * @ngdoc
     * @name showStatusWiseTranslatorList
     * @methodOf Translators.controller:TranslatorsController
     * @param {String} UserStatus This is selected status from filter dropdown.
     * @description
     * This function is used to show translator list as per the status (Active/Inactive/All).
     * @returns {undefined} This method does not return.
     */
    $scope.showStatusWiseTranslatorList = function (UserStatus) {
        switch (UserStatus) {
            //If the selected status is inactive then make the inactive flag true
            case 'inactive':
                $scope.isActive = false;
                $scope.isInactive = true;
                $scope.isAll = false;
                $scope.TranslatorState = 3;
                $('#actionsColumn').css('min-width', '166px');
                translatorSelection('inactive');
                break;

            //If the selected status is all then make the all flag true
            case 'all':
                $scope.isActive = false;
                $scope.isInactive = false;
                $scope.isAll = true;
                $scope.TranslatorState = 5;
                $('#actionsColumn').css('min-width', '214px');
                translatorSelection('all');
                break;

            //else display by default only the active users by making the active flag true
            default: $scope.isActive = true;
                $scope.isInactive = false;
                $scope.isAll = false;
                $scope.TranslatorState = 4;
                $('#actionsColumn').css('min-width', '214px');
                translatorSelection('active');
                break;

        }
    };

    /**
     * @ngdoc
     * @name addNewExperienceRow
     * @methodOf Translators.controller:TranslatorsController
     * @description
     * This function is used to add new experience row in add translator popup
     * @returns {undefined} This method does not return.
     */
    $scope.addNewExperienceRow = function () {
        var newRowObj = {
            Title: "",
            LanguageId: 0,
            Notes: ""
        };
        $scope.TranslatorExperience.push(newRowObj);
    };

    /**
     * @ngdoc
     * @name deleteNewExperienceRow
     * @methodOf Translators.controller:TranslatorsController
     * @param {Number} index This is index of row to be deleted.
     * @description
     * This function is used to delete experience row in add translator popup
     * @returns {undefined} This method does not return.
     */
    $scope.deleteNewExperienceRow = function (exp, index) {
        for (var i = 0; i < $scope.TranslatorExperience.length; i++) {
            if (i == index) {
                var deletedRow = $scope.TranslatorExperience.splice(index, 1);
            }
        }
    };

    /**
     * @ngdoc
     * @name addEditNewExperienceRow
     * @methodOf Translators.controller:TranslatorsController
     * @description
     * This function is used to add new experience row in edit translator popup
     * @returns {undefined} This method does not return.
     */
    $scope.addEditNewExperienceRow = function () {
        var newRowObj = {
            newExp: true,
            Title: "",
            ExperienceRecordId: 0,
            LanguageId: 0,
            Notes: ""
        };
        $scope.TranslatorEditExperience.push(newRowObj);
    };

    /**
     * @ngdoc
     * @name deleteNewExperienceRowForEdit
     * @methodOf Translators.controller:TranslatorsController
     * @param {Number} index This is index of row to be deleted.
     * @description
     * This function is used to delete experience row in edit translator popup
     * @returns {undefined} This method does not return.
     */
    $scope.deleteNewExperienceRowForEdit = function (exp, index) {
        for (var i = 0; i < $scope.TranslatorEditExperience.length; i++) {
            if (i == index) {
                var deletedRow = $scope.TranslatorEditExperience.splice(index, 1);
            }
        }
    };

     /**
     * @ngdoc
     * @name activateTranslator
     * @methodOf Translators.controller:TranslatorsController
     * @param {Object} trans This is object contains all the details of selected translator from list.
     * @description
     * This function is used to make inactive translators active.
     * @returns {undefined} This method does not return.
     */
    $scope.activateTranslator = function (trans) {
        TranslatorData.activateTranslatorInformation(trans.UserId, $scope.CurrentUserId, '2', function (isActivated) {
            if (isActivated) {
                $scope.deleteValidationMsg = "The selected user is activated";
                $('#deleteValidationMsgDiv').css('display', 'block');
                $timeout(function () { $('#deleteValidationMsgDiv').css('display', 'none') }, 3000);
                init();
            }
            else {
                $scope.deleteValidationMsg = "The selected user could not be activated";
            }
            setTimeout(function () { dynamicScreenHeight(); }, 500);
        });
    };

    /**
     * @ngdoc
     * @name addNewTranslator
     * @methodOf Translators.controller:TranslatorsController
     * @description
     * This function is used to open add new translators popup.
     * @returns {undefined} This method does not return.
     */
    $scope.addNewTranslator = function () {
        TranslatorData.getAddUserEmialNotificationInfo("Translator", function (notifications) {
            //adding new property IsActive to object in obj array
            for (var i = 0; i < notifications.length; i++) {
                notifications[i].IsActive = false;
            }
            //setting IsActive property to true for only those notifications which are by default set to true
            for (var i = 0; i < notifications.length; i++) {
                for (var j = 0; j < EnabledNotificationNames.length; j++) {
                    if (notifications[i].NotificationName === EnabledNotificationNames[j]) {
                        notifications[i].IsActive = true;
                    }
                }
            }
            $scope.notifications = notifications;
        });

        $('#newTranslator').modal({ backdrop: 'static', keyboard: false });
        $('#newTranslator').modal('show');
    };

      /**
     * @ngdoc
     * @name createNewTranslatorUser
     * @methodOf Translators.controller:TranslatorsController
     * @description
     * This function is used to add new translators. This function is called on create new translator button on add new translator popup.
     * @returns {undefined} This method does not return.
     */
    $scope.createNewTranslatorUser = function () {
        if ($scope.mandatoryValidation('createNewButtonClicked') === false) {
            $scope.notificationTab = false;
            $scope.addEditTraslatorTab = true;
        }
        else {
            $scope.afterFirstSelection = false;
            angular.copy($scope.selectLang, UserLanguagesList);
            UserLanguagesList.push($scope.nativeLanguage);

            $scope.NewTranslator.TranslatorDetails.ClientList = myDataClients;

            $scope.NewTranslator.TranslatorDetails.UserLanguagesList = UserLanguagesList;
            $scope.NewTranslator.TranslatorDetails.isStarred = $scope.StarredTermNew;
            $scope.NewTranslator.TranslatorExperienceList = $scope.TranslatorExperience;

            //create notifications settings array with required properties GLMGR-1349
            var notificationArray = [];
            for (var i = 0; i < $scope.notifications.length; i++) {
                var NotificationObj = {};
                NotificationObj.UserEmailNotificationId = 0;
                NotificationObj.UserId = 0;
                NotificationObj.NotificationId = $scope.notifications[i].Id;
                NotificationObj.NotificationName = $scope.notifications[i].NotificationName;
                NotificationObj.IsActive = $scope.notifications[i].IsActive;
                NotificationObj.OriginalUserId = $scope.originalUserId;
                NotificationObj.LoggedInUserId = commonService.getLocalData('userDetails').UserId;

                notificationArray.push(NotificationObj);
            }
            $scope.NewTranslator.TranslatorDetails.UserEmailNotificationList = notificationArray;

            $('#newTranslator').modal('hide');
            $('.modal-backdrop.fade.in').css('display', 'none');
            $scope.showLoader = true;
            //Calling Service to save the new Translator Information
            TranslatorData.saveTranslatorInformation($scope.NewTranslator, function (isSaved) {
                $route.reload();
            });
        }
    };

    $scope.dissmissPopup = function () {
        $route.reload();
        $('.modal-backdrop.fade.in').css('display', 'none');
    };

     /**
     * @ngdoc
     * @name checkForDuplicateUsername
     * @methodOf Translators.controller:TranslatorsController
     * @param {String} newUserName This is email id of translator which needs to checked for duplicate username.
     * @description
     * This function is called on change of input Username input field in add/edit translator popup.This function is used to check for duplicate user names for translators.
     * @returns {undefined} This method does not return.
     */
    $scope.checkForDuplicateUsername = function (newUserName) {
        if (EmailCopiedForComparison.Email) {
            if (newUserName.toLowerCase() !== EmailCopiedForComparison.Email.toLowerCase()) {
                for (var i = 0; i < availableUserNames.length; i++) {
                    if (newUserName.toLowerCase() === availableUserNames[i].toLowerCase()) {
                        $scope.isAvailable = true;
                        return false;
                    }
                    else {
                        $scope.isAvailable = false;
                    }
                }
            }
            else {
                $scope.isAvailable = false;
            }
        } else {
            for (var i = 0; i < availableUserNames.length; i++) {
                if (newUserName.toLowerCase() === availableUserNames[i].toLowerCase()) {
                    $scope.isAvailable = true;
                    return false;
                }
                else {
                    $scope.isAvailable = false;
                }
            }
        }
    };

     /**
     * @ngdoc
     * @name selectLangClick
     * @methodOf Translators.controller:TranslatorsController
     * @param {Object} selectedLang This is object containing all the details about selected language from select box.
     * @description
     * This function is used for selecting languages and pushing to the right side of the list from left side.
     * @returns {undefined} This method does not return.
     */
    $scope.selectLangClick = function (selectedLang) {
        $scope.UserLanguagesExp = [];
        //Add all the selected languages to the Native Language dropdown array
        for (var i = 0; i < selectedLang.length; i++) {
            ForNativeLang.push(selectedLang[i]);
        }
        //Adding the selected languages to the left side of the List
        for (var i = 0; i < selectedLang.length; i++) {
            $scope.selectLang.push(selectedLang[i]);
            var index = $scope.unSelectLang.indexOf(selectedLang[i]);
            if (index > -1) {
                $scope.unSelectLang.splice(index, 1);
            }
        }
        angular.copy($scope.selectLang, $scope.UserLanguagesExp);
        $scope.UserLanguagesExp.push($scope.nativeLanguage);
    };

    /**
     * @ngdoc
     * @name UnSelectLangClick
     * @methodOf Translators.controller:TranslatorsController
     * @param {Object} unSelectedLang This is object containing all the details about selected language from select box.
     * @description
     * This function is used for deselecting selected languages and pushing to the left side of the list from right side
     * @returns {undefined} This method does not return.
     */
    $scope.UnSelectLangClick = function (unSelectedLang) {
        $scope.UserLanguagesExp = [];
        //Removing all the deselected items from the Native Language Array
        for (var i = 0; i < unSelectedLang.length; i++) {
            var spliceIndex = ForNativeLang.indexOf(unSelectedLang[i]);
            if (spliceIndex > -1) {
                ForNativeLang.splice(spliceIndex, 1);
            }
        }
        //Adding data to the right side of the array
        for (var i = 0; i < unSelectedLang.length; i++) {
            $scope.unSelectLang.push(unSelectedLang[i]);
            var index = $scope.selectLang.indexOf(unSelectedLang[i]);
            if (index > -1) {
                $scope.selectLang.splice(index, 1);
            }
        }
        angular.copy($scope.selectLang, $scope.UserLanguagesExp);
        $scope.UserLanguagesExp.push($scope.nativeLanguage);
    };

     /**
     * @ngdoc
     * @name checkIsNativeLanguage
     * @methodOf Translators.controller:TranslatorsController
     * @param {Object} oldValue old value of native language.
     * @description
     * This function is used to check whether the selected language is Native Language or not
     * @returns {undefined} This method does not return.
     */
    $scope.checkIsNativeLanguage = function (oldValue) {
        $scope.mandatoryValidation();
        $scope.UserLanguagesExp = [];
        $scope.nativeLanguage.IsNative = true;
        $scope.afterFirstSelection = true;
        //this block checks for language same as that of selected native language from the right list of languages
        if ($scope.selectLang.length > 0) {
            for (var i = 0; i < $scope.selectLang.length; i++) {
                //reset all the IsNative flags to be false
                if ($scope.selectLang[i].IsNative) {
                    $scope.selectLang[i].IsNative = false;
                }
                //remove the selected native language from the right list
                if ($scope.nativeLanguage.LanguageId === $scope.selectLang[i].LanguageId) {
                    $scope.selectLang.splice(i, 1);
                    if (oldValue) {
                        oldValue.IsNative = false;
                        $scope.unSelectLang.push(oldValue);
                    }
                }
            }
        }
        //this block checks for language same as that of selected native language from the left list of languages
        if ($scope.unSelectLang.length > 0) {
            // var len = $scope.unSelectLang.length;
            for (var i = 0; i < $scope.unSelectLang.length; i++) {
                if ($scope.unSelectLang[i].IsNative) {
                    $scope.unSelectLang[i].IsNative = false;
                }
                if ($scope.nativeLanguage.LanguageId === $scope.unSelectLang[i].LanguageId) {
                    $scope.unSelectLang.splice(i, 1);
                    if (oldValue) {
                        oldValue.IsNative = false;
                        $scope.unSelectLang.push(oldValue);
                    }
                    //len = len - 1;
                    //i = i - 1;
                }
            }
        }
        //checking if there are same selected languages with the main list of languages
        if ($scope.unSelectLang.length > 0 && $scope.selectLang.length > 0) {
            var unselectedLanLength = $scope.unSelectLang.length;
            var selectedLanLength = $scope.selectLang.length;
            for (var i = 0; i < unselectedLanLength; i++) {
                for (var j = 0; j < selectedLanLength; j++) {
                    if ($scope.unSelectLang[i].LanguageId === $scope.selectLang[j].LanguageId) {
                        $scope.unSelectLang.splice(i, 1);
                        j = j - 1;
                        selectedLanLength = selectedLanLength - 1;
                    }
                }
            }
        }
        $scope.enableOtherLangs = true;
        angular.copy($scope.selectLang, $scope.UserLanguagesExp);
        $scope.UserLanguagesExp.push($scope.nativeLanguage);
    };
    /* End of Add New Translator */

    /*Delete a Translator*/
    /**
     * @ngdoc
     * @name deleteTranslator
     * @methodOf Translators.controller:TranslatorsController
     * @param {Object} trans This is translators details to be deleted.
     * @description
     * This function is used to open delete confirmation popup
     * @returns {undefined} This method does not return.
     */
    $scope.deleteTranslator = function (trans) {
        $scope.Username = trans.Email;
        $scope.UserId = trans.UserId;
        $('#deleteModal').modal({ backdrop: 'static', keyboard: false });
        $('#deleteModal').modal('show');
    };

      /**
     * @ngdoc
     * @name confirmDeleteUserButton
     * @methodOf Translators.controller:TranslatorsController
     * @description
     * This function is used delete user after clicking on yes button of delete popup
     * @returns {undefined} This method does not return.
     */
    $scope.confirmDeleteUserButton = function () {
        //Calling the service fro deleting a translator
        TranslatorData.deleteTranslatorInformation($scope.UserId, $scope.CurrentUserId, function (isDeleted) {
            if (isDeleted) {
                $scope.deleteValidationMsg = "The selected translator is deleted";
                $('#deleteValidationMsgDiv').css('display', 'block');
                setTimeout(function () { $('#deleteValidationMsgDiv').css('display', 'none') }, 3000);
                init();
            }
            else {
                $scope.deleteValidationMsg = "The selected user could not be deleted";
            }
            setTimeout(function () { dynamicScreenHeight(); }, 500);
        });
    }
    /* End of Delete a Translator */

    //for removing the default selected native language
    $scope.disableFirstoption = function () {
        $scope.preSelectedNativeLang = true;
    };

    /* Start Edit a  Translator Info */
     /**
     * @ngdoc
     * @name editTranslatorInfo
     * @methodOf Translators.controller:TranslatorsController
     * @param {Object} user This is object contains all the details of selected translator from list.
     * @description
     * This function is used to open edit translator popup with all the translator details.
     * @returns {undefined} This method does not return.
     */
    $scope.editTranslatorInfo = function (user) {
        currentEmailId = user.Email;
        OldFirstNameLastName = user.FirstName + " " + user.LastName;
        //GLMGR-1349 set add translator tab by default
        $scope.addEditTraslatorTab = true;
        $scope.notificationTab = false;

        $scope.preSelectedNativeLang = false;
        $scope.UserLanguagesExpEdit = [];

        $scope.TranslatorEditInfo.transInfo.FirstName = user.FirstName;
        $scope.TranslatorEditInfo.transInfo.LastName = user.LastName;
        $scope.TranslatorEditInfo.transInfo.Email = user.Email;

        //get users notification settings
        $scope.EditTrasnlatorNotifications = user.UserEmailNotificationList;

        angular.copy(user, EmailCopiedForComparison);

        angular.copy(user.UserLanguages, $scope.UserLanguages);
        angular.copy(user.unselectedLanguageInfo, $scope.uselectedLanguagesEdit);
        angular.copy(user.unselectedLanguageInfo, $scope.uselectedLanguagesEditCopy);

        $scope.ObjectId1 = [];
        $scope.client_str = '';
        for (var i = 0; i < user.AssignedClientList.length; i++) {
            $scope.ObjectId1.push(user.AssignedClientList[i].ClientId);
            $scope.client_str = $scope.client_str + user.AssignedClientList[i].ClientName + ', ';
        }
        $scope.client_str = $scope.client_str.slice(0, -2);
        if (user.AssignedClientList.length > 0) {
            $('.client_str').html($scope.client_str);
            $('.client_str').attr('title', $scope.client_str);
        } else {
            $('.client_str').html('Select Client(s)');
            $('.client_str').attr('title', 'Select Client(s)');
        }

        myDataClients = $scope.ObjectId1;

        //Checking and changing the native language as per the selection from the dropdown
        if ($scope.UserLanguages.length > 0) {
            for (var i = 0; i < $scope.UserLanguages.length; i++) {
                if ($scope.UserLanguages[i].IsNative) {
                    $scope.EditNativeLanguage = $scope.UserLanguages[i];
                    angular.copy($scope.EditNativeLanguage, $scope.EditNativeLanguageModelCopy);
                }
            }
        }

        //Remove the selected native language from the right side other languages list
        for (var i = 0; i < $scope.UserLanguages.length; i++) {
            if ($scope.UserLanguages[i].LanguageId === $scope.EditNativeLanguage.LanguageId) {
                $scope.UserLanguages.splice(i, 1);
            }
        }
        angular.copy($scope.UserLanguages, $scope.UserLanguagesExpEdit);
        $scope.UserLanguagesExpEdit.push($scope.EditNativeLanguage);

        //Calling Service to get the selected translator info
        TranslatorData.getTranslatorExperienceData(user.UserId, function (translatorExp) {
            //Copying the translator experience info in the edit mode
            if (translatorExp.length < 1) {
                var newRowObj = {
                    newExp: true,
                    Title: "",
                    LanguageId: 0,
                    Notes: ""
                };
                $scope.TranslatorEditExperience.push(newRowObj)
            }
            else {
                angular.copy(translatorExp, $scope.TranslatorEditExperience);
            }

        });

        $('#editUser').modal({ backdrop: 'static', keyboard: false });
        $('#editUser').modal('show');

        //Save info of translator on click of Update Button
        $scope.updateTranslatorInfo = function () {
            if ($scope.mandatoryValidation() === false) {
                $scope.notificationTab = false;
                $scope.addEditTraslatorTab = true;
            }
            else {
                $scope.TranslatorEditInfo.AssignedClientIds = [];
                angular.copy($scope.UserLanguages, UserLangList);
                UserLangList.push($scope.EditNativeLanguage);
                //Creating JSON for saving translator information to the DB
                $scope.TranslatorEditInfo.CurrentUserId = $scope.CurrentUserId;
                $scope.TranslatorEditInfo.AssignedClientIds = myDataClients;
                $scope.TranslatorEditInfo.transInfo.UserId = user.UserId;
                $scope.TranslatorEditInfo.transInfo.UserLanguages = UserLangList;
                $scope.TranslatorEditInfo.TranslatorExperiences = $scope.TranslatorEditExperience;

                //create notifications settings array with required properties GLMGR-1349
                var notificationArray = [];

                for (var i = 0; i < $scope.EditTrasnlatorNotifications.length; i++) {
                    var NotificationObj = {};
                    NotificationObj.UserEmailNotificationId = $scope.EditTrasnlatorNotifications[i].UserEmailNotificationId;
                    NotificationObj.UserId = $scope.TranslatorEditInfo.transInfo.UserId;
                    NotificationObj.NotificationId = $scope.EditTrasnlatorNotifications[i].NotificationId;
                    NotificationObj.NotificationName = $scope.EditTrasnlatorNotifications[i].NotificationName;
                    NotificationObj.IsActive = $scope.EditTrasnlatorNotifications[i].IsActive;
                    NotificationObj.OriginalUserId = $scope.originalUserId;
                    NotificationObj.LoggedInUserId = commonService.getLocalData('userDetails').UserId;


                    notificationArray.push(NotificationObj);
                }
                $scope.TranslatorEditInfo.UserEmailNotificationList = notificationArray;
                $scope.TranslatorEditInfo.OldEmailId = currentEmailId;
                $scope.TranslatorEditInfo.OldFirstNameLastName = OldFirstNameLastName;
                $('#editUser').modal('hide');
                $('.modal-backdrop.fade.in').css('display', 'none');
                $scope.showLoader = true;
                //Calling Service to save the info
                TranslatorData.updateTranslatorInformation($scope.TranslatorEditInfo, function (isUpdated) {
                    $route.reload();
                });
            }
        }
    };

    /**
     * @ngdoc
     * @name selectEditLangClick
     * @methodOf Translators.controller:TranslatorsController
     * @param {Object} selectedLang This is object containing all the details about selected language from select box on edit translator popup.
     * @description
     * This function is used for selecting languages and pushing to the right side of the list from left side.
     * @returns {undefined} This method does not return.
     */
    $scope.selectEditLangClick = function (selectedLang) {
        $scope.UserLanguagesExpEdit = [];
        for (var i = 0; i < selectedLang.length; i++) {
            ForNativeLangEdit.push(selectedLang[i]);
        }
        for (var i = 0; i < selectedLang.length; i++) {
            $scope.UserLanguages.push(selectedLang[i]);
            var index = $scope.uselectedLanguagesEdit.indexOf(selectedLang[i]);
            if (index > -1) {
                $scope.uselectedLanguagesEdit.splice(index, 1);
            }
        }
        angular.copy($scope.UserLanguages, $scope.UserLanguagesExpEdit);
        $scope.UserLanguagesExpEdit.push($scope.EditNativeLanguage);
    };

      /**
     * @ngdoc
     * @name UnSelectEditLangClick
     * @methodOf Translators.controller:TranslatorsController
     * @param {Object} unSelectedLang This is object containing all the details about selected language from select box on edit translator popup.
     * @description
     * This function is used for deselecting selected languages and pushing to the left side of the list from right side
     * @returns {undefined} This method does not return.
     */
    $scope.UnSelectEditLangClick = function (unSelectedLang) {
        $scope.UserLanguagesExpEdit = [];
        //Removing the unselected languages from the Native Language array of edit translator 
        for (var i = 0; i < unSelectedLang.length; i++) {
            var spliceIndex = ForNativeLangEdit.indexOf(unSelectedLang[i]);
            if (spliceIndex > -1) {
                ForNativeLangEdit.splice(spliceIndex, 1);
            }
        }
        //Adding the unselected language from right to left side list
        for (var i = 0; i < unSelectedLang.length; i++) {
            $scope.uselectedLanguagesEdit.push(unSelectedLang[i]);
            var index = $scope.UserLanguages.indexOf(unSelectedLang[i]);
            if (index > -1) {
                $scope.UserLanguages.splice(index, 1);
            }
        }
        angular.copy($scope.UserLanguages, $scope.UserLanguagesExpEdit);
        $scope.UserLanguagesExpEdit.push($scope.EditNativeLanguage);
    };

     /**
     * @ngdoc
     * @name checkIsNativeLanguageForEdit
     * @methodOf Translators.controller:TranslatorsController
     * @description
     * This function is used to select native language for translator and accordingly set to the appropriate boolean values as per the selection
     * @returns {undefined} This method does not return.
     */
    $scope.checkIsNativeLanguageForEdit = function () {
        $scope.mandatoryValidation();
        if ($scope.editFormIsRequired.requiredUsername === true || $scope.isAvailable === true || $scope.editFormIsRequired.invalidUsername === true || $scope.editFormIsRequired.requiredFirstName === true || $scope.editFormIsRequired.requiredLastName === true || $scope.editFormIsRequired.requiredNativeLanguage === true || $scope.editFormIsRequired.requiredClients === true) {
            $scope.notificationTab = false;
            $scope.addEditTraslatorTab = true;
            return false;
        } else {
            $scope.UserLanguagesExpEdit = [];
            //remove language from the right side list if it has same languages as the selected native language
            if ($scope.UserLanguages.length > 0) {
                for (var i = 0; i < $scope.UserLanguages.length; i++) {
                    if ($scope.UserLanguages[i].IsNative) {
                        $scope.UserLanguages[i].IsNative = false;
                    }
                    if ($scope.EditNativeLanguage.LanguageId === $scope.UserLanguages[i].LanguageId) {
                        $scope.UserLanguages.splice(i, 1);
                        if ($scope.oldValue) {
                            $scope.oldValue.IsNative = false;
                            $scope.uselectedLanguagesEdit.push($scope.oldValue);
                        }
                    }
                }
            }

            $scope.EditNativeLanguage.IsNative = true;
            //this block removes language from the left side list if it has same languages as the selected native language
            if ($scope.uselectedLanguagesEdit.length > 0) {
                for (var i = 0; i < $scope.uselectedLanguagesEdit.length; i++) {
                    if ($scope.uselectedLanguagesEdit[i].IsNative) {
                        $scope.uselectedLanguagesEdit[i].IsNative = false;
                    }
                    if ($scope.EditNativeLanguage.LanguageId === $scope.uselectedLanguagesEdit[i].LanguageId) {
                        $scope.uselectedLanguagesEdit.splice(i, 1);
                        if ($scope.oldValue) {
                            $scope.oldValue.IsNative = false;
                            $scope.uselectedLanguagesEdit.push($scope.oldValue);
                        }
                    }
                }
            }
            //checking if there are same languages in the right and left list
            for (var i = 0; i < $scope.uselectedLanguagesEdit.length; i++) {
                for (var j = 0; j < $scope.UserLanguages.length; j++) {
                    if ($scope.uselectedLanguagesEdit[i].LanguageId === $scope.UserLanguages[j].LanguageId) {
                        $scope.uselectedLanguagesEdit.splice(i, 1);
                    }
                }
            }
            $scope.enableOtherLangs = true;
            angular.copy($scope.UserLanguages, $scope.UserLanguagesExpEdit);
            $scope.UserLanguagesExpEdit.push($scope.EditNativeLanguage);
        }
    };
    /* End of Edit a  Translator Info */

    /* View Translator Info */
    /**
     * @ngdoc
     * @name viewTranslatorInfo
     * @methodOf Translators.controller:TranslatorsController
     * @param {Object} trans This is object contains all the details of selected translator from list.
     * @description
     * This function is used to view selected translators information.
     * @returns {undefined} This method does not return.
     */
    $scope.viewTranslatorInfo = function (trans) {
        $scope.ViewFirstName = trans.FirstName;
        $scope.ViewLastName = trans.LastName;
        $scope.ViewEmailId = trans.Email;
        angular.copy(trans.UserLanguages, $scope.ViewUserLanguages);
        if ($scope.ViewUserLanguages.length > 0) {
            //checking for the native language and assigning it to the appropriate model
            for (var i = 0; i < $scope.ViewUserLanguages.length; i++) {
                if ($scope.ViewUserLanguages[i].IsNative) {
                    $scope.ViewForNativeLang = $scope.ViewUserLanguages[i].LanguageName;
                }
            }
            //checking if the native language is present in the other languages list
            for (var i = 0; i < $scope.ViewUserLanguages.length; i++) {
                if ($scope.ViewUserLanguages[i].LanguageName === $scope.ViewForNativeLang) {
                    $scope.ViewUserLanguages.splice(i, 1);
                }
            }
        }
        $('#viewTranslator').modal({ backdrop: 'static', keyboard: false });
        $('#viewTranslator').modal('show');
        //Get selected translator info from the backend
        TranslatorData.getTranslatorExperienceData(trans.UserId, function (translatorExp) {
            angular.copy(translatorExp, $scope.TranslatorViewExperience);
        });
    };

    //reset pagination
    var translatorSelection = function (UserStatus) {
        $scope.TranslatorsInformationActive = {};
        $scope.noUserAvailable = true;
        if (!UserStatus || UserStatus === 'active') {
            var TrActive = [];
            for (i = 0; i < $scope.TranslatorList.TranslatorsInformation.length; i++) {
                if ($scope.TranslatorList.TranslatorsInformation[i].IsActive === true)
                    TrActive.push($scope.TranslatorList.TranslatorsInformation[i]);
            }
            $scope.TranslatorsInformationActive['TrActive'] = TrActive;
        } else if (UserStatus === 'inactive') {
            var TrInActive = [];
            for (i = 0; i < $scope.TranslatorList.TranslatorsInformation.length; i++) {
                if ($scope.TranslatorList.TranslatorsInformation[i].IsActive === false)
                    TrInActive.push($scope.TranslatorList.TranslatorsInformation[i]);
            }
            $scope.TranslatorsInformationActive['TrInActive'] = TrInActive;
        } else {
            $scope.TranslatorsInformationActive['all'] = $scope.TranslatorList.TranslatorsInformation;
        }
        setTimeout(function () { dynamicScreenHeight(); }, 500);
    };
    /* End Of Translator Info */

   /**
     * @ngdoc
     * @name showStatusLanguageWiseTranslatorList
     * @methodOf Translators.controller:TranslatorsController
     * @param {String} UserStatus This is user status active/inactive
     * @param {Number} selectedLanguageId This is selected language id. 
     * @description
     * This function is used to sort list of translator users language wise.
     * @returns {undefined} This method does not return.
     */
    $scope.showStatusLanguageWiseTranslatorList = function (UserStatus, selectedLanguageId) {
        translatorSelection(UserStatus);
        if (selectedLanguageId !== null) {
            if (!UserStatus || UserStatus === 'active') {
                var TrActive = [];
                for (var i = 0; i < $scope.TranslatorsInformationActive.TrActive.length; i++) {
                    for (var j = 0; j < $scope.TranslatorsInformationActive.TrActive[i].UserLanguages.length; j++) {
                        if ($scope.TranslatorsInformationActive.TrActive[i].UserLanguages[j].LanguageId == selectedLanguageId) {
                            TrActive.push($scope.TranslatorsInformationActive.TrActive[i]);
                        }
                    }
                }
                $scope.TranslatorsInformationActive = {};
                $scope.TranslatorsInformationActive['TrActive'] = TrActive;
                if ($scope.TranslatorsInformationActive['TrActive'].length > 0) {
                    $scope.noUserAvailable = true;
                } else {
                    $scope.noUserAvailable = false;
                }
            } else if (UserStatus === 'inactive') {
                var TrInActive = [];
                for (var i = 0; i < $scope.TranslatorsInformationActive.TrInActive.length; i++) {
                    for (var j = 0; j < $scope.TranslatorsInformationActive.TrInActive[i].UserLanguages.length; j++) {
                        if ($scope.TranslatorsInformationActive.TrInActive[i].UserLanguages[j].LanguageId == selectedLanguageId) {
                            TrInActive.push($scope.TranslatorsInformationActive.TrInActive[i]);
                        }
                    }
                }
                $scope.TranslatorsInformationActive = {};
                $scope.TranslatorsInformationActive['TrInActive'] = TrInActive;
                if ($scope.TranslatorsInformationActive['TrInActive'].length > 0) {
                    $scope.noUserAvailable = true;
                } else {
                    $scope.noUserAvailable = false;
                }
            } else {
                var all = [];
                for (var i = 0; i < $scope.TranslatorsInformationActive.all.length; i++) {
                    for (var j = 0; j < $scope.TranslatorsInformationActive.all[i].UserLanguages.length; j++) {
                        if ($scope.TranslatorsInformationActive.all[i].UserLanguages[j].LanguageId == selectedLanguageId) {
                            all.push($scope.TranslatorsInformationActive.all[i]);
                        }
                    }
                }
                $scope.TranslatorsInformationActive = {};
                $scope.TranslatorsInformationActive['all'] = all;
                if ($scope.TranslatorsInformationActive['all'].length > 0) {
                    $scope.noUserAvailable = true;
                } else {
                    $scope.noUserAvailable = false;
                }
            }
        }
    };
    $scope.resetAllLangDropdown = function () {
        $scope.selectedLanguageId = $scope.TranslatorList.LanguageList[-1];
    };

    $scope.reloadPage = function () {
        $route.reload();
    };
    /*Language filter end - GLMGR-131*/
    $scope.dynamicScreenHeightCall = function () {
        dynamicScreenHeight();
    }
   
      /**
     * @ngdoc
     * @name checkMaxLen
     * @methodOf Translators.controller:TranslatorsController
     * @param {String} field This is textbox in add/edit translator form to check for max character length 
     * @description
     * This function is used to validate add/edit translator form textboxes for maximum length.
     * @returns {undefined} This method does not return.
     */
    $scope.checkMaxLen = function (field) {
        switch (field) {
            case 'username':
                if ($scope.NewTranslator.TranslatorDetails.Email && $scope.NewTranslator.TranslatorDetails.Email.length > 150) {
                    $scope.isMaxLen.username = true;
                } else if ($scope.NewTranslator.TranslatorDetails.Email && $scope.NewTranslator.TranslatorDetails.Email.length <= 150) {
                    $scope.isMaxLen.username = false;
                }
                if ($scope.TranslatorEditInfo.transInfo.Email && $scope.TranslatorEditInfo.transInfo.Email.length > 150) {
                    $scope.isMaxLenEdit.username = true;
                } else if ($scope.TranslatorEditInfo.transInfo.Email && $scope.TranslatorEditInfo.transInfo.Email.length <= 150) {
                    $scope.isMaxLenEdit.username = false;
                }
                break;
            case 'fname':
                if ($scope.NewTranslator.TranslatorDetails.FirstName && $scope.NewTranslator.TranslatorDetails.FirstName.length > 35) {
                    $scope.isMaxLen.fname = true;
                } else if ($scope.NewTranslator.TranslatorDetails.FirstName && $scope.NewTranslator.TranslatorDetails.FirstName.length <= 35) {
                    $scope.isMaxLen.fname = false;
                }
                if ($scope.TranslatorEditInfo.transInfo.FirstName && $scope.TranslatorEditInfo.transInfo.FirstName.length > 35) {
                    $scope.isMaxLenEdit.fname = true;
                } else if ($scope.TranslatorEditInfo.transInfo.FirstName && $scope.TranslatorEditInfo.transInfo.FirstName.length <= 35) {
                    $scope.isMaxLenEdit.fname = false;
                }
                break;
            case 'lname':
                if ($scope.NewTranslator.TranslatorDetails.LastName && $scope.NewTranslator.TranslatorDetails.LastName.length > 35) {
                    $scope.isMaxLen.lname = true;
                    $('#lname').attr('style', 'display: block !important');
                } else if ($scope.NewTranslator.TranslatorDetails.LastName && $scope.NewTranslator.TranslatorDetails.LastName.length <= 35) {
                    $scope.isMaxLen.lname = false;
                    $('#lname').attr('style', 'display: none !important');
                }
                if ($scope.TranslatorEditInfo.transInfo.LastName && $scope.TranslatorEditInfo.transInfo.LastName.length > 35) {
                    $('#lnameEdit').attr('style', 'display: block !important');
                    $scope.isMaxLenEdit.lname = true;
                } else if ($scope.TranslatorEditInfo.transInfo.LastName && $scope.TranslatorEditInfo.transInfo.LastName.length <= 35) {
                    $scope.isMaxLenEdit.lanme = false;
                    $('#lnameEdit').attr('style', 'display: none !important');
                }
                break;
        }
    };

    /**
     * @ngdoc
     * @name mandatoryValidation
     * @methodOf Translators.controller:TranslatorsController
     * @param {String} btn This is button name of form (edit/add new form)
     * @description
     * This function is used to validate add/edit translator form.
     * @returns {undefined} This method does not return.
     */
    $scope.mandatoryValidation = function (btn) {
        if (btn === 'createNewButtonClicked') {
            $scope.isRequired.requiredUsername = false;
            $scope.isRequired.invalidUsername = false;
            $scope.isRequired.requiredFirstName = false;
            $scope.isRequired.requiredLastName = false;
            $scope.isRequired.requiredNativeLanguage = false;
            $scope.isRequired.requiredClients = false;


            if (!$scope.NewTranslator.TranslatorDetails.Email) {
                $scope.isRequired.requiredUsername = true;
            } else if (!$scope.isMaxLen.username && !(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($scope.NewTranslator.TranslatorDetails.Email))) {
                $scope.isRequired.invalidUsername = true;
            }

            if (!$scope.NewTranslator.TranslatorDetails.FirstName) {
                $scope.isRequired.requiredFirstName = true;
            }

            if (!$scope.NewTranslator.TranslatorDetails.LastName) {
                $scope.isRequired.requiredLastName = true;
            }

            if (!$scope.nativeLanguage) {
                $scope.isRequired.requiredNativeLanguage = true;
            }
            if (myDataClients.length < 1) {
                $scope.isRequired.requiredClients = true;
            }
            if ($scope.isMaxLen.username === true || $scope.isMaxLen.fname === true || $scope.isMaxLen.lname === true || $scope.isRequired.requiredUsername === true || $scope.isRequired.invalidUsername === true || $scope.isRequired.requiredFirstName === true || $scope.isRequired.requiredLastName === true || $scope.isRequired.requiredNativeLanguage === true || $scope.isRequired.requiredClients === true) {
                return false;
            }
        }
        else {
            $scope.editFormIsRequired.requiredUsername = false;
            $scope.editFormIsRequired.invalidUsername = false;
            $scope.editFormIsRequired.requiredFirstName = false;
            $scope.editFormIsRequired.requiredLastName = false;
            $scope.editFormIsRequired.requiredNativeLanguage = false;
            $scope.editFormIsRequired.requiredClients = false;

            if (!$scope.TranslatorEditInfo.transInfo.Email) {
                $scope.editFormIsRequired.requiredUsername = true;
            }
            if (!$scope.isMaxLenEdit.username && !(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($scope.TranslatorEditInfo.transInfo.Email))) {
                $scope.editFormIsRequired.invalidUsername = true;
            }
            if (!$scope.TranslatorEditInfo.transInfo.FirstName) {
                $scope.editFormIsRequired.requiredFirstName = true;
            }
            if (!$scope.TranslatorEditInfo.transInfo.LastName) {
                $scope.editFormIsRequired.requiredLastName = true;
            }
            if (!$scope.EditNativeLanguage) {
                $scope.editFormIsRequired.requiredNativeLanguage = true;
            }
            if (myDataClients.length < 1) {
                $scope.editFormIsRequired.requiredClients = true;
            }
            if ($scope.isMaxLenEdit.username === true || $scope.isMaxLenEdit.fname === true || $scope.isMaxLenEdit.lname === true || $scope.editFormIsRequired.requiredUsername === true || $scope.editFormIsRequired.invalidUsername === true || $scope.editFormIsRequired.requiredFirstName === true || $scope.editFormIsRequired.requiredLastName === true || $scope.editFormIsRequired.requiredNativeLanguage === true || $scope.editFormIsRequired.requiredClients === true) {
                return false;
            }
        }
    };
    
     /**
     * @ngdoc
     * @name imPersonate
     * @methodOf Translators.controller:TranslatorsController
     * @param {Object} trans This is object containing selected translators details to impersonate.
     * @description
     * This function is called on impersonation icon on translator page. This function is used to impersonate user. 
     * @returns {undefined} This method does not return.
     */
    $scope.imPersonate = function (trans) {
        var TranslatorImpersonateInfo = {};
        TranslatorImpersonateInfo.UserName = trans.Email;

        localStorage.setItem('adminUser', JSON.stringify(commonService.getLocalData('userDetails'))); // save original user to $scope.adminUser in CommonService impersonate feature
        TranslatorImpersonateInfo.OriginalUserName = JSON.parse(localStorage.getItem('adminUser')).UserName;

        TranslatorData.getUserAuthenticateImpersonate(TranslatorImpersonateInfo.UserName,
            function (data, status, headers, config) {
                getUserDetails(TranslatorImpersonateInfo);
            });

    };

     /**
     * @ngdoc
     * @name getUserDetails
     * @methodOf Translators.controller:TranslatorsController
     * @param {Object} TranslatorImpersonateInfo This is object containing selected translator's email id .
     * @description
     * This function is called inside imPersonate function. This is used to get selected translator's user details. This is used to set local storage variables. 
     * @returns {undefined} This method does not return.
     */
    var getUserDetails = function (TranslatorImpersonateInfo) {
        TranslatorData.impersonateTranslator(TranslatorImpersonateInfo, function (userDetails) {
            localStorage.setItem('isUserImpersonated', true);
            var localStorageUser = userDetails;
            localStorageUser.IsTermAccepted = true;
            localStorage.setItem('HomeValue', 'List');
            localStorage.setItem('userDetails', JSON.stringify(localStorageUser));
            window.location = '/Projects';
        });
    };

    /**
     * @ngdoc
     * @name init
     * @methodOf Translators.controller:TranslatorsController
     * @description
     * This function is called initially when page is loaded. This function is used for initialisation of the variables on page load.
     * @returns {undefined} This method does not return.
     */
    var init = function () {
        var userDetails = commonService.getLocalData('userDetails');
        if (userDetails.UserRoles[0].UserRoleName === "Translator" || userDetails.UserRoles[0].UserRoleName === "Approver" || userDetails.UserRoles[0].UserRoleName === "Client User" || userDetails.UserRoles[0].UserRoleName === "Editorial Staff") {
            return false;
        }
        $scope.showLoader = true;
        $scope.enableOtherLangs = false;
        var resorceIdx = 0;
        sessionStorage.setItem('resourcePageId', JSON.stringify(resorceIdx));
        $scope.TranslatorState = 4;
        $('#actionsColumn').css('min-width', '214px');
    
        //Calling Service for getting the Translator Information that has to be displayed in the Table       
        TranslatorData.getTranslatorData(commonService.getLocalData('userDetails').UserId, function (translatorlist) {
            if (translatorlist) {
                $scope.TranslatorList = translatorlist;
                var CurrentUserDetails = commonService.getLocalData('userDetails');
                $scope.CurrentUserId = CurrentUserDetails.UserId;
                $scope.unSelectLang = translatorlist.LanguageList;

                //GLMGR-619
                if (CurrentUserDetails.UserRoles[0].UserRoleName === 'Admin' && $scope.TranslatorList.UserPermissionList == null) {
                    $scope.showAddUserPermissionButton = true;
                }
                else {
                    if (CurrentUserDetails.UserRoles[0].UserRoleName === 'Admin' && $scope.TranslatorList.UserPermissionList.AddEditTranslator === false) {
                        $scope.showAddUserPermissionButton = false;
                    }
                    else {
                        $scope.showAddUserPermissionButton = true;
                    }
                }

                //Copying for the native language reference
                angular.copy($scope.unSelectLang, $scope.copyOfUnselectedLang);

                //Copying for unselected languages in the edit mode
                availableUserNames = translatorlist.EmailIds;
                $scope.showLoader = false;

                $scope.ClientRoles = $scope.TranslatorList.ClientList;
                $scope.member = { ClientRoles: [] };
                //For checking if the list to be populated is Active Translators or Inactive Translators
                if ($scope.isActive == true) {
                    translatorSelection('active');
                }
                else if ($scope.isAll == true) {
                    translatorSelection('all');
                }
                else {
                    translatorSelection('inactive');
                }
                $scope.ObjectId1 = [];
                $scope.resetAllLangDropdown();
            }
            dynamicScreenHeight();
        });
    };
    $scope.sort = function (keyname) {
        $scope.sortKey = keyname;   //set the sortKey to the param passed
        $scope.reverse = !$scope.reverse; //if true make it false and vice versa
    };

    init();
}]);