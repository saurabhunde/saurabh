/**
 * @ngdoc controller
 * @name Projects.controller:ProjectAddController
 * @element div
 *
 * @description
 * This Controller is responsible for adding new project.
 *
 * @requires AngularJS.$scope
 * @requires AngularJS.$http
 * @requires AngularJS.$location
 * @requires AngularJS.$route
 * @requires AngularJS.$timeout
 * @requires common
 * @requires common.commonService
 * @requires Projects.LandingPageData
 * 
 * @property {Array} myDataClients:Array  This property is list of all clients assigned to project.
 * @property {Array} myDataOwners:Array  This property is list of all owners assigned to project.
 * @property {Array} myDataBrands:Array  This property is list of all brands assigned to project.
 * @property {Object} userDetails:Object This is object stores the user details received  from backend when user is logged in. 
 * @property {String} Title:String This property is Project title.
 * @property {String} SecureTitle:String This property is Secure title given to project.
 * @property {Array} selectCat:Array This property is list of all additional info columns added to project.
 * @property {Array} selectLang:Array This property is list of selected languages for project. 
 * @property {Array} selectedLangSourceList:Array This property is list of languages which need language translation source.
 * @property {Array} selectedLangSourceList:Array This property is list of languages which need language translation source.
 * @property {Number} MasterLanguageId:Number This property is Id of master language.
 */

Projects.controller('projectAddController', ['$scope', '$http', '$location', 'LandingPageData', 'commonService', '$routeParams', 'ProjectIdService', '$timeout', function ($scope, $http, $location, LandingPageData, commonService, $routeParams, ProjectIdService, $timeout) {

    var userDetails = commonService.getLocalData('userDetails');
    var myDataClients = [];
    var myDataOwners = [];
    var myDataBrands = [];
    $scope.unSelectedLangSourceList = [];
    $scope.selectedLangSourceList = [];
    $scope.sourceSelectLang = [];
    $scope.sourceUnSelectLang = [];
    $scope.disableSaveButton = false;
    $scope.booltrue = true; // used as bool true to pass to directive(s) in HTML 
    $scope.boolfalse = false; // used as bool false to pass to directive(s) in HTML 
    $scope.isRequired = {
        "requiredTitle": false,
        "requiredUSReleaseDate": false,
        "requiredClients": false
    };
    $('#clientValMsg').hide();
    var copyOfLanguages = [];
    var ownerListing;
    var client_str = '';
    var owner_str = '';
    var finalBrands = [];
    var brand_str = '';

    /**
     * @ngdoc
     * @name getProjectAddData
     * @methodOf Projects.controller:ProjectAddController
     * @description
     *This method is used pre populate data on add project page.This data includes all languages list,all clients list,all categories  list.
     *@return {undefined} This method does not return.
     */
    var getProjectAddData = function () {
        LandingPageData.getNewProjectData(userDetails.UserId, userDetails.UserRoles[0].UserRoleName, function (projectadd) {
            $scope.ProjectAdd = projectadd;
            //load initial brands
            $scope.BrandRoles = [];
            $scope.brandMember = { BrandRoles: [] };
            $scope.ObjectId2 = [];

            copyOfLanguages = [];
            angular.copy($scope.ProjectAdd.Languages, copyOfLanguages);

            for (var l = 0; l < $scope.ProjectAdd.Languages.length; l++) {
                if ($scope.ProjectAdd.Languages[l].LanguageName.toLowerCase() === 'english') {
                    $scope.MasterLanguageId = $scope.ProjectAdd.Languages[l].Id;
                    break;
                }
            }

            //adding selected languages to selectedLang array to show in the right side of the list
            for (var i = 0; i < $scope.ProjectAdd.Languages.length; i++) {
                if ($scope.ProjectAdd.Languages[i].LanguageName.toLowerCase() !== 'english')
                    $scope.unSelectLang.push($scope.ProjectAdd.Languages[i]);
            }
            //adding unselected categories to the unSelectCat array to show in the left side of the list
            for (var i = 0; i < $scope.ProjectAdd.Categories.length; i++) {
                $scope.unSelectCat.push($scope.ProjectAdd.Categories[i]);
            }

            ///multiselect checkbox dropdown
            $scope.roles = $scope.ProjectAdd.Clients;
            $scope.OwnerRoles = $scope.ProjectAdd.Owners;
            $scope.member = { roles: [] };
            $scope.OwnerMember = { OwnerRoles: [] };

            $scope.ObjectId = [];
            $scope.ObjectId1 = [];
            myDataOwners = $scope.ObjectId1
            $scope.showLoader = false;
        });
    };

    //get ids of selected clients from multiselect dropdown
    $scope.$on('selectedModel', function (event, myData) {
        //multiselect dropdown: show values of selected items
        myDataClients = myData;
        $scope.member = { roles: [] };
        $scope.OwnerMember = { OwnerRoles: [] };
        $scope.ObjectId1 = [];
            myDataOwners = $scope.ObjectId1;
        if (myDataClients.length > 0) {
            LandingPageData.projectOwnerList(0, userDetails.UserId, myData, function (ownerList) {
                ownerListing = ownerList;
                $scope.OwnerRoles = ownerList.Owners;
            });
            client_str = '';
            $scope.disableSaveButton = false;
            for (j = 0; j < myDataClients.length; j++) {
                for (i = 0; i < $scope.ProjectAdd.Clients.length; i++) {
                    if ($scope.ProjectAdd.Clients[i].Id === myDataClients[j]) {
                        if (client_str !== '') {
                            client_str = client_str + ', ' + $scope.ProjectAdd.Clients[i].ClientName;
                        } else {
                            client_str = client_str + $scope.ProjectAdd.Clients[i].ClientName;
                        }
                        $('.client_str').html(client_str);
                        $('.client_str').attr('title', client_str);
                    }
                }
            }
        }
        else {
            $scope.OwnerRoles = [];
            $('.client_str').html('Select Client(s)');
            $('.client_str').attr('title', 'Select Client(s)');
            $scope.disableSaveButton = true;
        }

        //mandatory client validation
        if (myDataClients.length < 1) {
            $scope.mandatoryValidationOnChange('Clients');
            return false;
        } else {
            $('#clientValMsg').hide();
            $scope.mandatoryValidationOnChange('Clients');
        }
        showCommmonBrands(myDataClients);
    });

    //get ids of selected owners from multiselect dropdown
    $scope.$on('ownerselectedModel', function (event, myData) {
        myDataOwners = myData;
        showValuesOnOwnerDropDown();
    });

    /**
     * @ngdoc
     * @name showValuesOnOwnerDropDown
     * @methodOf Projects.controller:ProjectAddController
     * @description
     *This method is used show values of selected items in owners dropdown.
     *@return {undefined} This method does not return.
     */
    var showValuesOnOwnerDropDown = function () {
        if (myDataOwners.length > 0) {
            owner_str = '';
            $scope.isRequired.requiredOwner = false;
            $scope.disableSaveButton = false;
            for (j = 0; j < myDataOwners.length; j++) {
                if (owner_str !== '') {
                    owner_str = owner_str + ', ' + myDataOwners[j].OwnerName;
                } else {
                    owner_str = owner_str + myDataOwners[j].OwnerName;
                }
                $('.owner_str').html(owner_str);
                $('.owner_str').attr('title', owner_str);
            }
        }
        else {
            $('.owner_str').html('Select Owner(s)');
            $('.owner_str').attr('title', 'Select Owner(s)');
            $scope.isRequired.requiredOwner = true;
            $scope.disableSaveButton = true;
        }
    }

     /**
     * @ngdoc
     * @name showCommmonBrands
     * @methodOf Projects.controller:ProjectAddController
     * @description
     *This method is used to create array for brands respective to clients.
     *@return {undefined} This method does not return.
     */
    var showCommmonBrands = function (myData) {
        //to get Brand IDs of selected clients
        var selected = [];
        for (m = 0; m < myData.length; m++) {
            for (i = 0; i < $scope.ProjectAdd.ClientBrands.length; i++) {
                if ($scope.ProjectAdd.ClientBrands[i].ClientId === myData[m]) {
                    for (j = 0; j < $scope.ProjectAdd.ClientBrands[i].ClientBrandList.length; j++) {
                        selected.push($scope.ProjectAdd.ClientBrands[i].ClientBrandList[j].BrandId);
                    }
                }
            }
        }

        //to get Common Brand IDs
        var arr = selected;
        results = _.uniq(arr).sort();

        //create object of Brands
        var availableBrands = {};
        finalBrands = [];

        // var finalBrandIds = [];
        for (m = 0; m < results.length; m++) {
            availableBrands = {};
            for (i = 0; i < $scope.ProjectAdd.Brands.length; i++) {
                if ($scope.ProjectAdd.Brands[i].Id === results[m]) {
                    availableBrands.BrandName = $scope.ProjectAdd.Brands[i].BrandName;
                    availableBrands.Id = $scope.ProjectAdd.Brands[i].Id;
                    finalBrands.push(availableBrands);
                }
            }
        }
    };

    // brand multiselect
    $scope.$on('brandselectedModel', function (event, myData) {
        myDataBrands = myData;
        $scope.BrandRoles = finalBrands;
        brand_str = '';

        for (j = 0; j < myDataBrands.length; j++) {
            for (i = 0; i < finalBrands.length; i++) {
                if (finalBrands[i].Id === myDataBrands[j]) {
                    if (brand_str !== '') {
                        brand_str = brand_str + ', ' + finalBrands[i].BrandName;
                    } else {
                        brand_str = brand_str + finalBrands[i].BrandName;
                    }
                    $('.brand_str').html(brand_str);
                    $('.brand_str').attr('title', brand_str);
                }
            }
        }
    });


    //allow only delete date in usdate, no typing, 8 for backspace, 46 for delete button
    $('.us-release-date').keydown(function (e) {
        var usReleaseDateInput = $(document.activeElement).hasClass('us-release-date');

        if ((e.keyCode === 8 || e.keyCode === 46) && (usReleaseDateInput)) {
            $('#usdate').val('');
            return true;
        } else {
            return false;
        }
    });

     /**
     * @ngdoc
     * @name ownerGroupPopup
     * @methodOf Projects.controller:ProjectAddController
     * @description
     *This method is used to show popup to select owner groups.
     *@return {undefined} This method does not return.
     */
    $scope.ownerGroupPopup = function () {
        $scope.groupOwnerSelected = null;
        var myData = [];
        LandingPageData.projectOwnerList(0, userDetails.UserId, myData, function (ownerList) {
            $scope.GroupOwner = ownerList.OwnersGroup;
        });
        $scope.rightListGroupOwner = [];
        $scope.leftListGroupOwner = [];
        $('#ownerGroup').modal('show');
    };
   
    /**
     * @ngdoc
     * @name groupUserList
     * @methodOf Projects.controller:ProjectAddController
     * @param {Object} group This objects contains AssignedUserList array.
     * @description
     *This method is used to show users list in the group.
     *@return {undefined} This method does not return.
     */
    $scope.groupUserList = function (group) {
        $scope.rightListGroupOwner = [];
        $scope.leftListGroupOwner = [];
        for (var i = 0; i < group.AssignedUserList.length; i++) {
            var flag = false;
            for (var j = 0; j < myDataOwners.length; j++) {
                if (group.AssignedUserList[i].OwnerId === myDataOwners[j].Id) {
                    $scope.rightListGroupOwner.push(group.AssignedUserList[i]);
                    flag = true;
                    break;
                }
            }
            if (flag === false) {
                $scope.leftListGroupOwner.push(group.AssignedUserList[i]);
            }
        }
    };

     /**
     * @ngdoc
     * @name moveOwner
     * @methodOf Projects.controller:ProjectAddController
     * @param {string} dir This is string which is used to select/unselect user from owner group. dir is a direction in which user has to move. 
     * @description
     *This method is used to select/unselect user from owner group.
     *@return {undefined} This method does not return.
     */
    $scope.moveOwner = function (dir) {
        if (dir === "left") {
            if ($scope.ownerUnSelected.length > 0) {
                for (var i = 0; i < $scope.ownerUnSelected.length; i++) {
                    $scope.leftListGroupOwner.push($scope.ownerUnSelected[i]);
                    for (var j = 0; j < $scope.ObjectId1.length; j++) {
                        if ($scope.ObjectId1[j].Id === $scope.ownerUnSelected[i].OwnerId) {
                            $scope.ObjectId1.splice(j, 1);
                            break;
                        }
                    }
                    for (var j = 0; j < myDataOwners.length; j++) {
                        if (myDataOwners[j].Id === $scope.ownerUnSelected[i].OwnerId) {
                            myDataOwners.splice(j, 1);
                            break;
                        }
                    }
                    for (var j = 0; j < $scope.rightListGroupOwner.length; j++) {
                        if ($scope.rightListGroupOwner[j].OwnerId === $scope.ownerUnSelected[i].OwnerId) {
                            $scope.rightListGroupOwner.splice(j, 1);
                            break;
                        }
                    }
                }
            }
        } else {
            if ($scope.ownerSelected.length > 0) {
                for (var i = 0; i < $scope.ownerSelected.length; i++) {
                    $scope.rightListGroupOwner.push($scope.ownerSelected[i]);
                    for (var j = 0; j < $scope.OwnerRoles.length; j++) {
                        if ($scope.OwnerRoles[j].Id === $scope.ownerSelected[i].OwnerId) {
                            $scope.ObjectId1.push($scope.OwnerRoles[j]);
                            break;
                        }
                    }
                    for (var j = 0; j < $scope.leftListGroupOwner.length; j++) {
                        if ($scope.leftListGroupOwner[j].OwnerId === $scope.ownerSelected[i].OwnerId) {
                            $scope.leftListGroupOwner.splice(j, 1);
                            break;
                        }
                    }
                }
            }
        }
        showValuesOnOwnerDropDown();
    };

    /**
     * @ngdoc
     * @name saveProject
     * @methodOf Projects.controller:ProjectAddController
     * @description
     *This method called on click of save project button on add project page.
     *@return {undefined} This method does not return.
     */
    $scope.saveProject = function () {
        if ($scope.disableSaveButton === false) {
            $scope.disableSaveButton = true;
            var newProjectData = {};
            if (!$scope.mandatoryValidation()) {
                $scope.disableSaveButton = false;
                return false;
            }
            var ProjectTitle = {};
            ProjectTitle.ProjectTitleInput = $scope.Title;
            LandingPageData.getProjectList(ProjectTitle, function (data) {
                if (data === true) {
                    $('#duplicateProject').modal({ backdrop: 'static', keyboard: false });
                    $('#duplicateProject').modal('show');
                } else if (!$scope.Title) {
                    $('#noTitleProject').modal({ backdrop: 'static', keyboard: false });
                    $('#noTitleProject').modal('show');
                } else {
                    var rearrangedCategoryIds = [];
                    for (var i = 0; i < $scope.selectCat.length; i++) {
                        rearrangedCategoryIds.push($scope.selectCat[i].Id);
                    }
                    if ($scope.SecureTitle) {
                        if ($('#usdate').val() === '') {
                            $('#releaseDateWarning').modal('show');
                            $scope.disableSaveButton = false;
                            return false;
                        }
                    }
                    //image upload functionality
                    var x = document.getElementById("fileUpload");
                    var txt = "";
                    if ('files' in x) {
                        if (x.files.length === 0) {
                            txt = "Select one or more files.";
                        } else {
                            for (var i = 0; i < x.files.length; i++) {
                                txt += "<br><strong>" + (i + 1) + ". file</strong><br>";
                                var file = x.files[i];
                                if ('name' in file) {
                                    newProjectData['Filename'] = file.name;
                                    newProjectData['Fileext'] = file.name.substring(file.name.indexOf(".") + 1);
                                }
                                if ('size' in file) {
                                    newProjectData['Filesize'] = file.size;
                                }
                                if ('type' in file) {
                                    newProjectData['Filetype'] = file.type;
                                }
                                newProjectData['Filedata'] = $('.imagePreview img').attr('src').split(',')[1];
                            }
                        }
                    }
                    var categories = [];
                    var catLength = $scope.selectCat.length;
                    for (var i = 0; i < catLength; i++) {
                        categories.push($scope.selectCat[i].Id);
                    }
                    newProjectData['CategoriesIds'] = categories;
                    var languages = [];
                    var langLength = $scope.selectLang.length;
                    for (var i = 0; i < langLength; i++) {
                        languages.push($scope.selectLang[i].Id);
                    }
                    var sourceLanguages = [];
                    for (var i = 0; i < $scope.selectedLangSourceList.length; i++) {
                        sourceLanguages.push($scope.selectedLangSourceList[i].Id);
                    }
                    newProjectData['LanguagesIds'] = languages;
                    newProjectData['TranslationSourceRequiredLanguagesIds'] = sourceLanguages;
                    newProjectData['UserId'] = userDetails.UserId;
                    newProjectData['Title'] = $scope.Title;
                    newProjectData['SecureTitle'] = $scope.SecureTitle;
                    newProjectData['CategorySequence'] = rearrangedCategoryIds.toString();

                    //GLMGR -535
                    if ($('#usdate').val() === '') {
                        newProjectData['USReleaseDate'] = '';
                    } else {
                        newProjectData['USReleaseDate'] = $('#usdate').val();
                    }
                    //==GLMGR 535

                    newProjectData['DateCreated'] = $scope.CurrentDate;
                    newProjectData['CreatedById'] = userDetails.UserId;
                    //newProjectData['OwnedById'] = $scope.ProjectAdd.Owners[0].Id;
                    newProjectData['ClientIds'] = myDataClients;
                    newProjectData['OwnedById'] = [];
                    newProjectData['IsActive'] = 1;
                    newProjectData['OwnersEmailId'] = [];

                    //Project Owner is mandatory
                    if (myDataOwners.length === 0) {
                        newProjectData['OwnedById'].push(userDetails.UserId);
                        newProjectData['OwnersEmailId'].push(userDetails.UserName);
                    } else {
                        for (var i = 0; i < myDataOwners.length; i++) {
                            newProjectData['OwnedById'].push(myDataOwners[i].Id);
                            newProjectData['OwnersEmailId'].push(myDataOwners[i].OwnerMailId);
                        }
                    }

                    newProjectData['BrandIds'] = myDataBrands;
                    newProjectData['MasterLanguageId'] = $scope.MasterLanguageId;

                    $scope.showLoader = true;
                    LandingPageData.addNewProject(newProjectData, function (status) {
                        $('#projectSave').modal({ backdrop: 'static', keyboard: false });
                        if (status) {
                            $('#projectSave').modal('show');
                            $('#projectSave .modal-body').html('New Project is added successfully!');
                            $('#projectSave .modal-title').html('Add Project');
                        } else {
                            $('#projectSave').modal('show');
                            $scope.showLoader = false;
                            $('#projectSave .modal-body').html('New Project could not be added!');
                            $('#projectSave .modal-title').html('Add Project');
                        }
                    });
                }
            });
        }
    };

    /**
     * @ngdoc
     * @name translationSourcePopup
     * @methodOf Projects.controller:ProjectAddController
     * @description
     *This method called on click of Translation source button on add project page. Which is used to add translation source required language to project.
     *@return {undefined} This method does not return.
     */
    $scope.translationSourcePopup = function () {
        if ($scope.selectLang && $scope.selectLang.length > 0) {
            for (var i = 0; i < $scope.selectLang.length; i++) {
                var flag = false;
                for (var j = 0; j < $scope.selectedLangSourceList.length; j++) {
                    if ($scope.selectedLangSourceList[j].Id === $scope.selectLang[i].Id) {
                        flag = true;
                        break;
                    }
                }
                if (flag === false) {
                    for (var j = 0; j < $scope.unSelectedLangSourceList.length; j++) {
                        if ($scope.unSelectedLangSourceList[j].Id === $scope.selectLang[i].Id) {
                            flag = true;
                            break;
                        }
                    }
                }
                if (flag === false) {
                    $scope.unSelectedLangSourceList.push($scope.selectLang[i]);
                }
            }
            $('#translationSourcePopup').modal({ backdrop: 'static', keyboard: false });
            $('#translationSourcePopup').modal('show');
        } else {
            $('#translationSourceErrorPopup').modal('show');
        }
    };

    /**
     * @ngdoc
     * @name clearTransSourceLang
     * @methodOf Projects.controller:ProjectAddController
     * @description
     *This method called on click of Clear All button on add project page. Which is used to Clear added languages.
     *@return {undefined} This method does not return.
     */
    $scope.clearTransSourceLang = function () {
        $scope.selectedLangSourceList = [];
        $scope.unSelectedLangSourceList = [];
        for (var i = 0; i < $scope.selectLang.length; i++) {
            $scope.selectLang[i].TranslationSourceRequired = false;
            $scope.unSelectedLangSourceList.push($scope.selectLang[i]);
        }
        var temp = [];
        angular.copy($scope.selectLang, temp);
        $scope.selectLang = [];
        $timeout(function () { $scope.selectLang = temp }, 20);
    };

     /**
     * @ngdoc
     * @name moveSourceSelectedlang
     * @methodOf Projects.controller:ProjectAddController
     * @description
     *This method called on right move button on translation source popup. Which is used to move languages to right (select languages).
     *@return {undefined} This method does not return.
     */
    $scope.moveSourceSelectedlang = function () {
        if ($scope.sourceSelectLang && $scope.sourceSelectLang.length > 0) {
            for (var i = 0 ; i < $scope.sourceSelectLang.length ; i++) {
                $scope.sourceSelectLang[i].TranslationSourceRequired = true;
                $scope.selectedLangSourceList.push($scope.sourceSelectLang[i]);
                for (var j = 0; j < $scope.unSelectedLangSourceList.length; j++) {
                    if ($scope.unSelectedLangSourceList[j].Id === $scope.sourceSelectLang[i].Id) {
                        $scope.unSelectedLangSourceList.splice(j, 1);
                        break;
                    }
                }
            }
            for (var i = 0 ; i < $scope.selectedLangSourceList.length ; i++) {
                for (var j = 0; j < $scope.selectLang.length; j++) {
                    if ($scope.selectLang[j].Id === $scope.selectedLangSourceList[i].Id) {
                        $scope.selectLang[j].TranslationSourceRequired = true;
                        break;
                    }
                }
            }
        }
        var temp = [];
        angular.copy($scope.selectLang, temp);
        $scope.selectLang = [];
        $timeout(function () { $scope.selectLang = temp }, 20);
    };

     /**
     * @ngdoc
     * @name moveSourceUnSelectedSections
     * @methodOf Projects.controller:ProjectAddController
     * @description
     *This method called on left move button on translation source popup. Which is used to move languages to left (unselect languages).
     *@return {undefined} This method does not return.
     */
    $scope.moveSourceUnSelectedSections = function () {
        if ($scope.sourceUnSelectLang && $scope.sourceUnSelectLang.length > 0) {
            for (var i = 0 ; i < $scope.sourceUnSelectLang.length ; i++) {
                $scope.sourceUnSelectLang[i].TranslationSourceRequired = false;
                $scope.unSelectedLangSourceList.push($scope.sourceUnSelectLang[i]);
                for (var j = 0; j < $scope.selectedLangSourceList.length; j++) {
                    if ($scope.selectedLangSourceList[j].Id === $scope.sourceUnSelectLang[i].Id) {
                        $scope.selectedLangSourceList.splice(j, 1);
                        break;
                    }
                }
            }
        }
        for (var i = 0 ; i < $scope.unSelectedLangSourceList.length ; i++) {
            for (var j = 0; j < $scope.selectLang.length; j++) {
                if ($scope.selectLang[j].Id === $scope.unSelectedLangSourceList[i].Id) {
                    $scope.selectLang[j].TranslationSourceRequired = false;
                    break;
                }
            }
        }
        var temp = [];
        angular.copy($scope.selectLang, temp);
        $scope.selectLang = [];
        $timeout(function () { $scope.selectLang = temp }, 20);
    };

    //close popup
    $scope.dismissPopUp = function (activity) {
        $('.modal-backdrop.fade.in').css('display', 'none');
        if (activity === 'saveProject') {
            sessionStorage.setItem('isNewProject', true);
            $scope.showLoader = false;
            $scope.disableSaveButton = false;
            $location.path('/Projects/');
        } else if (activity === 'duplicateProject') {
            $('#duplicateProject').modal('hide');
            $scope.disableSaveButton = false;
        } else if (activity === 'noTitleProject') {
            $('#noTitleProject').modal('hide');
            $scope.disableSaveButton = false;
        }
    };

    $scope.addSecureTitle = function () {
        if ($scope.SecureTitle) {
            $('#secureTitleWarning').modal('show');
        }
    }
   
    //selecting languages and pushing to the left side of the list from right side
    $scope.selectLangClick = function (selectedLang) {
        for (var i = 0 ; i < selectedLang.length ; i++) {
            $scope.selectLang.push(selectedLang[i]);
            var index = $scope.unSelectLang.indexOf(selectedLang[i]);
            if (index > -1) {
                $scope.unSelectLang.splice(index, 1);
            }
        }
    };

    //Deselecting selected languages and pushing to the left side of the list from left side
    $scope.UnSelectLangClick = function (unSelectedLang) {
        for (var i = 0 ; i < unSelectedLang.length ; i++) {
            $scope.unSelectLang.push(unSelectedLang[i]);
            var index = $scope.selectLang.indexOf(unSelectedLang[i]);
            if (index > -1) {
                $scope.selectLang.splice(index, 1);
            }
        }
    };

    //selecting categories and pushing to the left side of the list from right side
    $scope.selectCatClick = function (selectedCat) {
        for (var i = 0 ; i < selectedCat.length ; i++) {
            $scope.selectCat.push(selectedCat[i]);
            var index = $scope.unSelectCat.indexOf(selectedCat[i]);
            if (index > -1) {
                $scope.unSelectCat.splice(index, 1);
            }
        }
    };

    //Deselecting selected categories and pushing to the left side of the list from left side
    $scope.UnSelectCatClick = function (unSelectedCat) {
        for (var i = 0 ; i < unSelectedCat.length ; i++) {
            $scope.unSelectCat.push(unSelectedCat[i]);
            var index = $scope.selectCat.indexOf(unSelectedCat[i]);
            if (index > -1) {
                $scope.selectCat.splice(index, 1);
            }
        }
    };

     /**
     * @ngdoc
     * @name clearLang
     * @methodOf Projects.controller:ProjectAddController
     * @description
     *This method is used to clear all the selected languages from the left side of the list
     *@return {undefined} This method does not return.
     */
    $scope.clearLang = function () {
        for (var i = 0 ; i < $scope.selectLang.length ; i++) {
            $scope.unSelectLang.push($scope.selectLang[i]);
        }
        $scope.selectLang = [];
    };

       /**
     * @ngdoc
     * @name clearCat
     * @methodOf Projects.controller:ProjectAddController
     * @description
     *This method is used to clear all the selected categories from the left side of the list.
     *@return {undefined} This method does not return.
     */
    $scope.clearCat = function () {
        for (var i = 0 ; i < $scope.selectCat.length ; i++) {
            $scope.unSelectCat.push($scope.selectCat[i]);
        }
        $scope.selectCat = [];
    };

    //Add New Category AddNewCategory
    $scope.AddNewcategoryButtonClick = function () {
        $scope.addNewCategoryClickDisabled = false;
        $('#category-message').hide();
        $('#category-lang-message').hide();
        $scope.newCategory = '';
    };

    $scope.addNewCategoryBlur = function () {
        $('#category-message').hide();
        $('#category-lang-message').hide();
    }
    $scope.addNewCategoryClick = function (newCategory) {
        var catlangFlag = false;
        if (!$scope.newCategory) {
            $scope.requiredCategory = true;
            return false;
        }
        else {
            $('#category-message').hide();
            $('#category-lang-message').hide();
            for (var i = 0; i < $scope.ProjectAdd.Categories.length; i++) {
                if ($scope.newCategory.toLowerCase() === $scope.ProjectAdd.Categories[i].CategoryName.toLowerCase()) {
                    $('#category-message').show();
                    var catFlag = true;
                    break;
                }
            }
            for (var i = 0; i < $scope.ProjectAdd.Languages.length; i++) {
                if ($scope.newCategory.toLowerCase() === $scope.ProjectAdd.Languages[i].LanguageName.toLowerCase()) {
                    $('#category-lang-message').show();
                    catlangFlag = true;
                    break;
                }
            }
            if (catFlag !== true && catlangFlag !== true) {
                var newCat = {};
                newCat['CategoryName'] = $scope.newCategory;
                LandingPageData.addNewCategory(newCat, function (data) {
                    newCat['Id'] = data;
                    if (data === 0) {
                        $('#category-message').show();
                        var catFlag = true;
                    } else {
                        $scope.unSelectCat.push(newCat);
                        $scope.newCategory = "";
                        $('#AddNewcategory').modal('hide');
                        $scope.addNewCategoryClickDisabled = true;
                    }
                });
            }
        }
    };

    /**
     * @ngdoc
     * @name checkProjectNameBlurDup
     * @methodOf Projects.controller:ProjectAddController
     * @param {String} projectName Name of project is passed as parameter.
     * @description
     *This method is used to check for duplicate project name on blur of input of project title.
     *@return {undefined} This method does not return.
     */
    $scope.checkProjectNameBlurDup = function (projectName) {
        var ProjectTitle = {};
        ProjectTitle.ProjectTitleInput = $scope.Title;
        LandingPageData.getProjectList(ProjectTitle, function (data) {
            if (data === true) {
                $('#duplicateProject').modal({ backdrop: 'static', keyboard: false });
                $('#duplicateProject').modal('show');
            } else if (!$scope.Title) {
                $('#noTitleProject').modal({ backdrop: 'static', keyboard: false });
                $('#noTitleProject').modal('show');
            }
        });
    };

     /**
     * @ngdoc
     * @name mandatoryValidation
     * @methodOf Projects.controller:ProjectAddController
     * @description
     *This method is used to validate all the fields on add project form.
     *@return {Boolean} This method returns true/false depending on validation.
     */
    $scope.mandatoryValidation = function () {
        if (!$scope.Title && myDataClients.length === 0) {
            $scope.isRequired.requiredTitle = true;
            $scope.isRequired.requiredClients = true;
            return false;
        } else if (myDataClients.length === 0 && $scope.Title) {
            $scope.isRequired.requiredTitle = false;
            $scope.isRequired.requiredClients = true;
            return false;
        }
        else if (!$scope.Title && (myDataClients.length > 0)) {
            $scope.isRequired.requiredTitle = true;
            if (myDataClients.length > 0) {
                $scope.isRequired.requiredClients = false;
            }
            return false;
        }
        else {
            $scope.isRequired.requiredTitle = false;
            $scope.isRequired.requiredClients = false;
            return true;
        }
    };

    /**
     * @ngdoc
     * @name moveUpClick
     * @methodOf Projects.controller:ProjectAddController
     * @description
     *This method is used to change the sequence of selected categories .
     *@return {undefined} This method does not return.
     */
    $scope.moveUpClick = function () {
        var idx = $scope.selectCat.indexOf($scope.unSelectedCat[0]);
        if (idx > 0) {
            var itemToMove = $scope.selectCat.splice(idx, 1);
            $scope.selectCat.splice(idx - 1, 0, itemToMove[0]);
        }
    };

    /**
     * @ngdoc
     * @name moveDownClick
     * @methodOf Projects.controller:ProjectAddController
     * @description
     *This method is used to change the sequence of selected categories .
     *@return {undefined} This method does not return.
     */
    $scope.moveDownClick = function () {
        for (var i = 0; i < $scope.unSelectedCat.length; i++) {
            var idx = $scope.selectCat.indexOf($scope.unSelectedCat[i]);
            if (idx < $scope.selectCat.length) {
                var itemToMove = $scope.selectCat.splice(idx, 1);
                $scope.selectCat.splice(idx + 1, 0, itemToMove[0]);
            }
        }
    };
    
    /**
     * @ngdoc
     * @name masterLanguageSelected
     * @methodOf Projects.controller:ProjectAddController
     * @param {Object} langaugeSelected this is selected language object.
     * @description
     *This method is called on change of dropdown to select master language.This function is used to set master language for the project.
     *@return {undefined} This method does not return.
     */
    $scope.masterLanguageSelected = function (langaugeSelected) {
        angular.copy(copyOfLanguages, $scope.unSelectLang);
        for (var i = 0; i < $scope.unSelectLang.length; i++) {
            if ($scope.unSelectLang[i].Id === langaugeSelected) {
                $scope.unSelectLang.splice(i, 1);
                break;
            }
        }

        for (var i = 0; i < $scope.selectLang.length; i++) {
            if ($scope.selectLang[i].Id === langaugeSelected) {
                $scope.selectLang.splice(i, 1);
                break;
            }
        }

        for (var i = 0; i < $scope.selectLang.length; i++) {
            for (var j = 0; j < $scope.unSelectLang.length; j++) {
                if ($scope.selectLang[i].Id === $scope.unSelectLang[j].Id) {
                    $scope.unSelectLang.splice(j, 1);
                    break;
                }
            }
        }
    };

    /**
     * @ngdoc
     * @name mandatoryValidationOnChange
     * @methodOf Projects.controller:ProjectAddController
     * @param {String} model input filed name on which validation function is applied.
     * @description
     *This method is called on change validation on input fields (for client and title change).
     *@return {undefined} This method does not return.
     */
    $scope.mandatoryValidationOnChange = function (model) {
        switch (model) {
            case 'Title':
                if ($scope.Title) {
                    $scope.isRequired.requiredTitle = false;
                }
                else {
                    $scope.isRequired.requiredTitle = true;
                }
                break;

            case 'Clients':
                if (myDataClients.length > 0) {
                    $scope.isRequired.requiredClients = false;
                }
                else {
                    $scope.isRequired.requiredClients = true;
                }
                break;
        }
    };

       /**
     * @ngdoc
     * @name init
     * @methodOf Projects.controller:ProjectAddController
     * @description
     *This method is called at the beginning of page load and used for initialisation of variables on page load
     *@return {undefined} This method does not return.
     */
    var init = function () {
        //initialisation of variables on page load
        $scope.CurrentDate = new Date(), 'yyyy-MM-dd';
        $scope.selectLang = [];
        $scope.unSelectLang = [];
        $scope.selectCat = [];
        $scope.unSelectCat = [];
        $scope.showLoader = true;

        //initializing datepicker format
        $('#usdate').datepicker({
            format: "yyyy-mm-dd"
        });

        $('#usdate').datepicker()
        .on('changeDate', function (ev) {
            $scope.USReleaseDate = $('#usdate').val();
        });

        $("#addMainDiv").scroll(function () {
            $('#usdate').datepicker('hide');
            $('#usdate').blur();
        });

        //GetPrePopulatedData for Adding New Project
        getProjectAddData();
        dynamicScreenHeight();

    };

    init();

}]);