/**
 * @ngdoc controller
 * @name Projects.controller:ProjectsPermissions
 * @element div
 *
 * @description
 * This Controller is responsible for assigning permissions to user.
 *
 * @requires AngularJS.$scope
 * @requires AngularJS.$http
 * @requires AngularJS.$location
 * @requires AngularJS.$route
 * @requires common.commonService
 * @requires Projects.LandingPageData
 * @requires Projects.ProjectPermissionsService
 * 
 * @property {Array} ClientUserName:Array  This property is list of all clients usernames to be shown in project permission page.
 * @property {Object} userDetails:Object This is object stores the user details received from backend when user is logged in. 
 * @property {String} ClientUserNameStr:String This property is comma separated username list to be displayed on input box on project permission page.
 * @property {Object} ProjectInfo:Object This property is object containing basic info of project to be displayed on project permission page.
 * @property {String} projectId:String This property is encrypted project id.
 * @property {String} selectedEditorialStaffsList:String This property is list of selected editorial staffs in comma separated string format.
 * @property {Array} permissionUserRoles:Array This property is list of all user roles.
 * @property {Array} selectedEditorialStaffs:Array This property is list of all selected editorial staff.
 * @property {Array} unselectedEditorialStaffs:Array This property is list of unselected editorial staff.
 * @property {Array} projectPermissions:Array This property is list of users who are already assigned to project for their respect role..
 * @property {Number} currProjID:Number This property is Id of selected project.
 * 
 */
Projects.controller('projectsPermissions', ['$scope', '$http', '$location', 'ProjectPermissionsService', 'commonService', '$routeParams', 'LandingPageData', 'ProjectIdService', function ($scope, $http, $location, ProjectPermissionsService, commonService, $routeParams, LandingPageData, ProjectIdService) {
    //declaring variables
    $scope.projectId = commonService.getSessionData('projectIBreadCrumb');
    var userDetails = commonService.getLocalData('userDetails');
    $scope.projectPermissions = [];
    $scope.permissionUserRoles = [];
    $scope.unselectedEditorialStaffs = [];
    $scope.selectedEditorialStaffs = [];
    $scope.ClientUserName = [];
    $scope.ClientUserNameStr = '';
    dynamicScreenHeight();
    var EditorialStaffProjectPermissionInputModel = {};

     /**
     * @ngdoc
     * @name getEditorialStaffInfo
     * @methodOf Projects.controller:ProjectsPermissions
     * @description
     * This method is used to get the editorial staff  information when popup is opened.
     *@return {object} This method returns object containing editorial staffs info.
     */
    $scope.getEditorialStaffInfo = function () {
        ProjectPermissionsService.getEditorialStaffInfo($scope.projectId, $scope.ProjectInfo.LanguageId, function (editorialInfo) {
            console.log('3--', editorialInfo);
            if (editorialInfo != null) {
                $scope.unselectedEditorialStaffs = editorialInfo.UserIdNameNotSelected;
                $scope.selectedEditorialStaffs = editorialInfo.UserIdNameSelected;
            }
            //string to show Editorial Staff
            $scope.selectedEditorialStaffsList = '';
            for (var i = 0; i < $scope.selectedEditorialStaffs.length; i++) {
                $scope.selectedEditorialStaffsList = $scope.selectedEditorialStaffsList + $scope.selectedEditorialStaffs[i].UserName + ', '
            }
            $scope.selectedEditorialStaffsList = $scope.selectedEditorialStaffsList.slice(0, -2);
            if (!$scope.selectedEditorialStaffsList) {
                $scope.selectedEditorialStaffsList = 'No Editorial Staff Assigned';
            }
        });
    };

     /**
     * @ngdoc
     * @name saveEditorialStaffs
     * @methodOf Projects.controller:ProjectsPermissions
     * @description
     * This method is used to save or update the editorial staff that is selected
     *@return {Boolean} This method returns true if operation is successful.
     */
    $scope.saveEditorialStaffs = function () {
        EditorialStaffProjectPermissionInputModel.UserIds = [];
        for (var i = 0; i < $scope.selectedEditorialStaffs.length; i++) {
            EditorialStaffProjectPermissionInputModel.UserIds.push($scope.selectedEditorialStaffs[i].UserId);
        }
        $scope.showLoader = true;

        if ($scope.adminUser) {
            EditorialStaffProjectPermissionInputModel['OriginalUserId'] = $scope.adminUser.UserId;
        } else {
            EditorialStaffProjectPermissionInputModel['OriginalUserId'] = null;
        }
        ProjectPermissionsService.saveEditorialUserList(EditorialStaffProjectPermissionInputModel, function (status) {
            if (status) {
                $scope.showLoader = false;
                init();
            }
        });
    };

      /**
     * @ngdoc
     * @name addSelectedEditorialUsers
     * @methodOf Projects.controller:ProjectsPermissions
     * @param {Array} selectedUsers These are selected editorial users to give particular permission.
     * @description
     * This method is used to add Selected Editorial Users From Left List to Right List
     *@return {undefined} This method does not return.
     */
    $scope.addSelectedEditorialUsers = function (selectedUsers) {
        for (var i = 0 ; i < selectedUsers.length ; i++) {
            $scope.selectedEditorialStaffs.push(selectedUsers[i]);
            var index = $scope.unselectedEditorialStaffs.indexOf(selectedUsers[i]);
            if (index > -1) {
                $scope.unselectedEditorialStaffs.splice(index, 1);
            }
        }
    };

     /**
     * @ngdoc
     * @name removeSelectedEditorialUsers
     * @methodOf Projects.controller:ProjectsPermissions
     * @param {Array} removedUsers These are editorial users which need to be removed.
     * @description
     * This method is used to remove the selected Editorial Users from right list to left list
     *@return {undefined} This method does not return.
     */
    $scope.removeSelectedEditorialUsers = function (removedUsers) {
        for (var i = 0 ; i < removedUsers.length ; i++) {
            $scope.unselectedEditorialStaffs.push(removedUsers[i]);
            var index = $scope.selectedEditorialStaffs.indexOf(removedUsers[i]);
            if (index > -1) {
                $scope.selectedEditorialStaffs.splice(index, 1);
            }
        }
    };

      /**
     * @ngdoc
     * @name showLoaderInDirective
     * @methodOf Projects.controller:ProjectsPermissions
     * @description
     * This method is used to show the loader from the directive
     *@return {undefined} This method does not return.
     */
    $scope.showLoaderInDirective = function () {
        if ($scope.showLoader == false) {
            $scope.showLoader = true;
        }
        else {
            $scope.showLoader = false;
        }
    };

     /**
     * @ngdoc
     * @name getAllPermissionsOnLoad
     * @methodOf Projects.controller:ProjectsPermissions
     * @description
     * This method is used for getting Permissions on page load or after assigning any permission to the user
     *@return {undefined} This method does not return.
     */
    $scope.getAllPermissionsOnLoad = function () {
        $scope.showLoader = true;
        ProjectPermissionsService.getProjectPermissions($scope.projectId, function (projectpermissions) {
        console.log("2---",projectpermissions);
            if (projectpermissions != null) {
                $scope.ClientUserNameStr = '';
                $scope.projectPermissions = projectpermissions.ProjectPermissionViewModelRowData;
                $scope.permissionUserRoles = projectpermissions.UserRoles;
                //Creating the string of client user names to be displayed
                for (var i = 0; i < projectpermissions.ProjectClientUserName.length; i++) {
                    $scope.ClientUserName.push(projectpermissions.ProjectClientUserName[i].UserName);
                    $scope.ClientUserNameStr = $scope.ClientUserNameStr + projectpermissions.ProjectClientUserName[i].UserName + ', ';
                }
                $scope.ClientUserNameStr = $scope.ClientUserNameStr.slice(0, -2);
                $scope.showLoader = false;
            }
        });
    };

    /**
     * @ngdoc
     * @name getProjectBasicInfoOnLoad
     * @methodOf Projects.controller:ProjectsPermissions
     * @description
     * This method is used for getting project basic information related to Title, Secure Title, Client (i.e. project generic info)
     *@return {undefined} This method does not return.
     */
    $scope.getProjectBasicInfoOnLoad = function () {
        ProjectPermissionsService.getProjectBasicInfo($scope.projectId, userDetails.UserId, function (projectinfo) {
            console.log("1---",projectinfo);
            if (projectinfo.accessRes) {
                if (projectinfo.accessRes == "AccessDenied") {
                    commonService.deniedRedirect();
                }
            } else {
                hideColors = false;
                $scope.ProjectInfo = projectinfo;
                $scope.client_str = '';
                //creating a string of client names to be displayed
                for (var i = 0; i < $scope.ProjectInfo.Clients.length; i++) {
                    $scope.client_str = $scope.client_str + $scope.ProjectInfo.Clients[i].ClientName + ', ';
                }
                $scope.client_str = $scope.client_str.slice(0, -2);
                //Initialising model for saving the editorial staff
                EditorialStaffProjectPermissionInputModel = {
                    "UserIds": [],
                    "ProjectId": $scope.projectId,
                    "MasterlanguageId": $scope.ProjectInfo.LanguageId
                };
                $scope.getEditorialStaffInfo();
            }
        });
    };

     /**
     * @ngdoc
     * @name changeView
     * @methodOf Projects.controller:ProjectsPermissions
     * @param {String} new_path This is string containing redirection path to project info page
     * @description
     * This method is used to change the view for project info
     *@return {undefined} This method does not return.
     */
    $scope.changeView = function (new_path) {
        var currProjID = $scope.ProjectInfo.ProjectId;
        switch (new_path) {
            case "projectInfo":
                $location.path('/projectPermissions/projectInfo');
                break;
        }
    };

    //fixed header scrollable table
    $('.permissions-list').on('scroll', function () {
        $('.header').css('top', $(this).scrollTop());
    });

    /**
     * @ngdoc
     * @name init
     * @methodOf Projects.controller:ProjectsPermissions
     * @description
     * This method is called when this controller for permissions is loaded
     *@return {undefined} This method does not return.
     */
    var init = function () {
        $scope.getProjectBasicInfoOnLoad();
        $scope.getAllPermissionsOnLoad();
    };

    init();
}]);
