/**
 * @ngdoc controller
 * @name Login.controller:ResetPasswordController
 * @element div
 *
 * @description
 * This Controller is responsible for showing Login page and handling requests made on Login page 
 *
 * @requires AngularJS.$scope
 * @requires AngularJS.$http
 * @requires AngularJS.$location 
 * @requires Users.UserAuthorizationService
 * @requires Users.UserAuthenticateService 
 * 
 * @property {Object} pass:Object This is object stores new password.
 * @property {Boolean} linkExpired:Boolean This is boolean variable used to check is reset password link is expired. 
 * @property {String} messageHeader:String This is used to show success message on reset password
 * @property {String} urlDateEncripted:String This is encrypted url.
 * 
 */
Login.controller('ResetPasswordController', ['$scope', '$http', '$location', 'commonService', 'UserAuthenticateService', 'UserAuthorizationService', function ($scope, $http, $location, commonService, UserAuthenticateService, UserAuthorizationService) {

    $scope.pass = {};
    $scope.linkExpired = false;
    $scope.resetPasswordPopup = false;
    $scope.messageHeader = 'Message';

    var URLSplited = window.location.href.slice(window.location.href.indexOf('/') + 1).split('/');
    var urlDate = URLSplited[3].split('?');
    var urlDateEncripted = urlDate[1];

     /**
     * @ngdoc
     * @name resetPassword
     * @methodOf Login.controller:ResetPasswordController
     *
     * @description
     * This method is used to reset password.
     * @return {String} This success message after reseting password.
     */
    $scope.resetPassword = function () {
        if ($scope.pass.newPassword == undefined && $scope.pass.confirmNewPassword == undefined) {
            $('#errorModal').modal('show');
            $scope.errorMessage = "Password fields should not be empty!";
            $scope.pass = {};
        } else if ($scope.pass.newPassword == undefined) {
            $('#errorModal').modal('show');
            $scope.errorMessage = "Please enter new password.";
        }
        else {
            var captitalLetter = /[A-Z]/.test($scope.pass.newPassword);
            var digit = /[0-9]/.test($scope.pass.newPassword);
            var passlength = $scope.pass.newPassword.length;
            var specialCharacter = /[@~`!#$%\^&*+=\-\[\]\\';,/_{}()\\:<>\?]/g.test($scope.pass.newPassword);
            if ($scope.pass == undefined) {
                $('#errorModal').modal('show');
                $scope.errorMessage = "Please enter new password.";
                $scope.pass = {};
            }
            if ($scope.pass.newPassword.localeCompare($scope.pass.confirmNewPassword) !== 0) {
                $('#errorModal').modal('show');
                $scope.errorMessage = "New Password does not match confirm password!";
                $scope.pass = {};
            }
            else if ($scope.pass.newPassword.localeCompare($scope.userName) === 0) {
                $('#errorModal').modal('show');
                $scope.errorMessage = "Password cannot be same as Username!";
                $scope.pass = {};
            }
            else if (!captitalLetter) {
                $('#errorModal').modal('show');
                $scope.errorMessage = "New Password must contain a capital letter!";
                $scope.pass = {};
            }
            else if (!digit) {
                $('#errorModal').modal('show');
                $scope.errorMessage = "New Password must contain a digit.";
                $scope.pass = {};
            }
            else if (!specialCharacter) {
                $('#errorModal').modal('show');
                $scope.errorMessage = "New Password must contain a Special Character.";
                $scope.pass = {};
            }
            else if (passlength < 8) {
                $('#errorModal').modal('show');
                $scope.errorMessage = "New Password must be of minimum 8 characters length.";
                $scope.pass = {};
            }
            else {
                $scope.pass['userId'] = urlDate[0];
                $scope.pass['newPassword'] = $scope.pass.newPassword;
                $scope.pass['confirmNewPassword'] = $scope.pass.confirmNewPassword;
                $http({
                    method: "post",
                    url: "../Login/ResetPassword",
                    data: $scope.pass
                })
                    .success(function (data) {
                        $('#errorModal').modal('show');
                        $scope.messageHeader = 'UPDATE SUCCESSFUL';
                        $scope.errorMessage = data.Message;
                        $scope.loginData = data;
                    })
                    .error(function (e) {
                    })
            }
        }
    };

    $scope.errorModalOk = function () {
        $('#errorModal').modal('hide');
        $('.modal-backdrop.fade.in').remove();
        $scope.authenticateUser($scope.loginData);
    };

    $scope.specialCharacterList = function () {
        $('#specialCharList').modal('show');
    };

     /**
     * @ngdoc
     * @name authenticateUser
     * @methodOf Login.controller:ResetPasswordController
     * @param {Object} data This is object containing user email and password enterded
     *
     * @description
     * This method is used to authenticate user.
     * @return {Object} This method returns user details object.
     * 
     */
    $scope.authenticateUser = function (data) {
        $scope.username = data.EmailId;
        $scope.password = data.Password;
        $scope.showLoader = true;
        $scope.loginAttempt = true;
        $http({
            method: "post",
            url: '../Login/AuthenticateUser/',
            data: {
                UserName: $scope.username,
                Password: $scope.password
            }
        })
            .success(function (data, status, headers, config) {
                $http({
                    method: "post",
                    url: "../Login/GetUserDetails",
                    data: {
                        UserName: $scope.username
                    }
                })
                    .success(function (data, status, headers, config) {
                        $scope.userdetails = data;
                        localStorage.setItem('userDetails', JSON.stringify($scope.userdetails));
                        sessionStorage.setItem('fromForgotPasswordPage', true);
                        $location.path("/");
                    })
                    .error(function (data, status, headers, config) {

                    })
            })
            .error(function (data, status, headers, config) {

            })
    };

    /**
     * @ngdoc
     * @name init
     * @methodOf Login.controller:ResetPasswordController
     *
     * @description
     * This method is called on page load and used to check password reset link expiration.
     * @return {Undefined} This method does not return.
     * 
     */
    var init = function () {
        $http.get('../Login/CheckLinkExpiration/' + urlDateEncripted + '/' + urlDate[0])
            .success(function (data) {
                if (data.Result === 'Success') {
                    $scope.userName = data.UserName;
                    $scope.linkExpired = false;
                    $scope.resetPasswordPopup = true;
                } else {
                    $scope.linkExpired = true;
                    $scope.resetPasswordPopup = false;
                }
            })
            .error(function (e) {
            })
    };

    init();
}]);