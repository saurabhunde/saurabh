/**
 * @ngdoc object
 * @name DistributionList
 * @element html
 * 
 * @requires AngularJS.$routeProvider
 * @requires AngularJS.$locationProvider
 * @requires AngularJS.$httpProvider
 * @requires AngularJS.ngRoute
 * @requires common
 * 
 * @description
 * This is DistributionList module, which contains distributionListController for distribution list menu to show all distribution lists in the application
 *
 */
var DistributionList = angular.module('distributionList', ['ngRoute', 'common', 'gmDistributionListModule', 'angularUtils.directives.dirPagination'])

DistributionList.config(['$routeProvider', '$locationProvider', '$httpProvider', function ($routeProvider, $locationProvider, $httpProvider) {
    $httpProvider.interceptors.push('myInterceptor');
    $routeProvider
     .when('/', {
         templateUrl: "/DistributionListController/Content/ngviews/DistributionList.html",
         controller: "distributionListController"
     })

}]);

DistributionList.factory('myInterceptor', function () {
    var requestInterceptor = {
        request: function (config) {
            localStorage.setItem('time', new Date());
            return config;
        }
    };

    return requestInterceptor;
});