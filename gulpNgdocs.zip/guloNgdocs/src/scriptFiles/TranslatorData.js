/**
 * @ngdoc service
 * @name Translators.TranslatorData
 * @requires AngularJS.$http
 * @requires common.commonService
 * 
 * @description
 * This is service in Translators module. It contains methods which are used for different operations done on translators page.
 *  
**/
gmTranslatorModule.service('TranslatorData', ['$http', 'commonService', function ($http, commonService) {

    var TranslatorPageService = {

        /**
        * @ngdoc function
        * @name Translators.TranslatorData#getTranslatorData
        * @methodOf Translators.TranslatorData
        * @param {Number} UserId This is user id of logged in user.
        * @description
        * This service is used to get the Translator Details to be displayed in the table.
        * @returns {Object}  This method returns object with list of all translators.
        */
        getTranslatorData: function (UserId, callback) {
            $http.get('Translators/TranslatorsList/' + UserId)
                .success(function (translatorlist) {
                    if (translatorlist.accessRes) {
                        if (translatorlist.accessRes == "AccessDenied") {
                            commonService.deniedRedirect();
                        }
                    }
                    hideColors = false;
                    callback(translatorlist);
                })

                .error(function (e) { });
        },
            /**
        * @ngdoc function
        * @name Translators.TranslatorData#getTranslatorExperienceData
        * @methodOf Translators.TranslatorData
        * @param {Number} userId This is user id of selected translator.
        * @description
        * This service is used to get the Translator's experience Details.
        * @returns {Object}  This method returns object with list of all translators.
        */
        getTranslatorExperienceData: function (userId, callback) {
            $http.get('Translators/TranslatorExperience/' + userId)
                .success(function (translatorExp) {
                    if (translatorExp.accessRes) {
                        if (translatorExp.accessRes == "AccessDenied") {
                            commonService.deniedRedirect();
                        }
                    }
                    hideColors = false;
                    callback(translatorExp);
                })

                .error(function (e) { });
        },

          /**
        * @ngdoc function
        * @name Translators.TranslatorData#saveTranslatorInformation
        * @methodOf Translators.TranslatorData
        * @param {Object} TranslatorDetails This all the details about newly added translator.
        * @description
        * This service is used to save the Translator Information to the DB.
        * @returns {Boolean}  This method returns boolean true/false.It returns true if operation performed is successful else it returns false. 
        */
        saveTranslatorInformation: function (TranslatorDetails, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token
                $http({
                    method: "post",
                    url: "Translators/AddTranslator",
                    data: TranslatorDetails,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (isSaved) {
                        callback(isSaved);
                        //return headerId;
                    })
                    .error(function (e) { })
            });

        },

         /**
        * @ngdoc function
        * @name Translators.TranslatorData#deleteTranslatorInformation
        * @methodOf Translators.TranslatorData
        * @param {Number} UserId This is user id of selected translator.
        * @param {Number} CurrentUserId This is user id of logged in user.
        * @description
        * This service is used to delete the selected translator info from table
        * @returns {Boolean}  This method returns boolean true/false.It returns true if operation performed is successful else it returns false. 
        */
        deleteTranslatorInformation: function (UserId, CurrentUserId, callback) {
            $http.get('Translators/DeleteTranslator/' + UserId + '/' + CurrentUserId)
                .success(function (isDeleted) {
                    callback(isDeleted);
                })

                .error(function (e) { });
        },

         /**
        * @ngdoc function
        * @name Translators.TranslatorData#activateTranslatorInformation
        * @methodOf Translators.TranslatorData
        * @param {Number} UserId This is user id of selected translator.
        * @param {Number} CurrentUserId This is user id of logged in user.
        * @param {Number} RoleId This is role id for translator role.
        * @description
        * This service is used to activate the deleted(Inactive) translator
        * @returns {Boolean}  This method returns boolean true/false.It returns true if operation performed is successful else it returns false. 
        */
        activateTranslatorInformation: function (UserId, CurrentUserId, RoleId, callback) {
            $http.get('Users/ActivateUser/' + UserId + '/' + CurrentUserId + '/' + RoleId)
                .success(function (isDeleted) {
                    callback(isDeleted);
                })

                .error(function (e) { });
        },

      
         /**
        * @ngdoc function
        * @name Translators.TranslatorData#updateTranslatorInformation
        * @methodOf Translators.TranslatorData
        * @param {Object} TranslatorEditInfo This all the details about updated translator.
        * @description
        * This service is used to save the Translator Information to the DB.
        * @returns {Boolean}  This method returns boolean true/false. It returns true if operation performed is successful else it returns false. 
        */
        updateTranslatorInformation: function (TranslatorEditInfo, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "Translators/EditTranslator",
                    data: TranslatorEditInfo,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (isUpdated) {
                        callback(isUpdated);
                    })
                    .error(function (e) { })
            });

        },

        /**
        * @ngdoc function
        * @name Translators.TranslatorData#getAddUserEmialNotificationInfo
        * @methodOf Translators.TranslatorData
        * @param {Object} TranslatorEditInfo This all the details about updated translator.
        * @description
        * This service is used to get email notifications settings
        * @returns {Array}  This method returns list of all email notification settings
        */
        getAddUserEmialNotificationInfo: function (roleName, callback) {
            $http.get('Users/AddUserEmialNotificationInfo/' + roleName)
                .success(function (notifications) {
                    callback(notifications);
                })

                .error(function (e) { });
        },


         /**
        * @ngdoc function
        * @name Users.UserList#impersonateTranslator
        * @methodOf Translators.TranslatorData
        * @param {Object} translatorImpersonateInfo This is object containing selected user's emailid.
        * @description
        * This service is used to get seleted user's user details
        * @returns {Object}  This method returns user details of impersonated user
        */
        impersonateTranslator: function (translatorImpersonateInfo, callback) {
            var TranslatorImpersonateInfo = {
                UserName: translatorImpersonateInfo.OriginalUserName,
                ImpersonateUserName: translatorImpersonateInfo.UserName
            };
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "Translators/ImpersonateTranslator",
                    data: TranslatorImpersonateInfo,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (UserDetails) {
                        callback(UserDetails);
                    })
                    .error(function (e) { })
            });

        },

        /**
        * @ngdoc function
        * @name Users.UserList#getUserAuthenticateImpersonate
        * @methodOf Translators.TranslatorData
        * @param {String} user This is username of impersonated user
        * @description
        * This service is used to authenticate user before impersonation
        * @returns {Boolean}  This method returns boolean. If operation is successful then true, else false.
        */
        getUserAuthenticateImpersonate: function (user, callbackGood, callbackBad) {

            $http({
                method: "post",
                url: 'Login/AuthenticateUserImpersonate/',
                data: {
                    UserName: user,
                }

            })
                .success(function (data, status, headers, config) {
                    callbackGood(data, status, headers, config);
                })
                .error(function (data, status, headers, config) {
                    callbackBad(data, status, headers, config);
                    return false;
                })

        }

    }
    return TranslatorPageService;
}])
