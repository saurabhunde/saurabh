
/**
 * @ngdoc object
 * @name Projects
 * @element html
 * 
 * @requires AngularJS.$routeProvider
 * @requires AngularJS.$locationProvider
 * @requires AngularJS.$httpProvider
 * @requires AngularJS.ngRoute
 * @requires common
 * 
 * @description
 * This is Projects module, which will contains controller for project page. 
 * 
 */
var Projects = angular.module('projects', ['ngRoute', 'common', 'gmProjectsModule', 'ngGrid', 'ui.bootstrap', 'mgcrea.ngStrap', 'ngTable', 'ngTableResizableColumns', 'ui.sortable', 'angularUtils.directives.dirPagination', 'ui.grid', 'ui.grid.resizeColumns', 'ngImgCrop'])

.config(['$routeProvider', '$locationProvider', '$httpProvider', function ($routeProvider, $locationProvider, $httpProvider) {

    $httpProvider.interceptors.push('myInterceptor');

    $routeProvider

    .when('/', {
        templateUrl: "/ProjectsController/Content/ngviews/ProjectHomePage.html",
        controller: "projectsController",
        label: 'Home'
    })

     .when('/netflixImport', {
       templateUrl: "/ProjectsController/Content/ngviews/NetflixImport.html",
       controller: "projectsController",
       label: 'Import KNP Wizard'
     })

    .when('/sourceSetup', {
        templateUrl: "/ProjectsController/Content/ngviews/ProjectMaster.html",
        controller: "projectMasterController",
        label: 'Source Setup'
    })
    .when('/glossary/sourceSetup', {
        templateUrl: "/ProjectsController/Content/ngviews/ProjectMaster.html",
        controller: "projectMasterController",
        label: 'Source Setup'
    })
    .when('/sourceSetup/glossary', {
        templateUrl: "/ProjectsController/Content/ngviews/ProjectGlossary.html",
        controller: "glossaryController",
        label: 'Glossary'
    })

    .when('/editProject/sourceSetup', {
        templateUrl: "/ProjectsController/Content/ngviews/ProjectMaster.html",
        controller: "projectMasterController",
        label: 'Source Setup'
    })
    .when('/addTranslation', {
        templateUrl: "/ProjectsController/Content/ngviews/AddTranslation.html",
        controller: "addTranslationController",
        label: 'Add Translation'
    })

    .when('/glossary', {
        templateUrl: "/ProjectsController/Content/ngviews/ProjectGlossary.html",
        controller: "glossaryController",
        label: 'Glossary'
    })
    .when('/glossary/glossaryAllSection', {
        templateUrl: "/ProjectsController/Content/ngviews/GlossaryAllSection.html",
        controller: "glossaryAllSectionController",
        label: 'AllGlossary'
    })
    .when('/glossary/translation/glossaryAllSection', {
        templateUrl: "/ProjectsController/Content/ngviews/GlossaryAllSection.html",
        controller: "glossaryAllSectionController",
        label: 'AllGlossary'
    })
    .when('/glossary/approve/glossaryAllSection', {
        templateUrl: "/ProjectsController/Content/ngviews/GlossaryAllSection.html",
        controller: "glossaryAllSectionController",
        label: 'AllGlossary'
    })
    .when('/projectInfo', {
        templateUrl: "/ProjectsController/Content/ngviews/ProjectInfo.html",
        controller: "projectInfoController",
        label: 'Project Info'
    })

     .when('/projectInfo/editProject', {
         templateUrl: "/ProjectsController/Content/ngviews/EditProject.html",
         controller: "projectEditController",
         label: 'Edit Project'
     })

    .when('/projectInfo/addProject', {
        templateUrl: "/ProjectsController/Content/ngviews/AddProject.html",
        controller: "projectAddController",
        label: 'Add Project'
    })
    .when('/addProject', {
        templateUrl: "/ProjectsController/Content/ngviews/AddProject.html",
        controller: "projectAddController",
        label: 'Add Project'
    })

    .when('/projectInfo/projectPermissions', {
        templateUrl: "/ProjectsController/Content/ngviews/ProjectPermissions.html",
        controller: "projectsPermissions",
        label: 'Project Permissions'
    })

    .when('/projectPermissions/projectInfo', {
        templateUrl: "/ProjectsController/Content/ngviews/ProjectInfo.html",
        controller: "projectInfoController",
        label: 'Project Info'
    })

    .when('/editProject', {
        templateUrl: "/ProjectsController/Content/ngviews/EditProject.html",
        controller: "projectEditController",
        label: 'Edit Project'
    })

    .when('/editProject/glossary', {
        templateUrl: "/ProjectsController/Content/ngviews/ProjectGlossary.html",
        controller: "glossaryController",
        label: 'Glossary'
    })
        .when('/projectInfo/glossary', {
            templateUrl: "/ProjectsController/Content/ngviews/ProjectGlossary.html",
            controller: "glossaryController",
            label: 'Glossary'
        })

    .when('/glossary/languageHistory', {
        templateUrl: "/ProjectsController/Content/ngviews/LanguageHistory.html",
        controller: "languageHistoryController",
        label: 'Language History'
    })

    .when('/approveGlossary', {
        templateUrl: "/ProjectsController/Content/ngviews/ApproveGlossary.html",
        controller: "approvalController",
        label: 'Approve Glossary'
    })

    .when('/glossary/translation/approve', {
        templateUrl: "/ProjectsController/Content/ngviews/ProjectGlossary.html",
        controller: "approvalController",
        label: 'Approve Glossary'
    })

    .when('/glossary/approve/translation', {
        templateUrl: "/ProjectsController/Content/ngviews/ProjectGlossary.html",
        controller: "translationController",
        label: 'Translation Glossary'
    })

    .when('/glossary/translation', {
        templateUrl: "/ProjectsController/Content/ngviews/ProjectGlossary.html",
        controller: "translationController",
        label: 'Translation Glossary'
    })

    .when('/glossary/approve', {
        templateUrl: "/ProjectsController/Content/ngviews/ProjectGlossary.html",
        controller: "approvalController",
        label: 'Approve Glossary'
    })

    .when('/projectPermissions', {
        templateUrl: "/ProjectsController/Content/ngviews/ProjectPermissions.html",
        controller: "projectsPermissions",
        label: 'Project Permissions'
    })
      .otherwise({
          redirectTo: '/'
      })
}]);

Projects.factory('myInterceptor', function () {
    var requestInterceptor = {
        request: function (config) {
            localStorage.setItem('time', new Date());
            return config;
        }
    };

    return requestInterceptor;
});

/**
 * @ngdoc service
 * @name Projects.saveBlob
 * @description
 * This is service in projects module. This service is used to download all browser supported files from application.
 *  
**/
Projects.factory('saveBlob', function () {

    var showSave,
           URL = window.URL || window.webkitURL,
           browserSupportedMimeTypes = {
               "image/jpeg": true,
               "image/png": true,
               "image/gif": true,
               "image/svg+xml": true,
               "image/bmp": true,
               "image/x-windows-bmp": true,
               "image/webp": true,
               "audio/wav": true,
               "audio/mpeg": true,
               "audio/webm": true,
               "audio/ogg": true,
               "video/mpeg": true,
               "video/webm": true,
               "video/ogg": true,
               "text/plain": true,
               "text/html": true,
               "text/xml": true,
               "application/xhtml+xml": true,
               "application/json": true,
               "application/pdf": true,
               "application/xls": true
           },
           downloadAttributeSupport = 'download' in document.createElement('a'),
           supported = true,

           saveBlob = navigator.saveBlob || navigator.msSaveOrOpenBlob || navigator.msSaveBlob || navigator.mozSaveBlob || navigator.webkitSaveBlob,
           saveAs = window.saveAs || window.webkitSaveAs || window.mozSaveAs || window.msSaveAs;

    if ((typeof Blob !== 'undefined') && (saveAs || saveBlob)) {
        showSave = function (data, name, mimetype) {

            var blob = new Blob([data], { type: mimetype || "application/excel" });

            if (!name) name = "Download.bin";
            if (saveAs) {
                saveAs(blob, name);
            }
            else {
                saveBlob(blob, name);
            }
        };
    }
    else if ((typeof Blob !== 'undefined') && URL) {
        showSave = function (data, name, mimetype) {

            var blob = new Blob([data], { type: mimetype || "application/octet-stream" })
            url = URL.createObjectURL(blob);

            if (downloadAttributeSupport) {

                var link = document.createElement("a");
                link.setAttribute("href", url);
                link.setAttribute("download", name || "Download.bin");

                var event = document.createEvent('MouseEvents');
                event.initMouseEvent('click', true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
                link.dispatchEvent(event);
                //window.open(url, '','location=no');

            }
            else {
                if (browserSupportedMimeTypes[mimetype.split(";")[0]] === true) {
                    mimetype = "application/excel";
                }

                window.open(url, '_blank', '');
            }

            setTimeout(function () {
                URL.revokeObjectURL(url);
            }, 250);
        };
    }
    else if (!/\bMSIE\b/.test(navigator.userAgent)) {
        showSave = function (data, name, mimetype) {
            if (!mimetype) mimetype = "application/octet-stream";
            // Again I need to filter the mime type so a download is forced.
            if (browserSupportedMimeTypes[mimetype.split(";")[0]] === true) {
                mimetype = "application/octet-stream";
            }
            window.open("data:" + mimetype + "," + encodeURIComponent(data), '_blank', '');
        };
    }
    else {
        showSave = function () {
        }
        supported = false;
    }

    return {
        supported: supported,
        save: showSave
    }
});

/**
* @ngdoc directive
* @name Projects.directive:optionsClass
* @restrict 'A'
* @element select 
* @scope
* @description 
* This is custom directive created for highlighting the secret section in dropdown of all sections on source setup page.
**/

Projects.directive('optionsClass', ['$parse', function ($parse) {
    return {
        require: 'select',
        link: function (scope, elem, attrs) {
            // get the source for the items array that populates the select.
            var optionsFiltersStripped = (attrs.ngOptions.indexOf('track') > -1) ? attrs.ngOptions.split('track')[0] : attrs.ngOptions;

            var optionarray = optionsFiltersStripped.trim().split(' ');
            var optionsSourceStr = optionarray.pop();

            //Get the field name that represents the label of the option (the item before 'for')
            var labelField = '';
            angular.forEach(optionarray, function (token, index) {
                if (token === "for") {
                    var itemParts = optionarray[index - 1].split('.');
                    labelField = (itemParts.length === 2) ? itemParts[1] : optionarray[index - 1];
                    return false;
                }
            });

            // use $parse to get a function from the options-class attribute
            // that you can use to evaluate later.
            getOptionsClass = $parse(attrs.optionsClass);
            scope.$watchCollection(optionsSourceStr, function (items) {
                scope.$$postDigest(function () {
                    // when the options source changes loop through its items.
                    angular.forEach(items, function (item) {
                        // evaluate against the item to get a mapping object for
                        // for your classes.
                        var classes = getOptionsClass(item),
                        // also get the option you're going to need. This can be found
                        // by looking for the option with the appropriate index in the
                        // value attribute.
                        option = elem.find("option[label='" + item[labelField] + "']");
                        // now loop through the key/value pairs in the mapping object
                        // and apply the classes that evaluated to be truthy.
                        angular.forEach(classes, function (add, className) {
                            if (add) {
                                angular.element(option).addClass(className);
                            }
                        });
                    });
                });
            });
        }
    };
}]);

/**
* @ngdoc directive
* @name Projects.directive:optionsClassOrder
* @restrict 'A'
* @element option 
* @scope
* @description 
* This is custom directive created for putting addtional info options in an alphabetical order.
* Add info select box is on add/edit project page.
**/

Projects.directive('optionsClassOrder', ['$parse', function ($parse) {
    return {
        require: 'select',
        link: function (scope, elem, attrs) {
            // get the source for the items array that populates the select.
            var optionsFiltersStripped = (attrs.ngOptions.indexOf('|') > -1) ? attrs.ngOptions.split('|')[0] : attrs.ngOptions;

            var optionarray = optionsFiltersStripped.trim().split(' ');
            var optionsSourceStr = optionarray.pop();

            //Get the field name that represents the label of the option (the item before 'for')
            var labelField = '';
            angular.forEach(optionarray, function (token, index) {
                if (token === "for") {
                    var itemParts = optionarray[index - 1].split('.');
                    labelField = (itemParts.length === 2) ? itemParts[1] : optionarray[index - 1];
                    return false;
                }
            });

            // use $parse to get a function from the options-class attribute
            // that you can use to evaluate later.
            getOptionsClass = $parse(attrs.optionsClassOrder);
            scope.$watchCollection(optionsSourceStr, function (items) {
                scope.$$postDigest(function () {
                    // when the options source changes loop through its items.
                    angular.forEach(items, function (item) {
                        // evaluate against the item to get a mapping object for
                        // for your classes.
                        var classes = getOptionsClass(item),
                        // also get the option you're going to need. This can be found
                        // by looking for the option with the appropriate index in the
                        // value attribute.
                        option = elem.find("option[label='" + item[labelField] + "']");
                        // now loop through the key/value pairs in the mapping object
                        // and apply the classes that evaluated to be truthy.
                        angular.forEach(classes, function (add, className) {
                            if (add) {
                                angular.element(option).addClass(className);
                            }
                        });
                    });
                });
            });
        }
    };
}]);

/**
* @ngdoc directive
* @name Projects.directive:optionsClassLangOrder
* @restrict 'A'
* @element option 
* @scope
* @description 
* This is custom directive created for putting selected languages in an alphabetical order.
* Selected language select box is on add/edit project page.
**/
Projects.directive('optionsClassLangOrder', ['$parse', function ($parse) {
    return {
        require: 'select',
        link: function (scope, elem, attrs) {
            // get the source for the items array that populates the select.
            var optionsFiltersStripped = (attrs.ngOptions.indexOf('|') > -1) ? attrs.ngOptions.split('|')[0] : attrs.ngOptions;

            var optionarray = optionsFiltersStripped.trim().split(' ');
            var optionsSourceStr = optionarray.pop();

            //Get the field name that represents the label of the option (the item before 'for')
            var labelField = '';
            angular.forEach(optionarray, function (token, index) {
                if (token === "for") {
                    var itemParts = optionarray[index - 1].split('.');
                    labelField = (itemParts.length === 2) ? itemParts[1] : optionarray[index - 1];
                    return false;
                }
            });

            // use $parse to get a function from the options-class attribute
            // that you can use to evaluate later.
            getOptionsClassforLangDropDown = $parse(attrs.optionsClassLangOrder);
            scope.$watchCollection(optionsSourceStr, function (items) {
                scope.$$postDigest(function () {
                    // when the options source changes loop through its items.
                    angular.forEach(items, function (item) {
                        // evaluate against the item to get a mapping object for
                        // for your classes.
                        var classes = getOptionsClassforLangDropDown(item),
                        // also get the option you're going to need. This can be found
                        // by looking for the option with the appropriate index in the
                        // value attribute.
                        option = elem.find("option[label='" + item[labelField] + "']");
                        // now loop through the key/value pairs in the mapping object
                        // and apply the classes that evaluated to be truthy.
                        angular.forEach(classes, function (add, className) {
                            if (add) {
                                angular.element(option).addClass(className);
                                if (className === "trans-source") {
                                    angular.element(option)[0].title = "Language Requires Translation Origin Source";
                                }
                            }
                        });
                    });
                });
            });
        }
    };
}]);

/**
* @ngdoc directive
* @name Projects.directive:optionsClassSections
* @restrict 'A'
* @element option 
* @scope
* @description 
* This is custom directive created for coloring the selected secret section in dropdown of all sections on source setup page.
**/
Projects.directive('optionsClassSections', ['$parse', function ($parse) {
    return {
        require: 'select',
        link: function (scope, elem, attrs) {
            // get the source for the items array that populates the select.
            var optionsFiltersStripped = (attrs.ngOptions.indexOf('track') > -1) ? attrs.ngOptions.split('track')[0] : attrs.ngOptions;

            var optionarray = optionsFiltersStripped.trim().split(' ');
            var optionsSourceStr = optionarray.pop();

            //Get the field name that represents the label of the option (the item before 'for')
            var labelField = '';
            angular.forEach(optionarray, function (token, index) {
                if (token === "for") {
                    var itemParts = optionarray[index - 1].split('.');
                    labelField = (itemParts.length === 2) ? itemParts[1] : optionarray[index - 1];
                    return false;
                }
            });

            // use $parse to get a function from the options-class attribute
            // that you can use to evaluate later.
            getOptionsClassSections = $parse(attrs.optionsClassSections);
            scope.$watchCollection(optionsSourceStr, function (items) {
                scope.$$postDigest(function () {
                    // when the options source changes loop through its items.
                    angular.forEach(items, function (item) {
                        // evaluate against the item to get a mapping object for
                        // for your classes.
                        var classes = getOptionsClassSections(item),
                        // also get the option you're going to need. This can be found
                        // by looking for the option with the appropriate index in the
                        // value attribute.
                        option = elem.find("option[label='" + item[labelField] + "']");
                        // now loop through the key/value pairs in the mapping object
                        // and apply the classes that evaluated to be truthy.
                        angular.forEach(classes, function (add, className) {
                            if (add) {
                                angular.element(option).addClass(className);
                            }
                        });
                    });
                });
            });
        }
    };
}]);




