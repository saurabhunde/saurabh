/**
 * @ngdoc object
 * @name Login
 * @element html
 * 
 * @requires AngularJS.$routeProvider
 * @requires AngularJS.$locationProvider
 * @requires AngularJS.ngRoute
 * @requires Users
 * 
 * @description
 * This is login module, which will contain controller for login page. 
 * 
 */
var Login = angular.module('login', ['ngRoute', 'gmUsersModule']);

Login.config(['$routeProvider', '$locationProvider', function ($routeProvider, $locationProvider) {
    $locationProvider.html5Mode(true);
    $locationProvider.hashPrefix('!');

    $locationProvider.html5Mode({
        enabled: true,
        requireBase: false
    });
    $routeProvider

  .when('/', {
      templateUrl: "LoginController/Content/ngviews/LoginInput.html",
      controller: "LoginController"
  })

  .when('/resets', {
      templateUrl: "LoginController/Content/ngviews/SecurityChangePass.html",
      controller: "ResetPasswordSecurityParameterChangesController"
  })
  .when('/reset/:optionalId', {
      templateUrl: "../LoginController/Content/ngviews/ResetPassword.html",
      controller: "ResetPasswordController"
  })
  .when('/projects', {

  })
}])

