/**
 * @ngdoc controller
 * @name AuditTrail.controller:AuditTrailController
 * @element div
 *
 * @description
 * This Controller is responsible for showing and exporting log on audit trail page.
 *
 * @requires AngularJS.$scope
 * @requires AngularJS.$http
 * @requires AngularJS.$location
 * @requires common.commonService
 * @requires AuditTrail.AuditTrailService
 * 
 * @property {object} userDetails:Object This is object stores the user details received from backend when user is logged in 
 * @property {object} FilterCriteriaForLogs:Object This is object stores applied filters values.
 * @property {String} projectId:String This is encrypted project id.
 * @property {Boolean} showAuditTable:Boolean This is boolean value to show audit log table.
 * @property {Boolean} showEmptyTableMsg:Boolean This is boolean value to show empty audit log table message.
 * @property {Boolean} showExportLogsBtn:Boolean This is boolean value to disable export log button.
 * 
 */
AuditTrail.controller('auditTrailController', ['$scope', '$http', '$location', 'commonService', 'AuditTrailService', 'dirPaginateDirective', function ($scope, $http, $location, commonService, AuditTrailService, dirPaginateDirective) {

    var userDetails = commonService.getLocalData('userDetails');
    var projectId = commonService.getSessionData('projectIBreadCrumb');
    $scope.showAuditTable = false;
    $scope.showEmptyTableMsg = false;
    $scope.showExportLogsBtn = true;
    $scope.showLoader = false;
    var ExpPassword;
    var FilterCriteriaForLogs = {
        ProjectId: 0,
        UserId: userDetails.UserId,
        ClientId: 0,
        PageId: 0,
        OperationstartDate: null,
        OperationEndDate: null,
        DateTimeFormatStartDate: null,
        DateTimeFormatEndDate: null
    };

    //set hashURL for GLMGR-1189
    sessionStorage.setItem('hashURL', null);

     /**
     * @ngdoc
     * @name getFilterData
     * @methodOf AuditTrail.controller:AuditTrailController
     * @description
     * This function is called on page load to get data for the dropdown filters.
     * @returns {Undefined} This method does not return.
     */
    var getFilterData = function () {
        AuditTrailService.getFilterDataForAudit(function (filterData) {
            $scope.clientList = filterData.clients;
            $scope.pageList = filterData.pages;
        });
    };

     /**
     * @ngdoc
     * @name getClientSpecificProjects
     * @methodOf AuditTrail.controller:AuditTrailController
     * @param {Object} selectedClient This is object contains selected client's details.
     * @description
     * This function is called on change of client dropdown to get projects list on the basis of client selected.
     * @returns {Undefined} This method does not return.
     */
    $scope.getClientSpecificProjects = function (selectedClient) {
        var clientIdList = [];
        clientIdList[0] = selectedClient.Id;
        AuditTrailService.getClientSpecificProjects(clientIdList, userDetails.UserId, userDetails.UserRoles[0].UserRoleName, function (projects) {
            $scope.projectsList = projects;
        });
    };

     /**
     * @ngdoc
     * @name showAuditLogs
     * @methodOf AuditTrail.controller:AuditTrailController
     * @param {Object} selectedClient This is object contains selected client's details.
     * @param {String} selectedProjectId This is project id of selected project. 
     * @param {Number} selectedPage This is page id of selected page.
     * @param {Number} startDate This is start date
     * @param {Number} endDate This is end date
     * @description
     * This function is called on show logs button. This function is used to show audit log.
     * @returns {Undefined} This method does not return.
     */
    $scope.showAuditLogs = function (selectedClient, selectedProjectId, selectedPage, startDate, endDate) {
        if (!$scope.selectedClient || !$scope.selectedProject) {
            $scope.validationMsg = "* Mandatory fields are required";
            return false;
        }
        else if (!$scope.selectedClient || !$scope.selectedProject) {
            $scope.validationMsg = "* Mandatory fields are required";
            return false;
        }
        else {
            if ($scope.startDate && $scope.endDate) {
                if ($scope.startDate > $scope.endDate) {
                    $scope.validationMsg = "* The start date cannot be greater than the end date";
                    return false;
                }
            }
        }
        $scope.validationMsg = "";

        //Creating model to send it to backend
        FilterCriteriaForLogs.ClientId = selectedClient;
        FilterCriteriaForLogs.ProjectId = selectedProjectId;
        FilterCriteriaForLogs.PageId = selectedPage;
        FilterCriteriaForLogs.DateTimeFormatStartDate = $scope.startDate;//$scope.startDate.toString();
        FilterCriteriaForLogs.DateTimeFormatEndDate = $scope.endDate;//$scope.endDate.toString();

        $scope.showLoader = true;
        AuditTrailService.getAuditInfo(FilterCriteriaForLogs, function (auditInfoList) {
            $scope.auditInfoList = auditInfoList;
            if (auditInfoList.length > 0) {
                $scope.showAuditTable = true;
                $scope.showEmptyTableMsg = false;
                $scope.showExportLogsBtn = false;
                $scope.auditInfoList = auditInfoList;
            }
            else {
                $scope.showAuditTable = false;
                $scope.showEmptyTableMsg = true;
                $scope.showExportLogsBtn = true;
            }
            $scope.showLoader = false;
        });
    };

    /**
     * @ngdoc
     * @name exportAuditLogs
     * @methodOf AuditTrail.controller:AuditTrailController
     * @description
     * This function is called on export log button. This function is used to export audit log.
     * @returns {Undefined} This method does not return.
     */
    var exportAuditLogs = function () {
        var XExportLogDisplayResult = {};
        XExportLogDisplayResult.XExportLogDisplay = $scope.auditInfoList;
        XExportLogDisplayResult.ProjectId = $scope.selectedProject.ProjectId;
        XExportLogDisplayResult.Password = ExpPassword;
        AuditTrailService.exportAuditInfo(XExportLogDisplayResult, function (status) {
            $scope.showExportLogsBtn = false;
        });
    };

    /**
     * @ngdoc
     * @name setExportPassword
     * @methodOf AuditTrail.controller:AuditTrailController
     * @description
     * This function is called inside checkExportPassword method. This function is used to set password for export log file.
     * @returns {Undefined} This method does not return.
     */
    $scope.setExportPassword = function () {
        $('#expPass').modal({ backdrop: 'static', keyboard: false });
        $scope.exportPass = "";
        $scope.isValidExport = false;
        $scope.validationMsgSaveAsExcel = "";
        $(".exp-password").attr("type", "password");
        $('#showHide').prop('checked', false);
        $('#expPass').modal('show');
    };

    //show-hide password GLMGR-1257
    $("#showHide").click(function () {
        if ($(".exp-password").attr("type") == "password") {
            $(".exp-password").attr("type", "text");

        } else {
            $(".exp-password").attr("type", "password");
        }
    });

     /**
     * @ngdoc
     * @name checkExportPassword
     * @methodOf AuditTrail.controller:AuditTrailController
     * @description
     * This function is called on export button on set password popup. This function is used to validate password.
     * @returns {Undefined} This method does not return.
     */
    $scope.checkExportPassword = function () {
        if (!$scope.exportPass || $scope.exportPass.length == 0) {
            $scope.isValidExport = true;
            $scope.validationMsgSaveAsExcel = 'Password cannot be empty';
            return false;
        }
        else if ($scope.exportPass.length > 15 || $scope.exportPass.length < 3 || $scope.exportPass.indexOf(' ') >= 0) {
            $scope.isValidExport = true;
            $scope.validationMsgSaveAsExcel = 'Password length should be minimum 3 and maximum 15 characters, no blank space allowed.';
            return false;
        } else {
            $('#expPass').modal('hide');
            ExpPassword = $scope.exportPass;
            $scope.exportPass = '';
            $(".exp-password").attr("type", "password");
            $('#showHide').prop('checked', false);
            exportAuditLogs();
        }
    };

    //show-hide password GLMGR-1257
    $scope.cancelExport = function () {
        $scope.exportPass = '';
        $(".exp-password").attr("type", "password");
        $('#showHide').prop('checked', false);
    };

     /**
     * @ngdoc
     * @name sort
     * @methodOf AuditTrail.controller:AuditTrailController
     * @param {String} keyname This is column name of column which is need to be sorted
     * @description
     * This function is used to sort list of users.
     * @returns {undefined} This method does not return.
     */
    $scope.sort = function (keyname) {
        $scope.sortKey = keyname;   //set the sortKey to the param passed
        $scope.reverse = !$scope.reverse; //if true make it false and vice versa
    };

     /**
     * @ngdoc
     * @name init
     * @methodOf AuditTrail.controller:AuditTrailController
     * @description
     * This function is called initially when page is loaded. This function is used for initialisation of the variables on page load.
     * @returns {undefined} This method does not return.
     */
    var init = function () {
        dynamicScreenHeight();
        var currentDate = new Date();
        var date = currentDate.getDate();
        var month = currentDate.getMonth() + 1;
        var year = currentDate.getFullYear();
        if (date < 10) {
            date = '0' + date
        }
        if (month < 10) {
            month = '0' + month
        }
        $scope.maxDate = year + "-" + month + "-" + date;
        var resorceIdx = 0;
        localStorage.setItem('resourcePageId', JSON.stringify(resorceIdx));
        getFilterData();
    };

    init();
}]);