/**
 * @ngdoc service
 * @name Search.SearchTermService
 * @requires AngularJS.$http
 * @requires common.commonService
 * @requires Projects.saveBlob
 * 
 * @description
 * This is service in Search module. It contains methods which are used for different operations done on search page.
 *  
**/
Search.service('SearchTermService', ['$http', 'saveBlob', 'commonService', function ($http, saveBlob, commonService) {

    var SearchTerm = {

         /**
        * @ngdoc function
        * @name Search.SearchTermService#getSearchTermPrePopulatedData
        * @methodOf Search.SearchTermService
        * @param {Number} UserId This is the user id of current logged in user.
        * @param {Number} UserRoleName This is the user role of current logged in user.
        * @description
        * This service is used to get initial search data on page load. 
        * @returns {Object}  This method returns object with all search page initial data
        */
        getSearchTermPrePopulatedData: function (UserId, UserRoleName, callback) {
            $http.get('Search/SearchTermPrePopulatedData/' + UserId + '/' + UserRoleName)
                .success(function (initialdata) {
                    if (initialdata.accessRes) {
                        if (initialdata.accessRes == "AccessDenied") {
                            commonService.deniedRedirect();
                        }
                    }
                    else {
                        callback(initialdata);
                    }
                })
                .error(function (e) {

                });
        },

          /**
        * @ngdoc function
        * @name Search.SearchTermService#searchTypePopulatedData
        * @methodOf Search.SearchTermService
        * @description
        * This service is used to get search type values in search type dropdown
        * @returns {Array}  This method returns array with all search types.
        */
        searchTypePopulatedData: function (callback) {
            $http.get('Search/SearchTypePopulatedData')
                .success(function (searchTypeData) {
                    callback(searchTypeData);
                })
                .error(function (e) {
                });
        },

        /**
        * @ngdoc function
        * @name Search.SearchTermService#searchTranslationStatusPopulatedData
        * @methodOf Search.SearchTermService
        * @description
        * This service is used to get status values in status dropdown
        * @returns {Array}  This method returns array with all status types.
        */
        searchTranslationStatusPopulatedData: function (callback) {
            $http.get('Search/SearchTranslationStatusPopulatedData')
                .success(function (translationStatus) {
                    callback(translationStatus);
                })
                .error(function (e) {
                });
        },

        /**
        * @ngdoc function
        * @name Search.SearchTermService#searchTranslationStatusPopulatedData
        * @methodOf Search.SearchTermService
        * @param {Object} InputSearchClientData This is object containing selected clients,brands,languages from dropdowns on search page.
        * @description
        * This service is used to get the list of brands and projects assigned to selected client.
        * @returns {Object}  This method returns Object with list of brands and projects assigned to selected client. 
        */
        searchClientsBrandProjectLanguagePopulatedData: function (InputSearchClientData, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: 'POST',
                    url: "Search/SearchClientsBrandProjectLanguagePopulatedData",
                    data: InputSearchClientData,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (data) {
                        callback(data);
                    })
                    .error(function (data) {
                    })
            });
        },

       /**
        * @ngdoc function
        * @name Search.SearchTermService#searchBrandsProjectLanguagePopulatedData
        * @methodOf Search.SearchTermService
        * @param {Object} InputSearchClientData This is object containing selected clients,brands,languages from dropdowns on search page.
        * @description
        * This service is used to get the list of projects assigned to selected client and selected brands.
        * @returns {Object}  This method returns Object with list of projects assigned to selected client and selected brands.
        */
        searchBrandsProjectLanguagePopulatedData: function (InputSearchClientData, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: 'POST',
                    url: "Search/SearchBrandsProjectLanguagePopulatedData ",
                    data: InputSearchClientData,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (data) {
                        callback(data);
                    })
                    .error(function (data) {
                    })
            });
        },

         /**
        * @ngdoc function
        * @name Search.SearchTermService#searchProjectsLanguagePopulatedData
        * @methodOf Search.SearchTermService
        * @param {Object} InputSearchClientData This is object containing selected clients,brands,languages from dropdowns on search page.
        * @description
        * This service is used to get the list of languages assigned to selected projects.
        * @returns {Object}  This method returns Object with list of languages assigned to selected projects.
        */
        searchProjectsLanguagePopulatedData: function (InputSearchClientData, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: 'POST',
                    url: "Search/SearchProjectsLanguagePopulatedData",
                    data: InputSearchClientData,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (data) {
                        callback(data);
                    })
                    .error(function (data) {
                    })
            });
        },
        
        /**
        * @ngdoc function
        * @name Search.SearchTermService#searchButtonMethod
        * @methodOf Search.SearchTermService
        * @param {Object} SearchInputInfoDetails This is object containing selected clients,brands,languages from dropdowns on search page.
        * @description
        * This service is used to search term in application with applied filters.
        * @returns {Object}  This method returns Object with list of all projects containing searched term.
        */
        searchButtonMethod: function (SearchInputInfoDetails, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: 'POST',
                    url: "Search/SearchGlossaryTerms",
                    data: SearchInputInfoDetails,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (data) {
                        callback(data);
                    })
                    .error(function (data) {
                    })
            });
        },

        /**
        * @ngdoc function
        * @name Search.SearchTermService#searchDetailsOnProjectClick
        * @methodOf Search.SearchTermService
        * @param {Object} SearchInputInfoDetails This is object containing selected clients,brands,languages from dropdowns on search page.
        * @description
        * This service is used to show grid view of selected project from list list view..
        * @returns {Object}  This method returns Object with details of selected project.
        */
        searchDetailsOnProjectClick: function (SearchInputInfoDetails, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: 'POST',
                    url: "Search/SearchDetailsOnProjectClick",
                    data: SearchInputInfoDetails,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (data) {
                        callback(data);
                    })
                    .error(function (data) {
                    })
            });
        }

    }

    return SearchTerm;
}])