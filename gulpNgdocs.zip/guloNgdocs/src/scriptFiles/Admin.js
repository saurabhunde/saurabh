﻿
/**
 * @ngdoc object
 * @name Admin
 * @element html
 * 
 * @requires AngularJS.$routeProvider
 * @requires AngularJS.$httpProvider
 * @requires AngularJS.ngRoute
 * @requires common
 * 
 * @description
 * This is admin module, which contains adminController which is responsible for all the operations done on the admin page.
 *
 */
var Admin = angular.module('admin', ['ngRoute', 'common', 'gmAdminModule'])

Admin.config(['$routeProvider', '$httpProvider', function ($routeProvider, $httpProvider) {
    $httpProvider.interceptors.push('myInterceptor');
   $routeProvider
    .when('/', {
        templateUrl: "/AdminController/Content/ngviews/Admin.html",
        controller: "adminController"
    })

}]);

Admin.factory('myInterceptor', function () {
    var requestInterceptor = {
        request: function (config) {
            localStorage.setItem('time', new Date());
            return config;
        }
    };

    return requestInterceptor;
});