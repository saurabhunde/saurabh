/**
 * @ngdoc object
 * @name common
 * @element html
 *
 * @requires AngularJS.ng-breadcrumbs
 * 
 * @description
 * This is common module for all modules.
 *
 */
var Common = angular.module('common', ['projectIdService', 'ng-breadcrumbs']);

/**
 * @ngdoc service
 * @name AngularJS.ng-breadcrumbs
 * 
 * @description
 * * ng-breadcrumb.js - v0.4.1 - A better AngularJS service to help with
 * breadcrumb-style navigation between views.
 *
 * @author Ian Kennington Walter (http://ianvonwalter.com)
 *
**/
angular.module('ng-breadcrumbs', []);

/**
 * @ngdoc service
 * @name AngularJS.$routeProvider
 * 
  @description
 * This built in AngularJS API (service) 
 * 
 * Please click the below link for more details
 * 
 * https://docs.angularjs.org/api/
 *
 *
**/
angular.module('$routeProvider', []);

/**
 * @ngdoc service
 * @name AngularJS.$route
 * 
  @description
 * This AngularJS routing provider module.
 * 
 * Please click the below link for more details
 * 
 * https://docs.angularjs.org/api/
 *
 *
**/
angular.module('$route', []);

/**
 * @ngdoc service
 * @name AngularJS.$interval
 * 
  @description
 * This built in AngularJS API (service) 
 * 
 * Please click the below link for more details
 * 
 * https://docs.angularjs.org/api/
 *
 *
**/
angular.module('$interval', []);

/**
 * @ngdoc service
 * @name AngularJS.$timeout
 * 
  @description
 *  This built in AngularJS API (service) 
 * 
 * Please click the below link for more details
 * 
 * https://docs.angularjs.org/api/
 *
 *
**/
angular.module('$timeout', []);

/**
 * @ngdoc service
 * @name AngularJS.$rootScope
 * 
  @description
 * This built in AngularJS API (service).
 * 
 * Please click the below link for more details
 * 
 * https://docs.angularjs.org/api/
 *
 *
**/
angular.module('$rootScope', []);

/**
 * @ngdoc service
 * @name AngularJS.$locationProvider
 * 
 * @description
 * This AngularJS routing provider module.
 * 
 * Please click the below link for more details.
 * 
 *https://docs.angularjs.org/api/
 *
 *
**/

angular.module('$locationProvider', []);

/**
 * @ngdoc service
 * @name AngularJS.ngRoute
 * 
* @description
 * This AngularJS in built module which is used for routing.
 * 
 * Please click the below link for more details.
 * 
 *https://docs.angularjs.org/api/
 *
 *
**/
angular.module('ngRoute', []);

 /**
 * @ngdoc service
 * @name AngularJS.$httpProvider
 * 
 * @description
 * This AngularJS in built module which is used to change the default behavior of the $http service.
 * 
 * Please click the below link for more details.
 * 
 *https://docs.angularjs.org/api/
 *
**/
angular.module('$httpProvider', []);


/**
 * @ngdoc service
 * @name AngularJS.$location 
 * 
 * @description
 * This built in AngularJS API (service) .
 * 
 * Please click the below link for more details.
 * 
 * https://docs.angularjs.org/api/
 *
**/
angular.module('$location', []);

/**
 * @ngdoc service
 * @name AngularJS.$scope 
 * 
 * @description
 * This built in AngularJS API (service) .
 * 
 * Please click the below link for more details.
 * 
 * https://docs.angularjs.org/api/
 *
**/
angular.module('$scope', []);

/**
 * @ngdoc service
 * @name AngularJS.$http 
 * 
 * @description
 * This built in AngularJS API (service) .
 * 
 * Please click the below link for more details.
 * 
 * https://docs.angularjs.org/api/
 *
**/
angular.module('$http', []);

/**
 * @ngdoc object
 * @name AngularJS
 *
 * @description
 * This section contains all inbuilt in functionalities of angualr js.
 * Respective reference is given in their sections.
 * 
 * Please click the below link for more details.
 * 
 *https://docs.angularjs.org/api/
 *
 */
angular.module('AngularJS', []);