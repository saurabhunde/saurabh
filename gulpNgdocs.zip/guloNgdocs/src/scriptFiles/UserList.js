/**
 * @ngdoc service
 * @name Users.UserList
 * @requires AngularJS.$http
 * @requires common.commonService
 * 
 * @description
 * This is service in Users module. It contains methods which are used for different operations done on users page.
 *  
**/
gmUsersModule.service('UserList', ['$http', 'commonService', function ($http, commonService) {

    var UserListPageService = {

        /**
        * @ngdoc function
        * @name Users.UserList#getUserList
        * @methodOf Users.UserList
        * @description
        * This service is used to get User List Details to be displayed in the Table
        * @returns {Object}  This method returns object with all users page initial data
        */
        getUserList: function (callback) {
            var userDetails = commonService.getLocalData('userDetails');

            $http.get('Users/UsersList/' + userDetails.UserId)
                .success(function (userlist) {
                    if (userlist.accessRes) {
                        if (userlist.accessRes == "AccessDenied") {
                            commonService.deniedRedirect();
                        }
                    }
                    else {
                        hideColors = false;
                        callback(userlist);
                    }
                })

                .error(function (e) { });
        },

         /**
        * @ngdoc function
        * @name Users.UserList#getClientProjectString
        * @methodOf Users.UserList
        * @param {Array} ClientIdList This is list of ids of assigned clients
        * @param {Number} userId This is user id of current logged in user.
        * @param {String} userRoleName This is user role of current logged in user.
        * @description
        * This service is used for getting the Client Project List for User Edit
        * @returns {Object}  This method returns object with all list of project assigned to selected client.
        */
        getClientProjectString: function (ObjectId1, userId, userRoleName, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "Users/ClientProjectString",
                    data: {
                        ClientIdList: ObjectId1,
                        userId: userId,
                        userRoleName: userRoleName

                    },
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (projectlist) {
                        if (projectlist.accessRes) {
                            if (projectlist.accessRes == "AccessDenied") {
                                commonService.deniedRedirect();
                            }
                        }
                        else {
                            callback(projectlist);
                        }
                        //return headerId;
                    })
                    .error(function (e) { })
            });

        },

        /**
        * @ngdoc function
        * @name Users.UserList#saveUserInformation
        * @methodOf Users.UserList
        * @param {Object} UserDetails This is newly added user's details.
        * @description
        * This service is used to save New User Information
        * @returns {Boolean}  This method returns boolean. If operation is successful then true, else false.
        */
        saveUserInformation: function (UserDetails, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "Users/AddUser",
                    data: UserDetails,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }


                })
                    .success(function (isSaved) {
                        callback(isSaved);
                    })
                    .error(function (e) { })
            });

        },

         /**
        * @ngdoc function
        * @name Users.UserList#saveClientAdminInformation
        * @methodOf Users.UserList
        * @param {Object} UserDetails This is newly added user's details.
        * @param {Array} ProjectIdList This is list of ids of selected projects
        * @param {Boolean} IsReadOnly This is boolean value. set as true when newly added user need to be read only.
        * @param {Boolean} AccessAllClients This is boolean value. set as true when newly added user has access to all projects.
        * @description
        * This service is used to save New Client Admin Information
        * @returns {Boolean}  This method returns boolean. If operation is successful then true, else false.
        */
        saveClientAdminInformation: function (UserDetails, ProjectIdList, IsReadOnly, AccessAllClients, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "Users/AddClientAdmin",
                    data: {
                        UserDetails: UserDetails,
                        ProjectIdList: ProjectIdList,
                        IsReadOnly: IsReadOnly,
                        AccessAllClients: AccessAllClients
                    },
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }


                })
                    .success(function (isSaved) {
                        callback(isSaved);
                    })
                    .error(function (e) { })
            });

        },

         /**
        * @ngdoc function
        * @name Users.UserList#saveClientUserInformation
        * @methodOf Users.UserList
        * @param {Object} UserDetails This is newly added user's details.
        * @param {Array} ProjectIdList This is list of ids of selected projects
        * @description
        * This service is used to save new Client User Infomartion
        * @returns {Boolean}  This method returns boolean. If operation is successful then true, else false.
        */
        saveClientUserInformation: function (UserDetails, ProjectIdList, callback) {

            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "Users/AddClientUser",
                    data: {
                        UserDetails: UserDetails,
                        ProjectIdList: ProjectIdList,
                    },
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (isSaved) {
                        callback(isSaved);
                    })
                    .error(function (e) { })
            });
        },


         /**
        * @ngdoc function
        * @name Users.UserList#deleteUserInformation
        * @methodOf Users.UserList
        * @param {Number} UserId This is user to be deleted.
        * @param {Number} CurrentUserId This is user id of logged in user
        * @description
        * This service is used to delete selected User Info from the table
        * @returns {Boolean}  This method returns boolean. If operation is successful then true, else false.
        */
        deleteUserInformation: function (UserId, CurrentUserId, callback) {
            $http.get('Users/DeleteUser/' + UserId + '/' + CurrentUserId)
                .success(function (isActivated) {
                    callback(isActivated);
                })

                .error(function (e) { });
        },

           /**
        * @ngdoc function
        * @name Users.UserList#activateUserInformation
        * @methodOf Users.UserList
        * @param {Number} UserId This is user to be deleted.
        * @param {Number} CurrentUserId This is user id of logged in user
        * @param {Number} RoleId This is user role id of current logged in user.
        * @description
        * This service is used to activate the deleted(Inactive) User
        * @returns {Boolean}  This method returns boolean. If operation is successful then true, else false.
        */
        activateUserInformation: function (UserId, CurrentUserId, RoleId, callback) {
            $http.get('Users/ActivateUser/' + UserId + '/' + CurrentUserId + '/' + RoleId)
                .success(function (isDeleted) {
                    callback(isDeleted);
                })

                .error(function (e) { });
        },

        /**
        * @ngdoc function
        * @name Users.UserList#updateUserInformation
        * @methodOf Users.UserList
        * @param {Object} UserEditInfo This is edited user's details.
        * @description
        * This service is used to update User Information
        * @returns {Boolean}  This method returns boolean. If operation is successful then true, else false.
        */
        updateUserInformation: function (UserEditInfo, callback) {
            UserEditInfo['UserId'] = commonService.getLocalData('userDetails').UserId;
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "Users/EditUser",
                    data: UserEditInfo,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }


                })
                    .success(function (isUpdated) {
                        callback(isUpdated);
                    })
                    .error(function (e) { })
            });

        },

       /**
        * @ngdoc function
        * @name Users.UserList#getUserEditInfo
        * @methodOf Users.UserList
        * @param {Number} edituserId This is the id of user to be edited.
        * @param {Number} userId This is user id of current logged in user.
        * @param {String} userRoleName This is user role of current logged in user.
        * @description
        * This service is used for getting the Client Project List for User Edit
        * @returns {Object}  This method returns object with all details of user to be edited.
        */
        getUserEditInfo: function (edituserId, userId, userRoleName, callback) {
            $http.get('Users/UserPrepopulatedInfo/' + edituserId + '/' + userId + '/' + userRoleName)
                .success(function (projectEditInfo) {
                    callback(projectEditInfo);
                })

                .error(function (e) { });
        },

         /**
        * @ngdoc function
        * @name Users.UserList#updateClientUserInformation
        * @methodOf Users.UserList
        * @param {Object} UserEditInfo This is user details of user to be deleted.
        * @description
        * This service is used to update Client User Information
        * @returns {Boolean}  This method returns boolean. If operation is successful then true, else false.
        */
        updateClientUserInformation: function (UserEditInfo, callbackGood, callbackBad) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "Users/EditClientUser",
                    data: UserEditInfo,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (isUpdated) {
                        callbackGood(isUpdated);
                    })
                    .error(function (e) {
                        callbackBad(e);
                    })
            });
        },

        /**
        * @ngdoc function
        * @name Users.UserList#showCommonProjects
        * @methodOf Users.UserList
        * @param {Array} ClientIdList This is list of ids of assigned clients
        * @param {Number} userId This is user id of current logged in user.
        * @param {String} userRoleName This is user role of current logged in user.
        * @description
        * This service is used to create array for projects respective to clients
        * @returns {Object}  This method returns object with all list of project assigned to selected client.
        */
        showCommonProjects: function (ClientIdList, userId, userRoleName, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "Users/ClientProjectString",
                    data: {
                        ClientIdList: ClientIdList,
                        userId: userId,
                        userRoleName: userRoleName

                    },
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                }).success(function (projectlist) {
                    callback(projectlist);
                })
                    .error(function (e) { });
            });
        },

         /**
        * @ngdoc function
        * @name Users.UserList#updateClientAdminInformation
        * @methodOf Users.UserList
        * @param {Object} UserEditInfo This is user details of user to be updated.
        * @description
        * This service is used to update New Client Admin Information
        * @returns {Boolean}  This method returns boolean. If operation is successful then true, else false.
        */
        updateClientAdminInformation: function (UserEditInfo, callbackGood, callbackBad) {
            //UserEditInfo['UserId'] = commonService.getLocalData('userDetails').UserId;
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "Users/EditClientAdmin",
                    data: UserEditInfo,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (isUpdated) {
                        callbackGood(isUpdated);
                    })
                    .error(function (e) {
                        callbackBad(e);
                    })
            });
        },

         /**
        * @ngdoc function
        * @name Users.UserList#getAddUserEmialNotificationInfo
        * @methodOf Users.UserList
        * @param {String} roleName This is selected role name.
        * @description
        * This service is used to get email notifications settings
        * @returns {Array}  This method returns list of all email notification settings
        */
        getAddUserEmialNotificationInfo: function (roleName, callback) {
            $http.get('Users/AddUserEmialNotificationInfo/' + roleName)
                .success(function (notifications) {
                    callback(notifications);
                })

                .error(function (e) { });
        },

         /**
        * @ngdoc function
        * @name Users.UserList#impersonateUser
        * @methodOf Users.UserList
        * @param {Object} UserImpersonateInfo This is object containing selected user's email id .
        * @description
        * This service is used to get seleted user's user details
        * @returns {Object}  This method returns user details of impersonated user
        */
        impersonateUser: function (UserImpersonateInfo, callback) {
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "Users/ImpersonateUser",
                    data: UserImpersonateInfo,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (UserDetails) {
                        callback(UserDetails);
                    })
                    .error(function (e) { })
            });
        },

         /**
        * @ngdoc function
        * @name Users.UserList#getUserAuthenticateImpersonate
        * @methodOf Users.UserList
        * @param {String} user This is username of impersonated user
        * @description
        * This service is used to authenticate user before impersonation
        * @returns {Boolean}  This method returns boolean. If operation is successful then true, else false.
        */
        getUserAuthenticateImpersonate: function (user, callbackGood, callbackBad) {
            $http({
                method: "post",
                url: 'Login/AuthenticateUserImpersonate/',
                data: {
                    UserName: user,
                }

            })
                .success(function (data, status, headers, config) {
                    callbackGood(data, status, headers, config);
                })
                .error(function (data, status, headers, config) {
                    callbackBad(data, status, headers, config);
                    return false;
                })

        }
    }
    return UserListPageService;
}])