/**
 * @ngdoc controller
 * @name ViewGlossary.controller:ViewGlossaryController
 * @element div
 *
 * @description
 * This Controller is responsible for showing content on sent glossary page.
 *
 * @requires AngularJS.$scope
 * @requires AngularJS.$rootScope
 * @requires AngularJS.$http
 * @requires AngularJS.$location
 * @requires AngularJS.$route
 * 
 * @property {Object} viewLogin:Object This is object stores the user details.
 * @property {Object} gridOptions:Object This is object store ng grid configuration
 * @property {Array} facdata:Array This is array of objects contains data property of gridOptions 
 * @property {Array} defdata:Array This is array of objects column definitions for ng grid column set as columnDefs property in gridOptions
 * @property {Array} Catsequence:Array This is array of objects is list of all categories .
 * @property {String} hc_nopin_source:String This property is header template for Translation Source column.
 * @property {String} hc_nopin:String This property is header template for categories
 * @property {String} hc_nopin_language:String This property is header template for Languages(left to right)
 * @property {String} hc_nopin_language_rtl:String This property is header template for Languages(right to left)
 * @property {String} hc_nopin_master_rtl:String This property is header template for master-language(source term)(right to left)
 * @property {Boolean} viewloginCred:Boolean This is boolean value used to validate token.
 * @property {Boolean} tokenExpired:Boolean This is boolean value used to check if token is expired.
 * @property {Boolean} glossaryLocked:Boolean This is boolean value used to check if glossary is locked.
 * @property {Boolean} viewloginCredFail:Boolean This is boolean value used to show message when token validation fails.
 *
 * 
 */
ViewGlossary.controller('viewGlossaryController', ['$scope', '$rootScope', '$http', '$location', '$routeParams', function ($scope, $rootScope, $http, $location, $routeParams) {
    $scope.viewLogin = {};
    $scope.viewloginCred = true;
    $scope.tokenExpired = false;
    $scope.glossaryLocked = false;
    $scope.viewloginCredFail = false;
    $scope.sectionListdrop = false;
    var isVisible = false;
    var winHt = window.innerHeight;
    var winOutHt = window.outerHeight;
    $rootScope.headerId = "";
    $rootScope.languageSelected = "";
    $scope.facdata = [];
    $scope.defdata = [];
    $scope.myData = [];
    var Catsequence = [];

    $scope.totalServerItems = 0;
    //ng-grid pagination options for initialization of ng-grid pagination logic
    $scope.pagingOptions = {
        pageSizes: [20, 30, 50],
        pageSize: '20',
        currentPage: 1,
        angularCompileRows: true
    };
    //ng-grid options for initialization of ng-grid
    $scope.gridOptions = {
        data: 'myData',
        columnDefs: 'defdata',
        showColumnMenu: true, enableCellEdit: false, enableColumnResize: true, enableColumnReordering: false, enablePinning: true,
        enablePaging: true, enableSorting: true, noKeyboardNavigation: false, showFilter: true, showGroupPanel: false,
        groupable: false, rowHeight: 70,
        pagingOptions: $scope.pagingOptions,
        showFooter: true,
        multiSelect: false,
        keepLastSelected: false,
        totalServerItems: "totalServerItems",
        rowHeight: 110
    };

      /**
    * @ngdoc
    * @name paginate
    * @methodOf ViewGlossary.controller:ViewGlossaryController
    * @description
    * This function is used for pagination. 
    * @returns {undefined} This method does not return.
    */
    var paginate = function () {
        $scope.totalServerItems = $scope.facdata.length;
        $scope.myData = [];
        $scope.myData = $scope.facdata.slice(($scope.pagingOptions.currentPage - 1) * $scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage * $scope.pagingOptions.pageSize);
    };
    //Watching for change in page
    $scope.$watch('pagingOptions', function (newVal, oldVal) {
        if (newVal.pageSize !== oldVal.pageSize) {
            $scope.pagingOptions.currentPage = 1;
            paginate();
        }
        if (newVal.currentPage !== oldVal.currentPage) {

            paginate();
        }
    }, true);

    /**
    * @ngdoc
    * @name GlossaryNgGrid
    * @methodOf ViewGlossary.controller:ViewGlossaryController
    * @param {Object} glossaryData This is object contains whole glossary data.
    * @param {Object} headerValue This is object contains selected sections details.
    * @description
    * This function is called on page load.Used to create grid structure to show glossary data
    * @returns {undefined} This method does not return.
    */
    var GlossaryNgGrid = function (glossaryData, headerValue) {

        var uuid = 'a';
        var catList = glossaryData.SectionCategories;

        var hc_nopin = "<div class=\"ngHeaderSortColumn {{col.headerClass}}\" ng-style=\"{'cursor': col.cursor}\" ng-class=\"{ 'ngSorted': !col.noSortVisible() }\">\r" +
            "\n" +
            " <div ng-click=\"col.sort($event)\" ng-class=\"'colt' + col.index\" class=\"ngHeaderText\">{{col.displayName}}</div>\r" +
            "\n" +
            " <div class=\"ngSortButtonDown\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonDown()\"></div>\r" +
            "\n" +
            " <div class=\"ngSortButtonUp\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonUp()\"></div>\r" +
            "\n" +
            " <div class=\"ngSortPriority\">{{col.sortPriority}}</div>\r" +
            "\n" +
            "</div>\r" +
            "\n" +
            "<div ng-show=\"col.resizable\" class=\"ngHeaderGrip\" ng-click=\"col.gripClick($event)\" ng-mousedown=\"col.gripOnMouseDown($event)\"></div>\r" +
            "\n";

        var hc_nopin_language = "<div class=\"ngHeaderSortColumn {{col.headerClass}}\" ng-style=\"{'cursor': col.cursor}\" ng-class=\"{ 'ngSorted': !col.noSortVisible() }\">\r" +
            "\n" +
            " <div ng-click=\"col.sort($event)\" ng-class=\"'colt' + col.index\" class=\"ngHeaderText\">{{col.displayName}}</div>\r" +
            "\n" +
            " <div class=\"ngSortButtonDown\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonDown()\"></div>\r" +
            "\n" +
            " <div class=\"ngSortButtonUp\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonUp()\"></div>\r" +
            "\n" +
            " <div class=\"ngSortPriority\">{{col.sortPriority}}</div>\r" +
            "\n" +
            '<div class="lang-info-icon" ng-click="langInfo(col)" ></div>' +
            '</div>\r' +
            "</div>\r" +
            "\n" +
            "<div ng-show=\"col.resizable\" class=\"ngHeaderGrip\" ng-click=\"col.gripClick($event)\" ng-mousedown=\"col.gripOnMouseDown($event)\"></div>\r" +
            "\n";

        var hc_nopin_language_rtl = "<div class=\"ngHeaderSortColumn {{col.headerClass}}\" ng-style=\"{'cursor': col.cursor}\" ng-class=\"{ 'ngSorted': !col.noSortVisible() }\">\r" +
            "\n" +
            " <div ng-click=\"col.sort($event)\" ng-class=\"'colt' + col.index\" class=\"ngHeaderText-rtl\">{{col.displayName}}</div>\r" +
            "\n" +
            " <div class=\"ngSortButtonDown\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonDown()\"></div>\r" +
            "\n" +
            " <div class=\"ngSortButtonUp\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonUp()\"></div>\r" +
            "\n" +
            " <div class=\"ngSortPriority\">{{col.sortPriority}}</div>\r" +
            "\n" +
            '<div class="lang-info-icon-rtl" ng-click="langInfo(col)" ></div>' +
            '</div>\r' +
            "</div>\r" +
            "\n" +
            "<div ng-show=\"col.resizable\" class=\"ngHeaderGrip\" ng-click=\"col.gripClick($event)\" ng-mousedown=\"col.gripOnMouseDown($event)\"></div>\r" +
            "\n";

        var staticName = 'cat';
        //column defn for categories.
        var countCat = 0;

        if (Catsequence) {

            for (var j = 0; j < Catsequence.length; j++) {
                for (var i = 0; i < catList.length; i++) {
                    //var str = catList[i].CategoryName;
                    //str = str.replace(/[^A-Z0-9]/ig, "");
                    if (Catsequence[j] == catList[i].CategoryId) {


                        var str = catList[i].CategoryId.toString();

                        countCat = countCat + 1;
                        if (countCat < 5) {
                            if (catList[i].CategoryName == 'English Description') {
                                $scope.defdata.push({ field: staticName.concat(str), displayName: catList[i].CategoryName, width: 400, pinned: true, enableCellEdit: false });
                            } else {
                                $scope.defdata.push({ field: staticName.concat(str), displayName: catList[i].CategoryName, width: 150, pinned: true, enableCellEdit: false });
                            }
                        }
                        else {
                            $scope.defdata.push({ field: staticName.concat(str), displayName: catList[i].CategoryName, width: 150, pinned: false, enableCellEdit: false });
                        }
                    }

                }
            }
        }
        else {
            for (var i = 0; i < catList.length; i++) {
                //var str = catList[i].CategoryName;
                //str = str.replace(/[^A-Z0-9]/ig, "");

                var str = catList[i].CategoryId.toString();
                countCat = countCat + 1;
                if (countCat < 5) {
                    if (catList[i].CategoryName == 'English Description') {
                        $scope.defdata.push({ field: staticName.concat(str), displayName: catList[i].CategoryName, width: 400, pinned: true, enableCellEdit: false });
                    } else {
                        $scope.defdata.push({ field: staticName.concat(str), displayName: catList[i].CategoryName, width: 150, pinned: true, enableCellEdit: false });
                    }
                }
                else {
                    $scope.defdata.push({ field: staticName.concat(str), displayName: catList[i].CategoryName, width: 150, pinned: false, enableCellEdit: false });
                }
            }
        }

        var masterLangfield = $scope.GlossaryInitialTerms.MasterLanguage.MasterLanguageName;
        masterLangfield = masterLangfield.replace(/ +/g, "");
        masterLangfield = masterLangfield.replace(/\//g, '');

        //$scope.defdata.push({ field: $scope.GlossaryInitialTerms.MasterLanguage.MasterLanguageName, displayName: $scope.GlossaryInitialTerms.MasterLanguage.MasterLanguageName, width: 200, pinned: true, enableCellEdit: false, cellTemplate: '<div class="ngCellText" tooltip={{row.getProperty(col.field)}}  tooltip-placement="top" ng-cell-text>{{row.getProperty(col.field)}}</div>', cellClass: 'cellToolTip' });
        $scope.defdata.push({ field: masterLangfield, displayName: $scope.GlossaryInitialTerms.MasterLanguage.MasterLanguageName, width: 300, pinned: false, enableCellEdit: false, cellTemplate: '<div class="ngCellText pull-left width100per"><div class="pull-left ngCellText ngCellTextMasterTerm" tooltip={{row.getProperty(col.field)}}  tooltip-placement="top" ng-cell-text>{{row.getProperty(col.field).MasterText}}<br><br><span style="color:lime;">{{row.getProperty(col.field).brandcount}}</span></div><div class="pull-right termImgDiv" ng-hide="row.getProperty(col.field).MasterImageUrl == null"><img src="{{row.getProperty(col.field).MasterImageUrl}}" ng-hide="row.getProperty(col.field).MasterImageUrl == null" class="termImg"/> </div></div>', cellClass: 'cellToolTip' });
        $scope.defdata.push({ field: uuid, displayName: 'English Unique Id', width: 150, pinned: false, enableCellEdit: true, cellTemplate: '<div class="ngCellText" tooltip={{row.getProperty(col.field)}}  tooltip-placement="top" ng-cell-text>{{row.getProperty(col.field)}}</div>', cellClass: 'cellToolTip', editableCellTemplate: '<textarea readonly ng-class="\'colt\' + col.index" style="min-width:200px; resize: none; height:70px;"  ng-model="row.getProperty(col.field)" ng-input="row.getProperty(col.field)" class="txtArea"/>' });
        //$scope.defdata.push({ field: $scope.GlossaryInitialTerms.MasterLanguage.MasterLanguageName, displayName: $scope.GlossaryInitialTerms.MasterLanguage.MasterLanguageName, width: 200, pinned: true, cellTemplate: '<div class="ngCellText" ng-click="listStarredTerms(row.getProperty(col.field))" ng-class="{\'ngCellText\' : isStarred, \'starred-icon\': !isStarred && checkIsStarred(row.getProperty(col.field))}" style="padding-right: 30px" tooltip={{row.getProperty(col.field).MasterText}}  tooltip-placement="top" ng-cell-text>{{row.getProperty(col.field).MasterText}}</div>', cellClass: 'cellToolTip' });

        var langList = $scope.GlossaryInitialTerms.ProjectLanguages;

        for (var i = 0; i < langList.length; i++) {
            var str2 = langList[i].LanguageName;
            str2 = str2.replace(/[^A-Z0-9]/ig, "");
            if (langList[i].IsRightToLeft == true) {
                $scope.defdata.push({ field: str2, displayName: langList[i].LanguageName, width: 400, headerCellTemplate: hc_nopin_language_rtl, cellTemplate: '<div  class="ngCellText"  ng-cell-text>{{row.getProperty(col.field).lang}}</div>', cellClass: 'langg' });
            }
            else {
                $scope.defdata.push({ field: str2, displayName: langList[i].LanguageName, width: 400, headerCellTemplate: hc_nopin_language, cellTemplate: '<div  class="ngCellText"  ng-cell-text>{{row.getProperty(col.field).lang}}</div>' });
            }
        }

        // data for columns according to colmn def.
        for (var k = 0; k < $scope.glossaryData.MasterGlossaries.length; k++) {
            var obj = {};
            var obj1 = {};
            var stt = [];
            for (var l = 0; l < $scope.glossaryData.MasterGlossaries[k].ProjectCategories.length; l++) {
                var str3 = $scope.glossaryData.MasterGlossaries[k].ProjectCategories[l].CategoryId.toString();
                obj[staticName.concat(str3)] = $scope.glossaryData.MasterGlossaries[k].ProjectCategories[l].CategoryText;
            }
            var x = $scope.glossaryData.MasterGlossaries[k].ProjectCategories.length;
            var obj5 = {};
            obj5['MasterText'] = $scope.glossaryData.MasterGlossaries[k].MasterText;
            obj5['MasterImageUrl'] = $scope.glossaryData.MasterGlossaries[k].MasterImageUrl;
            obj5['MasterGlossaryId'] = $scope.glossaryData.MasterGlossaries[k].MasterGlossaryId;
            obj5['starred'] = $scope.glossaryData.MasterGlossaries[k].IsStarred;
            obj[masterLangfield] = obj5;
            obj[uuid] = $scope.glossaryData.MasterGlossaries[k].MasterGlossaryId;
            $scope.masterText = $scope.glossaryData.MasterGlossaries[k].MasterText;
            $scope.masterText = $scope.masterText.replace(/ +/g, "");

            for (var m = 0; m < $scope.glossaryData.MasterGlossaries[k].ProjectLanguages.length; m++) {
                var str4 = $scope.glossaryData.MasterGlossaries[k].ProjectLanguages[m].LanguageName;
                str4 = str4.replace(/ +/g, "");
                var obj1 = {};

                obj1['lang'] = $scope.glossaryData.MasterGlossaries[k].ProjectLanguages[m].TranslatedTerm;
                obj1['TermStatus'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus;
                obj1['ProjectLanguageId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].ProjectLanguageId;
                obj1['MasterGlossaryId'] = $scope.glossaryData.MasterGlossaries[k].MasterGlossaryId;
                obj1['GlossaryTranslationId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].GlossaryTranslationId;
                obj1['edit'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].IsEditable;
                obj[str4] = obj1;
            }

            $scope.facdata.push(obj);
        }

        $('section.container').css('height', winHt);
        $('.wide-screen-wrapper .ngViewport').css('height', winHt - 230);
        $('.wide-screen-wrapper .gridStyle').css('height', winHt - 200);

    };

     /**
    * @ngdoc
    * @name sendForToken
    * @methodOf ViewGlossary.controller:ViewGlossaryController
    * @description
    * This function is used to send token on user's email.
    * @returns {undefined} This method does not return.
    */
    $scope.sendForToken = function () {
        $scope.viewloginCredFail = false;
        $http.get('../GetTokenToValidate/' + $scope.url + '/' + $scope.viewLogin.firstName + '/' + $scope.viewLogin.lastName)
            .success(function (tokenData) {
                if (tokenData === 'Success') {
                    $scope.viewloginCred = false;
                }
                else if (tokenData === 'Locked') {
                    $scope.glossaryLocked = true;
                }
                else {
                    $scope.viewloginCredFail = true;
                    $scope.viewloginCredFailMessage = tokenData;
                }
            }).error(function (e) {
                console.log("error..." + e);
            });;
    };

    /**
    * @ngdoc
    * @name verIfyToken
    * @methodOf ViewGlossary.controller:ViewGlossaryController
    * @description
    * This function is used to verify token.
    * @returns {undefined} This method does not return.
    */
    $scope.verIfyToken = function () {
        $scope.viewTokenCredFail = false;
        $http.get('../ValidateToken/' + $scope.url + '/' + $scope.viewLogin.token)

            .success(function (data) {
                if (data === 'Success') {
                    $('#viewLoginPopup').modal('hide');
                    $http.get('../GetProjectDetailsById/' + $scope.url)
                        .success(function (glossaryInitialTerms) {
                            $scope.GlossaryInitialTerms = glossaryInitialTerms;
                            $scope.IsLocked = glossaryInitialTerms.IsLocked;

                            for (var i = 0; i < $scope.GlossaryInitialTerms.GlossaryGroups.length; i++) {
                                if ($scope.GlossaryInitialTerms.GlossaryGroups[i].IsSecret == true) {
                                    $scope.GlossaryInitialTerms.GlossaryGroups.splice(i, 1);
                                    i--;
                                }
                            }

                            $scope.ExpirationTime = $scope.GlossaryInitialTerms.LinkExpiredDatetimeView;
                            $scope.headingsDropdown = $scope.GlossaryInitialTerms.GlossaryGroups[0];
                            $scope.sectionId = $scope.GlossaryInitialTerms.GlossaryGroups[0].Id;

                            //Glossary.getGlossaryData($scope.projectId, $scope.sectionId, commonService.getLocalData('userDetails').UserId, $scope.glossaryData);
                            $rootScope.headerId = $scope.sectionId;

                            $scope.ObjectId1 = [];
                            $scope.ClientName_str = '';
                            for (var i = 0; i < $scope.GlossaryInitialTerms.Clients.length; i++) {
                                $scope.ObjectId1.push($scope.GlossaryInitialTerms.Clients[i].ClientName);
                                $scope.ClientName_str = $scope.ClientName_str + $scope.GlossaryInitialTerms.Clients[i].ClientName + ', ';
                            }
                            $scope.ClientName_str = $scope.ClientName_str.slice(0, -2);

                            $http.get('../GetProjectGlossaryDetailsById/' + $scope.url + '/' + $scope.sectionId)

                                .success(function (glossaryData) {

                                    $scope.glossaryData = glossaryData;

                                    Catsequence = glossaryData.projectCategorySequence;

                                    $scope.showLoader = false;

                                    //dynamicScreenHeight();
                                    $('section.container').css('height', winHt);
                                    $('.wide-screen-wrapper .ngViewport').css('height', winHt - 230);
                                    $('.wide-screen-wrapper .gridStyle').css('height', winHt - 200);

                                    $scope.sectionHeader = $scope.glossaryData.HeaderText;
                                    GlossaryNgGrid(glossaryData, $scope.headingsDropdown);
                                    paginate();

                                })

                                .error(function (e) {
                                    console.log("error..." + e);
                                });

                        })

                        .error(function (e) {
                            console.log("error..." + e);
                        });


                    //watch for change in headerdropdown
                    $scope.$watch('headingsDropdown', function (new_value, old_value) {

                        if (old_value && new_value) {
                            $scope.showLoader = true;
                            $http.get('../GetProjectGlossaryDetailsById/' + $scope.url + '/' + new_value.Id)

                                .success(function (glossaryData) {

                                    $scope.glossaryData = glossaryData;

                                    $scope.showLoader = false;
                                    $scope.glossaryData = glossaryData;

                                    $rootScope.headerId = new_value.Id;
                                    $scope.headingsDropdown.Id = new_value.Id;

                                    $('section.container').css('height', winHt);
                                    $('.wide-screen-wrapper .ngViewport').css('height', winHt - 230);
                                    $('.wide-screen-wrapper .gridStyle').css('height', winHt - 200);

                                    $scope.sectionHeader = $scope.glossaryData.HeaderText;
                                    $scope.facdata = [];
                                    $scope.defdata = [];

                                    GlossaryNgGrid(glossaryData, new_value);

                                    $scope.pagingOptions.currentPage = 1;
                                    paginate();

                                })

                                .error(function (e) {

                                });

                        }
                    });
                }
                else if (data === 'Locked') {
                    $scope.glossaryLocked = true;
                }
                else if (data === 'This token is expired, Please generate another token.') {
                    $scope.tokenExpired = true;
                    $scope.viewTokenCredFail = true;
                    $scope.viewTokenCredFailMessage = data;
                }
                else {
                    $scope.viewTokenCredFail = true;
                    $scope.viewTokenCredFailMessage = data;
                }
            }).error(function (e) {
                console.log("error..." + e);
            });;
    };

    $scope.refresh = function () {
        location.reload();
    };

     /**
     * @ngdoc
     * @name init
     * @methodOf ViewGlossary.controller:ViewGlossaryController
     * 
     * @description
     * This function is used for initialisation of the variables on page load and check link expiration time.
     * @return {undefined} This method does not return.
     */
    var init = function () {
        $scope.showGlossaryPage = false;
        $scope.showSaveButton = false;
        $scope.url = location.pathname;
        $scope.url = $scope.url.replace("/ViewGlossary/Index/", "");
        $scope.url = $scope.url.replace("#/", "");

        $('.container-header, .navbar-default, .glossary-header-wrapper, footer').hide();
        $('section.container').css('height', winHt);
        $('.wide-screen-wrapper .ngViewport').css('height', winHt - 130);
        $('.wide-screen-wrapper .gridStyle').css('height', winHt - 100);
        $http.get('../CheckLinkExpiration/' + $scope.url)

            .success(function (tokenData) {
                if (tokenData === 'Success') {
                    $('#viewLoginPopup').modal('show');
                } else {
                    if (tokenData === 'Locked') {
                        $scope.linkExpMessage = "You Have exceeded your attempts to login this link. Hence this link is now locked.";
                    } else {
                        $scope.linkExpMessage = tokenData;
                    }

                    $('#viewGlossaryExpired').modal('show');
                }
            }).error(function (e) {
                console.log("error..." + e);
            });

    };
    init();
}]);
