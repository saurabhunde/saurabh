/**
 * @ngdoc service
 * @name DistributionList.DistributionListService
 * @requires AngularJS.$http
 * @requires common.commonService
 * 
 * @description
 * This is service in Users module. It contains methods which are used for different operations done on users page.
 *  
**/
gmDistributionListModule.service('DistributionListService', ['$http', 'commonService', function ($http, commonService) {

    var DISTRIBUTIONLISTSERVICE = {

         /**
        * @ngdoc function
        * @name DistributionList.DistributionListService#getDistributionList
        * @methodOf DistributionList.DistributionListService
        * @param {Number} userId This is current logged in user's id
        * @description
        * This service is used to get distribution lists to be displayed in the table
        * @returns {Object}  This method returns object with all DLs.
        */
        getDistributionList: function (userId, callback) {
            $http({
                method: 'get',
                url: 'DistributionList/GetDistributionList/' + userId
            })
                .success(function (distributionList) {
                    callback(distributionList);
                })
                .error(function (e) {
                    callback(e);
                });
        },

        /**
        * @ngdoc function
        * @name DistributionList.DistributionListService#retrieveUsersByClientsAndLanguages
        * @methodOf DistributionList.DistributionListService
        * @param {Object} DistributionListFilterData This is object of applied filters to get users
        * @description
        * This service is used to get users accoriding to applied filters.
        * @returns {Array}  This method returns list of users.
        */
        retrieveUsersByClientsAndLanguages: function (DistributionListFilterData, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: 'post',
                    url: 'DistributionList/RetrieveUsersByClientsAndLanguages/',
                    data: DistributionListFilterData,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (distributionUser) {
                        callback(distributionUser);
                    })
                    .error(function (e) {
                        callback(e);
                    });
            });
        },

        /**
        * @ngdoc function
        * @name DistributionList.DistributionListService#addDistributionList
        * @methodOf DistributionList.DistributionListService
        * @param {Object} DistributionListInfo This is object contains all the information about newly added DL
        * @description
        * This service is used to save new DL.
        * @returns {Array}  This method returns list of users.
        */
        addDistributionList: function (DistributionListInfo, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: 'post',
                    url: 'DistributionList/AddDistributionList/',
                    data: DistributionListInfo,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (success) {
                        callback(success);
                    })
                    .error(function (e) {
                        callback(e);
                    });
            });
        },

       /**
        * @ngdoc function
        * @name DistributionList.DistributionListService#getDLDetails
        * @methodOf DistributionList.DistributionListService
        * @param {Number} DistributionListId This is selected DLs id.
        * @param {Number} UserId This is logged in user's id
        * @description
        * This service is used to get DL information. This service is called on click of edit icon.This is uesed to show DL data on edit DL popup 
        * @returns {Object}  This method returns object which contains all the details of selected DL.
        */
        getDLDetails: function (DistributionListId, UserId, callback) {
            $http({
                method: 'get',
                url: 'DistributionList/GetDLDetails/' + DistributionListId + '/' + UserId
            })
                .success(function (status) {
                    callback(status);
                })
                .error(function (e) {
                    callback(e);
                });
        },

        /**
        * @ngdoc function
        * @name DistributionList.DistributionListService#editDistributionList
        * @methodOf DistributionList.DistributionListService
        * @param {Object} DistributionListInfo This is object contains all the information about DL which is to be edited
        * @description
        * This service is used to update existing DL.
        * @returns {Object}  This method returns object which contains all the details of selected DL.
        */
        editDistributionList: function (DistributionListInfo, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: 'post',
                    url: 'DistributionList/EditDistributionList/',
                    data: DistributionListInfo,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (success) {
                        callback(success);
                    })
                    .error(function (e) {
                        callback(e);
                    });
            });
        },

        /**
        * @ngdoc function
        * @name DistributionList.DistributionListService#changeDistributionListStatus
        * @methodOf DistributionList.DistributionListService
        * @param {Number} DistributionListId This is selected DLs id.
        * @param {Number} userId This is logged in user's id
        * @description
        * This service is used to update DL status
        * @returns {Object}  This method returns object which contains all the details of selected DL.
        */
        changeDistributionListStatus: function (userId, DistributionListId, callback) {
            $http({
                method: 'get',
                url: 'DistributionList/ChangeDistributionListStatus/' + userId + '/' + DistributionListId
            })
                .success(function (status) {
                    callback(status);
                })
                .error(function (e) {
                    callback(e);
                });
        }

    }

    return DISTRIBUTIONLISTSERVICE;

}]);