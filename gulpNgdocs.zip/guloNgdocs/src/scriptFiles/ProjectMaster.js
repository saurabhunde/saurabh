/**
 * @ngdoc service
 * @name Projects.ProjectMaster
 * @requires AngularJS.$http
 * @requires common.commonService
 * 
 * @description
 * This is service in projects module. It contains methods which are used for different operations done on project source setup page.
 *  
**/

gmProjectsModule.service('ProjectMaster', ['$http', 'commonService', function ($http, commonService) {

    var PROJECTMASTERSERVICE = {

    /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#getCategoriesAndHeaderList
    * @methodOf Projects.ProjectMaster
    * @description
    * This service to get the list of categories and headers.
    * @param {string} projectid This is the encrypted project id of selected project passed as parameter to this method.
    * @param {number} sectionType This is the selected section type.
    * @returns {object}  This method returns object with all sections and their details required on source setup page.
    */
        getCategoriesAndHeaderList: function (projectid, sectionType, callback) {
            $http({
                method: "get",
                url: "ProjectSourceSetup/GetProjectDetails/" + projectid + "/" + commonService.getLocalData('userDetails').UserId + "/" + sectionType
            })
            .success(function (projectmaster) {
                var timeData = {};
                timeData.UserId = commonService.getLocalData('userDetails').UserId;
                timeData.PageId = 4;
                timeData.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                timeData.SessionId = null;
                commonService.setTimeInSourceSetupCall(timeData, function () {
                    callback(projectmaster);
                });
            })
           .error(function (e) {
               callback(e);
           })
        },

     /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#changeRowSequence
    * @methodOf Projects.ProjectMaster
    * @description
    * This service for sending the changed sequence of rows.
    * @param {number} glossaryGroupId This is the selected sections ID
    * @param {number} masterGlossaryIdStr This is master glossary sequence used to change row sequence
    * @param {number} UserId This is current logged in user id
    * @param {number} OriginalUserId This is impersonated user id
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        changeRowSequence: function (glossaryGroupId, masterGlossaryIdStr, UserId, OriginalUserId, callback) {
            var SourceSetupSequence = {};
            SourceSetupSequence.glossaryGroupId = glossaryGroupId;
            SourceSetupSequence.masterGlossaryId = masterGlossaryIdStr;
            SourceSetupSequence.UserId = UserId;
            SourceSetupSequence.OriginalUserId = OriginalUserId;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/GlossarySequence",
                    data: SourceSetupSequence,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (status) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(status);
                    });
                })
               .error(function (e) {
                   callback(e);
               })
            });
        },

    /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#glossarySequenceForMoveTerm
    * @methodOf Projects.ProjectMaster
    * @description
    * Service for sending Master Glossary Id to changed header for sequencing of the changed header
    * @param {number} glossaryGroupId This is the selected sections ID
    * @param {number} masterGlossaryId This is master glossary ID
    * @param {string} projectId This is encrypted project id
    * @param {number} UserId This is current logged in user id
    * @param {number} OriginalUserId This is impersonated user id
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        glossarySequenceForMoveTerm: function (glossaryGroupId, masterGlossaryId, projectId, userId, originaluser, callback) {
            $http({
                method: "get",
                url: "ProjectSourceSetup/GlossarySequenceForMoveTerm/" + glossaryGroupId + "/" + masterGlossaryId + "/" + projectId + "/" + userId + "/" + originaluser
            })
            .success(function (status) {
                var data = {};
                data.UserId = commonService.getLocalData('userDetails').UserId;
                data.PageId = 4;
                data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                data.SessionId = null;
                commonService.setTimeInSourceSetupCall(data, function () {
                    callback(status);
                });
            })
           .error(function (e) {
               callback(e);
           })
        },

    /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#getProjectHeaderId
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to get the project header id
    * @param {string} projectId This is encrypted project id
    * @param {string} headerText This is section name
    * @param {boolean} IsSecret This is boolean value. if section is marked as secret then true else false.
    * @param {number} InsertedByUserId This is user id of current user.
    * @param {number} sectionType This is the selected section type.
    * @param {number} sectionSubType This is the selected section subtype(NTL/FD).
    * @param {number} originalUser This is impersonated user id
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        getProjectHeaderId: function (projectId, headerText, IsSecret, InsertedByUserId, sectionType, sectionSubType, originalUser, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/AddGlossaryGroupHeader",
                    data: {
                        ProjectId: projectId,
                        ProjectHeaderText: headerText,
                        IsSecret: IsSecret,
                        InsertedByUserId: InsertedByUserId,
                        SectionType: sectionType,
                        SectionSubType: sectionSubType,
                        OriginalUserId: originalUser
                    },
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (headerId) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(headerId);
                    });
                })
                .error(function (e) {
                    callback(e);
                })
            });
        },

    /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#updateGlossaryGroupHeader
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to update project header text
    * @param {string} projectId This is encrypted project id
    * @param {number} SectionId This is the selected section’s ID
    * @param {string} headerText This is section name
    * @param {boolean} IsSecret This is boolean value. if section is marked as secret then true else false.
    * @param {number} UpdatedByUserId This is user id of current user.
    * @param {number} sectionType This is the selected section type.
    * @param {number} originalUser This is impersonated user id
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        updateGlossaryGroupHeader: function (projectId, headerId, headerText, IsSecret, SectionId, UpdatedByUserId, sectionType, originalUser, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/UpdateGlossaryGroupHeader",
                    data: {
                        ProjectId: projectId,
                        DbProjectId: 0,
                        GlossaryGroupId: headerId,
                        ProjectHeaderText: headerText,
                        UpdatedByUserId: UpdatedByUserId,
                        IsSecret: IsSecret,
                        SectionId: SectionId,
                        SectionType: sectionType,
                        OriginalUserId: originalUser
                    },
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (headerId) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(headerId);
                    });
                })
                .error(function (e) {
                    callback(e);
                })
            });
        },

    /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#saveHeaderDataToDb
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to insert a new row from the existing table to the db
    * @param {string} projectId This is encrypted project id
    * @param {object} newAddedRowsList This is object contains all details about new row added
    * @returns {number} This method returns master glossary id.
    */
        saveHeaderDataToDb: function (projectId, newAddedRowsList, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/AddMasterGlossary",
                    data: {
                        ProjectId: projectId,
                        ProjectHeaders: newAddedRowsList
                    },
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
               .success(function (data) {
                   var timeData = {};
                   timeData.UserId = commonService.getLocalData('userDetails').UserId;
                   timeData.PageId = 4;
                   timeData.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                   timeData.SessionId = null;
                   commonService.setTimeInSourceSetupCall(timeData, function () {
                       callback(data);
                   });
               })
               .error(function (e) {
                   callback(e);
               })
            });
        },

     /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#insertRowToNewSection
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to insert a new row while adding new section to the db
    * @param {string} projectId This is encrypted project id
    * @param {object} newAddedRowsList This is object contains all details about new row added
    * @returns {number} This method returns master glossary id.
    */
        insertRowToNewSection: function (projectId, newAddedRowsList, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/AddMasterGlossaryForNewSection",
                    data: {
                        ProjectId: projectId,
                        ProjectHeaders: newAddedRowsList
                    },
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
               .success(function (data) {
                   var timeData = {};
                   timeData.UserId = commonService.getLocalData('userDetails').UserId;
                   timeData.PageId = 4;
                   timeData.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                   timeData.SessionId = null;
                   commonService.setTimeInSourceSetupCall(timeData, function () {
                       callback(data);
                   });
               })
               .error(function (e) {
                   callback(e);
               })
            });
        },

   /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#getSavedHeadersFromDb
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to get saved headers from the db
    * @param {string} projectId This is encrypted project id
    * @param {number} headerId This is the project header id 
    * @param {number} sectionType This is the selected section type.
    * @param {number} modeType This is the selected mode type(default/review mode).
    * @returns {object} This method returns headers from db.
    */
        getSavedHeadersFromDb: function (projectId, headerId, sectionType, modeType, callback) {
            $http({
                method: "get",
                url: "ProjectSourceSetup/GetMasterGlossary/" + projectId + "/" + headerId + "/" + commonService.getLocalData('userDetails').UserId + "/" + sectionType + "/" + modeType
            })
            .success(function (header) {
                var data = {};
                data.UserId = commonService.getLocalData('userDetails').UserId;
                data.PageId = 4;
                data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                data.SessionId = null;
                commonService.setTimeInSourceSetupCall(data, function () {
                    callback(header);
                });
            })
            .error(function (e) {
                callback(e);
            })
        },

  /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#deleteRecordsFromHeader
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to delete the saved records
    * @param {string} projectId This is encrypted project id
    * @param {object} deletedRowsList This is object contains all details about row to be deleted
    * @param {number} UserId This is current logged in user id
    * @param {number} OriginalUserId This is impersonated user id
    * @param {boolean} IsSectionComplete This is the section complete reminder flag
    * @param {boolean} IsSectionUnlock This is the section lock status flag
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        deleteRecordsFromHeader: function (projectId, deletedRowsList, UserId, OriginalUserId, IsSectionComplete, IsSectionUnlock, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/DeleteMasterGlossary",
                    data: {
                        ProjectId: projectId,
                        ProjectHeaders: deletedRowsList,
                        UserId: UserId,
                        OriginalUserId: OriginalUserId,
                        IsSectionComplete: IsSectionComplete,
                        IsSectionUnlock: IsSectionUnlock
                    },
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
               .success(function (data) {
                   var timeData = {};
                   timeData.UserId = commonService.getLocalData('userDetails').UserId;
                   timeData.PageId = 4;
                   timeData.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                   timeData.SessionId = null;
                   commonService.setTimeInSourceSetupCall(timeData, function () {
                       callback(data);
                   });
               })
               .error(function (e) {
                   callback(e);
               })
            });
        },

     /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#deleteSection
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to delete the sections
    * @param {string} glossaryGroupId This is the glossary group id
    * @param {number} UserId This is current logged in user id
    * @param {number} OriginalUserId This is impersonated user id
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    * 
    */
        deleteSection: function (glossaryGroupId, UserId, OriginalUserId, callback) {
            $http({
                method: "get",
                url: "ProjectSourceSetup/SectionDelete/" + glossaryGroupId + "/" + UserId + "/" + OriginalUserId
            })
            .success(function (status) {
                var data = {};
                data.UserId = commonService.getLocalData('userDetails').UserId;
                data.PageId = 4;
                data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                data.SessionId = null;
                commonService.setTimeInSourceSetupCall(data, function () {
                    callback(status);
                });
            })
           .error(function (e) {
               callback(e);
           })
        },

     /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#updateHeaderRecords
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to update the existing records
    * @param {string} projectId This is encrypted project id
    * @param {object} updatedRowsList This is object contains all details about row to be updated
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        updateHeaderRecords: function (projectId, updatedRowsList, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/UpdateMasterGlossary",
                    data: {
                        ProjectId: projectId,
                        ProjectHeaders: updatedRowsList
                    },
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
              .success(function (data) {
                  var timeData = {};
                  timeData.UserId = commonService.getLocalData('userDetails').UserId;
                  timeData.PageId = 4;
                  timeData.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                  timeData.SessionId = null;
                  commonService.setTimeInSourceSetupCall(timeData, function () {
                      callback(data);
                  });
              })
              .error(function (e) {
                  callback(e);
              })
            });
        },

   /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#getSectionsBrandsList
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to get the list of sections and brands
    * @param {string} projectId This is encrypted project id
    * @param {number} sectionType This is the selected section type.
    * @returns {object} This method returns sections and brand list
    */
        getSectionsBrandsList: function (projectid, sectionType, callback) {

            $http({
                method: "get",
                url: "ProjectSourceSetup/GetProjectSectionsBrands/" + projectid + '/' + sectionType
            })
            .success(function (sectionsBrandsList) {
                var data = {};
                data.UserId = commonService.getLocalData('userDetails').UserId;
                data.PageId = 4;
                data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                data.SessionId = null;
                commonService.setTimeInSourceSetupCall(data, function () {
                    callback(sectionsBrandsList);
                });
            })
           .error(function (e) {
               callback(e);
           })
        },

    /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#saveSectionsBrandsList
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to save the project brands with sections selected
    * @param {string} projectId This is encrypted project id
    * @param {object} sectionBrandsToBeSaved This is the selected brands to be saved.
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        saveSectionsBrandsList: function (projectId, sectionBrandsToBeSaved, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/SaveProjectSectionsBrands",
                    data: sectionBrandsToBeSaved,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (status) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(status);
                    });
                })
                .error(function (e) {
                    callback(e);
                })
            });

        },

    /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#moveTermToOtherSection
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to get the list of categories and headers
    * @param {string} glossaryGroupId This is the glossary group id
    * @param {number} masterGlossaryId This is master glossary ID
    * @param {number} UserId This is current logged in user id
    * @param {number} OriginalUserId This is impersonated user id
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    * 
    */
        moveTermToOtherSection: function (glossaryGroupId, masterGlossaryId, userId, OriginalUserId, callback) {
            $http({
                method: "get",
                url: "ProjectSourceSetup/SectionModificationForMasterTerm/" + glossaryGroupId + '/' + masterGlossaryId + '/' + userId + '/' + OriginalUserId
            })
            .success(function (status) {
                var data = {};
                data.UserId = commonService.getLocalData('userDetails').UserId;
                data.PageId = 4;
                data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                data.SessionId = null;
                data.OriginalUserId = OriginalUserId;
                commonService.setTimeInSourceSetupCall(data, function () {
                    callback(status);
                });
            })
           .error(function (e) {
               callback(e);
           })
        },

   /**
    * @ngdoc function
    * @name Projects.ProjectMaster#saveSectionsCategoryList
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to save the project Categories with sections selected
    * @param {string} projectId This is encrypted project id
    * @param {array} SelectedSectionIds This is array of selected section's ids
    * @param {array} CategoryAddedIds This is array of categories added
    * @param {array} CategoryRemovedIds This is array of categories removed
    * @param {number} UserId This is current logged in user id
    * @param {number} OriginalUserId This is impersonated user id
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    * 
    */
        saveSectionsCategoryList: function (projectId, SelectedSectionIds, CategoryAddedIds, CategoryRemovedIds, UserId, originaluser, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/SaveProjectSectionsCategories",
                    data: {
                        projectId: projectId,
                        SelectedSectionIds: SelectedSectionIds,
                        CategoryAddedIds: CategoryAddedIds,
                        CategoryRemovedIds: CategoryRemovedIds,
                        UserId: UserId,
                        OriginalUserId: originaluser
                    },
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (status) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(status);
                    });
                })
                .error(function (e) {
                    callback(e);
                })
            });
        },

   /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#uploadScriptDB
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to upload script to Section
    * @param {object} uploadFile This is objects contains attached files, userid and projectid properties.
    * @returns {boolean}  This method returns true/false status. true if successful upload else false.
    */
        uploadScriptDB: function (uploadFile, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/ImportDocFileData",
                    data: uploadFile,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (status) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(status);
                    });
                })
                .error(function (e) {
                    callback(e);
                })
            });
        },

    /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#commitScriptDB
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to commit script to db
    * @param {object} uploadFile This is objects contains attached files, userid and projectid properties.
    * @returns {boolean}  This method returns true/false status. true if successful upload else false.
    */
        commitScriptDB: function (uploadFile, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/CommitImportDocFileData",
                    data: uploadFile,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (status) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(status);
                    });
                })
                .error(function (e) {
                    callback(e)
                })
            });
        },

    /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#commitScriptDBNTL
    * @methodOf Projects.ProjectMaster
    * @description
    * Upload script to NTL Section Validation for duplicate terms GLMGR-758
    * @param {object} uploadFile This is objects contains attached files, userid and projectid properties.
    * @returns {boolean}  This method returns true/false status. true if successful upload else false.
    */
        commitScriptDBNTL: function (uploadFile, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/CommitImportDocFileDataValidateDuplicateNTL",
                    data: uploadFile,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (status) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(status);
                    });
                })
                .error(function (e) {
                    callback(e)
                })
            });
        },

    /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#getBulkSectionData
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to get initial Bulk section
    * @param {string} projectId This is encrypted project id
    * @param {number} UserId This is current logged in user id
    * @param {number} sectionType This is the selected section type.
    * @returns {object} This method returns sections data
    */
        getBulkSectionData: function (projectid, UserId, sectionType, goodCallback, badCallback) {

            $http({
                method: "get",
                url: "ProjectSourceSetup/GetBulkSectionDetails/" + projectid + '/' + UserId + '/' + sectionType
            })
            .success(function (backData) {

                var timeData = {};
                timeData.UserId = commonService.getLocalData('userDetails').UserId;
                timeData.PageId = 4;
                timeData.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                timeData.SessionId = null;
                commonService.setTimeInSourceSetupCall(timeData, function () {
                    goodCallback(backData);
                });
            })
           .error(function (e) {
               badCallback(e);

           })
        },

     /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#saveEditedBulkSection
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to get initial Bulk section
    * @param {object} editdata This is updated sections data
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        saveEditedBulkSection: function (editdata, goodCallback, badCallback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/EditSection",
                    data: editdata,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (backData) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        goodCallback(backData);
                    });
                })
                .error(function (e) {
                    badCallback(e);
                })
            });
        },

    /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#saveNewBulkSection
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to save new bulk section
    * @param {object} newSecdata This is new sections data
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        saveNewBulkSection: function (newSecdata, goodCallback, badCallback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/AddLocalSection",
                    data: newSecdata,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (backData) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        goodCallback(backData);
                    });
                })
                .error(function (e) {
                    badCallback(e);
                })
            });
        },

    /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#delBulkSection
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to delete bulk section
    * @param {object} delSecdata This is deleted sections data
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        delBulkSection: function (delSecdata, goodCallback, badCallback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/DeleteLocalSection",
                    data: delSecdata,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (backData) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        goodCallback(backData);
                    });
                })
                .error(function (e) {
                    badCallback(e);
                })
            });
        },

     /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#saveEntireSections
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to save bulk sections
    * @param {object} sectionList List of sections to be saved
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        saveEntireSections: function (sectionList, goodCallback, badCallback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/SaveBulkSection",
                    data: sectionList,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (backData) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        goodCallback(backData);
                    });

                })
                .error(function (e) {
                    badCallback(e);
                })
            });
        },

        
     /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#CheckSectionCategories
    * @methodOf Projects.ProjectMaster
    * @description
    * service to compare the categories in Origin(Source) Section and Destination(Target) Section
    * @param {number} OriginSectionId Current section id while moving term to other section
    * @param {number} TargetSectionId Target section id while moving term to other section
    * @param {number} masterGlossaryId This is master glossary ID
    * @param {string} ProjectId This is encrypted project id
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        CheckSectionCategories: function (OriginSectionId, TargetSectionId, masterGlossaryId, ProjectId, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/CheckSectionCategories",
                    data: {
                        SourceSectionId: OriginSectionId,
                        DestinationSectionId: TargetSectionId,
                        MasterGlossaryId: masterGlossaryId,
                        ProjectId: ProjectId
                    },
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (status) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(status);
                    });
                })
                .error(function (e) {
                    callback(e);
                })
            });
        },

     /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#DeleteTermImage
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to Delete Term Image
    * @param {string} ProjectId This is encrypted project id
    * @param {array} deletedImageList Array of images data to be deleted.
    * @param {number} UserId This is current logged in user id
    * @param {number} OriginalUserId This is impersonated user id
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        DeleteTermImage: function (projectId, deletedImageList, UserId, OriginalUserId, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/DeleteTermImage",
                    data: {
                        ProjectId: projectId,
                        ProjectHeaders: deletedImageList,
                        UserId: UserId,
                        OriginalUserId: OriginalUserId
                    },
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (status) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(status);
                    });
                })
                .error(function (e) {
                    callback(e);
                })
            });
        },

        
     /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#CheckStarredTerm
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to check duplicate masterTerm, That is starred term
    * @param {object} AutoSaveMasterTermModel Object which contains master term data eg. MasterText,MasterGlossaryId
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        CheckStarredTerm: function (AutoSaveMasterTermModel, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/CheckStarredTerm",
                    data: AutoSaveMasterTermModel,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (autoSaveResult) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(autoSaveResult);
                    });
                })
                .error(function (e) {
                    callback(e);
                })
            });
        },

     /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#ChangeStarredState
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to check star/unstar status
    * @param {object} ChangeStarredStatusModel Object which contains master term data eg. GlossaryAddedBrands,IsStarred
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        ChangeStarredState: function (ChangeStarredStatusModel, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/ChangeStarredState",
                    data: ChangeStarredStatusModel,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (autoSaveResult) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(autoSaveResult);
                    });
                })
                .error(function (e) {
                    callback(e);
                })
            });
        },

    /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#GetStarredTermInfo
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to get details about starred term
    * @param {number} MasterGlossaryId This is master glossary ID
    * @param {number} UserId This is current logged in user id
    * @param {string} Role This is current logged in user role
    * @param {array} BrandIdList This is list of assigned brands.
    * @returns {object} This method returns object which contains details about starred term 
    */
        GetStarredTermInfo: function (MasterGlossaryId, UserId, Role, BrandIdList, callback) {

            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/GetStarredTermInfo",
                    data: {
                        MasterGlossaryId: MasterGlossaryId,
                        UserId: UserId,
                        Role: Role,
                        BrandIds: BrandIdList
                    },
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (starredTermInfo) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(starredTermInfo);
                    });
                })
                .error(function (e) {
                    callback(e);
                })
            });
        },

   /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#GetStarredTermInfo
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to get details about starred term
    * @param {object} AutoSaveMasterTermModel Object which contains master term data eg. MasterText,MasterGlossaryId
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        autoSaveMasterTerm: function (AutoSaveMasterTermModel, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/AutoSaveMasterTerm",
                    data: AutoSaveMasterTermModel,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (autoSaveResult) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(autoSaveResult);
                    });
                })
                .error(function (e) {
                    callback(e);
                })
            });
        },

   /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#GetStarredTermInfo
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to auto Save for MasterTerm NTL
    * @param {object} AutoSaveMasterTermModel Object which contains master term data eg. MasterText,MasterGlossaryId
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */  
        autoSaveMasterTermNTL: function (AutoSaveMasterTermModel, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/AutoSaveMasterTermValidateNTL",
                    data: AutoSaveMasterTermModel,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (autoSaveResult) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(autoSaveResult);
                    });
                })
                .error(function (e) {
                    callback(e);
                })
            });
        },

   /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#autoSaveCategoryInfo
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to save the category information on lost focus of category text area
    * @param {object} MasterGlossaryCategoryModel Object which contains master term data eg. ProjectCategoryData,MasterGlossaryId
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        autoSaveCategoryInfo: function (MasterGlossaryCategoryModel, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/AssignCategoriesToMasterTerm",
                    data: MasterGlossaryCategoryModel,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (autoSaveResult) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(autoSaveResult);
                    });
                })
                .error(function (e) {
                    callback(e);
                })
            });
        },

    /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#autoSaveGlossaryBrands
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to auto save glossary brands
    * @param {object} MasterGlossaryBrandsModel Object which contains master term data eg. GlossaryAddedBrands,GlossaryRemovedBrands
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        autoSaveGlossaryBrands: function (MasterGlossaryBrandsModel, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/ApplyBrandsToMasterTerm",
                    data: MasterGlossaryBrandsModel,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (autoSaveResult) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(autoSaveResult);
                    });
                })
                .error(function (e) {
                    callback(e);
                })
            });
        },

     /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#autoSaveRowSequence
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to auto Save when row sequence is changed
    * @param {object} SourceSetupSequence Object which contains row sequence data eg. GlossaryGroupId,MasterGlossaryId
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        autoSaveRowSequence: function (SourceSetupSequence, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/GlossarySequence",
                    data: SourceSetupSequence,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (autoSaveResult) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(autoSaveResult);
                    });
                })
                .error(function (e) {
                    callback(e);
                })
            });
        },

   /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#autoSaveTermImage
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to auto Save Term Image
    * @param {object} ImageUploadMasterTermModel Object which contains image file data eg. FileName,Filesize
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        autoSaveTermImage: function (ImageUploadMasterTermModel, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/AutoSaveTermImage",
                    data: ImageUploadMasterTermModel,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (autoSaveResult) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(autoSaveResult);
                    });
                })
                .error(function (e) {
                    callback(e);
                })
            });
        },

    /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#getPreviewTermImage
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to Preview Term Image
    * @param {string} ProjectId This is encrypted project id
    * @param {number} masterGlossaryId This is master glossary ID
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        getPreviewTermImage: function (projectId, masterGlossaryId, callback) {
            $http({
                method: "get",
                url: "ProjectSourceSetup/PreviewTermImage/" + projectId + '/' + masterGlossaryId
            })
            .success(function (backData) {
                callback(backData);
            })
           .error(function (e) {
               callback(e);
           })
        },

    /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#ConvertDefaultSectionToNTLSection
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to Migrate Default Section to NTL
    * @param {array} SectionViewModel Array which contains headers to migrate
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        ConvertDefaultSectionToNTLSection: function (SectionViewModel, projectId, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/ConvertDefaultSectionToNTLSection",
                    data: {
                        SelectedSections: SectionViewModel,
                        ProjectId: projectId,
                    },
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (autoSaveResult) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(autoSaveResult);
                    });
                })
               .error(function (e) {
                   callback(e);
               })
            });
        },

  /**
    * @ngdoc function
    * @name Projects.ProjectMaster#sectionComplete
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to mark section complete
    * @param {string} projectId This is encrypted project id
    * @param {string} glossaryGroupId This is the glossary group id
    * @param {number} UserId This is current logged in user id
    * @param {number} OriginalUserId This is impersonated user id
    * @param {boolean} IsSectionComplete This is the section complete reminder flag
    * @param {boolean} IsSectionUnlock This is the section lock status flag
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        sectionComplete: function (GlossaryGroupId, ProjectId, UserId, OriginalUserId, IsSectionComplete, IsSectionUnlock, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/CompleteSection",
                    data: {
                        GlossaryGroupId: GlossaryGroupId,
                        ProjectId: ProjectId,
                        UserId: UserId,
                        OriginalUserId: OriginalUserId,
                        IsSectionComplete: IsSectionComplete,
                        IsSectionUnlock: IsSectionUnlock
                    },
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (autoSaveResult) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(autoSaveResult);
                    });
                })
               .error(function (e) {
                   callback(e);
               })
            });
        },

    /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#getTermSuggestions
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to get suggestions on term.
    * @param {string} ProjectId This is encrypted project id
    * @param {string} glossaryGroupId This is the glossary group id
    * @param {number} masterGlossaryId This is master glossary ID
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        getTermSuggestions: function (projectId, masterGlossaryId, glossaryGroupId, callback) {
            $http({
                method: "get",
                url: "ProjectSourceSetup/SuggestionHistory/" + projectId + '/' + masterGlossaryId + '/' + glossaryGroupId + '/' + commonService.getLocalData('userDetails').UserId
            })
            .success(function (backData) {
                callback(backData);
            })
           .error(function (e) {
               callback(e);
           })
        },


    /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#suggestedTextAutoSave
    * @methodOf Projects.ProjectMaster
    * @description
    * Service for sending the changed sequence of rows
    * @param {number} masterGlossaryId This is master glossary ID
    * @param {string} suggestedText This is suggestion on term
    * @param {string} comment This is comment on suggestion
    * @param {number} OriginalUserId This is impersonated user id
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        suggestedTextAutoSave: function (masterGlossaryId, suggestedText, comment, OriginalUserId, callback) {
            var reviewDataAutoSave = {};
            reviewDataAutoSave.MasterGlossaryId = masterGlossaryId;
            reviewDataAutoSave.TextFlag = "FromSuggested";
            reviewDataAutoSave.SuggestedText = suggestedText;
            reviewDataAutoSave.Comment = comment;
            reviewDataAutoSave.UserId = commonService.getLocalData('userDetails').UserId;
            reviewDataAutoSave.OriginalUserId = OriginalUserId;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/AutoSaveSuggestionTextInReviewMode",
                    data: reviewDataAutoSave,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (status) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(status);
                    });
                })
               .error(function (e) {
                   callback(e);
               })
            });
        },

     /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#commentTextAutoSave
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to auto save comments
    * @param {number} masterGlossaryId This is master glossary ID
    * @param {string} suggestedText This is suggestion on term
    * @param {string} comment This is comment on suggestion
    * @param {number} OriginalUserId This is impersonated user id
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        commentTextAutoSave: function (masterGlossaryId, suggestedText, comment, OriginalUserId, callback) {
            var reviewDataAutoSave = {};
            reviewDataAutoSave.MasterGlossaryId = masterGlossaryId;
            reviewDataAutoSave.TextFlag = "FromComment";
            reviewDataAutoSave.SuggestedText = suggestedText;
            reviewDataAutoSave.Comment = comment;
            reviewDataAutoSave.UserId = commonService.getLocalData('userDetails').UserId;
            reviewDataAutoSave.OriginalUserId = OriginalUserId
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/AutoSaveSuggestionTextInReviewMode",
                    data: reviewDataAutoSave,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (status) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(status);
                    });
                })
               .error(function (e) {
                   callback(e);
               })
            });
        },

        
     /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#reviewModeDelete
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to delete term in review mode
    * @param {number} masterGlossaryId This is master glossary ID
    * @param {number} OriginalUserId This is impersonated user id
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        reviewModeDelete: function (masterGlossaryId, OriginalUserId, callback) {
            var reviewDataAutoSave = {};
            reviewDataAutoSave.MasterGlossaryId = masterGlossaryId;
            reviewDataAutoSave.UserId = commonService.getLocalData('userDetails').UserId;
            reviewDataAutoSave.OriginalUserId = OriginalUserId;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/DeleteMasterGlossaryInReviewMode",
                    data: reviewDataAutoSave,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (status) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(status);
                    });
                })
               .error(function (e) {
                   callback(e);
               })
            });
        },

    /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#reviewModeRestore
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to retore deleted term
    * @param {number} masterGlossaryId This is master glossary ID
    * @param {number} OriginalUserId This is impersonated user id
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        reviewModeRestore: function (masterGlossaryId, OriginalUserId, callback) {
            var AutoSaveSuggestionTextInReviewMode = {};
            AutoSaveSuggestionTextInReviewMode.MasterGlossaryId = masterGlossaryId;
            AutoSaveSuggestionTextInReviewMode.UserId = commonService.getLocalData('userDetails').UserId;
            AutoSaveSuggestionTextInReviewMode.OriginalUserId = OriginalUserId;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/RestoreSuggestionInReviewMode",
                    data: AutoSaveSuggestionTextInReviewMode,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (status) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(status);
                    });
                })
               .error(function (e) {
                   callback(e);
               })
            });
        },

   /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#applyTermSuggestions
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to apply/aaprove/reject individual term suggestion.
    * @param {object} appliedSuggestion Object which contains applied suggestions data eg. IsAccepted,SuggestionType
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        applyTermSuggestions: function (appliedSuggestion, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/ApplySuggestion",
                    data: appliedSuggestion,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (status) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(status);
                    });
                })
               .error(function (e) {
                   callback(e);
               })
            });
        },

  /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#applyBulkSuggestions
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to apply/aaprove/reject bulk term suggestions.
    * @param {object} ApplySuggestionHistoryForBulkModel Object which contains applied bulk suggestions data eg. ApplySuggestionPerMasterGlossary,GlossaryGroupId
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        applyBulkSuggestions: function (ApplySuggestionHistoryForBulkModel, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/ApplySuggestionsForBulk",
                    data: ApplySuggestionHistoryForBulkModel,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (status) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(status);
                    });
                })
               .error(function (e) {
                   callback(e);
               })
            });
        },

     /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#removeSuggestions
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to remove suggestions
    * @param {number} masterId This is master glossary ID
    * @param {number} OriginalUserId This is impersonated user id
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        removeSuggestions: function (masterId, OriginalUserId, callback) {
            var forgerytoken;
            var data = {};
            data.UserId = commonService.getLocalData('userDetails').UserId;
            data.MasterGlossaryId = masterId;
            data.OriginalUserId = OriginalUserId;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/RemoveSuggestion",
                    data: data,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (status) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(status);
                    });
                })
               .error(function (e) {
                   callback(e);
               })
            });
        },

    /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#getWatcherListData
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to get watcher list
    * @param {string} ProjectId This is encrypted project id
    * @param {string} glossaryGroupId This is the glossary group id
    * @param {array} ClientIds This is array of ids of project clients
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        getWatcherListData: function (projectId, groupId, ClientIds, callback) {
            var forgerytoken;
            var data = {};
            data.UserId = commonService.getLocalData('userDetails').UserId;
            data.ProjectId = projectId;
            data.GlossaryGroupId = groupId;
            data.ClientIds = ClientIds;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/GetWatchers",
                    data: data,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (status) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(status);
                    });
                })
               .error(function (e) {
                   callback(e);
               })
            });
        },

    /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#setWatchers
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to set watcher list
    * @param {object} data Object which contains watchers data eg. WachersUserId array ,ProjectId
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        setWatchers: function (data, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/SetWatchers",
                    data: data,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (status) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(status);
                    });
                })
               .error(function (e) {
                   callback(e);
               })
            });
        },

    /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#submitTermSuggestions
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to apply/aaprove/reject individual term suggestion.
    * @param {object} appliedSuggestion Object which contains applied suggestions data eg. IsAccepted,SuggestionType
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        submitTermSuggestions: function (appliedSuggestion, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/BulkSaveMasterTermInReview",
                    data: appliedSuggestion,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (status) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(status);
                    });
                })
               .error(function (e) {
                   callback(e);
               })
            });
        },

    /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#getDistibutionListUsers
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to get Distibution List Users
    * @param {number} distributionListId this is distribution list id.
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        getDistibutionListUsers: function (distributionListId, callback) {
            $http({
                method: "get",
                url: "ProjectSourceSetup/GetDistibutionListUsers/" + distributionListId
            })
            .success(function (backData) {
                callback(backData);
            })
           .error(function (e) {
               callback(e);
           })
        },

    /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#getAssignedDistibutionListUsers
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to get Distibution List assigned Users
    * @param {number} distributionListId this is distribution list id.
    * @param {string} glossaryGroupId This is the glossary group id
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        getAssignedDistibutionListUsers: function (distributionListId, glossaryGroupId, callback) {
            $http({
                method: "get",
                url: "ProjectSourceSetup/GetAssignedDistibutionListUsers/" + distributionListId + "/" + glossaryGroupId
            })
            .success(function (backData) {
                callback(backData);
            })
           .error(function (e) {
               callback(e);
           })
        },

        //Service to unlock a section
   /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#unlockSection
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to unlock a section
    * @param {string} glossaryGroupId This is the glossary group id
    * @param {number} UserId This is current logged in user id
    * @param {number} OriginalUserId This is impersonated user id
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        unlockSection: function (glossaryGroupId, userId, originalUserId, callback) {
            $http({
                method: "get",
                url: "ProjectSourceSetup/UnlockSection/" + glossaryGroupId + "/" + userId + "/" + originalUserId,
            })
            .success(function (backData) {
                callback(backData);
            })
           .error(function (e) {
               callback(e);
           })
        },

    /**
    * 
    * @ngdoc function
    * @name Projects.ProjectMaster#checkSectionStatus
    * @methodOf Projects.ProjectMaster
    * @description
    * Service to check current section status
    * @param {object} objSectionStatus this is object contains status data (complete/incomplete and lock/unlocked )
    * @returns {boolean} This method returns true/false. If process successful the true, else false.
    */
        checkSectionStatus: function (objSectionStatus, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectSourceSetup/CheckSectionStatus",
                    data: objSectionStatus,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .success(function (status) {
                    var data = {};
                    data.UserId = commonService.getLocalData('userDetails').UserId;
                    data.PageId = 4;
                    data.ResourceId = commonService.getSessionData('projectIBreadCrumb');
                    data.SessionId = null;
                    commonService.setTimeInSourceSetupCall(data, function () {
                        callback(status);
                    });
                })
               .error(function (e) {
                   callback(e);
               })
            });
        },
    }
    return PROJECTMASTERSERVICE;

}]);