/**
 * @ngdoc controller
 * @name Help.controller:HelpController
 * @element div
 *
 * @description
 * This Controller is responsible for download the user guides from help page.
 *
 * @requires AngularJS.$scope
 * @requires AngularJS.$http
 * @requires AngularJS.$location
 * @requires common.commonService
 * 
 * @property {object} userDetails:Object This is object stores the userdeatails received from backend when user is logged in 
 * 
 */
Help.controller('helpController', ['$scope', '$http', '$location', 'commonService', function ($scope, $http, $location, commonService) {
    
    var userDetails = {};
    //set hashURL for GLMGR-1189
    sessionStorage.setItem('hashURL', null);
    
    /**
     * @ngdoc
     * @name getUserGuides
     * @methodOf Help.controller:HelpController
     * @description
     * This function is used to get user guide details eg. path of file.
     * @returns {Undefined} This method does not return.
     */
    $scope.getUserGuides = function () {
        commonService.getUserGuide(function (userGuides) {
            $scope.userGuides = userGuides;
        });
    };

    /**
     * @ngdoc
     * @name init
     * @methodOf Help.controller:HelpController
     * @description
     * This function is called initially when page is loaded. This function is used for initialisation of the variables on page load.
     * @returns {undefined} This method does not return.
     */
    var init = function () {
        dynamicScreenHeight();
        var resorceIdx = 0;
        sessionStorage.setItem('resourcePageId', JSON.stringify(resorceIdx));
        var userDetails = commonService.getLocalData('userDetails');
        $scope.getUserGuides();
        $scope.UserRoleName = userDetails.UserRoles[0].UserRoleName;
    };

    init();

}]);