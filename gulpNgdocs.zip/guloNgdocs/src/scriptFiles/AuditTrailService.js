/**
 * @ngdoc service
 * @name AuditTrail.AuditTrailService
 * @requires AngularJS.$http
 * @requires common.commonService
 * @requires Projects.saveBlob
 * 
 * @description
 * This is service in Audit trail module. It contains methods which are used for different operations done on audit trail page.
 *  
**/
gmAuditTrailModule.service('AuditTrailService', ['$http', 'saveBlob', 'commonService', function ($http, saveBlob, commonService) {

    var AuditTrailPageService = {

        /**
        * @ngdoc function
        * @name AuditTrail.AuditTrailService#getFilterDataForAudit
        * @methodOf AuditTrail.AuditTrailService
        * @description
        * This service is used to get user list details to be displayed in the Table
        * @returns {Object}  This method returns user list details
        */
        getFilterDataForAudit: function (callback) {
            var userDetails = commonService.getLocalData('userDetails');

            $http.get('AuditTrail/PrePopulateDropDowns')
                .success(function (filterData) {
                    callback(filterData);
                })

                .error(function (e) { });
        },

        /**
        * @ngdoc function
        * @name AuditTrail.AuditTrailService#getClientSpecificProjects
        * @methodOf AuditTrail.AuditTrailService
        * @param {Array} clienIdList This is id of selected client in filter.
        * @param {Number} userId This is user id of logged in user.
        * @param {String} userRoleName This is user role of logged in user.
        * @description
        * This service is used to get the Audit Info on the basis of the filters
        * @returns {Array}  This method returns list of projects
        */
        getClientSpecificProjects: function (clienIdList, userId, userRoleName, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "Users/ClientProjectString",
                    data: {
                        ClientIdList: clienIdList,
                        userId: userId,
                        userRoleName: userRoleName
                    },
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (projectList) {
                        callback(projectList);
                    })
                    .error(function (e) { })
            });

        },

         /**
        * @ngdoc function
        * @name AuditTrail.AuditTrailService#getAuditInfo
        * @methodOf AuditTrail.AuditTrailService
        * @param {Object} FilterCriteriaForLogs This is object contains all the applied filter details
        * @description
        * This service is used to get the Audit Info on the basis of the filters
        * @returns {Array}  This method returns array of audit information
        */
        getAuditInfo: function (FilterCriteriaForLogs, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "AuditTrail/DisplayFilterResult",
                    data: FilterCriteriaForLogs,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (auditInfo) {
                        callback(auditInfo);
                    })
                    .error(function (e) { })
            });

        },

        /**
        * @ngdoc function
        * @name AuditTrail.AuditTrailService#exportAuditInfo
        * @methodOf AuditTrail.AuditTrailService
        * @param {Object} XExportLogDisplayResult This is object contains projectid,password
        * @description
        * This service is used to get the exported excel sheet data.
        * @returns {Array}  This method returns array of audit information
        */
        exportAuditInfo: function (XExportLogDisplayResult, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "AuditTrail/ExportToExcelForAuditLog",
                    data: XExportLogDisplayResult,
                    responseType: 'blob',
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (XExportLogDisplayResult, status, headers, config) {
                        if (JSON.parse(sessionStorage.getItem('resourcePageId')) === 2 || JSON.parse(sessionStorage.getItem('resourcePageId')) === 3) {
                            var updateUserLockData = {};
                            updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                            updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                            updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                            commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                                saveBlob.save(XExportLogDisplayResult, 'AuditLogExportFile.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8');
                                callback(true);
                            });
                        }
                        else {
                            saveBlob.save(XExportLogDisplayResult, 'AuditLogExportFile.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8');
                            callback(true);
                        }
                    })
                    .error(function (data, status, headers, config) { })
            });

        }
    }
    return AuditTrailPageService;
}])