/**
 * @ngdoc object
 * @name Translators
 * @element html
 * 
 * @requires AngularJS.$routeProvider
 * @requires AngularJS.$locationProvider
 * @requires AngularJS.$httpProvider
 * @requires AngularJS.ngRoute
 * @requires common
 * 
 * @description
 * This is Translators module, which contains TranslatorsController for translators menu to show all translator users in the application. 
 *
 */
var Translators = angular.module('translators', ['ngRoute', 'common', 'gmTranslatorModule', 'angularUtils.directives.dirPagination'])

Translators.config(['$routeProvider', '$locationProvider', '$httpProvider', function ($routeProvider, $locationProvider, $httpProvider) {
    $httpProvider.interceptors.push('myInterceptor');
   $routeProvider
    .when('/', {
        templateUrl: "/TranslatorsController/Content/ngviews/TranslatorList.html",
        controller: "translatorsController"
    })

}]);

Translators.factory('myInterceptor', function () {
    var requestInterceptor = {
        request: function (config) {
            localStorage.setItem('time', new Date());
            return config;
        }
    };

    return requestInterceptor;
});