/**
 * @ngdoc service
 * @name Projects.Glossary
 * @requires AngularJS.$http
 * @requires common.commonService
 * @requires Projects.saveBlob
 * 
 * @description
 * This is service in projects module. It contains methods which are used for different operations done on project glossary pages.
 *  
**/
Projects.service('Glossary', ['$http', '$location', 'saveBlob', 'commonService', function ($http, $location, saveBlob, commonService) {
    var updateUserLockData = {};
    var GlossaryData = {

        /**
        * @ngdoc function
        * @name Projects.Glossary#getGlossaryInitialData
        * @methodOf Projects.Glossary
        * @description
        * This service is to get intial glossary data on page load. 
        * @param {String} projectId This is the encrypted project id of selected project passed as parameter to this method.
        * @param {Number} userid This is the userid of current logged in user.
        * @param {Number} sectionType This is the section type. for default section sectionType is 1 for NTL/FD 2
        * @returns {object}  This method returns object with all glossary data to be shown on glossary grids(Tables).
        */
        getGlossaryInitialData: function (projectId, userid, sectionType, callback) {
            $http.get('ProjectGlossary/GetProjectInfoById/' + projectId + '/' + userid + '/' + sectionType)

                .success(function (glossaryInitialTerms) {
                    callback(glossaryInitialTerms);
                })

                .error(function (e) {
                    callback("error");
                });
        },

        /**
        * @ngdoc function
        * @name Projects.Glossary#getApprovalGlossaryInitialData
        * @methodOf Projects.Glossary
        * @description
        * This service is to get intial glossary data on page load on approval gloosary page. 
        * @param {String} projectId This is the encrypted project id of selected project passed as parameter to this method.
        * @param {Number} userid This is the userid of current logged in user.
        * @param {Number} sectionType This is the section type. for default section sectionType is 1 for NTL/FD 2
        * @returns {object}  This method returns object with all glossary data to be shown on glossary grids(Tables).
        */
        getApprovalGlossaryInitialData: function (projectId, userid, sectionType, callback) {
            $http.get('ProjectGlossary/GetProjectInfoByIdApprover/' + projectId + '/' + userid + '/' + sectionType)

                .success(function (glossaryInitialTerms) {
                    callback(glossaryInitialTerms);
                })
                .error(function (e) {
                    callback("error");
                });
        },

        /**
       * @ngdoc function
       * @name Projects.Glossary#getTranslationInitialData
       * @methodOf Projects.Glossary
       * @description
       * This service is to get intial glossary data on page load on translation page. 
       * @param {String} projectId This is the encrypted project id of selected project passed as parameter to this method.
       * @param {Number} userid This is the userid of current logged in user.
       * @param {Number} sectionType This is the section type. for default section sectionType is 1 for NTL/FD 2
       * @returns {object}  This method returns object with all glossary data to be shown on glossary grids(Tables).
       */
        getTranslationInitialData: function (projectId, userid, sectionType, callback) {
            $http.get('ProjectGlossary/GetProjectInfoByIdTranslator/' + projectId + '/' + userid + '/' + sectionType)

                .success(function (glossaryInitialTerms) {
                    callback(glossaryInitialTerms);
                })
                .error(function (e) {
                    callback("error");
                });
        },


        /**
       * @ngdoc function
       * @name Projects.Glossary#getTranslationData
       * @methodOf Projects.Glossary
       * @description
       * This service is to get translation page data with language translations when filters are applied or section is changed.
       * @param {String} projectid This is the encrypted project id of selected project passed as parameter to this method.
       * @param {Number} userid This is the userid of current logged in user.
       * @param {Number} headerid This is the section id current selected section
       * @param {Number} langId This is language id of selected language.
       * @returns {object}  This method returns object with all glossary data to be shown on glossary grids(Tables).
       */
        getTranslationData: function (projectid, headerid, userid, langId, callback) {
            $http.get('ProjectGlossary/GetProjectDetailsBySelectedProjectLanguageId/' + projectid + '/' + headerid + '/' + userid + '/' + langId)
                .success(function (glossaryTerms) {
                    updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                    updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                    updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                    commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                        callback(glossaryTerms);
                    });
                })
                .error(function (e) {
                    callback("error");
                });
        },

        /**
       * @ngdoc function
       * @name Projects.Glossary#getApproveData
       * @methodOf Projects.Glossary
       * @description
       * This service is to get approval page data when filters are applied or section is changed.
       * @param {String} projectid This is the encrypted project id of selected project passed as parameter to this method.
       * @param {String} userrole This is the logged in user role.
       * @param {Number} userid This is the userid of current logged in user.
       * @param {Number} headerid This is the section id current selected section
       * @param {Number} langId This is language id of selected language.
       * @returns {object}  This method returns object with all glossary data to be shown on glossary grids(Tables) on approval page.
       */
        getApproveData: function (projectid, langId, headerid, userid, userrole, callback) {
            $http.get('ProjectGlossaryApprove/GetProjectGlossaryApproveDetails/' + projectid + '/' + langId + '/' + headerid + '/' + userid + '/' + userrole)
                .success(function (glossaryTerms) {
                    updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                    updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                    updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                    commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                        callback(glossaryTerms);
                    });
                })

                .error(function (e) {
                    callback("error");
                });
        },

        /**
     * @ngdoc function
     * @name Projects.Glossary#getGlossaryData
     * @methodOf Projects.Glossary
     * @description
     * This service is to get load main glossary data for the glosaary page
     * @param {String} projectid This is the encrypted project id of selected project passed as parameter to this method.
     * @param {Number} userid This is the userid of current logged in user.
     * @param {Number} headerid This is the section id current selected section
     * @returns {object}  This method returns object with all glossary data to be shown on glossary grids(Tables) on approval page.
     */
        getGlossaryData: function (projectid, headerid, userid, callback) {
            $http.get('ProjectGlossary/GetProjectDetailsById/' + projectid + '/' + headerid + '/' + userid)
                .success(function (glossaryTerms) {
                    callback(glossaryTerms);
                })
                .error(function (e) {
                    callback("error");
                });
        },

        /**
        * @ngdoc function
        * @name Projects.Glossary#getSectionData
        * @methodOf Projects.Glossary
        * @description
        * This service is to get glossary data section wise.
        * @param {Object} data This is the object contains project and logged in user's details
        * @returns {object}  This method returns object with all glossary terms.
        */
        getSectionData: function (data, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: 'POST',
                    url: "ProjectGlossary/SearchGlossaryForSpecificTerm",
                    data: data,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })

                    .success(function (glossaryTerms) {
                        if (JSON.parse(sessionStorage.getItem('resourcePageId')) === 2 || JSON.parse(sessionStorage.getItem('resourcePageId')) === 3) {
                            updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                            updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                            updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                            commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                                callback(glossaryTerms);
                            });
                        }
                        else {
                            callback(glossaryTerms);
                        }
                    })

                    .error(function (e) {
                        callback("error");
                    });
            });
        },

        //Glossary Language lock check
        checkGlossaryLanguage: function (data, callback) {
            $http({
                method: 'POST',
                url: "ProjectGlossary/LockGlossaryLangauge",
                data: data
            })

                .success(function (status) {
                    callback(status);
                })

                .error(function (e) {
                    callback("error");
                });

        },

        checkGlossaryLanguageStatus: function (GlossaryLangCheck, callback) {
            $http.get('ProjectGlossary/GetGlossaryLangaugeLockData/' + GlossaryLangCheck.UserId + '/' + GlossaryLangCheck.ProjectLangaugeId)

                .success(function (status) {
                    callback(status);
                })

                .error(function (e) {
                    callback("error");
                });
        },

        /**
       * @ngdoc function
       * @name Projects.Glossary#getStarredItems
       * @methodOf Projects.Glossary
       * @description
       * This service is to get list of  strred terms
       * @param {Number} MasterGlossaryId This is the master glossary id.
       * @param {Number} UserId This is the userid of current logged in user.
       * @returns {object}  This method returns object which contains list of all starred terms.
       */
        getStarredItems: function (MasterGlossaryId, UserId, callback) {
            $http({
                method: "get",
                url: "TermTranslation/StarredTermInfo/" + MasterGlossaryId + "/" + UserId
            })
                .success(function (starredTerms) {
                    if (JSON.parse(sessionStorage.getItem('resourcePageId')) === 2 || JSON.parse(sessionStorage.getItem('resourcePageId')) === 3) {
                        updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                        updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                        updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                        commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                            callback(starredTerms);
                        });
                    }
                    else {
                        callback(starredTerms);
                    }
                })
                .error(function (e) { })
        },

        /**
        * @ngdoc function
        * @name Projects.Glossary#postExportSettings
        * @methodOf Projects.Glossary
        * @param {Object} data This is the object containing all the selected columns for export glossary, eg.catagories,languages
        * @description
        * This service is to export (download) the glossary in excel format.
        * @returns {object}  This method returns object which contains data to be shown in exported excel file.
        */
        postExportSettings: function (data, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: 'POST',
                    url: "ProjectGlossary/ExportToExcel",
                    data: data,
                    responseType: 'blob',
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                }).
                    success(function (data, status, headers, config) {
                        if (JSON.parse(sessionStorage.getItem('resourcePageId')) === 2 || JSON.parse(sessionStorage.getItem('resourcePageId')) === 3) {
                            updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                            updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                            updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                            commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                                saveBlob.save(data, 'GlossaryManagerExportFile.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8');
                                callback(true);
                            });
                        }
                        else {
                            saveBlob.save(data, 'GlossaryManagerExportFile.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8');
                            callback(true);
                        }
                    }).
                    error(function (data, status, headers, config) { })
            });
        },

        /**
       * @ngdoc function
       * @name Projects.Glossary#sendGlossaryService
       * @methodOf Projects.Glossary
       * @param {Object} sendData This is the object containing all the data to send glossary, eg.section,languages,user details of user to whom glossary is to be sent
       * @description
       * This service is to send glossary to users on their email.
       * @returns {Boolean}  This method returns true/false.
       */
        sendGlossaryService: function (sendData, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token
                $http({
                    method: "post",
                    url: "ProjectGlossary/SaveSendGlossary",
                    data: sendData,
                    headers: {
                        '__RequestVerificationToken': forgerytoken

                    }
                })
                    .success(function (data) {
                        if (JSON.parse(sessionStorage.getItem('resourcePageId')) === 2 || JSON.parse(sessionStorage.getItem('resourcePageId')) === 3) {
                            updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                            updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                            updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                            commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                                callback(data);
                            });
                        }
                        else {
                            callback(data);
                        }

                    })
                    .error(function (e) {
                        callback("error");
                    })
            });
        },

        /**
        * @ngdoc function
        * @name Projects.Glossary#saveComment
        * @methodOf Projects.Glossary
        * @param {Object} commentTerm This is the object containing all the details about entered comment,section and user
        * @description
        * This service is to save comments on comments popup
        * @returns {Boolean}  This method returns true/false.
        */
        saveComment: function (commentTerm, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token
                $http({
                    method: "post",
                    url: "TermTranslation/SaveComments",
                    data: commentTerm,
                    headers: {
                        '__RequestVerificationToken': forgerytoken

                    }
                })
                    .success(function (data) {
                        if (JSON.parse(sessionStorage.getItem('resourcePageId')) === 2 || JSON.parse(sessionStorage.getItem('resourcePageId')) === 3) {
                            updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                            updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                            updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                            commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                                callback(data);
                            });
                        }
                        else {
                            callback(data);
                        }

                    })
                    .error(function (e) {
                        callback("error");
                    })
            });
        },

        /**
        * @ngdoc function
        * @name Projects.Glossary#saveTranslationSource
        * @methodOf Projects.Glossary
        * @param {Object} GlossaryTranslationSource This is the object containing all the details about translation source and source comment.
        * @param {String} projectid This is the encrypted project id of selected project passed as parameter to this method.
        * @param {Number} userid This is the userid of current logged in user.
        * @param {Number} OriginalUserId This is the userid of impersonated in user.
        * @description
        * This service is to save translation source information
        * @returns {Boolean}  This method returns true/false.
        */
        saveTranslationSource: function (GlossaryTranslationSource, ProjectId, UserId, OriginalUserId, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token
                $http({
                    method: "post",
                    url: "ProjectGlossary/SaveGlossaryTranslationSource",
                    data: {
                        GlossaryTranslationSource: GlossaryTranslationSource,
                        ProjectId: ProjectId,
                        UserId: UserId,
                        OriginalUserId: OriginalUserId
                    },
                    headers: {
                        '__RequestVerificationToken': forgerytoken

                    }
                })
                    .success(function (data) {
                        if (JSON.parse(sessionStorage.getItem('resourcePageId')) === 2 || JSON.parse(sessionStorage.getItem('resourcePageId')) === 3) {
                            updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                            updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                            updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                            commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                                callback(data);
                            });
                        }
                        else {
                            callback(data);
                        }
                    })
                    .error(function (e) {
                        callback("error");
                    })
            });
        },

        /*save Bulk Translation Source GLMGR-1030*/
         /**
        * @ngdoc function
        * @name Projects.Glossary#saveBulkTranslationSource
        * @methodOf Projects.Glossary
        * @param {Object} GlossaryBulkTranslationSource This is the object containing all the details about translation source and source comment.
        * @param {String} ProjectId This is the encrypted project id of selected project passed as parameter to this method.
        * @param {Number} UserId This is the userid of current logged in user.
        * @param {Number} OriginalUserId This is the userid of impersonated in user.
        * @description
        * This service is to save translation source information for all terms.
        * @returns {Boolean}  This method returns true/false.
        */
        saveBulkTranslationSource: function (GlossaryBulkTranslationSource, ProjectId, UserId, IsForAll, OriginalUser, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token
                $http({
                    method: "post",
                    url: "ProjectGlossary/SaveGlossaryBulkTranslationSource",
                    data: {
                        GlossaryBulkTranslationSource: GlossaryBulkTranslationSource,
                        ProjectId: ProjectId,
                        UserId: UserId,
                        IsForAll: IsForAll,
                        OriginalUserId: OriginalUser
                    },
                    headers: {
                        '__RequestVerificationToken': forgerytoken

                    }
                })
                    .success(function (data) {
                        if (JSON.parse(sessionStorage.getItem('resourcePageId')) === 2 || JSON.parse(sessionStorage.getItem('resourcePageId')) === 3) {
                            updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                            updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                            updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                            commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                                callback(data);
                            });
                        }
                        else {
                            callback(data);
                        }
                    })
                    .error(function (e) {
                        callback("error");
                    })
            });
        },

          /**
        * @ngdoc function
        * @name Projects.Glossary#addcmnt
        * @methodOf Projects.Glossary
        * @param {Object} row This is the object containing all the details selected row.
        * @description
        * This service is to add comment.
        * @returns {Boolean}  This method returns true/false.
        */
        addcmnt: function (row, callback) {
            $http.get('TermTranslation/GetCommentListByGlossaryTranslationId/' + row)
                .success(function (data) {
                    if (JSON.parse(sessionStorage.getItem('resourcePageId')) === 2 || JSON.parse(sessionStorage.getItem('resourcePageId')) === 3) {
                        updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                        updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                        updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                        commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                            callback(data);
                        });
                    }
                    else {
                        callback(data);
                    }
                })
                .error(function (e) {
                    console.log('error');
                })
        },

        /*GLMGR-1030 get Translation source data*/
        
          /**
        * @ngdoc function
        * @name Projects.Glossary#GetTranslationSource
        * @methodOf Projects.Glossary
        * @param {Object} row This is the object containing all the details selected row.
        * @param {Number} MasterGlossaryId This is the master glossary id.
        * @param {Number} projectLanguageId This is the project language id.
        * @param {Number} userId This is the userid of current logged in user.
        * @description
        * This service is to get translation source details.
        * @returns {Boolean}  This method returns true/false.
        */
        GetTranslationSource: function (projectId, masterGlossaryId, projectLanguageId, userId, callback) {
            $http.get('ProjectGlossary/GetGlossaryTranslationSource/' + projectId + '/' + masterGlossaryId + '/' + projectLanguageId + '/' + userId)
                .success(function (data) {
                    if (JSON.parse(sessionStorage.getItem('resourcePageId')) === 2 || JSON.parse(sessionStorage.getItem('resourcePageId')) === 3) {
                        updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                        updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                        updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                        commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                            callback(data);
                        });
                    }
                    else {
                        callback(data);
                    }
                })
                .error(function (e) {
                    console.log('error');
                })
        },

        /**
        * @ngdoc function
        * @name Projects.Glossary#SaveAutoTranslation
        * @methodOf Projects.Glossary
        * @param {Object} autoTrans This is the object containing all the details about term to be translated.
        * @description
        * This service is to get save term translation 
        * @returns {Boolean}  This method returns true/false.
        */
        SaveAutoTranslation: function (autoTrans, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectGlossary/AutoSaveApprovedGlossaryTranslation",
                    data: autoTrans,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (data) {
                        if (JSON.parse(sessionStorage.getItem('resourcePageId')) === 2 || JSON.parse(sessionStorage.getItem('resourcePageId')) === 3) {
                            updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                            updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                            updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                            commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                                callback(data);
                            });
                        }
                    })
                    .error(function (e) {
                        console.log('error');
                    })
            });


        },

         /**
        * @ngdoc function
        * @name Projects.Glossary#InsertAutoTranslation
        * @methodOf Projects.Glossary
        * @param {Object} autoTrans This is the object containing all the details about term to be translated.
        * @description
        * This service is to insert translation from inconsistency popup
        * @returns {Boolean}  This method returns true/false.
        */
        InsertAutoTranslation: function (autoTrans, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectGlossary/AutoInsertApprovedGlossaryTranslation",
                    data: autoTrans,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (data) {
                        if (JSON.parse(sessionStorage.getItem('resourcePageId')) === 2 || JSON.parse(sessionStorage.getItem('resourcePageId')) === 3) {
                            updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                            updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                            updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                            commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                                callback(data);
                            });
                        }
                    })
                    .error(function (e) {
                        console.log('error');
                    })
            });


        },

        /**
        * @ngdoc function
        * @name Projects.Glossary#finaltranslationSubmit
        * @methodOf Projects.Glossary
        * @param {Object} finalSubmit This is the object containing all the details about all terms.
        * @description
        * This service is to submit all translations
        * @returns {Boolean}  This method returns true/false.
        */
        finaltranslationSubmit: function (finalSubmit, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectGlossary/SubmitGlossaryTranslationTerm",
                    data: finalSubmit,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (data) {
                        if (JSON.parse(sessionStorage.getItem('resourcePageId')) === 2 || JSON.parse(sessionStorage.getItem('resourcePageId')) === 3) {
                            updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                            updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                            updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                            commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                                callback(data);
                            });
                        }
                    })
                    .error(function (e) {
                        console.log('error');
                    })
            });
        },

         /**
        * @ngdoc function
        * @name Projects.Glossary#ValidateGlossaryTranslationForTranslationSource
        * @methodOf Projects.Glossary
        * @param {Object} finalSubmit This is the object containing all the details about all terms.
        * @description
        * This service is to check if translation source is added.
        * @returns {Boolean}  This method returns true/false.
        */
        ValidateGlossaryTranslationForTranslationSource: function (finalSubmit, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectGlossary/ValidateGlossaryTranslationForTranslationSource",
                    data: finalSubmit,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (data) {
                        if (JSON.parse(sessionStorage.getItem('resourcePageId')) === 2 || JSON.parse(sessionStorage.getItem('resourcePageId')) === 3) {
                            updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                            updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                            updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                            commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                                callback(data);
                            });
                        }
                    })
                    .error(function (e) {
                        console.log('error');
                    })
            });
        },

         /**
        * @ngdoc function
        * @name Projects.Glossary#emailSendConfirmation
        * @methodOf Projects.Glossary
        * @param {Object} emailData This is the object containing all the details about email data.
        * @description
        * This is send email service for translation.
        * @returns {Boolean}  This method returns true/false.
        */
        emailSendConfirmation: function (emailData, callback) {
            $http({
                method: "post",
                url: "ProjectGlossary/SendMail",
                data: emailData
            })
                .success(function (data) {
                    callback(data);
                })
                .error(function (e) {
                    console.log('error');
                })

        },

         /**
        * @ngdoc function
        * @name Projects.Glossary#emailSendConfirmationApproval
        * @methodOf Projects.Glossary
        * @param {Object} emailData This is the object containing all the details about email data.
        * @description
        * This is send email service for approval.
        * @returns {Boolean}  This method returns true/false.
        */
        emailSendConfirmationApproval: function (emailData, callback) {
            $http({
                method: "post",
                url: "ProjectGlossaryApprove/SendMailForApproval",
                data: emailData
            })
                .success(function (data) {
                    callback(data);
                })
                .error(function (e) {
                    console.log('error');
                })

        },

       /**
        * @ngdoc function
        * @name Projects.Glossary#translationAutoSave
        * @methodOf Projects.Glossary
        * @param {Object} termtrans This is the object containing all the details about term to be translated.
        * @description
        * This service is to auto save term translation 
        * @returns {Boolean}  This method returns true/false.
        */
        translationAutoSave: function (termtrans, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;

                $http({
                    method: "post",
                    url: "ProjectGlossary/SaveGlossaryTranslation",
                    data: termtrans,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (obj) {
                        updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                        updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                        updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                        commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                            callback(obj);
                        });
                    })
                    .error(function (e) {
                        callback("error");
                    })
            });
        },

        /*Auto save accept/reject checkbox on ApproverPage*/
        
       /**
        * @ngdoc function
        * @name Projects.Glossary#approveCheckAutoSave
        * @methodOf Projects.Glossary
        * @param {Object} state This is the object containing all the details about term to be approved.
        * @description
        * This service is to auto save accept/reject checkbox on ApproverPage
        * @returns {Boolean}  This method returns true/false.
        */
        approveCheckAutoSave: function (state, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectGlossaryApprove/UpdateApproverGlossary",
                    data: state,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (data) {
                        updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                        updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                        updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                        commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                            callback(data);
                        });
                        //if (data == false) {
                        //    callback('term not approved');
                        //}
                        //if (data == true) {
                        //    callback('term  approved');
                        //}
                    })
                    .error(function (e) {
                        callback("error");
                    })
            });
        },

         /**
        * @ngdoc function
        * @name Projects.Glossary#approveAllCheckAutoSave
        * @methodOf Projects.Glossary
        * @param {Object} allSave This is the object containing all the details about all terms to be approved/rejected.
        * @description
        * This service is to auto save accept/reject checkbox on ApproverPage on check all check box.
        * @returns {Boolean}  This method returns true/false.
        */
        approveAllCheckAutoSave: function (allSave, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectGlossaryApprove/UpdateAllApproverGlossary",
                    data: allSave,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (data) {
                        updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                        updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                        updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                        commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                            callback(data);
                        });

                    })
                    .error(function (e) {
                        callback(e);
                    })
            });
        },

        /**
        * @ngdoc function
        * @name Projects.Glossary#approveFinalSubmit
        * @methodOf Projects.Glossary
        * @param {Object} finalSubmit This is the object containing all the details about all terms to be approved/rejected.
        * @description
        * This service is to submit all terms.
        * @returns {Boolean}  This method returns true/false.
        */
        approveFinalSubmit: function (finalSubmit, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "ProjectGlossaryApprove/SubmitApproverGlossary",
                    data: finalSubmit,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (data) {
                        updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                        updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                        updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                        commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                            callback(data);
                        });

                    })
                    .error(function (e) {
                        console.log(e);
                    })
            });
        },


        /**
        * @ngdoc function
        * @name Projects.Glossary#getStarredItemsTranslationApproval
        * @methodOf Projects.Glossary
        * @param {Number} MasterGlossaryId This is the master glossary id.
        * @param {Number} GlossaryTranslationId This is the glossary translation id.
        * @param {Number} UserId This is the userid of current logged in user.
        * @description
        * This service is to get starred terms on translation  and approval page.
        * @returns {Boolean}  This method returns true/false.
        */
        getStarredItemsTranslationApproval: function (GlossaryTranslationId, UserId, MasterGlossaryId, callback) {
            $http({
                method: "get",
                url: "ProjectGlossaryApprove/StarredTermInfo/" + GlossaryTranslationId + "/" + UserId + "/" + MasterGlossaryId
            })
                .success(function (starredTerms) {
                    if (JSON.parse(sessionStorage.getItem('resourcePageId')) === 2 || JSON.parse(sessionStorage.getItem('resourcePageId')) === 3) {
                        updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                        updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                        updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                        commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                            callback(starredTerms);
                        });
                    }
                })
                .error(function (e) {
                    callback(e);
                })
        },

        
        /**
        * @ngdoc function
        * @name Projects.Glossary#getLangInfo
        * @methodOf Projects.Glossary
        * @param {Number} langInfoId This is the selected language id
        * @description
        * This service is to get language information.
        * @returns {Boolean}  This method returns true/false.
        */
        getLangInfo: function (langInfoId, callback) {
            $http({
                method: "get",
                url: "ProjectGlossary/ViewProjectLangaugeComments/" + langInfoId
            })
                .success(function (data) {
                    if (JSON.parse(sessionStorage.getItem('resourcePageId')) === 2 || JSON.parse(sessionStorage.getItem('resourcePageId')) === 3) {
                        updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                        updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                        updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                        commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                            callback(data);
                        });
                    }
                    else {
                        callback(data);
                    }
                })
                .error(function (e) {
                    callback(e);
                })
        },

       /**
        * @ngdoc function
        * @name Projects.Glossary#saveLangInfo
        * @methodOf Projects.Glossary
        * @param {Object} saveLangModel This is the object containing all the information about language entered by user in lang info form.
        * @description
        * This service is to save language information.
        * @returns {Boolean}  This method returns true/false.
        */
        saveLangInfo: function (saveLangModel, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;

                $http({
                    method: "post",
                    url: "ProjectGlossary/SaveProjectLangaugeComments",
                    data: saveLangModel,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (data) {
                        if (JSON.parse(sessionStorage.getItem('resourcePageId')) === 2 || JSON.parse(sessionStorage.getItem('resourcePageId')) === 3) {
                            updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                            updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                            updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                            commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                                callback(data);
                            });
                        }
                        else {
                            callback(data);
                        }
                    })
                    .error(function (e) {
                        callback(e);
                    })
            });
        },

         /**
        * @ngdoc function
        * @name Projects.Glossary#searchTermInGlossary
        * @methodOf Projects.Glossary
        * @param {Object} ProjectGlossarySearchModel This is the object containing all the details about search filters.
        * @description
        * This service is to search term in the glossary.
        * @returns {Boolean}  This method returns true/false.
        */
        searchTermInGlossary: function (ProjectGlossarySearchModel, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;

                $http({
                    method: "post",
                    url: "ProjectGlossary/GetGlossarySearchResult",
                    data: ProjectGlossarySearchModel,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (data) {
                        if (JSON.parse(sessionStorage.getItem('resourcePageId')) === 2 || JSON.parse(sessionStorage.getItem('resourcePageId')) === 3) {
                            updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                            updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                            updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                            commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                                callback(data);
                            });
                        }
                        else {
                            callback(data);
                        }
                    })
                    .error(function (e) {
                        callback(e);
                    })
            });
        },

        /**
        * @ngdoc function
        * @name Projects.Glossary#saveEditedCmnt
        * @methodOf Projects.Glossary
        * @param {Object} editedcmnt This is the object containing all the details about edited comment.
        * @description
        * This service is to save edited comment.
        * @returns {Boolean}  This method returns true/false.
        */
        saveEditedCmnt: function (editedcmnt, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;

                $http({
                    method: "post",
                    url: "TermTranslation/UpdateComments",
                    data: editedcmnt,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (data) {
                        if (JSON.parse(sessionStorage.getItem('resourcePageId')) === 2 || JSON.parse(sessionStorage.getItem('resourcePageId')) === 3) {
                            updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                            updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                            updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                            commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                                callback(data);
                            });
                        }
                        else {
                            callback(data);
                        }
                    })
                    .error(function (e) {
                        callback(e);
                    })
            });
        },

         /**
        * @ngdoc function
        * @name Projects.Glossary#getAttachmentList
        * @methodOf Projects.Glossary
        * @param {String} projectid This is encrypted project id
        * @param {Number} UserId This is the userid of current logged in user.
        * @description
        * This is service to get attachments list on user Id in init
        * @returns {Boolean}  This method returns true/false.
        */
        getAttachmentList: function (projectid, userid, callback) {
            $http.get('ProjectGlossary/ShowAllAttachments/' + projectid + '/' + userid)
                .success(function (AttachmentList) {
                    callback(AttachmentList);
                })
                .error(function (e) {
                    console.log("error..." + e);
                });
        },

          /**
        * @ngdoc function
        * @name Projects.Glossary#getDownloadAttachmentAll
        * @methodOf Projects.Glossary
        * @param {String} projectid This is encrypted project id
        * @param {Number} languageid This is the language id.
        * @param {Number} attachmentid This is the attachment id of attached file.
        * @description
        * This is service to get file data to download for all languages
        * @returns {Boolean}  This method returns true/false.
        */
        getDownloadAttachmentAll: function (projectid, languageid, attachmentid, callback) {

            $http.get('ProjectGlossary/DownloadAttachment/' + projectid + '/' + languageid + '/' + attachmentid)

                .success(function (data) {
                    callback(data);
                })

                .error(function (e) {
                    console.log("error..." + e);
                });
        },

          /**
        * @ngdoc function
        * @name Projects.Glossary#getDownloadAttachment
        * @methodOf Projects.Glossary
        * @param {String} projectid This is encrypted project id
        * @param {Number} languageid This is the language id.
        * @param {Number} attachmentid This is the attachment id of attached file.
        * @description
        * This is service to get file data to download for single language
        * @returns {Boolean}  This method returns true/false.
        */
        getDownloadAttachment: function (projectid, projectlanguageid, attachmentid, callback) {

            $http.get('ProjectGlossary/DownloadAttachmentToInfo/' + projectid + '/' + projectlanguageid + '/' + attachmentid)

                .success(function (data) {
                    callback(data);
                })

                .error(function (e) {
                    console.log("error..." + e);
                });
        },

          /**
        * @ngdoc function
        * @name Projects.Glossary#getTermSuggestions
        * @methodOf Projects.Glossary
        * @param {String} projectId This is encrypted project id
        * @param {Number} masterGlossaryId This is the master glossary id.
        * @param {Number} glossaryGroupId This is the section id.
        * @param {Number} userId This is the userid of current logged in user.
        * @description
        * This is service to get master term suggestion history
        * @returns {Boolean}  This method returns true/false.
        */
        getTermSuggestions: function (projectId, masterGlossaryId, glossaryGroupId, userId, callback) {
            $http.get('ProjectGlossary/SuggestionHistory/' + projectId + '/' + masterGlossaryId + '/' + glossaryGroupId + '/' + userId)
                .success(function (data) {
                    callback(data);
                })
                .error(function (e) {
                    console.log("error..." + e);
                });
        },

        /**
        * @ngdoc function
        * @name Projects.Glossary#getPendingSuggestionTermList
        * @methodOf Projects.Glossary
        * @param {String} projectId This is encrypted project id
        * @param {Number} projectLanguageId This is the language id.
        * @param {Number} glossaryGroupId This is the section id.
        * @description
        * This is Service to get master term suggestion history
        * @returns {Boolean}  This method returns true/false.
        */
        getPendingSuggestionTermList: function (glossaryGroupId, projectId, projectLanguageId, callback) {
            $http.get('ProjectGlossaryApprove/CheckPendingSuggestion/' + glossaryGroupId + '/' + projectId + '/' + projectLanguageId)
                .success(function (data) {
                    callback(data);
                })
                .error(function (e) {
                    console.log("error..." + e);
                });
        },

        /**
        * @ngdoc function
        * @name Projects.Glossary#getProjectHistory
        * @methodOf Projects.Glossary
        * @param {String} projectId This is encrypted project id
        * @param {Number} languageId This is the language id.
        * @param {Number} headerId This is the section id.
        * @param {Number} userId This is the userid of current logged in user.
        * @param {String} userRoleName This is the user role of current logged in user.
        * @description
        * This is Service to get the language history information
        * @returns {Boolean}  This method returns true/false.
        */
        getProjectHistory: function (projectId, headerId, userId, userRoleName, languageId, callback) {
            $http({
                method: "get",
                url: 'ProjectGlossary/GetProjectHistory/' + projectId + '/' + headerId + '/' + userId + '/' + userRoleName + '/' + languageId
            })
                .success(function (languageHistory) {
                    callback(languageHistory);

                })
                .error(function (e) {
                    callback(e);
                })
        },

        /*Revert Translation*/
        saveRevertedTranslation: function (revertTranslation, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;

                $http({
                    method: "post",
                    url: "ProjectGlossary/SaveGlossaryTranslation",
                    data: revertTranslation,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (data) {
                        if (JSON.parse(sessionStorage.getItem('resourcePageId')) === 2 || JSON.parse(sessionStorage.getItem('resourcePageId')) === 3) {
                            updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                            updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                            updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                            commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                                callback(data);
                            });
                        }
                        else {
                            callback(data);
                        }
                    })
                    .error(function (e) {
                        callback(e);
                    })
            });
        },

        /*Get Glossary All section initial data*/
        getAllsection: function (initdata, callback) {
            $http({
                method: 'POST',
                url: "ProjectGlossary/AllSections",
                data: initdata
            })

                .success(function (glossaryTerms) {
                    callback(glossaryTerms);
                })
                .error(function (e) {
                    callback(e);
                })
        },

       /**
        * @ngdoc function
        * @name Projects.Glossary#exportSFeraKNP
        * @methodOf Projects.Glossary
        * @param {Object} status This is object containing all the filters applied to export glossary in sfera KNP format
        * @description
        * This is service for export sfera functionality
        * @returns {Boolean}  This method returns true/false.
        */
        exportSFeraKNP: function (status, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;

                $http({
                    method: 'POST',
                    url: "ProjectGlossary/XExportToExcelSendSferaKNP",
                    data: status,
                    responseType: 'blob',
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })

                    .success(function (data) {
                        if (JSON.parse(sessionStorage.getItem('resourcePageId')) === 2 || JSON.parse(sessionStorage.getItem('resourcePageId')) === 3) {
                            updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
                            updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
                            updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
                            commonService.setTimeInSourceSetupCall(updateUserLockData, function () {
                                saveBlob.save(data, 'Project Consistency and Instructions_Sample KNP Project.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8');
                                callback(true);
                            });
                        }
                        else {
                            saveBlob.save(data, 'Project Consistency and Instructions_Sample KNP Project.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8');
                            callback(true);
                        }
                    })
                    .error(function (e) {
                        callback(e);
                    })
            })
        }
    }

    return GlossaryData;
}])