/**
 * @ngdoc controller
 * @name Projects.controller:ProjectEditController
 * @element div
 *
 * @description
 * This Controller is responsible for editing the existing project.
 *
 * @requires AngularJS.$scope
 * @requires AngularJS.$http
 * @requires AngularJS.$location
 * @requires AngularJS.$route
 * @requires AngularJS.$timeout
 * @requires common
 * @requires common.commonService
 * @requires Projects.LandingPageData
 * 
 * @property {Array} myDataClients:Array  This property is list of all clients assigned to project.
 * @property {Array} myDataOwners:Array  This property is list of all owners assigned to project.
 * @property {Array} myDataBrands:Array  This property is list of all brands assigned to project.
 * @property {Object} userDetails:Object This is object stores the user details received  from backend when user is logged in. 
 * @property {String} Title:String This property is Project title.
 * @property {String} SecureTitle:String This property is Secure title given to project.
 * @property {String} newCategory:String This property is name of new category to be added.
 * @property {Object} editCategory:String This property is object of existing category which need to be edited
 * @property {String} projectId:String This property is encrypted project id.
 * @property {Array} selectCat:Array This property is list of all additional info columns added to project.
 * @property {Array} selectLang:Array This property is list of selected languages for project. 
 * @property {Array} selectedLangSourceList:Array This property is list of languages which need language translation source.
 * @property {Array} selectedLangSourceList:Array This property is list of languages which need language translation source.
 * @property {Array} attachedFiles:Array This property is list of files to be attached.
 * @property {Number} MasterLanguageId:Number This property is Id of master language.
 * @property {Number} attachmentLanguageId:Number This property is Id of language for which attachment is to be added.
 * 
 */

Projects.controller('projectEditController', ['$scope', '$http', '$location', 'LandingPageData', 'commonService', '$q', '$timeout', function ($scope, $http, $location, LandingPageData, commonService, $q, $timeout) {

    var projectId = commonService.getSessionData('projectIBreadCrumb');
    var userDetails = commonService.getLocalData('userDetails');
    var userRole = userDetails.UserRoles[0].UserRoleName;
    var myDataClients = [];
    var myDataOwners = [];
    var myDataBrands = [];
    var attachedFiles = [];
    $scope.ObjectId2 = [];
    var CopyOfAllCategories = [];
    var CopyOfAllLanguages = [];
    $scope.disableSaveButton = false;
    var AnswerGiven = false;
    $scope.booltrue = true; // used as bool true to pass to directive(s) in HTML 
    $scope.boolfalse = false; // used as bool false to pass to directive(s) in HTML 

    var editProjectData = {};
    //original userid GLMGR-1103
    if ($scope.adminUser) {
        editProjectData['OriginalUserId'] = $scope.adminUser.UserId;
    } else {
        editProjectData['OriginalUserId'] = null;
    }

    var duplicateBrandFlag = false;
    $scope.confirmationMsg = '';
    $scope.unSelectedLangSourceList = [];
    $scope.selectedLangSourceList = [];
    $scope.sourceSelectLang = [];
    $scope.sourceUnSelectLang = [];
    var check;
    $('#clientValMsg').hide();
    $('.jumbotron .btn-save').attr('disabled', false);
    $scope.isRequired = {
        "requiredTitle": false,
        "requiredClients": false
    };
    $scope.editCategory = {};
    $scope.requiredCategory = false;
    var OwnersList = {};
    var client_str = '';
    var createrIsOwner = false;
    var finalBrands = [];
    var brand_str = '';
    var GlossaryLangCheck = {};
    var attachedFilesListing;
    var rearrangedCategoryIds = [];
    var OldBrands;

    //get ids of selected clients from multiselect dropdown
    $scope.$on('selectedModel', function (event, myData) {
        //multiselect dropdown: show values of selected items
        myDataClients = myData;
        
        $scope.member = { roles: [] };
        $scope.OwnerMember = { OwnerRoles: [] };
        $scope.ObjectId1 = [];
        myDataOwners = $scope.ObjectId1;
        if (myDataClients.length > 0) {
            LandingPageData.projectOwnerList(0, userDetails.UserId, myData, function (ownerList) {
                OwnersList = ownerList;
                $scope.OwnerRoles = ownerList.Owners;
                showValuesOnOwnerDropDown();
            });
            client_str = '';
            $scope.disableSaveButton = false;
            for (j = 0; j < myDataClients.length; j++) {
                for (i = 0; i < $scope.ProjectEdit.AllClients.length; i++) {
                    if ($scope.ProjectEdit.AllClients[i].Id === myDataClients[j]) {
                        if (client_str) {
                            client_str = client_str + ', ' + $scope.ProjectEdit.AllClients[i].ClientName;
                        } else {
                            client_str = client_str + $scope.ProjectEdit.AllClients[i].ClientName;
                        }
                        $('.client_str').html(client_str);
                        $('.client_str').attr('title', client_str);
                    }
                }
            }
        }
        else {
            $scope.OwnerRoles = [];
            showValuesOnOwnerDropDown();
            $('.client_str').html('Select Client(s)');
            $('.client_str').attr('title', 'Select Client(s)');
            $('.brand_str').html('Select Brand(s)');
            $('.brand_str').attr('title', 'Select Brand(s)');
            $scope.disableSaveButton = true;
            showCommmonBrands(myDataClients);
        }

        //mandatory client validation
        if (myDataClients.length < 1) {
            $scope.mandatoryValidationOnChange('Clients');
            return false;
        } else {
            $scope.mandatoryValidationOnChange('Clients');
        }
        showCommmonBrands(myDataClients);
    });

    // Project Owner field required
    $scope.ownerRequired = function () {
        createrIsOwner = true;
        AnswerGiven = true;
        $scope.disableSaveButton = false;
        $('.owner_str').html(userDetails.FirstName + ' ' + userDetails.LastName);
        $('.owner_str').attr('title', userDetails.FirstName + ' ' + userDetails.LastName);
        $('.modal-backdrop.fade.in').css('display', 'none');
        $('#ownerRequired').modal('hide');
        $scope.saveProject($scope.redirectURL);
    };

    $scope.$on('ownerselectedModel', function (event, myData) {
        myDataOwners = myData;
        //multiselect dropdown: show values of selected items
        showValuesOnOwnerDropDown();
    });

    /**
     * @ngdoc
     * @name showValuesOnOwnerDropDown
     * @methodOf Projects.controller:ProjectEditController
     * @description
     *This method is used show values of selected items in owners dropdown.
     *@return {undefined} This method does not return.
     */
    var showValuesOnOwnerDropDown = function () {
        //multiselect dropdown: show values of selected items
        if (myDataOwners.length > 0) {
            $scope.owner_str = '';
            $scope.isRequired.requiredOwner = false;
            $scope.disableSaveButton = false;
            for (j = 0; j < myDataOwners.length; j++) {
                if ($scope.owner_str) {
                    $scope.owner_str = $scope.owner_str + ', ' + myDataOwners[j].OwnerName;
                } else {
                    $scope.owner_str = $scope.owner_str + myDataOwners[j].OwnerName;
                }
                $('.owner_str').html($scope.owner_str);
                $('.owner_str').attr('title', $scope.owner_str);
            }
        }
        else {
            $('.owner_str').html('Select Owner(s)');
            $('.owner_str').attr('title', 'Select Owner(s)');
            $scope.isRequired.requiredOwner = true;
            $scope.disableSaveButton = true;
        }
    }

     /**
     * @ngdoc
     * @name ownerGroupPopup
     * @methodOf Projects.controller:ProjectEditController
     * @description
     *This method is used to show popup to select owner groups.
     *@return {undefined} This method does not return.
     */
    $scope.ownerGroupPopup = function () {
        $scope.groupOwnerSelected = null;
        $scope.GroupOwner = OwnersList.OwnersGroup;
        $scope.rightListGroupOwner = [];
        $scope.leftListGroupOwner = [];
        $('#ownerGroup').modal('show');
    };

     /**
     * @ngdoc
     * @name groupUserList
     * @methodOf Projects.controller:ProjectEditController
     * @param {Object} group This objects contains AssignedUserList array.
     * @description
     *This method is used to show users list in the group.
     *@return {undefined} This method does not return.
     */
    $scope.groupUserList = function (group) {
        $scope.rightListGroupOwner = [];
        $scope.leftListGroupOwner = [];

        for (var i = 0; i < group.AssignedUserList.length; i++) {
            var flag = false;
            for (var j = 0; j < myDataOwners.length; j++) {
                if (group.AssignedUserList[i].OwnerId === myDataOwners[j].Id) {
                    $scope.rightListGroupOwner.push(group.AssignedUserList[i]);
                    flag = true;
                    break;
                }
            }
            if (flag === false) {
                $scope.leftListGroupOwner.push(group.AssignedUserList[i]);
            }
        }
    };

     /**
     * @ngdoc
     * @name moveOwner
     * @methodOf Projects.controller:ProjectEditController
     * @param {string} dir This is string which is used to select/unselect user from owner group. dir is a direction in which user has to move. 
     * @description
     *This method is used to select/unselect user from owner group.
     *@return {undefined} This method does not return.
     */
    $scope.moveOwner = function (dir) {
        if (dir === "left") {
            if ($scope.ownerUnSelected.length > 0) {
                for (var i = 0; i < $scope.ownerUnSelected.length; i++) {
                    $scope.leftListGroupOwner.push($scope.ownerUnSelected[i]);
                    for (var j = 0; j < $scope.ObjectId1.length; j++) {
                        if ($scope.ObjectId1[j].Id === $scope.ownerUnSelected[i].OwnerId) {
                            $scope.ObjectId1.splice(j, 1);
                            break;
                        }
                    }
                    for (var j = 0; j < myDataOwners.length; j++) {
                        if (myDataOwners[j].Id === $scope.ownerUnSelected[i].OwnerId) {
                            myDataOwners.splice(j, 1);
                            break;
                        }
                    }
                    for (var j = 0; j < $scope.rightListGroupOwner.length; j++) {
                        if ($scope.rightListGroupOwner[j].OwnerId === $scope.ownerUnSelected[i].OwnerId) {
                            $scope.rightListGroupOwner.splice(j, 1);
                            break;
                        }
                    }
                }
            }
        } else {
            if ($scope.ownerSelected.length > 0) {
                for (var i = 0; i < $scope.ownerSelected.length; i++) {
                    $scope.rightListGroupOwner.push($scope.ownerSelected[i]);
                    for (var j = 0; j < $scope.OwnerRoles.length; j++) {
                        if ($scope.OwnerRoles[j].Id === $scope.ownerSelected[i].OwnerId) {
                            $scope.ObjectId1.push($scope.OwnerRoles[j]);
                            break;
                        }
                    }
                    for (var j = 0; j < $scope.leftListGroupOwner.length; j++) {
                        if ($scope.leftListGroupOwner[j].OwnerId === $scope.ownerSelected[i].OwnerId) {
                            $scope.leftListGroupOwner.splice(j, 1);
                            break;
                        }
                    }
                }
            }
        }
        showValuesOnOwnerDropDown();
    };

     /**
     * @ngdoc
     * @name showCommmonBrands
     * @methodOf Projects.controller:ProjectEditController
     * @description
     *This method is used to create array for brands respective to clients.
     *@return {undefined} This method does not return.
     */
    var showCommmonBrands = function (myData) {
        //to get Brand IDs of selected clients
        var selected = [];
        for (m = 0; m < myData.length; m++) {
            for (i = 0; i < $scope.ProjectEdit.ClientBrand.length; i++) {
                if ($scope.ProjectEdit.ClientBrand[i].ClientId === myData[m]) {
                    for (j = 0; j < $scope.ProjectEdit.ClientBrand[i].ClientBrandList.length; j++) {
                        selected.push($scope.ProjectEdit.ClientBrand[i].ClientBrandList[j].BrandId);
                    }
                }
            }
        }

        //to get Common Brand IDs
        var arr = selected;
        results = _.uniq(arr).sort();

        //create object of Brands
        var availableBrands = {};
       finalBrands = [];

        // var finalBrandIds = [];
        for (m = 0; m < results.length; m++) {
            availableBrands = {};
            for (i = 0; i < $scope.ProjectEdit.AllBrand.length; i++) {
                if ($scope.ProjectEdit.AllBrand[i].Id === results[m]) {
                    availableBrands.BrandName = $scope.ProjectEdit.AllBrand[i].BrandName;
                    availableBrands.Id = $scope.ProjectEdit.AllBrand[i].Id;
                    finalBrands.push(availableBrands);
                }
            }
        }

        if (myDataBrands.length > 0) {
            $('.brand_str').html(myDataBrands[0].BrandName);
            $('.brand_str').attr('title', myDataBrands[0].BrandName);
        } else {
            $('.brand_str').html('Select Brand(s)');
            $('.brand_str').attr('title', 'Select Brand(s)');
        }
    };

    // brand multiselect
    $scope.$on('brandselectedModel', function (event, myData) {
        myDataBrands = myData;
        $scope.BrandRoles = finalBrands;
        brand_str = '';

        if (myDataBrands.length > 0) {
            for (j = 0; j < myDataBrands.length; j++) {
                for (i = 0; i < finalBrands.length; i++) {
                    if (finalBrands[i].Id === myDataBrands[j]) {
                        if (brand_str) {
                            brand_str = brand_str + ', ' + finalBrands[i].BrandName;
                        } else {
                            brand_str = brand_str + finalBrands[i].BrandName;
                        }
                        $('.brand_str').html(brand_str);
                        $('.brand_str').attr('title', brand_str);
                    }
                }
            }
            OldBrands = myData;
        } else {
            $('.brand_str').html('Select Brand(s)');
            $('.brand_str').attr('title', 'Select Brand(s)');
        }
    });

    /**
     * @ngdoc
     * @name navSorceSetup
     * @methodOf Projects.controller:ProjectEditController
     * @description
     *This method is used to navigate to source setup page.
     *
     */
    var navSorceSetup = function () {
        GlossaryLangCheck = {};

        GlossaryLangCheck.UserId = commonService.getLocalData('userDetails').UserId;
        GlossaryLangCheck.PageId = 4;
        GlossaryLangCheck.ResourceId = commonService.getSessionData('projectIBreadCrumb');
        commonService.checkSourceSetup(GlossaryLangCheck, function (status) {
            if (status === "error") {
                $('#serverError').modal('show');
            }
            else if (status.IsLocked === true) {
                $('#multipleSourceSetupUser').modal('show');
            } else {
                changeView('sourceSetup');
            }
        });
    };

    $scope.continueToSourceSetup = function () {
        $('.modal-backdrop.fade.in').css('display', 'none');
        $('#multipleSourceSetupUser').modal('hide');
        changeView('sourceSetup');
    }
    $scope.cancelSourceSetup = function () {
        var resorceIdx = 4;
        sessionStorage.setItem('resourcePageId', JSON.stringify(resorceIdx));
        var userDetails = commonService.getLocalData('userDetails');
        changeView('glossary');
        $('.modal-backdrop.fade.in').css('display', 'none');
    }

    /**
     * @ngdoc
     * @name getFileList
     * @methodOf Projects.controller:ProjectEditController
     * @description
     *This method is used get list of all files attached to for entire project as well as for selected language.This method is called on Project Language dropdown on edit page in attachment section.
     *@return {undefined} This method does not return.
     */
    $scope.getFileList = function () {
        attachedFiles = [];
        editProjectData['languageId'] = ($scope.attachmentLanguageId > 0) ? $scope.attachmentLanguageId : 0;
        editProjectData['projectId'] = projectId;
        if (editProjectData['languageId'] === 0) {
            LandingPageData.getAttachedFileListEntireProject(projectId, editProjectData['languageId'], function (attachedFilesList) {
                attachedFilesListing = attachedFilesList;
                $scope.attachedFile1 = '';
                $scope.attachedFile2 = '';
                $scope.attachedFile3 = '';

                for (var i = 0; i < attachedFilesListing.length; i++) {
                    var j = i + 1;
                    $scope['attachedFile' + j] = attachedFilesList[i].Name;
                    $('#' + j).html($scope['attachedFile' + j]);
                }
                for (var i = attachedFilesListing.length + 1; i < 4; i++) {
                    var empty = "";
                    $('#' + i).html(empty);
                }
            });
        } else {
            LandingPageData.getAttachedFileList(projectId, editProjectData['languageId'], function (attachedFilesList) {
                attachedFilesListing = attachedFilesList;
                $scope.attachedFile1 = '';
                $scope.attachedFile2 = '';
                $scope.attachedFile3 = '';

                for (var i = 0; i < attachedFilesListing.length; i++) {
                    var j = i + 1;
                    $scope['attachedFile' + j] = attachedFilesList[i].Name;
                    $('#' + j).html($scope['attachedFile' + j]);
                }
                for (var i = attachedFilesListing.length + 1; i < 4; i++) {
                    var empty = "";
                    $('#' + i).html(empty);
                }
            });
        }
    }

    $scope.$on('addedFileDetails', function (event, myData, fileid) {

        if (myData[0].filename === $scope.attachedFile1 || myData[0].filename === $scope.attachedFile2 || myData[0].filename === $scope.attachedFile3) {
            $('#attachmentSave').modal('show');
            $('#attachmentSave .modal-body').html('File already exists!');
            $('#attachmentSave .modal-title').html('Duplicate file name');
        } else {
            if (myData[0].filesize <= 2000000) {
                $scope['attachedFile' + fileid] = myData[0].filename;
                $('#' + fileid).html($scope['attachedFile' + fileid]).css('color', '#333');
                attachedFiles.push(myData[0]);
            } else {
                $('#' + fileid).html('File size is (' + myData[0].filesize + ') exceeding 2MB.').css('color', 'red');
            }
        }
    });

     /**
     * @ngdoc
     * @name deleteFile
     * @methodOf Projects.controller:ProjectEditController
     * @description
     * This function is called on delete button on file upload.
     *@return {undefined} This method doed not return.
     */
    deleteFile = function (fileId) {
        editProjectData['languageId'] = ($scope.attachmentLanguageId > 0) ? $scope.attachmentLanguageId : 0;
        editProjectData['projectId'] = projectId;
        var deactiveteFileId = -1;
        if (attachedFilesListing[(fileId - 1)] != undefined) {
            deactiveteFileId = attachedFilesListing[(fileId - 1)].AttachmentId;
        }

        if (deactiveteFileId !== undefined && deactiveteFileId !== -1) {
            if (deactiveteFileId) {
                $scope.showLoader = true;
                LandingPageData.postDeleteAttachment(deactiveteFileId, projectId, editProjectData['languageId'], userDetails.UserId, editProjectData['OriginalUserId'], function (data) {
                    $scope.showLoader = false;
                    if (data === true) {
                        $('#attachmentSave').modal('show');
                        $scope.message = 'Attachment successfully deleted!';
                        $('#attachmentSave .modal-title').html('Delete Attachment');
                        deactiveteFileId = null;
                        $scope['attachedFile' + fileId] = '';
                        attachedFilesListing[(fileId - 1)].AttachmentId = 0;
                        $('#' + fileId).html($scope['attachedFile' + fileId]);
                    } else {
                        $('#attachmentSave').modal('show');
                        $scope.message = 'Attachment can not be deleted!';
                        $('#attachmentSave .modal-title').html('Delete Attachment');
                    }
                })
            }
        } else {
            for (i = 0; i < attachedFiles.length; i++) {
                if (attachedFiles[i].filename === $scope['attachedFile' + fileId]) {
                    var index = i;
                    break;
                }
            }
            attachedFiles.splice(index, 1);
            $scope['attachedFile' + fileId] = '';
            $('#' + fileId).html($scope['attachedFile' + fileId]);
        }
    };

      /**
     * @ngdoc
     * @name UploadAttachments
     * @methodOf Projects.controller:ProjectEditController
     * @description
     *This method is used to upload attachments.
     *@return {undefined} This method does not return.
     */
    $scope.UploadAttachments = function () {
        editProjectData['LanguageId'] = ($scope.attachmentLanguageId > 0) ? $scope.attachmentLanguageId : 0;
        editProjectData['ProjectId'] = projectId;
        editProjectData['files'] = attachedFiles;
        editProjectData['UserId'] = userDetails.UserId;

        if (editProjectData['files'].length > 0) {
            $scope.showLoader = true;
            LandingPageData.saveUploadAttachments(editProjectData, function (data) {
                $scope.showLoader = false;
                if (data === true) {
                    $('#attachmentSave').modal('show');
                    $('#attachmentSave .modal-title').html('Upload Attachment(s)');
                    $scope.message = 'Attachment(s) uploaded successfully!';
                } else {
                    $('#attachmentSave').modal('show');
                    $scope.message = 'Attachment(s) upload failed!';
                    $('#attachmentSave .modal-title').html('Upload Attachment(s)');
                }
            });
        } else {
            $('#attachmentSave').modal('show');
            $('#attachmentSave .modal-body').html('No Attachment(s) to upload!');
            $('#attachmentSave .modal-title').html('Upload Attachment(s)');
        }
        attachedFiles = [];
    }

    $scope.attachmentSaveClose = function (message) {
        $('#attachmentSave').modal('hide');
        if (message === 'Attachment(s) uploaded successfully!') {
            init();
        }
        $scope.message = '';
    }

    //allow only delete date in usdate, no typing, 8 for backspace, 46 for delete button
    $('.us-release-date').keydown(function (e) {
        var usReleaseDateInput = $(document.activeElement).hasClass('us-release-date');
        if ((e.keyCode === 8 || e.keyCode === 46) && (usReleaseDateInput)) {
            $('#usdate').val('');
            return true;
        } else {
            return false;
        }
    });

     /**
     * @ngdoc
     * @name saveProject
     * @methodOf Projects.controller:ProjectEditController
     * @param {string} redirectURL this url is used redirect user to either glossary or source setup or landing page.
     * @description
     *This method called on click of save project button on edit project page.this function sends the updated values to backend.
     *@return {undefined} This method does not return.
     */
    $scope.saveProject = function (redirectURL) {
        if ($scope.disableSaveButton === false) {
            $scope.disableSaveButton = true;

            $scope.redirectURL = redirectURL;
            if ($scope.Title) {
                check = true;
            }
            if (!mandatoryValidation()) {
                return false;
            }

            var promise = $scope.checkProjectNameBlur();
            promise.then(function (greeting) {
                if ($scope.SecureTitle) {
                    if ($('#usdate').val() === '') {
                        $('#releaseDateWarning').modal('show');
                        $scope.disableSaveButton = false;
                        return false;
                    }
                }

                //adding re-arranged category ids in an array
                rearrangedCategoryIds = [];
                for (var i = 0; i < $scope.selectCat.length; i++) {
                    rearrangedCategoryIds.push($scope.selectCat[i].Id);
                }


                $('.jumbotron .btn-save').attr('disabled', true);
                $('.save-prj .btn-save').attr('disabled', true);
                if (check === true) {

                    //image upload functionality
                    var x = document.getElementById("fileUpload");
                    var txt = "";
                    if ('files' in x) {
                        if (x.files.length === 0) {
                            txt = "Select one or more files.";
                        } else {
                            for (var i = 0; i < x.files.length; i++) {
                                txt += "<br><strong>" + (i + 1) + ". file</strong><br>";
                                var file = x.files[i];
                                if ('name' in file) {
                                    editProjectData['Filename'] = file.name;
                                    editProjectData['Fileext'] = file.name.substring(file.name.indexOf(".") + 1);
                                }
                                if ('size' in file) {
                                    editProjectData['Filesize'] = file.size;
                                }
                                if ('type' in file) {
                                    editProjectData['Filetype'] = file.type;
                                }
                                editProjectData['Filedata'] = $('.imagePreview img').attr('src').split(',')[1];
                            }
                        }
                    }

                    var categories = [];
                    var catLength = $scope.selectCat.length;
                    for (var i = 0; i < catLength; i++) {
                        categories.push($scope.selectCat[i].Id);
                    }
                    editProjectData['CategoriesIds'] = categories;

                    var languages = [];
                    var langLength = $scope.selectLang.length;
                    for (var i = 0; i < langLength; i++) {
                        languages.push($scope.selectLang[i].Id);
                    }
                    var sourceLanguages = [];
                    for (var i = 0; i < $scope.selectedLangSourceList.length; i++) {
                        sourceLanguages.push($scope.selectedLangSourceList[i].Id);
                    }

                    editProjectData['LanguagesIds'] = languages;
                    editProjectData['TranslationSourceRequiredLanguagesIds'] = sourceLanguages;
                    editProjectData['UserId'] = userDetails.UserId;
                    editProjectData['Title'] = $scope.Title;
                    editProjectData['SecureTitle'] = $scope.SecureTitle;

                    editProjectData['CategorySequence'] = rearrangedCategoryIds.toString();
                    //GLMGR -535
                    if ($('#usdate').val() === '') {
                        editProjectData['USReleaseDate'] = '';
                    } else {
                        editProjectData['USReleaseDate'] = $scope.UsReleaseDate;
                    }
                    //==GLMGR 535
                    editProjectData['DateCreated'] = $scope.ProjectEdit.ProjectModel.DateCreated;
                    if (!$scope.BrandId) {
                        $scope.BrandId = 0;
                    }
                    myDataBrandsNew = [];
                    for (var i = 0; i < finalBrands.length; i++) {
                        for (var j = 0; j < myDataBrands.length; j++) {
                            if (myDataBrands[j] === finalBrands[i].Id) {
                                myDataBrandsNew.push(myDataBrands[j]);
                                break;
                            }
                        }
                    }

                    editProjectData['BrandIds'] = myDataBrandsNew;
                    editProjectData['OldBrand'] = OldBrands;
                    editProjectData['ProjectId'] = projectId;
                    editProjectData['MasterLanguageId'] = $scope.MasterLanguageId;
                    editProjectData['OwnedById'] = [];

                    //get Project Status
                    if ($scope.IsActive === 'Active') {
                        editProjectData['IsActive'] = true;
                    } else {
                        editProjectData['IsActive'] = false;
                    }

                    editProjectData['OwnersEmailId'] = [];


                    editProjectData['ClientIds'] = myDataClients;

                    //Project Owner is mandatory
                    if (myDataOwners.length === 0 && AnswerGiven === false) {
                        $scope.isRequired.requiredOwner = true;
                        $('#ownerRequired').modal({ backdrop: 'static', keyboard: false });
                        $('#ownerRequired').modal('show');
                        return false;
                    } else {
                        for (var i = 0; i < myDataOwners.length; i++) {
                            editProjectData['OwnedById'].push(myDataOwners[i].Id);
                            editProjectData['OwnersEmailId'].push(myDataOwners[i].OwnerMailId);
                        }
                    }

                    if (createrIsOwner) {
                        editProjectData['OwnedById'].push(userDetails.UserId);
                        editProjectData['OwnersEmailId'].push(userDetails.UserName);
                    }

                    $scope.showLoader = true;

                    LandingPageData.saveEditedProject(editProjectData, function (status) {
                        if (status) {
                            $('#projectSave').modal({ backdrop: 'static', keyboard: false });
                            $('#projectSave').modal('show');
                            $('#projectSave .modal-body').html('Project changes are saved successfully!');
                            $('#projectSave .modal-title').html('Edit Project');
                            $scope.disableSaveButton = false;
                        } else {
                            $('#projectSave').modal({ backdrop: 'static', keyboard: false });
                            $('#projectSave').modal('show');
                            $('#projectSave .modal-body').html('Project changes are not saved!');
                            $('#projectSave .modal-title').html('Add Project');
                            $scope.disableSaveButton = false;
                        }
                    });

                }
            }, function (greet) {
            });
        }
    };

    //close popup
    $scope.dismissPopUp = function (redirectURL) {
        $('.modal-backdrop.fade.in').css('display', 'none');
        $('#duplicateProject').modal('hide');
        $('#projectSave').modal('hide');
        $('.jumbotron .btn-save').attr('disabled', false);
        $('.save-prj .btn-save').attr('disabled', false);
        $scope.showLoader = false;
        $scope.disableSaveButton = false;
        if (redirectURL === 'sourceSetup') {
            navSorceSetup();
        }
        if (redirectURL === 'glossary') {
            if ($scope.ProjectEdit.IsAllSectionInActive === true) {
                changeView('/');
            } else {
                changeView(redirectURL);
            }
        }
        if (redirectURL === 'project') {
            changeView(redirectURL);
        }
    };
    $scope.dismissDuplicateProjectPopUp = function () {
        $('.modal-backdrop.fade.in').css('display', 'none');
        $('#duplicateProject').modal('hide');
        $('.jumbotron .btn-save').attr('disabled', false);
        $('.save-prj .btn-save').attr('disabled', false);
        $scope.disableSaveButton = false;
    };

      /**
     * @ngdoc
     * @name categoryRemoveOk
     * @methodOf Projects.controller:ProjectEditController
     * @param {Array} unSelectedCat All categories  which are need to be removed. from selection.
     * @description
     *This method called on click of yes in popup when user try to remove categories  from selected categories .
     *@return {undefined} This method does not return.
     */
    $scope.categoryRemoveOk = function (unSelectedCat) {
        $('#categoryRemove').modal('hide');
        if (unSelectedCat === undefined || unSelectedCat.length === 0) {
            for (var i = 0 ; i < $scope.selectCat.length ; i++) {
                $scope.unSelectCat.push($scope.selectCat[i]);
            }
            $scope.selectCat = [];
        } else {
            for (var i = 0 ; i < unSelectedCat.length ; i++) {
                $scope.unSelectCat.push(unSelectedCat[i]);
                var index = $scope.selectCat.indexOf(unSelectedCat[i]);
                if (index > -1) {
                    $scope.selectCat.splice(index, 1);
                }
            }
        }
    };

    /**
     * @ngdoc
     * @name languageRemoveOk
     * @methodOf Projects.controller:ProjectEditController
     * @param {Array} unSelectedLang All languages which are need to be removed. from selection.
     * @description
     *This method called on click of yes in popup when user try to remove languages from selected categories .
     *@return {undefined} This method does not return.
     */
    $scope.languageRemoveOk = function (unSelectedLang) {
        $('#languageRemove').modal('hide');
        if (unSelectedLang === undefined || unSelectedLang.length === 0) {
            for (var i = 0 ; i < $scope.selectLang.length ; i++) {
                $scope.unSelectLang.push($scope.selectLang[i]);
            }
            $scope.selectLang = [];
            $scope.selectedLangSourceList = [];
            $scope.sourceUnSelectLang = [];
        } else {
            for (var i = 0 ; i < $scope.unSelectedLang.length ; i++) {
                $scope.unSelectLang.push($scope.unSelectedLang[i]);
                var flag = false;
                for (var j = 0; j < $scope.selectLang.length; j++) {
                    if ($scope.selectLang[j].Id === $scope.unSelectedLang[i].Id) {
                        $scope.selectLang.splice(j, 1);
                        break;
                    }
                }
                for (var j = 0; j < $scope.unSelectedLangSourceList.length; j++) {
                    if ($scope.unSelectedLangSourceList[j].Id === $scope.unSelectedLang[i].Id) {
                        $scope.unSelectedLangSourceList.splice(j, 1);
                        flag = true;
                        break;
                    }
                }
                if (flag === false) {
                    for (var j = 0; j < $scope.selectedLangSourceList.length; j++) {
                        if ($scope.selectedLangSourceList[j].Id === $scope.unSelectedLang[i].Id) {
                            $scope.selectedLangSourceList.splice(j, 1);
                            break;
                        }
                    }
                }
            }

            var temp = [];
            angular.copy($scope.selectLang, temp);
            $scope.selectLang = [];
            $timeout(function () { $scope.selectLang = temp }, 20);

        }
    };

    /**
     * @ngdoc
     * @name moveUpClick
     * @methodOf Projects.controller:ProjectEditController
     * @description
     *This method is used to change the sequence of selected categories .
     *@return {undefined} This method does not return.
     */
    $scope.moveUpClick = function () {
        var idx = $scope.selectCat.indexOf($scope.unSelectedCat[0]);
        if (idx > 0) {
            var itemToMove = $scope.selectCat.splice(idx, 1);
            $scope.selectCat.splice(idx - 1, 0, itemToMove[0]);
        }
    };

    /**
     * @ngdoc
     * @name moveDownClick
     * @methodOf Projects.controller:ProjectEditController
     * @description
     *This method is used to change the sequence of selected categories .
     *@return {undefined} This method does not return.
     */
    $scope.moveDownClick = function () {
        for (var i = 0; i < $scope.unSelectedCat.length; i++) {
            var idx = $scope.selectCat.indexOf($scope.unSelectedCat[i]);
            if (idx < $scope.selectCat.length) {
                var itemToMove = $scope.selectCat.splice(idx, 1);
                $scope.selectCat.splice(idx + 1, 0, itemToMove[0]);
            }
        }
    };

    /**
     * @ngdoc
     * @name changeView
     * @methodOf Projects.controller:ProjectEditController
     * @param {string} new_path The Name of the view bound with element on which this fuction is called.

     * @description
     * This function is called to change views and loads respective html page.Below are some views
     * Glossary, Source Setup, Add project, Edit Project,Project Permissions,Project Info
     * @returns {undefined} This method does not return.
     */
    var changeView = function (new_path) {
        switch (new_path) {
            case "glossary":
                $location.path('/editProject/glossary');
                break;

            case "sourceSetup":
                sessionStorage.setItem('ActiveSectionType', "1");
                sessionStorage.setItem('SourceSetupActiveSection', '');
                sessionStorage.setItem('isShowRemovedTermsFlag', '0');
                sessionStorage.setItem('hideInfoColumns', '0');
                sessionStorage.setItem('hideTermUniqueID', '0');
                sessionStorage.setItem('hideStarred', '0');
                sessionStorage.setItem('ishideStarred', '0');
                $location.path('/editProject/sourceSetup');
                break;

            case "project":
                $location.path('/');
                break;
            case "/":
                $location.path('/');
                break;
        }
    };
    
    /**
     * @ngdoc
     * @name translationSourcePopup
     * @methodOf Projects.controller:ProjectEditController
     * @description
     *This method called on click of Translation source button on edit project page. Which is used to edit translation source required language to project.
     *@return {undefined} This method does not return.
     */
    $scope.translationSourcePopup = function () {
        if ($scope.selectLang && $scope.selectLang.length > 0) {


            for (var i = 0; i < $scope.selectLang.length; i++) {
                var flag = false;
                for (var j = 0; j < $scope.selectedLangSourceList.length; j++) {
                    if ($scope.selectedLangSourceList[j].Id === $scope.selectLang[i].Id) {
                        flag = true;
                        break;
                    }
                }
                if (flag === false) {
                    for (var j = 0; j < $scope.unSelectedLangSourceList.length; j++) {
                        if ($scope.unSelectedLangSourceList[j].Id === $scope.selectLang[i].Id) {
                            flag = true;
                            break;
                        }
                    }
                }
                if (flag === false) {
                    $scope.unSelectedLangSourceList.push($scope.selectLang[i]);
                }
            }
            $('#translationSourcePopup').modal({ backdrop: 'static', keyboard: false });
            $('#translationSourcePopup').modal('show');
        } else {
            $('#translationSourceErrorPopup').modal('show');
        }
    };

      /**
     * @ngdoc
     * @name clearTransSourceLang
     * @methodOf Projects.controller:ProjectEditController
     * @description
     *This method called on click of Clear All button on edit project page. Which is used to Clear added languages.
     *@return {undefined} This method does not return.
     */
    $scope.clearTransSourceLang = function () {
        $scope.selectedLangSourceList = [];
        $scope.unSelectedLangSourceList = [];
        for (var i = 0; i < $scope.selectLang.length; i++) {
            $scope.selectLang[i].TranslationSourceRequired = false;
            $scope.unSelectedLangSourceList.push($scope.selectLang[i]);
        }
        var temp = [];
        angular.copy($scope.selectLang, temp);
        $scope.selectLang = [];
        $timeout(function () { $scope.selectLang = temp }, 20);
    };

     /**
     * @ngdoc
     * @name moveSourceSelectedlang
     * @methodOf Projects.controller:ProjectEditController
     * @description
     *This method called on right move button on translation source popup. Which is used to move languages to right (select languages).
     *@return {undefined} This method does not return.
     */
    $scope.moveSourceSelectedlang = function () {
        if ($scope.sourceSelectLang && $scope.sourceSelectLang.length > 0) {
            for (var i = 0 ; i < $scope.sourceSelectLang.length ; i++) {
                $scope.sourceSelectLang[i].TranslationSourceRequired = true;
                $scope.selectedLangSourceList.push($scope.sourceSelectLang[i]);
                for (var j = 0; j < $scope.unSelectedLangSourceList.length; j++) {
                    if ($scope.unSelectedLangSourceList[j].Id === $scope.sourceSelectLang[i].Id) {
                        $scope.unSelectedLangSourceList.splice(j, 1);
                        break;
                    }
                }
            }
            for (var i = 0 ; i < $scope.selectedLangSourceList.length ; i++) {
                for (var j = 0; j < $scope.selectLang.length; j++) {
                    if ($scope.selectLang[j].Id === $scope.selectedLangSourceList[i].Id) {
                        $scope.selectLang[j].TranslationSourceRequired = true;
                        break;
                    }
                }
            }
        }
        var temp = [];
        angular.copy($scope.selectLang, temp);
        $scope.selectLang = [];
        $timeout(function () { $scope.selectLang = temp }, 20);
    };
    
     /**
     * @ngdoc
     * @name moveSourceUnSelectedSections
     * @methodOf Projects.controller:ProjectEditController
     * @description
     *This method called on left move button on translation source popup. Which is used to move languages to left (unselect languages).
     *@return {undefined} This method does not return.
     */
    $scope.moveSourceUnSelectedLang = function () {
        if ($scope.sourceUnSelectLang && $scope.sourceUnSelectLang.length > 0) {
            for (var i = 0 ; i < $scope.sourceUnSelectLang.length ; i++) {
                $scope.sourceUnSelectLang[i].TranslationSourceRequired = false;
                $scope.unSelectedLangSourceList.push($scope.sourceUnSelectLang[i]);
                for (var j = 0; j < $scope.selectedLangSourceList.length; j++) {
                    if ($scope.selectedLangSourceList[j].Id === $scope.sourceUnSelectLang[i].Id) {
                        $scope.selectedLangSourceList.splice(j, 1);
                        break;
                    }
                }
            }
        }
        for (var i = 0 ; i < $scope.unSelectedLangSourceList.length ; i++) {
            for (var j = 0; j < $scope.selectLang.length; j++) {
                if ($scope.selectLang[j].Id === $scope.unSelectedLangSourceList[i].Id) {
                    $scope.selectLang[j].TranslationSourceRequired = false;
                    break;
                }
            }
        }

        var temp = [];
        angular.copy($scope.selectLang, temp);
        $scope.selectLang = [];
        $timeout(function () { $scope.selectLang = temp }, 20);
    };


    //Clearing all the selected languages from the left side of the list
    $scope.clearLang = function () {
        if ($scope.selectLang.length > 0) {
            $('#languageRemove .modal-body').html('Data may be associated with selected language(s). Do you still want to remove it?');
            $('#languageRemove').modal('show');
        }
    };

    //Clearing all the selected categories from the left side of the list    
    $scope.clearCat = function () {
        if ($scope.selectCat.length > 0) {
            $('#categoryRemove .modal-body').html('Data may be associated with the Additional Information option(s). Do you still want to remove it?');
            $('#categoryRemove').modal('show');
        }
    };

     /**
     * @ngdoc
     * @name AddNewcategoryButtonClick
     * @methodOf Projects.controller:ProjectEditController
     * @description
     *This method called on Add category button.
     *@return {undefined} This method does not return.
     */
    $scope.AddNewcategoryButtonClick = function () {
        $scope.addNewCategoryClickDisabled = false;
        $('#category-message').hide();
        $('#category-lang-message').hide();
        $scope.newCategory = '';
    };

     /**
     * @ngdoc
     * @name showEditCategoryPopup
     * @methodOf Projects.controller:ProjectEditController
     * @description
     *This method called on Edit category button opens popup.
     *@return {undefined} This method does not return.
     */
    $scope.showEditCategoryPopup = function () {
        $scope.requiredCategory = false;
        angular.copy($scope.selectedCat[0], $scope.editCategory);
        $('#Editcategory').modal('show');
    };

    $scope.cancelEditCategoryPopup = function () {
        $scope.requiredCategory = '';
        $('#category-message-edit').hide();
        $('#category-lang-message-edit').hide();
    };

    /**
     * @ngdoc
     * @name editCategoryClick
     * @methodOf Projects.controller:ProjectEditController
     * @param {Object} editCategory this object contains details of category to be edited.
     * @description
     *This method called to Edit category name.
     *@return {undefined} This method does not return.
     */
    $scope.editCategoryClick = function (editCategory) {
        var catFlag = false;
        var catlangFlag = false;
        var selectedCatFlag = false;

        if (!$scope.editCategory.CategoryName) {
            $scope.requiredCategory = true;
            return false;
        }
        else {
            $('#category-message-edit').hide();
            for (var i = 0; i < CopyOfAllCategories.length; i++) {
                if ($scope.editCategory.CategoryName.toLowerCase() === CopyOfAllCategories[i].CategoryName.toLowerCase()) {
                    $('#category-message-edit').show();
                    $scope.requiredCategory = false;
                    catFlag = true;
                    break;
                }
                else {
                    catFlag = false;
                }
            }
            for (var i = 0; i < $scope.selectCat.length; i++) {
                if ($scope.editCategory.CategoryName.toLowerCase() === $scope.selectCat[i].CategoryName.toLowerCase()) {
                    $('#category-message-edit').show();
                    $scope.requiredCategory = false;
                    selectedCatFlag = true;
                    break;
                }
                else {
                    selectedCatFlag = false;
                }
            }
            for (var i = 0; i < CopyOfAllLanguages.length; i++) {
                if ($scope.editCategory.CategoryName.toLowerCase() === CopyOfAllLanguages[i].LanguageName.toLowerCase()) {
                    $('#category-lang-message-edit').show();
                    $scope.editCategory.Id = CopyOfAllLanguages[i].Id;
                    catlangFlag = true;
                    break;
                }
                else {
                    catlangFlag = false;
                }
            }
            if (catFlag !== true && catlangFlag !== true && selectedCatFlag !== true) {
                //Service Call for edit category
                var editedLocalCategory = {};
                editedLocalCategory['categoryId'] = $scope.editCategory.Id;
                editedLocalCategory['categoryName'] = $scope.editCategory.CategoryName;
                editedLocalCategory['projectId'] = projectId;

                //original userid GLMGR-1103
                editedLocalCategory['UserId'] = userDetails.UserId;
                if ($scope.adminUser) {
                    editedLocalCategory['OriginalUserId'] = $scope.adminUser.UserId;
                } else {
                    editedLocalCategory['OriginalUserId'] = null;
                }

                LandingPageData.updateLocalCategory(editedLocalCategory, function (status) {
                    if (status) {
                        $('#Editcategory').modal('hide');
                        init();
                    }
                });
            }
        }
    };

      /**
     * @ngdoc
     * @name deleteLocalCategory
     * @methodOf Projects.controller:ProjectEditController
     * @description
     *This method called to delete selected categories .
     *@return {undefined} This method does not return.
     */
    $scope.deleteLocalCategory = function () {
        var deletedLocalCategory = {};
        deletedLocalCategory['categoryId'] = $scope.selectedCat[0].Id;
        deletedLocalCategory['categoryName'] = $scope.selectedCat[0].CategoryName;
        deletedLocalCategory['projectId'] = projectId;

        //original userid GLMGR-1103
        deletedLocalCategory['UserId'] = userDetails.UserId;
        if ($scope.adminUser) {
            deletedLocalCategory['OriginalUserId'] = $scope.adminUser.UserId;
        } else {
            deletedLocalCategory['OriginalUserId'] = null;
        }
        LandingPageData.deleteLocalCategory(deletedLocalCategory, function (status) {
            if (status) {
                $('#deleteCategoryConfirm').modal('hide');
                init();
            }
        });
    };

    $scope.addNewCategoryBlur = function () {
        $('#category-message').hide();
        $('#category-lang-message').hide();
    };

    /**
     * @ngdoc
     * @name addNewCategoryClick
     * @methodOf Projects.controller:ProjectEditController
     * @param {String} newCategory This is category name to be added newly
     * @description
     *This method called to Edit category name.
     *@return {undefined} This method does not return.
     */
    $scope.addNewCategoryClick = function (newCategory) {
        var catlangFlag = false;
        if (!$scope.newCategory) {
            $scope.requiredCategory = true;
            return false;
        }
        else {
            $('#category-message').hide();
            for (var i = 0; i < $scope.ProjectEdit.AllCategories.length; i++) {
                if ($scope.newCategory.toLowerCase() === $scope.ProjectEdit.AllCategories[i].CategoryName.toLowerCase()) {
                    $('#category-message').show();
                    var catFlag = true;
                    break;
                }
            }
            for (var i = 0; i < $scope.ProjectEdit.AllLanguages.length; i++) {
                if ($scope.newCategory.toLowerCase() === $scope.ProjectEdit.AllLanguages[i].LanguageName.toLowerCase()) {
                    $('#category-lang-message').show();
                    catlangFlag = true;
                    break;
                }
            }
            if (catFlag !== true && catlangFlag !== true) {
                var newCat = {};
                newCat['CategoryName'] = $scope.newCategory;
                newCat['projectId'] = projectId;
                newCat['UserId'] = userDetails.UserId;

                //original userid to add new cat GLMGR-1103
                if ($scope.adminUser) {
                    newCat['OriginalUserId'] = $scope.adminUser.UserId;
                } else {
                    newCat['OriginalUserId'] = null;
                }
                LandingPageData.addNewCategory(newCat, function (data) {
                    newCat['Id'] = data;
                    if (data === 0) {
                        $('#category-message').show();
                        var catFlag = true;
                    } else {
                        $scope.unSelectCat.push(newCat);
                        $scope.newCategory = "";
                        $('#AddNewcategory').modal('hide');
                        $scope.addNewCategoryClickDisabled = true;
                    }
                });
            }
        }
    };

    /**
     * @ngdoc
     * @name checkProjectNameBlur
     * @methodOf Projects.controller:ProjectEditController
     * @description
     *This method used to check Project Name for duplication.
     *@return {undefined} This method does not return.
     */
    $scope.checkProjectNameBlur = function () {
        $scope.deferred = $q.defer();
        var ProjectTitle = {};
        ProjectTitle.ProjectTitleInput = $scope.Title;
        if ($scope.Title !== $scope.ProjectEdit.ProjectModel.ProjectTitle) {
            LandingPageData.getProjectList(ProjectTitle, function (data) {
                if (data === true) {
                    $('#duplicateProject').modal({ backdrop: 'static', keyboard: false });
                    $('#duplicateProject').modal('show');
                    $('.jumbotron .btn-save').attr('disabled', true);
                    $('.save-prj .btn-save').attr('disabled', true);
                    check = false;
                    $scope.deferred.reject(true);
                } else {
                    $('.jumbotron .btn-save').attr('disabled', false);
                    $('.save-prj .btn-save').attr('disabled', false);
                    check = true;
                    $scope.deferred.resolve(true);
                }
            });
        }
        else {
            $('.jumbotron .btn-save').attr('disabled', false);
            $('.save-prj .btn-save').attr('disabled', false);
            check = true;
            $scope.deferred.resolve(true);
        }
        return $scope.deferred.promise;
    };
    
     /**
     * @ngdoc
     * @name checkProjectNameBlurDup
     * @methodOf Projects.controller:ProjectEditController
     * @description
     *This method used to check Project Name for duplication on blur function of project title.
     *@return {undefined} This method does not return.
     */
    $scope.checkProjectNameBlurDup = function () {
        var ProjectTitle = {};
        ProjectTitle.ProjectTitleInput = $scope.Title;

        if ($scope.Title !== $scope.ProjectEdit.ProjectModel.ProjectTitle) {
            LandingPageData.getProjectList(ProjectTitle, function (data) {
                if (data === true) {
                    $('#duplicateProject').modal({ backdrop: 'static', keyboard: false });
                    $('#duplicateProject').modal('show');
                    $('.jumbotron .btn-save').attr('disabled', true);
                    $('.save-prj .btn-save').attr('disabled', true);
                    check = false;
                } else {
                    $('.jumbotron .btn-save').attr('disabled', false);
                    $('.save-prj .btn-save').attr('disabled', false);
                    check = true;
                }
            });
        }
        else {
            $('.jumbotron .btn-save').attr('disabled', false);
            $('.save-prj .btn-save').attr('disabled', false);
            check = true;
        }
    };

    /**
     * @ngdoc
     * @name mandatoryValidation
     * @methodOf Projects.controller:ProjectEditController
     * @description
     *This method is used to validate all the fields on edit project form.
     *@return {Boolean} This method returns true/false depending on validation.
     */
    var mandatoryValidation = function () {
        if ($scope.Title === undefined && myDataClients.length == 0) {
            $scope.isRequired.requiredTitle = true;
            $scope.isRequired.requiredClients = true;
            return false;
        }
        else if (myDataClients.length === 0 && $scope.Title !== undefined) {
            $scope.isRequired.requiredClients = true;
            if ($scope.Title !== undefined) {
                $scope.isRequired.requiredTitle = false;
            }
            return false;
        }
        else if ($scope.Title === undefined && myDataClients.length > 0) {
            $scope.isRequired.requiredTitle = true;
            if (myDataClients.length > 0) {
                $scope.isRequired.requiredClients = false;
            }
            return false;
        }
        else {
            $scope.isRequired.requiredTitle = false;
            $scope.isRequired.requiredClients = false;
            return true;
        }
    };

      /**
     * @ngdoc
     * @name mandatoryValidationOnChange
     * @methodOf Projects.controller:ProjectEditController
     * @description
     *This method is used to validate title and clients fields on change.
     *@return {Boolean} This method returns true/false depending on validation.
     */
    $scope.mandatoryValidationOnChange = function (model) {
        switch (model) {
            case 'Title':
                if ($scope.Title !== undefined) {
                    $scope.isRequired.requiredTitle = false;
                }
                else {
                    $scope.isRequired.requiredTitle = true;
                }
                break;

            case 'Clients':
                if (myDataClients.length > 0) {
                    $scope.isRequired.requiredClients = false;
                }
                else {
                    $scope.isRequired.requiredClients = true;
                }
                break;
        }
    };

    /**
     * @ngdoc
     * @name getProjectEditData
     * @methodOf Projects.controller:ProjectEditController
     * @description
     *This method is used to load initial project data.
     *@return {Boolean} This method returns true/false depending on validation.
     */
    var getProjectEditData = function () {
        LandingPageData.getPageEditData(projectId, userDetails.UserId, userRole, function (projects) {
            //default values load
            $scope.ProjectEdit = projects;
            OwnersList.Owners = $scope.ProjectEdit.Owners;
            OwnersList.OwnersGroup = $scope.ProjectEdit.OwnersGroup;
            if ($scope.ProjectEdit.ProjectModel.OldUsReleaseDate === '') {
                $scope.UsReleaseDate = '';
            } else {
                $scope.UsReleaseDate = $scope.ProjectEdit.ProjectModel.OldUsReleaseDate;
            }

            $('#usdate').val($scope.ProjectEdit.ProjectModel.OldUsReleaseDate);
            $('#usdate').datepicker({
                format: "yyyy-mm-dd"
            });

            $('#usdate').datepicker()
           .on('changeDate', function (ev) {
               $scope.UsReleaseDate = $('#usdate').val();
           });

            $("#mainDiv").scroll(function () {
                $('#usdate').datepicker('hide');
                $('#usdate').blur();
            });

            $scope.ObjectId1 = [];
            myDataOwners = $scope.ObjectId1;


            $scope.Title = $scope.ProjectEdit.ProjectModel.ProjectTitle;
            $scope.SecureTitle = $scope.ProjectEdit.ProjectModel.SecureTitle;
            $scope.BrandId = $scope.ProjectEdit.ProjectModel.BrandId;
            $scope.ClientId = $scope.ProjectEdit.ProjectModel.ClientId;
            $scope.MasterLanguageId = $scope.ProjectEdit.ProjectModel.MasterLanguageId;

            angular.copy($scope.ProjectEdit.AllCategories, CopyOfAllCategories);

            angular.copy($scope.ProjectEdit.AllLanguages, CopyOfAllLanguages);


            for (var i = 0; i < $scope.ProjectEdit.ProjectModel.Clientlist.length; i++) {
                myDataClients.push($scope.ProjectEdit.ProjectModel.Clientlist[i].ClientId);
            }
            //adding selected languages to selectedLang array to show in the right side of the list
            for (var i = 0; i < $scope.ProjectEdit.ProjectLanguages.length; i++) {
                $scope.selectLang.push($scope.ProjectEdit.ProjectLanguages[i]);
                $scope.sourceUnSelectLang.push($scope.ProjectEdit.ProjectLanguages[i]);
            }
            for (var i = 0; i < $scope.ProjectEdit.ProjectTranslationRequiredSourceLanguages.length; i++) {
                for (var j = 0; $scope.ProjectEdit.ProjectLanguages.length; j++) {
                    if ($scope.ProjectEdit.ProjectTranslationRequiredSourceLanguages[i].Id === $scope.ProjectEdit.ProjectLanguages[j].Id) {
                        $scope.selectedLangSourceList.push($scope.ProjectEdit.ProjectLanguages[j]);
                        var index = $scope.sourceUnSelectLang.indexOf($scope.ProjectEdit.ProjectLanguages[j]);
                        if (index > -1) {
                            $scope.sourceUnSelectLang.splice(index, 1);
                        }
                        break;
                    }
                }
            }
            //adding unselected languages to the unSelectLang array to show in left side of the list
            for (var i = 0; i < $scope.ProjectEdit.ProjectsUnselectedLangaues.length; i++) {
                $scope.unSelectLang.push($scope.ProjectEdit.ProjectsUnselectedLangaues[i]);
            }
            //adding seletced categories to the selectCat array to show in the right side of the list
            for (var i = 0; i < $scope.ProjectEdit.ProjectCategories.length; i++) {
                $scope.selectCat.push($scope.ProjectEdit.ProjectCategories[i]);
            }
            //adding unselected categories to the unSelectCat array to show in the left side of the list
            for (var i = 0; i < $scope.ProjectEdit.AllCategories.length; i++) {
                $scope.unSelectCat.push($scope.ProjectEdit.AllCategories[i]);
            }
            //get Project Status
            if ($scope.ProjectEdit.ProjectModel.IsActive === true) {
                $scope.IsActive = 'Active';
            } else {
                $scope.IsActive = 'Inactive';
            }
            ///multiselect checkbox dropdown
            $('.jumbotron .btn-save').attr('disabled', false);
            $scope.roles = $scope.ProjectEdit.AllClients;
            $scope.OwnerRoles = $scope.ProjectEdit.Owners;

            // don't change the sequence of next 2 consecutive mutually exclusive  for loops here
            for (var j = 0; j < $scope.ProjectEdit.ProjectOwnersInfo.length; j++) {

                for (var i = 0; i < $scope.OwnerRoles.length; i++) {
                    if ($scope.OwnerRoles[i].Id === $scope.ProjectEdit.ProjectOwnersInfo[j].OwnerId) {
                        myDataOwners.push($scope.OwnerRoles[i]);
                        break;
                    }
                }
            }

            //load initial brands
            showCommmonBrands(myDataClients);

            $scope.BrandRoles = finalBrands;
            $scope.member = { roles: [] };
            $scope.OwnerMember = { OwnerRoles: [] };
            $scope.brandMember = { BrandRoles: [] };
            $scope.ObjectId = [];
            $scope.ObjectId2 = [];

            $scope.owner_str = '';
            for (var i = 0; i < $scope.ProjectEdit.ProjectOwnersInfo.length; i++) {
                $scope.owner_str = $scope.owner_str + $scope.ProjectEdit.ProjectOwnersInfo[i].OwnerName + ', ';
            }
            $scope.owner_str = $scope.owner_str.slice(0, -2);
            if ($scope.ProjectEdit.ProjectOwnersInfo.length > 0) {
                $('.owner_str').html($scope.owner_str);
                $('.owner_str').attr('title', $scope.owner_str);
            }
            else {
                $('.owner_str').html('Select Owner(s)');
                $('.owner_str').attr('title', 'Select Owner(s)');
            }

            client_str = '';
            for (var i = 0; i < $scope.ProjectEdit.ProjectModel.Clientlist.length; i++) {
                $scope.ObjectId.push($scope.ProjectEdit.ProjectModel.Clientlist[i].ClientId);
                client_str = client_str + $scope.ProjectEdit.ProjectModel.Clientlist[i].ClientName + ', ';
            }
            client_str = client_str.slice(0, -2);
            if ($scope.ProjectEdit.ProjectModel.Clientlist.length > 0) {
                $('.client_str').html(client_str);
                $('.client_str').attr('title', client_str);
            }
            else {
                $('.client_str').html('Select Client(s)');
                $('.client_str').attr('title', 'Select Client(s)');
            }

            brand_str = '';
            for (var i = 0; i < $scope.ProjectEdit.ProjectModel.ProjectBrands.length; i++) {
                $scope.ObjectId2.push($scope.ProjectEdit.ProjectModel.ProjectBrands[i].Id);
                brand_str = brand_str + $scope.ProjectEdit.ProjectModel.ProjectBrands[i].BrandName + ', ';
                myDataBrands.push($scope.ProjectEdit.ProjectModel.ProjectBrands[i].Id);
            }
            brand_str = brand_str.slice(0, -2);
            if ($scope.ProjectEdit.ProjectModel.ProjectBrands.length > 0) {
                $('.brand_str').html(brand_str);
                $('.brand_str').attr('title', brand_str);
            }
            else {
                $('.brand_str').html('Select Brand(s)');
                $('.brand_str').attr('title', 'Select Brand(s)');
            }

            //Load attached files (if available) for all Projects on initial Page load
            $('#attachmentSave .close').hide();
            $scope.attachmentLanguageId = 0;
            LandingPageData.getAttachedFileListEntireProject(projectId, $scope.attachmentLanguageId, function (attachedFilesList) {
                attachedFilesListing = attachedFilesList;
                $scope.attachedFile1 = '';
                $scope.attachedFile2 = '';
                $scope.attachedFile3 = '';
                for (i = 0; i < attachedFilesListing.length; i++) {
                    var j = i + 1;
                    $scope['attachedFile' + j] = attachedFilesList[i].Name;
                    $('#' + j).html($scope['attachedFile' + j]);
                }
                for (var i = attachedFilesListing.length + 1; i < 4; i++) {
                    var empty = "";
                    $('#' + i).html(empty);
                }

                $scope.showLoader = false;
            });
        });
    }
    $scope.getTimeStamp = function () {
        return Math.floor(Date.now() / 1000);
    }
    
    /**
     * @ngdoc
     * @name init
     * @methodOf Projects.controller:ProjectEditController
     * @description
     *This method is called at the beginning of page load and used for initialisation of variables on page load
     *@return {undefined} This method does not return.
     */
    var init = function () {
        //initialisation of variables on page load     
        $scope.UsReleaseDate = new Date('yyyy/MM/dd');
        $scope.selectLang = [];
        $scope.unSelectLang = [];
        $scope.selectCat = [];
        $scope.unSelectCat = [];
        myDataOwners = [];
        $scope.IsSave = false;
        $scope.showLoader = true;

        var temp = [];
        sessionStorage.setItem('gridContextInstance', JSON.stringify(temp));
        sessionStorage.setItem('GlossarySection', JSON.stringify(null));
        sessionStorage.setItem('gridContextSaved', JSON.stringify(false));

        //Get the Project edited data
        getProjectEditData();
        dynamicScreenHeight();
    };

    init();

}]);