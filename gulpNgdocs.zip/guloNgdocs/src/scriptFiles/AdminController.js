/**
 * @ngdoc controller
 * @name Admin.controller:AdminController
 * @element div
 *
 * @description
 * This Controller is responsible for all the operations done on the admin page
 *
 * @requires AngularJS.$scope
 * @requires AngularJS.$http
 * @requires AngularJS.$route
 * @requires AngularJS.$timeout
 * @requires common.commonService
 * @requires Admin.AdminService
 * 
 * @property {number} userId:Number  This property is user id of logged in user.
 * @property {object} clientlist:Object This object contains the list of all clients.
 * @property {object} brandlist:Object This object contains the list of all associated brands to clients.
 * @property {object} categorylist:Object This object contains the list of all associated categories to clients.
 * @property {object} sectionlist:Object This object contains the list of all associated sections to clients.
 * @property {boolean} isExistingClient:Boolean This property is boolean value to check if client already exist.
 * @property {boolean} isExistingBrand:Boolean This property is boolean value to check if brand already exist.
 * @property {boolean} isExistingCategory:Boolean This property is boolean value to check if category already exist.
 * @property {boolean} isExistingSection:Boolean This property is boolean value to check if section already exist.
 * @property {Array} globalCategories:Array This property is array all global categories
 * 
 */
Admin.controller('adminController', ['$scope', '$http', '$timeout', 'commonService', 'AdminService', function ($scope, $http, $timeout, commonService, AdminService) {
    var userId = commonService.getLocalData('userDetails').UserId;
    $scope.clientlist = {};
    $scope.brandlist = {};
    $scope.categorylist = {};
    $scope.sectionlist = {};
    var isBlankClient = false;
    $scope.isExistingClient = false;
    var isBlankBrand = false;
    $scope.isExistingBrand = false;
    var isBlankCategory = false;
    $scope.isExistingCategory = false;
    var isBlankSection = false;
    $scope.isExistingSection = false;
    $scope.isNTLStringPresent = false;
    $scope.showLoader = false;
    var copyglobalCategories = [];
    var clientlistcopy = {};
    var ClientListLength;
    $scope.SuccessMessage = '';
    $scope.clientsTab = true;
    var selectedClientId;
    $scope.maxlenErrorCname = false;

    //set hashURL for GLMGR-1189
    sessionStorage.setItem('hashURL', null);

    /**
      * @ngdoc
      * @name checkMaxLen
      * @methodOf Admin.controller:AdminController
      * @param {String} name This is name entered in input fields.
      * @param {String} popup This is name of popup
      * @description
      * This function is called on change of input fields on admin page. This function is used to check max length for client,brand,section name
      * @returns {undefined} This method does not return.
      */
    $scope.checkMaxLen = function (name, popup) {
        if (popup === 'catName') {
            if (name.length > 30) {
                $scope.maxlenErrorCatname = true;
            } else {
                $scope.maxlenErrorCatname = false;
            }
        }
        if (name.length > 40) {
            if (popup === 'clientName') {
                $scope.maxlenErrorCname = true;
            }
            if (popup === 'brandName') {
                $scope.maxlenErrorBname = true;
            }
            if (popup === 'SectionName') {
                $scope.maxlenErrorSname = true;
            }
        } else {
            if (popup === 'clientName') {
                $scope.maxlenErrorCname = false;
            }
            if (popup === 'brandName') {
                $scope.maxlenErrorBname = false;
            }
            if (popup === 'SectionName') {
                $scope.maxlenErrorSname = false;
            }
        }
    };

    /**
      * @ngdoc
      * @name populateBrand
      * @methodOf Admin.controller:AdminController
      * @param {Object} clientsel This is object which contains details about selected client from client select box. 
      * @description
      * This function is called on change of left select box value in brands tab on admin page. This function is used to get associated brands for selected clients.
      * @returns {undefined} This method does not return.
      */
    $scope.populateBrand = function (clientsel) {
        if (clientsel) {
            $scope.brandlist = clientsel.ClientBrandList;
            $scope.categorylist = clientsel.ClientCategoryList;
            $scope.sectionlist = clientsel.ClientSectionList;
        }
    };

    /**
      * @ngdoc
      * @name AddClient
      * @methodOf Admin.controller:AdminController
      * @description
      * This function is called on ok button on add client popup. This method is used to add new client.
      * @returns {undefined} This method does not return.
      */
    $scope.AddClient = function () {
        if ($scope.maxlenErrorCname) {
            return false;
        }
        for (var i = 0; i < ClientListLength; i++) {
            if (($scope.newClient).toLowerCase() === ($scope.clientlist.ClientList[i].ClientName).toLowerCase()) {
                $scope.isExistingClient = true;
                return false;
            }
        }
        var addNewClient = {};
        addNewClient['ClientName'] = $scope.newClient;
        $('#addNewClient').modal('hide');
        //service to add new client
        AdminService.addClient(addNewClient, function (status) {
            init();
            $scope.SuccessMessage = '"' + $scope.newClient + '" Client added successfully!';
            $timeout(function () {
                $scope.SuccessMessage = '';
                $scope.newClient = "";
            }, 3000);
            $scope.isExistingClient = false;
        })
    };

     /**
      * @ngdoc
      * @name EditClient
      * @methodOf Admin.controller:AdminController
      * @description
      * This function is called on ok button on edit client popup. This method is used to edit client name.
      * @returns {undefined} This method does not return.
      */
    $scope.EditClient = function () {
        if ($scope.maxlenErrorCname) {
            return false;
        }
        for (var i = 0; i < ClientListLength; i++) {
            if (($scope.editClientName.ClientName).toLowerCase() === (clientlistcopy.ClientList[i].ClientName).toLowerCase()) {

                $scope.isExistingClient = true;
                return false;
            }
        }
        $('#editClient').modal('hide');
        //service call to edit client
        AdminService.editClient($scope.editClientName, function (status) {
            $scope.SuccessMessage = 'Client updated successfully to "' + $scope.selectClient.ClientName + '"';
            $timeout(function () {
                $scope.SuccessMessage = '';
                $scope.editClientName.ClientName == '';
            }, 3000);
            $scope.isExistingClient = false;
            refreshInitService();
        })
    };

    //GLMGR-723
    var refreshInitService = function () {
        AdminService.getClientsBrandsCategoriesSections(userId, function (clientlist) {
            if (clientlist.accessRes) {
                if (clientlist.accessRes === "AccessDenied") {
                    commonService.deniedRedirect();
                }
            }
            else {
                $scope.clientlist = clientlist;
                angular.copy($scope.clientlist, clientlistcopy);
                for (var i = 0; i < ClientListLength; i++) {
                    if (selectedClientId === $scope.clientlist.ClientList[i].ClientId) {
                        $scope.selectClient = $scope.clientlist.ClientList[i];
                        break;
                    }
                }
                $scope.brandlist = {};
                $scope.sectionlist = {};
                $scope.brandlist = $scope.clientlist.ClientList[i].ClientBrandList; //display associated brandlist for current client
                $scope.sectionlist = $scope.clientlist.ClientList[i].ClientSectionList; //display associated sectionlist for current client
            }
        });

    };
    //Client implementation end

    /**
      * @ngdoc
      * @name GetBrandsToAssociate
      * @methodOf Admin.controller:AdminController
      * @description
      * This function is called on associate brands button on brands tab. This method is used to all list of brands in application
      * @returns {undefined} This method does not return.
      */
    $scope.GetBrandsToAssociate = function () {
        var clientId = $scope.selectClient.ClientId;
        //service call to get unassociated brands
        AdminService.getBrandsToAssociate(clientId, function (data) {
            $scope.UnassociatedBrandList = data;
        })
    };

    /**
      * @ngdoc
      * @name AssociateBrand
      * @methodOf Admin.controller:AdminController
      * @description
      * This function is called on associate brands button on associate brands popup. This method is used to associate selected brands to selected client
      * @returns {undefined} This method does not return.
      */
    $scope.AssociateBrand = function () {
        $scope.setClientNameInPopup();
        var associateBrandObj = {};
        associateBrandObj['ClientId'] = $scope.selectClient.ClientId;
        associateBrandObj['BrandId'] = $scope.selectBrandToAssociate.BrandId;
        $('#AssociateBrand').modal('hide');
        //service call to associate brand
        AdminService.associateBrand(associateBrandObj, function (data) {
            $scope.SuccessMessage = 'Selected Brand "' + $scope.selectBrandToAssociate.BrandName + '" is Associated with Client "' + $scope.selectClient.ClientName + '"';
            $timeout(function () {
                $scope.SuccessMessage = '';
            }, 3000);
            refreshInitService();
        })
    };

     /**
      * @ngdoc
      * @name DeassociateBrand
      * @methodOf Admin.controller:AdminController
      * @description
      * This function is called on De-associate brands button on Deassociate brands popup. This method is used to De-associate selected brands to selected client
      * @returns {undefined} This method does not return.
      */
    $scope.DeassociateBrand = function () {
        $scope.setClientNameInPopup();
        var deassociateBrandObj = {};
        deassociateBrandObj['ClientBrandId'] = $scope.selectAssociatedBrand.ClientBrandId;
        //service call to deassociate brand
        AdminService.deassociateBrand(deassociateBrandObj, function (data) {
            $scope.SuccessMessage = 'Selected Brand "' + $scope.selectAssociatedBrand.BrandName + '" is De-associated from Client "' + $scope.selectClient.ClientName + '"';
            $timeout(function () {
                $scope.SuccessMessage = '';
            }, 3000);
            refreshInitService();
        })
    };

    /**
      * @ngdoc
      * @name AddBrand
      * @methodOf Admin.controller:AdminController
      * @description
      * This function is called on ok button on add brands popup. This method is used to add new brands in the application.
      * @returns {undefined} This method does not return.
      */
    $scope.AddBrand = function () {
        if ($scope.maxlenErrorBname) {
            return false;
        }
        if ($scope.clientlist.BrandList) {
            for (var i = 0; i < $scope.clientlist.BrandList.length; i++) {
                if (($scope.newBrand).toLowerCase() === ($scope.clientlist.BrandList[i].BrandName).toLowerCase()) {

                    $scope.isExistingBrand = true;
                    return false;
                }
            }
        }

        $('#addNewBrand').modal('hide');
        var addBrandObj = {};
        addBrandObj['BrandName'] = $scope.newBrand;
        //service call to add new brand
        AdminService.addBrand(addBrandObj, function (data) {
            init();
            $scope.SuccessMessage = '"' + $scope.newBrand + '" Brand added successfully!';
            $timeout(function () {
                $scope.SuccessMessage = '';
                $scope.newBrand = '';
            }, 3000);
        })
    };

       /**
      * @ngdoc
      * @name EditBrand
      * @methodOf Admin.controller:AdminController
      * @description
      * This function is called on ok button on edit brands popup. This method is used to edit brands in the application.
      * @returns {undefined} This method does not return.
      */
    $scope.EditBrand = function () {
        if ($scope.maxlenErrorBname) {
            return false;
        }
        for (var i = 0; i < $scope.clientlist.BrandList.length; i++) {
            if (($scope.editBrandName.BrandName).toLowerCase() === (clientlistcopy.BrandList[i].BrandName).toLowerCase()) {
                $scope.isExistingBrand = true;
                return false;
            }
        }

        $('#editBrand').modal('hide');
        var editBrandObj = $scope.editBrandName;
        //service to edit a Brand
        AdminService.editBrand(editBrandObj, function (data) {
            init();
            $scope.SuccessMessage = 'Brand updated successfully to "' + $scope.selectBrand.BrandName + '"';
            $timeout(function () {
                $scope.SuccessMessage = '';
                $scope.editBrandName.BrandName = '';
            }, 3000);
        });
    };
    //Brand implementation end

    /**
      * @ngdoc
      * @name AddCategory
      * @methodOf Admin.controller:AdminController
      * @description
      * This function is called on ok button on add categories popup. This method is used to add new categories in the application.
      * @returns {undefined} This method does not return.
      */
    $scope.AddCategory = function () {
        //GLMGR-863
        if ($scope.maxlenErrorCatname) {
            return false;
        }
        $scope.newCategory = $scope.newCategory.replace(/^\s+|\s+$|\s+(?=\s)/g, "");
        for (var i = 0; i < $scope.globalCategories.length; i++) {
            if ($scope.newCategory.toLowerCase() === $scope.globalCategories[i].CategoryName.toLowerCase()) {
                $scope.isExistingCategory = true;
                return false;
            }
        }

        $scope.showLoader = true;
        AdminService.addNewGlobalCategory($scope.newCategory, function (status) {
            $('#addNewCategoryPopup').modal('hide');
            getGlobalCategoryDetails();
            $scope.showLoader = false;
            $scope.SuccessMessage = '"' + $scope.newCategory + '" Additional Information option added successfully!';
            $timeout(function () {
                $scope.SuccessMessage = '';
                $scope.newCategory = '';
            }, 3000);
            $scope.isExistingCategory = false;
        });
    };
    $scope.preventClick = function (popupName) {
        $('#' + popupName).modal({
            backdrop: 'static',
            keyboard: false
        })
    };

    $scope.setClientNameInPopup = function () {
        selectedClientId = $scope.selectClient.ClientId;
        $scope.editClientName = $scope.selectClient;
    }
    $scope.setBrandNameInPopup = function () {
        $scope.editBrandName = $scope.selectBrand;
    }
    $scope.setCategoryNameInPopup = function () {
        $scope.editGlobalCategory = $scope.selectCategory;
    }
    $scope.setSectionNameInPopup = function () {
        $scope.editSectionName = $scope.selectSection;
    }

    $scope.resetCategoryNameForAdd = function () {
        $scope.newCategory = '';
    }

    /**
      * @ngdoc
      * @name updateCategory
      * @methodOf Admin.controller:AdminController
      * @description
      * This function is called on ok button on edit categories popup. This method is used to update category name in the application.
      * @returns {undefined} This method does not return.
      */
    $scope.updateCategory = function () {
        //GLMGR-853
        if ($scope.maxlenErrorCatname) {
            return false;
        }
        $scope.editGlobalCategory.CategoryName = $scope.editGlobalCategory.CategoryName.replace(/^\s+|\s+$|\s+(?=\s)/g, "");;

        for (var i = 0; i < copyglobalCategories.length; i++) {
            if ($scope.editGlobalCategory.CategoryName.toLowerCase() === copyglobalCategories[i].CategoryName.toLowerCase()) {
                $scope.isExistingCategory = true;
                return false;
            }
        }
        var editedGlobalCategory = {};
        editedGlobalCategory['GlobalCategoryId'] = $scope.editGlobalCategory.Id;
        editedGlobalCategory['CategoryName'] = $scope.editGlobalCategory.CategoryName;
        $scope.showLoader = true;

        AdminService.updateNewGlobalCategory(editedGlobalCategory, function (status) {
            $scope.SuccessMessage = 'Additional Information updated successfully to "' + $scope.editGlobalCategory.CategoryName + '"';
            $timeout(function () {
                $scope.SuccessMessage = '';
                $scope.isExistingCategory = false;
            }, 3000);
            $('#editCategoryPopup').modal('hide');
            getGlobalCategoryDetails();
            $scope.showLoader = false;
        });
    };

    var getGlobalCategoryDetails = function () {
        AdminService.getGlobalCategories(function (globalCategories) {
            $scope.globalCategories = globalCategories;
            angular.copy($scope.globalCategories, copyglobalCategories);
        });
    };

    //Category implementation end


     /**
      * @ngdoc
      * @name AddSection
      * @methodOf Admin.controller:AdminController
      * @description
      * This function is called on ok button on add section popup. This method is used to add new section in the application.
      * @returns {undefined} This method does not return.
      */
    $scope.AddSection = function () {
        if ($scope.maxlenErrorSname) {
            return false;
        }
        if (
            ($scope.newSection.toLowerCase().indexOf("ntl -")) >= 0 ||
            ($scope.newSection.toLowerCase().indexOf("fd -")) >= 0 ||
            ($scope.newSection.toLowerCase().indexOf("ntl-")) >= 0 ||
            ($scope.newSection.toLowerCase().indexOf("fd-")) >= 0 ||
            ($scope.newSection.toLowerCase().indexOf("localization list")) >= 0 ||
            ($scope.newSection.toLowerCase().indexOf("localisation list")) >= 0 ||
            ($scope.newSection.toLowerCase().indexOf("foreign dialogue")) >= 0 ||
            ($scope.newSection.toLowerCase().indexOf("foreign dialog")) >= 0
        ) {

            $scope.isExistingSection = false;
            $scope.isNTLStringPresent = true;
            return false;
        }

        for (var i = 0; i < $scope.clientlist.SectionList.length; i++) {
            if (($scope.newSection).toLowerCase() === ($scope.clientlist.SectionList[i].SectionName).toLowerCase()) {
                sectionExist = true;
                isBlankSection = false;
                $scope.isNTLStringPresent = false;
                $scope.isExistingSection = true;
                return false;
            }
        }
        $('#addNewSection').modal('hide');
        var addSectionObj = {};
        addSectionObj['SectionName'] = $scope.newSection;
        addSectionObj['SectionType'] = 1;
        //service call to add new section
        AdminService.addSection(addSectionObj, function (data) {
            init();
            $scope.SuccessMessage = '"' + $scope.newSection + '" Section added successfully!';
            $timeout(function () {
                $scope.SuccessMessage = '';
                $scope.newSection = '';
            }, 3000);
            isBlankSection = false;
            $scope.isExistingSection = false;
            $scope.isNTLStringPresent = false;
        })
    };
    
    /**
      * @ngdoc
      * @name EditSection
      * @methodOf Admin.controller:AdminController
      * @description
      * This function is called on ok button on edit section popup. This method is used to update section name in the application.
      * @returns {undefined} This method does not return.
      */
    $scope.EditSection = function () {

        if (
            ($scope.editSectionName.SectionName.toLowerCase().indexOf("ntl -")) >= 0 ||
            ($scope.editSectionName.SectionName.toLowerCase().indexOf("fd -")) >= 0 ||
            ($scope.editSectionName.SectionName.toLowerCase().indexOf("ntl-")) >= 0 ||
            ($scope.editSectionName.SectionName.toLowerCase().indexOf("fd-")) >= 0 ||
            ($scope.editSectionName.SectionName.toLowerCase().indexOf("localization list")) >= 0 ||
            ($scope.editSectionName.SectionName.toLowerCase().indexOf("localisation list")) >= 0 ||
            ($scope.editSectionName.SectionName.toLowerCase().indexOf("foreign dialogue")) >= 0 ||
            ($scope.editSectionName.SectionName.toLowerCase().indexOf("foreign dialog")) >= 0
        ) {
            $scope.isNTLStringPresent = true;
            $scope.isExistingSection = false;
            return false;
        }

        for (var i = 0; i < $scope.clientlist.SectionList.length; i++) {
            if (($scope.editSectionName.SectionName).toLowerCase() === (clientlistcopy.SectionList[i].SectionName).toLowerCase()) {
                $scope.isExistingSection = true;
                $scope.isNTLStringPresent = false;
                return false;
            }
        }

        $('#editSection').modal('hide');
        var editSectionObj = $scope.editSectionName;
        //service to edit a Section
        AdminService.editSection(editSectionObj, function (data) {
            init();
            $scope.SuccessMessage = 'Section updated successfully to "' + $scope.selectSection.SectionName + '"';
            $timeout(function () {
                $scope.SuccessMessage = '';
                $scope.editSectionName.SectionName = '';
            }, 3000);
            $scope.isExistingSection = false;
            $scope.isNTLStringPresent = false;
        });
    };

    /**
      * @ngdoc
      * @name GetSectionsToAssociate
      * @methodOf Admin.controller:AdminController
      * @description
      * This function is called on Associate section button on sections tab. This method is used to get all the sections list
      * @returns {undefined} This method does not return.
      */
    $scope.GetSectionsToAssociate = function () {
        $scope.setClientNameInPopup();
        $scope.UnassociatedSectionList = [];
        var isSectionAlreadyAssociated = false;
        for (var i = 0; i < $scope.clientlist.SectionList.length; i++) {
            for (var j = 0; j < $scope.selectClient.ClientSectionList.length; j++) {
                if ($scope.clientlist.SectionList[i].SectionName === $scope.selectClient.ClientSectionList[j].SectionName) {
                    isSectionAlreadyAssociated = true;
                    break;
                }
            }
            if (!isSectionAlreadyAssociated) {
                $scope.UnassociatedSectionList.push($scope.clientlist.SectionList[i]);
            }
            isSectionAlreadyAssociated = false;
        }
    };

    /**
      * @ngdoc
      * @name AssociateSection
      * @methodOf Admin.controller:AdminController
      * @description
      * This function is called on Associate button on Associate sections popup. This method is used to associate section to client.
      * @returns {undefined} This method does not return.
      */
    $scope.AssociateSection = function () {
        var associateSectionObj = {};
        associateSectionObj['ClientId'] = $scope.selectClient.ClientId;
        associateSectionObj['SectionId'] = $scope.selectSectionToAssociate.SectionId;
        associateSectionObj['UserId'] = userId;
        $('#AssociateSection').modal('hide');
        //service call to associate Section
        AdminService.associateSection(associateSectionObj, function (data) {
            $scope.SuccessMessage = 'Selected Section "' + $scope.selectSectionToAssociate.SectionName + '" is Associated with Client "' + $scope.selectClient.ClientName + '"';
            $timeout(function () {
                $scope.SuccessMessage = '';
            }, 3000);
            refreshInitService();
        })
    };

     /**
      * @ngdoc
      * @name DeassociateSection
      * @methodOf Admin.controller:AdminController
      * @description
      * This function is called on De-Associate button on section tab. This method is used to De-associate section.
      * @returns {undefined} This method does not return.
      */
    $scope.DeassociateSection = function () {
        $scope.setClientNameInPopup();
        var clientSectionId = $scope.selectAssociatedSection.clientSectionId;
        //service call to deassociate Section
        AdminService.deassociateSection(clientSectionId, function (data) {
            $scope.SuccessMessage = 'Selected Section "' + $scope.selectAssociatedSection.SectionName + '" is De-associated from Client "' + $scope.selectClient.ClientName + '"';
            $timeout(function () {
                $scope.SuccessMessage = '';
            }, 3000);
            refreshInitService();
        })
    };

    //Section implementation end

    $scope.cancelClientClick = function () {
        isBlankClient = false;
        $scope.isExistingClient = false;
        $scope.maxlenErrorCname = false;
        $scope.newClient = '';
        init();
    }

    $scope.cancelBrandClick = function () {
        isBlankBrand = false;
        $scope.isExistingBrand = false;
        $scope.maxlenErrorBname = false;
        $scope.newBrand = '';
        init();
    }

    $scope.cancelCategoryClick = function () {
        isBlankCategory = false;
        $scope.isExistingCategory = false;
        $scope.maxlenErrorCatname = false;
        $scope.newCategory = '';
        init();
    };

    $scope.cancelSectionClick = function () {
        isBlankSection = false;
        $scope.isExistingSection = false;
        $scope.isNTLStringPresent = false;
        $scope.maxlenErrorSname = false;
        $scope.newSection = '';
        init();
    }

    /**
      * @ngdoc
      * @name selectedTab
      * @methodOf Admin.controller:AdminController
      * @param {String} tabId This is tab name.
      * @description
      * This function is called on click of tabs on admin page. This function is used to show data on selected tab.
      * @returns {undefined} This method does not return.
      */
    $scope.selectedTab = function (tabId) {

        $scope.clientsTab = false;
        $scope.brandsTab = false;
        $scope.additionalInfoTab = false;
        $scope.sectionsTab = false;

        if (tabId === 'Clients') {
            $scope.clientsTab = true;
        } else if (tabId === 'Brands') {
            $scope.brandsTab = true;
        } else if (tabId === 'AdditionalInfo') {
            $scope.additionalInfoTab = true;
        } else if (tabId === "Sections") {
            $scope.sectionsTab = true;
        } else {
            $scope.clientsTab = true;
        }
    };

     /**
     * @ngdoc
     * @name init
     * @methodOf Admin.controller:AdminController
     * @description
     * This function is called initially when page is loaded. This function is used to get initial page data.
     * @returns {undefined} This method does not return.
     */
    var init = function () {
        getGlobalCategoryDetails();
        var resorceIdx = 0;
        sessionStorage.setItem('resourcePageId', JSON.stringify(resorceIdx));
        //Service to get client,brands,categories,sections list
        AdminService.getClientsBrandsCategoriesSections(userId, function (clientlist) {
            if (clientlist.accessRes) {
                if (clientlist.accessRes === "AccessDenied") {
                    commonService.deniedRedirect();
                }
            }
            else {
                $scope.clientlist = clientlist;
                angular.copy($scope.clientlist, clientlistcopy);
                if ($scope.clientlist.ClientList) {
                    ClientListLength = $scope.clientlist.ClientList.length;
                } else {
                    ClientListLength = 0;
                }
                $scope.brandlist = clientlist.ClientList[0].ClientBrandList; //display associated brandlist for first client by default
                $scope.sectionlist = clientlist.ClientList[0].ClientSectionList;
                $scope.selectClient = clientlist.ClientList[0]; //highlight first client
                dynamicScreenHeight();
            }
        });
    };

    init();

}]);