/**
 * @ngdoc service
 * @name Projects.LandingPageData
 * @requires AngularJS.$http
 * @requires common.commonService
 * 
 * @description
 * This is service in projects module. It contains methods which are used for different operations done on project landing page.
 *  
**/

angular.module('projects', ['ngRoute', 'common', 'gmProjectsModule', 'ngGrid', 'ui.bootstrap', 'mgcrea.ngStrap', 'ngTable', 'ngTableResizableColumns', 'ui.sortable', 'angularUtils.directives.dirPagination', 'ui.grid', 'ui.grid.resizeColumns', 'ngImgCrop'])
    .service('LandingPageData', ['$http', 'commonService', function ($http, commonService) {

        var HomePageService = {

            /**
            * 
            * @ngdoc function
            * @name Projects.LandingPageData#getPageData
            * @methodOf Projects.LandingPageData
            * @description
            * This service is to get the selected project data on landing page.  
            * @param {string} projectid This is the encrypted project id of selected project passed as parameter to this method.
            * @param {number} userid This is the userid of current logged in user.
            * @param {boolean} excludeNTLFD This is boolan value depending on check box checked value(checked /unchecked) on project page.
            * @returns {object}  This method returns object with all project details required on landing page of that project(eg. Project title,Project languages).
            */
            getPageData: function (projectid, userid, excludeNTLFD, callback) {
                $http.get('Projects/HomePage/' + projectid + '/' + userid + '/' + excludeNTLFD)
                    .success(function (landingproject) {
                        if (landingproject.accessRes) {
                            if (landingproject.accessRes === "AccessDenied") {
                                commonService.deniedRedirect();
                            }
                        }
                        else {
                            Project = {};
                            Project = landingproject;
                            hideColors = false;
                            callback(Project);
                        }
                    })

                    .error(function (e) {
                        callback(null);
                    });
            },

            /**
            * 
            * @ngdoc function
            * @name Projects.LandingPageData#carosalProjectListFilter
            * @methodOf Projects.LandingPageData
            * @description
            * This function is used to get CarosalProjectList after every filter (status/client/brand filter above on the project landing page) value change.  
            * @param {number} UserId This is the userid of current logged in user.
            * @param {number} ClientIdFilter This is selected client's id, selected from client filter dropdown.
            * @param {number} BrandIdFilter This is selected brand's id, selected from brands filter dropdown.
            * @param {string} UserRole This is user role of logged in user.
            * @param {string} InputTextFilter This is search text entered in search box on project landing page. 
            * @param {number} ProjectStateFilterActive This is active/inactive filter value. This is number assigned to each status (eg 1 for all projects, 2 for active, 3 for inactive projects).
            * @param {boolean} IsOwnerOfProjectFilter This is boolan value depending on project owner filter. True if myProjects filter selected, else false.
            * @returns {array}  This method returns array of all projects list depending on applied filters. 
            */
            carosalProjectListFilter: function (UserId, ClientIdFilter, BrandIdFilter, UserRole, InputTextFilter, ProjectStateFilterActive, IsOwnerOfProjectFilter, callback) {
                var forgerytoken;
                commonService.getToken(function (token) {
                    forgerytoken = token;
                    $http({
                        method: 'post',
                        url: 'Projects/GetCarosalProjectListFilter',
                        data: {
                            UserId: UserId,
                            ClientIdFilter: ClientIdFilter,
                            BrandIdFilter: BrandIdFilter,
                            UserRole: UserRole,
                            InputTextFilter: InputTextFilter,
                            ProjectStateFilterActive: ProjectStateFilterActive,
                            IsOwnerOfProjectFilter: IsOwnerOfProjectFilter
                        },
                        headers: {
                            '__RequestVerificationToken': forgerytoken
                        }
                    })
                        .success(function (CorousalInfo) {
                            if (CorousalInfo.accessRes) {
                                if (CorousalInfo.accessRes === "AccessDenied") {
                                    commonService.deniedRedirect();
                                }
                            } else {
                                callback(CorousalInfo);
                            }
                        })
                        .error(function (CorousalInfo) {
                            callback(CorousalInfo);
                        })
                });

            },

            /**
             * 
             * @ngdoc function
             * @name Projects.LandingPageData#getCorousalData
             * @methodOf Projects.LandingPageData
             * @description
             * This function is used to get the projects data that is to be displayed in the carousel view on landing page.
             * @param {number} userId This is the userid of current logged in user.
             * @param {number} clientid This is selected client's id, selected from client filter dropdown.
             * @param {number} brandid This is selected brand's id, selected from brands filter dropdown.
             * @param {string} userRole This is user role of logged in user.
             * @param {string} token This encrypted ant forgery token. 
             * @returns {array}  This method returns array of all projects list depending on applied filters. 
             */
            getCorousalData: function (userId, clientid, brandid, userRole, token, callback) {
                var forgerytoken;

                forgerytoken = token;
                $http({
                    method: "post",
                    url: "Projects/GetCarosalProjectList",
                    data: {
                        UserId: userId,
                        ClientId: clientid,
                        BrandId: brandid,
                        UserRole: userRole
                    },
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                }).success(function (CorousalInfo) {
                    if (CorousalInfo.accessRes) {
                        if (CorousalInfo.accessRes === "AccessDenied") {
                            commonService.deniedRedirect();
                        }
                    }
                    else {
                        corousalarray = {};
                        hideColors = false;
                        corousalarray = CorousalInfo;
                        callback(corousalarray);
                    }
                })


            },

            /**
            * 
            * @ngdoc function
            * @name Projects.LandingPageData#getPageInfoData
            * @methodOf Projects.LandingPageData
            * @description
            * This function is used to get project-wise information that is to be displayed in the project info page  
            * @param {string} projectid This is the encrypted project id of selected project passed as parameter to this method.
            * @param {number} userid This is the userid of current logged in user.
            * @param {boolean} excludeNTLFD This is boolan value depending on check box checked value(checked /unchecked) on project page.
            * @returns {object}  This method returns object with all project details required on landing page of that project(eg. Project title,Project languages).
            */
            getPageInfoData: function (projectid, userid, excludeNTLFD, callback) {
                $http.get('Projects/ProjectInfo/' + projectid + '/' + userid + '/' + excludeNTLFD)
                    .success(function (projectinfo) {
                        if (projectinfo.accessRes) {
                            if (projectinfo.accessRes === "AccessDenied") {
                                commonService.deniedRedirect();
                            }
                        }
                        else {
                            hideColors = false;
                            callback(projectinfo);
                        }
                    })

                    .error(function (e) {
                        callback(e);
                    });
            },

            /**
            * 
            * @ngdoc function
            * @name Projects.LandingPageData#getPageEditData
            * @methodOf Projects.LandingPageData
            * @description
            * This function is used to get project-wise information that is to be displayed in the project info page  
            * @param {string} projectid This is the encrypted project id of selected project passed as parameter to this method.
            * @param {number} UserId This is the userid of current logged in user.
            * @param {string} userRole This is user role of logged in user.
            * @returns {object}  This method returns object with all project details required on project edit page of that project(eg. Project title,Project languages).
            */
            //Service to get project-wise edited information that is to be displayed in the project edit page
            getPageEditData: function (projectid, UserId, userRole, callback) {
                $http.get('Projects/EditProject/' + projectid + '/' + UserId + '/' + userRole)
                    .success(function (projectedit) {
                        if (projectedit.accessRes) {
                            if (projectedit.accessRes === "AccessDenied") {
                                commonService.deniedRedirect();
                            }
                        }
                        else {
                            hideColors = false;
                            callback(projectedit);
                        }
                    })

                    .error(function (e) {
                        callback(e);
                    });
            },

            /**
             * 
             * @ngdoc function
             * @name Projects.LandingPageData#ShowAttachmentToInfo
             * @methodOf Projects.LandingPageData
             * @description
             * This function is used to get language specific attached file list .
             * @param {string} projectid This is the encrypted project id of selected project passed as parameter to this method.
             * @param {number} projectLanguageId This is the project language id from master glossary table in db.
             * @param {number} languageId This is the language id from language table.
             * @returns {array}  This method returns array of all file list.
             */
            ShowAttachmentToInfo: function (projectid, projectLanguageId, languageId, callback) {
                $http.get('ProjectGlossary/ShowAttachmentToInfo/' + projectid + '/' + projectLanguageId + '/' + languageId) //LanguageId
                    .success(function (data) {
                        if (data.accessRes) {
                            if (data.accessRes === "AccessDenied") {
                                commonService.deniedRedirect();
                            }
                        }
                        else {

                            callback(data);
                        }
                    })
                    .error(function (e) {
                        callback(e);
                    })
            },

            /**
            * 
            * @ngdoc function
            * @name Projects.LandingPageData#getAttachedFileList
            * @methodOf Projects.LandingPageData
            * @description
            * This function is used to get language specific attached file list .
            * @param {string} projectid This is the encrypted project id of selected project passed as parameter to this method.
            * @param {number} languageId This is the language id.
            * @returns {array}  This method returns array of all file list.
            */
            getAttachedFileList: function (projectid, languageid, callback) {
                $http.get('Projects/ShowAttachments/' + projectid + '/' + languageid) //LanguageId
                    .success(function (data) {
                        if (data.accessRes) {
                            if (data.accessRes === "AccessDenied") {
                                commonService.deniedRedirect();
                            }
                        }
                        else {

                            callback(data);
                        }
                    })
                    .error(function (e) {
                        callback(e);
                    })
            },

            /**
             * 
             * @ngdoc function
             * @name Projects.LandingPageData#getAttachedFileListEntireProject
             * @methodOf Projects.LandingPageData
             * @description
             * This function is used to get Attached File List for Entire Project.
             * @param {string} projectid This is the encrypted project id of selected project passed as parameter to this method.
             * @param {number} languageId This is the language id.
             * @returns {array}  This method returns array of all file list.
             */
            getAttachedFileListEntireProject: function (projectid, languageid, callback) {
                $http.get('Projects/ShowAttachmentsProject/' + projectid + '/' + 0)
                    .success(function (data) {

                        callback(data);
                    })
                    .error(function (e) {
                        callback(e);
                    })
            },

            /**
            * 
            * @ngdoc function
            * @name Projects.LandingPageData#postDeleteAttachment
            * @methodOf Projects.LandingPageData
            * @description
            * This function is to pass attachment files data for deletion operation.
            * @param {number} attachmentId This is the id of attached document.
            * @param {string} projectid This is the encrypted project id of selected project passed as parameter to this method.
            * @param {number} languageId This is the language id.
            * @param {number} UserId This is the userid of current logged in user.
            * @param {number} OriginalUserId This is the userid of impersonated user.
            * @returns {boolean}  This method returns true/false status.
            */
            //function to pass attachment files data 
            postDeleteAttachment: function (attachmentId, projectId, languageId, UserId, OriginalUserId, callback) {
                $http.get('Projects/DeleteAttachment/' + attachmentId + '/' + projectId + '/' + languageId + '/' + UserId + '/' + OriginalUserId)
                    .success(function (data) {
                        callback(true);
                    }).
                    error(function (e) {
                        callback(false);
                    })
            },

            //function to pass attachment files data 
            saveUploadAttachments: function (data, callback) {
                var forgerytoken;
                commonService.getToken(function (token) {
                    forgerytoken = token;
                    $http({
                        method: 'POST',
                        url: 'Projects/AddAttachments',
                        data: data,
                        responseType: 'blob',
                        headers: {
                            '__RequestVerificationToken': forgerytoken
                        }
                    }).
                        success(function (data) {
                            callback(true);
                        }).
                        error(function (e) {
                            callback(false);
                        })
                });

            },

            /**
            * 
            * @ngdoc function
            * @name Projects.LandingPageData#saveEditedProject
            * @methodOf Projects.LandingPageData
            * @description
            * This function to pass data for save edited project.
            * @param {object} data All edit data to be updated.
            * @returns {boolean}  This method returns true/false status.
            */
            saveEditedProject: function (data, callback) {
                var forgerytoken;
                commonService.getToken(function (token) {
                    forgerytoken = token;
                    $http({
                        method: 'POST',
                        url: "Projects/SaveProject",
                        data: data,
                        headers: {
                            '__RequestVerificationToken': forgerytoken
                        }
                    }).
                        success(function (data, status, headers, config) {
                            callback(true);
                        }).
                        error(function (e) {
                            callback(e);
                        })
                });

            },


            /**
            * 
            * @ngdoc function
            * @name Projects.LandingPageData#updateLocalCategory
            * @methodOf Projects.LandingPageData
            * @description
            * This is function to pass data to update the local categories
            * @param {object} editedLocalCategory Updated details for category .
            * @returns {boolean}  This method returns true/false status.
            */
            updateLocalCategory: function (editedLocalCategory, callback) {
                var forgerytoken;
                commonService.getToken(function (token) {
                    forgerytoken = token;
                    $http({
                        method: 'POST',
                        url: "Projects/EditCategory",
                        data: editedLocalCategory,
                        headers: {
                            '__RequestVerificationToken': forgerytoken
                        }
                    }).
                        success(function (data, status, headers, config) {
                            callback(true);
                        }).
                        error(function (e) {
                            callback(e);
                        })
                });

            },

            /**
            * 
            * @ngdoc function
            * @name Projects.LandingPageData#deleteLocalCategory
            * @methodOf Projects.LandingPageData
            * @description
            * This is function to pass data to delete the local categories
            * @param {object} deletedLocalCategory details of category  to be deleted.
            * @returns {boolean}  This method returns true/false status.
            */
            //function to pass data to delete the local categories
            deleteLocalCategory: function (deletedLocalCategory, callback) {
                var forgerytoken;
                commonService.getToken(function (token) {
                    forgerytoken = token;
                    $http({
                        method: 'POST',
                        url: "Projects/DeleteCategory",
                        data: deletedLocalCategory,
                        headers: {
                            '__RequestVerificationToken': forgerytoken
                        }
                    }).
                        success(function (data, status, headers, config) {
                            callback(true);
                        }).
                        error(function (e) {
                            callback(e);
                        })
                });

            },


            /**
            * 
            * @ngdoc function
            * @name Projects.LandingPageData#getClientList
            * @methodOf Projects.LandingPageData
            * @description
            * This function is used to get the client list that is to be displayed in the landing page dropdown.
            * @param {number} userId This is the userid of current logged in user.
            * @param {number} clientid This is selected client's id, selected from client filter dropdown.
            * @param {number} brandid This is selected brand's id, selected from brands filter dropdown.
            * @param {string} userRole This is user role of logged in user.
            * @returns {array}  This method returns array of all clients. 
            */
            getClientList: function (userid, clientid, brandid, userRole, callback) {
                var forgerytoken;
                commonService.getToken(function (token) {
                    forgerytoken = token;
                    $http({
                        method: "post",
                        url: "Projects/ClientListOfActiveProjects",
                        data: {
                            UserId: userid,
                            ClientId: clientid,
                            BrandId: brandid,
                            UserRole: userRole
                        },
                        headers: {
                            '__RequestVerificationToken': forgerytoken
                        }
                    }).success(function (clientlist) {
                        callback(clientlist);
                    })

                        .error(function (e) {
                            callback(e);
                        });
                });

            },

            //Service to get the brand list that is to be displayed in the landing page dropdown
            getBrandList: function (userid, clientid, brandid, userRole, callback) {
                var forgerytoken;
                commonService.getToken(function (token) {
                    forgerytoken = token;
                    $http({
                        method: "post",
                        url: "Projects/BrandList",
                        data: {
                            UserId: userid,
                            ClientId: clientid,
                            BrandId: brandid,
                            UserRole: userRole
                        },
                        headers: {
                            '__RequestVerificationToken': forgerytoken
                        }
                    }).success(function (brandlist) {
                        callback(brandlist);
                    })

                        .error(function (e) {
                            callback(e);
                        });
                });

            },

            /**
            * 
            * @ngdoc function
            * @name Projects.LandingPageData#getNewProjectData
            * @methodOf Projects.LandingPageData
            * @description
            * This function is used to get the Prepopulated data for New Project.
            * @param {number} userId This is the userid of current logged in user.
            * @param {string} userRole This is user role of logged in user.
            * @returns {array}  This method returns array of all clients. 
            */
            getNewProjectData: function (userid, userRole, callback) {
                $http.get('Projects/HomePage/GetPrePopulatedData')
                    .success(function (projectadd) {
                        if (projectadd.accessRes) {
                            if (projectadd.accessRes === "AccessDenied") {
                                commonService.deniedRedirect();
                            }
                        }
                        else {
                            callback(projectadd);
                        }
                    })

                    .error(function (e) {
                        callback(e);
                    });
            },

            /**
            * 
            * @ngdoc function
            * @name Projects.LandingPageData#getNewProjectData
            * @methodOf Projects.LandingPageData
            * @description
            * This is a function to pass the form data to add new project
            * @param {number} data This is a object containing all the details entered by user while creating new project.
            * @returns {boolean} This method returns status true/false. 
            */
            addNewProject: function (data, callback) {
                var forgerytoken;
                commonService.getToken(function (token) {
                    forgerytoken = token;
                    $http({
                        method: 'POST',
                        url: "Projects/AddNewProject",
                        data: data,
                        headers: {
                            '__RequestVerificationToken': forgerytoken,
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    }).
                        success(function (data, status, headers, config) {
                            callback(true);
                        }).
                        error(function (e) {
                            callback(e);
                        })
                });

            },

            /**
             * 
             * @ngdoc function
             * @name Projects.LandingPageData#addNewCategory
             * @methodOf Projects.LandingPageData
             * @description
             * This is a function to pass the form data to add new category .
             * @param {number} newCat This is a object containing all the details of new category .
             * @returns {boolean} This method returns status true/false. 
             */
            addNewCategory: function (newCat, callback) {
                var forgerytoken;
                commonService.getToken(function (token) {
                    forgerytoken = token;
                    $http({
                        method: 'POST',
                        url: "Projects/AddNewCategory",
                        data: newCat,
                        headers: {
                            '__RequestVerificationToken': forgerytoken,
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    }).
                        success(function (data) {
                            callback(data);
                        }).
                        error(function (e) {
                            callback(e);
                        })
                });

            },

            /**
            * 
            * @ngdoc function
            * @name Projects.LandingPageData#getProjectList
            * @methodOf Projects.LandingPageData
            * @description
            * This is a function to get list of projects and check for duplicates.
            * @param {string} ProjectTitle This is a Project title entered.
            * @returns {boolean}  This method returns true/false.If project with same name found then true else false. 
            */
            getProjectList: function (ProjectTitle, callback) {
                var forgerytoken;
                commonService.getToken(function (token) {
                    forgerytoken = token;
                    $http({
                        method: 'POST',
                        url: "Projects/GetProjectInfo",
                        data: ProjectTitle,
                        headers: {
                            '__RequestVerificationToken': forgerytoken
                        }
                    }).
                        success(function (data) {
                            callback(data);
                        }).
                        error(function (e) {
                            callback(e);
                        })
                });
            },

            /**
              * 
              * @ngdoc function
              * @name Projects.LandingPageData#changeProjectStatus
              * @methodOf Projects.LandingPageData
              * @description
              * This function to change status(Active/Inactive) of project.
              * @param {object} data This object contains project status,projectid,userid and original userid
              * @returns {undefined}  This method does not return. 
              */
            changeProjectStatus: function (data, callback) {
                var forgerytoken;
                commonService.getToken(function (token) {
                    forgerytoken = token;
                    $http({
                        method: 'POST',
                        url: "Projects/ChangeProjectStatus",
                        data: data,
                        headers: {
                            '__RequestVerificationToken': forgerytoken
                        }
                    }).
                        success(function () {
                            callback();
                        }).
                        error(function (e) {
                            callback(e);
                        })
                });

            },

            /**
             * 
             * @ngdoc function
             * @name Projects.LandingPageData#changeProjectLockStatus
             * @methodOf Projects.LandingPageData
             * @description
             * This function to change status(Locked/Unlocked) of project.
             * @param {object} data This object contains project status,projectid,userid and original userid
             * @returns {undefined}  This method does not return. 
             */
            //function to chnage status of project
            changeProjectLockStatus: function (data, callback) {
                var forgerytoken;
                commonService.getToken(function (token) {
                    forgerytoken = token;
                    $http({
                        method: 'POST',
                        url: "Projects/ChangeProjectLockStatus",
                        data: data,
                        headers: {
                            '__RequestVerificationToken': forgerytoken
                        }
                    }).
                        success(function () {
                            callback();
                        }).
                        error(function (e) {
                            callback(e);
                        })
                });

            },

            getUserInfo: function (callback) {
                $http.get('Users/UserProfile/' + commonService.getLocalData('userDetails').UserId)
                    .success(function (userinfo) {
                        if (userinfo.accessRes) {
                            if (userinfo.accessRes === "AccessDenied") {
                                commonService.deniedRedirect();
                            }
                        }
                        else {
                            callback(userinfo);
                        }
                    })

                    .error(function (e) {
                        callback(e);
                    });
            },

            /**
            * 
            * @ngdoc function
            * @name Projects.LandingPageData#projectOwnerList
            * @methodOf Projects.LandingPageData
            * @description
            * This function is used to get thr owner list in the dropdown on page load.
            * @param {number} userId This is the userid of current logged in user.
            * @param {number} ProjectId This is project id of selected project.
            * @param {array} ClientIds This is list of all selected clients IDs.
            * @returns {array}  This method returns array of all clients. 
            */
            projectOwnerList: function (ProjectId, UserId, ClientIds, callback) {
                var forgerytoken;
                commonService.getToken(function (token) {
                    forgerytoken = token;
                    $http({
                        method: 'POST',
                        url: "Projects/GetOwners",
                        data: {
                            ProjectId: ProjectId,
                            UserId: UserId,
                            ClientIds: ClientIds
                        },
                        headers: {
                            '__RequestVerificationToken': forgerytoken
                        }
                    }).
                        success(function (abc) {
                            callback(abc);
                        }).
                        error(function (e) {
                            callback(e);
                        })
                });
            },

            /**
            * 
            * @ngdoc function
            * @name Projects.LandingPageData#uploadScriptDB
            * @methodOf Projects.LandingPageData
            * @description
            * This function is called on click of upload button on netflix knp wizard.
            * @param {object} uploadFile This is objects contains attached files, userid and projectid properties.
            * @returns {boolean}  This method returns true/false status. true if successful upload else false.
            */
            uploadScriptDB: function (uploadFile, callback) {
                var forgerytoken;
                commonService.getToken(function (token) {
                    forgerytoken = token;
                    $http({
                        method: "post",
                        url: "Projects/ImportNetflixKNPFileData",
                        data: uploadFile,
                        headers: {
                            '__RequestVerificationToken': forgerytoken
                        }
                    })
                        .success(function (status) {
                            callback(status);
                        })
                        .error(function (e) {
                            callback(e);
                        })
                });
            },


            /**
            * 
            * @ngdoc function
            * @name Projects.LandingPageData#importNetflixDataCommit
            * @methodOf Projects.LandingPageData
            * @description
            * This function is used to pass column mappings to show preview.
            * @param {object} columnMppingObj This is object contains column mapping data from import knp wizard.
            * @returns {boolean}  This method returns true/false status. true if successful upload else false.
            */
            importNetflixDataCommit: function (columnMppingObj, callback) {
                var forgerytoken;
                commonService.getToken(function (token) {
                    forgerytoken = token;
                    $http({
                        method: "post",
                        url: "Projects/ImportNetflixKNPFileDataPreview",
                        data: columnMppingObj,
                        headers: {
                            '__RequestVerificationToken': forgerytoken
                        }
                    })
                        .success(function (status) {
                            callback(status);
                        })
                        .error(function (e) {
                            callback(e);
                        })
                });
            },
            /**
            * 
            * @ngdoc function
            * @name Projects.LandingPageData#importNetflixKNPFileDataCommit
            * @methodOf Projects.LandingPageData
            * @description
            * This function is used to pass column mappings data to db.
            * @param {object} columnMppingObj This is object contains column mapping data from import knp wizard.
            * @returns {boolean}  This method returns true/false status. true if successful upload else false.
            */
            importNetflixKNPFileDataCommit: function (columnMppingObj, callback) {
                var forgerytoken;
                commonService.getToken(function (token) {
                    forgerytoken = token;
                    $http({
                        method: "post",
                        url: "Projects/ImportNetflixKNPFileDataCommit",
                        data: columnMppingObj,
                        headers: {
                            '__RequestVerificationToken': forgerytoken
                        }
                    })
                        .success(function (status) {
                            callback(status);
                        })
                        .error(function (e) {
                            callback(e);
                        })
                });
            },

            /**
            * 
            * @ngdoc function
            * @name Projects.LandingPageData#deleteExistingFileOnServer
            * @methodOf Projects.LandingPageData
            * @description
            * This function is used to delete file from server if upload is cancelled .
            * @param {object} uploadFile This is objects contains attached files, userid and projectid properties.
            * @returns {boolean}  This method returns true/false status. true if successful upload else false.
            */
            deleteExistingFileOnServer: function (uploadFile, callback) {
                var forgerytoken;
                commonService.getToken(function (token) {
                    forgerytoken = token;
                    $http({
                        method: "post",
                        url: "Projects/DeleteExistingFileOnServer",
                        data: uploadFile,
                        headers: {
                            '__RequestVerificationToken': forgerytoken
                        }
                    })
                        .success(function (status) {
                            callback(status);
                        })
                        .error(function (e) {
                            callback(e);
                        })
                });
            },

            /**
            * 
            * @ngdoc function
            * @name Projects.LandingPageData#getLimitAccessAllAdmin
            * @methodOf Projects.LandingPageData
            * @description
            * This function is used to get all the admin users from DB to show on popup
            * @param {object} admins This is objects contains list of users who are creator and owners
            * @returns {Array}  This method returns array of all admin users in the application.
            */
            getLimitAccessAllAdmin: function (admins, callback) {
                var forgerytoken;
                commonService.getToken(function (token) {
                    forgerytoken = token;
                    $http({
                        method: "post",
                        url: 'Projects/GetLimitAccessAllAdmin/',
                        data: admins,
                        headers: {
                            '__RequestVerificationToken': forgerytoken
                        }
                    })
                        .success(function (list) {
                            callback(list);
                        })
                        .error(function (e) {
                            callback(e);
                        })
                });
            },

             /**
            * 
            * @ngdoc function
            * @name Projects.LandingPageData#saveLimitAccessAdminUsers
            * @methodOf Projects.LandingPageData
            * @description
            * This function is used to save limited acces admin users list
            * @param {object} assignedAdminList This is objects contains list of all selected admin users
            * @returns {boolean}  This method returns true/false status. true if successful upload else false.
            */
            saveLimitAccessAdminUsers: function (assignedAdminList, callback) {
                var forgerytoken;
                commonService.getToken(function (token) {
                    forgerytoken = token;
                    $http({
                        method: "post",
                        url: "Projects/SaveLimitAccessAdminUsers",
                        data: assignedAdminList,
                        headers: {
                            '__RequestVerificationToken': forgerytoken
                        }
                    })
                        .success(function (status) {
                            callback(status);
                        })
                        .error(function (e) {
                            callback(e);
                        })
                });
            },

            /**
            * 
            * @ngdoc function
            * @name Projects.LandingPageData#accessUserReport
            * @methodOf Projects.LandingPageData
            * @description
            * This function is used to download excel file of user reports
            * @param {object} exportReportInputs This is objects contains project id, user id and password for excel file.
            * @returns {object}  This method returns object which contains file data.
            */
            accessUserReport: function (exportReportInputs, callback) {
                var updateUserLockData = {};
                var forgerytoken;
                commonService.getToken(function (token) {
                    forgerytoken = token;
                    $http({
                        method: "post",
                        url: "Projects/AccessUsersReport",
                        data: exportReportInputs,
                        responseType: 'blob',
                        headers: {
                            '__RequestVerificationToken': forgerytoken
                        }
                    })
                        .
                        success(function (data, status, headers, config) {
                            saveBlobExcel.save(data, 'GlossaryManagerExportFile.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8');
                            callback(true);
                        }).
                        error(function (data, status, headers, config) { })
                });
            }
        },



        return HomePageService;
    }])