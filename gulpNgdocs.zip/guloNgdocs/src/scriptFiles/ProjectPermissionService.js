/**
 * @ngdoc service
 * @name Projects.ProjectPermissionsService
 * @requires AngularJS.$http
 * @requires common.commonService
 * 
 * @description
 * This is service in projects module. It is responsible for assigning project permissions to user.
 *  
**/
gmProjectsModule.service('ProjectPermissionsService', ['$http', 'commonService', function ($http, commonService) {

    var PROJECTPERMISSIONSSERVICE = {
    /**
    * @ngdoc function
    * @name Projects.LandingPageData#getProjectPermissions
    * @methodOf Projects.ProjectPermissionsService
    * @description
    * This service is to get user list from db.  
    * @param {string} projectid This is the encrypted project id of selected project passed as parameter to this method.
    * @returns {Array}  This method returns Array with all users list from db.
    */
        getProjectPermissions: function (projectid, callback) {
            $http({
                method: "get",
                url: "Projects/ProjectPermissions/" + projectid + '/' + commonService.getLocalData('userDetails').UserId
            })
            .success(function (projectpermissions) {
                callback(projectpermissions);
            })
           .error(function (e) {
               callback(e);
           })
        },
  
/**
    * @ngdoc function
    * @name Projects.LandingPageData#getProjectBasicInfo
    * @methodOf Projects.ProjectPermissionsService
    * @description
    * This service is to get project's Basic info on load.  
    * @param {string} projectid This is the encrypted project id of selected project passed as parameter to this method.
    * @param {number} userid This is the userid of current logged in user.
    * @returns {Object}  This method returns Object with all the details of project.
    */
        getProjectBasicInfo: function (projectId, UserId, callback) {
        $http({
            method: "get",
            url: 'Projects/GetProjectInfoPermission/' + projectId + '/' + UserId
        })
        .success(function (projectinfo) {
            callback(projectinfo);
        })
    .error(function (e) {
        callback(e);
    })
        },

   /**
    * @ngdoc function
    * @name Projects.LandingPageData#getEditorialStaffInfo
    * @methodOf Projects.ProjectPermissionsService
    * @description
    * This service is to get  Editorial Staff Information.  
    * @param {string} projectid This is the encrypted project id of selected project passed as parameter to this method.
    * @param {number} masterLanguageId This property is Id of master language.
    * @returns {Object}  This method returns Object with all the details of editorial staff.
    */
        //Get Editorial Staff Information
        getEditorialStaffInfo: function (projectId, masterLanguageId, callback) {
            $http({
                method: "get",
                url: 'Projects/EditorialStaffUsers/' + projectId + '/' + masterLanguageId
            })
            .success(function (editorialStaffInfo) {
                callback(editorialStaffInfo);
            })
        .error(function (e) {
            callback(e);
        })
        },

    /**
    * @ngdoc function
    * @name Projects.LandingPageData#getEditorialStaffInfo
    * @methodOf Projects.ProjectPermissionsService
    * @description
    * This service is to save editorial user list to db.  
    * @param {number} EditorialStaffProjectPermissionInputModel This property is details of editorial users input model.
    * @returns {boolean}  This method returns boolean if operation is successful
    */
        saveEditorialUserList: function (EditorialStaffProjectPermissionInputModel, callback) {
            EditorialStaffProjectPermissionInputModel['UserId'] = commonService.getLocalData('userDetails').UserId;
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "Projects/EditorialStaff",
                    data: EditorialStaffProjectPermissionInputModel,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
         .success(function (status) {
             callback(status);
         })
        .error(function (e) {
            callback(e);
        })
            });
          

        },

        /**
    * @ngdoc function
    * @name Projects.LandingPageData#savePermissionsUserList
    * @methodOf Projects.ProjectPermissionsService
    * @description
    * This service is to save user list to db.  
    * @param {number} permissionsList This property is details of user list.
    * @returns {boolean}  This method returns boolean if operation is successful
    */
        savePermissionsUserList: function (permissionsList, callback) {
            var forgerytoken;
            permissionsList['UserId'] = commonService.getLocalData('userDetails').UserId;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "Projects/ProjectPermissionsUserList",
                    data: permissionsList,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
         .success(function (status) {
             callback(status);
         })
        .error(function (e) { 
            callback(e);
        })
            });
          

        }
    }
    return PROJECTPERMISSIONSSERVICE;

}]);