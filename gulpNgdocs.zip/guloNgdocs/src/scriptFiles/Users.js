/**
 * @ngdoc object
 * @name Users
 * @element html
 * 
 * @requires AngularJS.$routeProvider
 * @requires AngularJS.$locationProvider
 * @requires AngularJS.$httpProvider
 * @requires AngularJS.ngRoute
 * @requires common
 * 
 * @description
 * This is Users module, which contains usersController for users menu to show all users in the application
 *
 */
var Users = angular.module('users', ['ngRoute', 'common', 'gmUsersModule', 'angularUtils.directives.dirPagination']);

Users.config(['$routeProvider', '$locationProvider', '$httpProvider', function ($routeProvider, $locationProvider, $httpProvider) {
    $httpProvider.interceptors.push('myInterceptor');
    $routeProvider

  .when('/', {
      templateUrl: "UsersController/Content/ngviews/UserList.html",
      controller: "usersController"
  })

 
}])
Users.factory('myInterceptor', function () {
    var requestInterceptor = {
        request: function (config) {
            localStorage.setItem('time', new Date());
            return config;
        }
    };

    return requestInterceptor;
});