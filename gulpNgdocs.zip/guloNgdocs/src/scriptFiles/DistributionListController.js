/**
 * @ngdoc controller
 * @name DistributionList.controller:DistributionListController
 * @element div
 *
 * @description
 * This Controller is responsible for showing distribution lists on distribution list page and all the operations done on distribution list page.
 *
 * @requires AngularJS.$scope
 * @requires AngularJS.$route
 * @requires AngularJS.$location
 * @requires AngularJS.$timeout
 * @requires common.commonService
 * @requires DistributionList.DistributionListService
 * 
 * @property {string} DistrubutionListStatus:String This property is used to store the DL(Distribution list) status(Active/Inactive)
 * @property {Boolean} IsActiveFilter:String This property is used to store the active status filter value. 
 * @property {Boolean} IsInActiveFilter:String This property is used to store the InActive status filter value. 
 * @property {Boolean} ShowAllFilter:String This property is used to store the All status filter value.
 * @property {Array} Selectedclients:Array This is list of selected clients.
 * @property {Array} Selectedclients:Array This is list of selected clients.
 * @property {Array} AllClientLlist:Array This is list of all clients.
 * @property {Object} RoleName:Object This is list of all user roles
 * @property {Object} AddDLForm:Object This is validation object for add DL form
 * @property {Object} EditDLForm:Object This is validation object for edit DL form
 * 
 */
DistributionList.controller('distributionListController', ['$scope', '$http', '$location', 'DistributionListService', 'commonService', '$route', 'dirPaginateDirective', '$timeout', function ($scope, $http, $location, DistributionListService, commonService, $route, dirPaginateDirective, $timeout) {
    $scope.DistrubutionListStatus = "";
    $scope.IsActiveFilter = true;
    $scope.IsInActiveFilter = false;
    $scope.ShowAllFilter = false;
    $scope.Selectedclients = [];
    $scope.unSelectedLang = [];
    $scope.RoleName = {};
    $scope.distributionListAll = {};
    var DLlistSelected = {};
    $scope.AllClientLlist = [];
    $scope.IsUsersWithAllLanguages = false;
    $scope.noDLAvailable = false;
    $scope.forApproverAndTranslators = true;
    $scope.forAdmin = true;
    $scope.isGroupNameDuplicate = false;
    $scope.showLoader = false;

    //set hashURL for GLMGR-1189
    sessionStorage.setItem('hashURL', null);

    $scope.objLangUser = {
        "unSelectLang ": [],
        "selectLang": [],
        "userListArray": [],
        "selectUsers": []
    };

    $scope.AddDLForm = {
        "isGroupNameRequired": false,
        "isGroupTypeRequired": false,
        "isClientRequired": false,
        "islanguageRquired": false,
        "isUserRequired": false
    };


    $scope.EditDLForm = {
        "isGroupNameRequired": false,
        "isGroupTypeRequired": false,
        "isClientRequired": false,
        "islanguageRquired": false,
        "isUserRequired": false
    };

     /**
     * @ngdoc
     * @name createNewDLpopup
     * @methodOf DistributionList.controller:DistributionListController
     * @description
     * This function is used to show add DL popup
     * @returns {undefined} This method does not return.
     */
    $scope.createNewDLpopup = function () {
        $('#addNewDL').modal({ backdrop: 'static', keyboard: false });
        $("#addNewDL").modal('show');
    };

    // dismiss popup
    $scope.dissmissPopup = function () {
        resetData();
        $("#addNewDL").modal('hide');
        $('.modal-backdrop.fade.in').css('display', 'none');
        $route.reload();
    };

     /**
     * @ngdoc
     * @name selectRoleOnPopup
     * @methodOf DistributionList.controller:DistributionListController
     * @param {Object} role This is object contains Group type information. 
     * @description
     * This function is called on change of group type dropdown in add DL popup.This function is used show fields in the form accordingly.
     * @returns {undefined} This method does not return.
     */
    $scope.selectRoleOnPopup = function (role) {

        $scope.AddDLForm = {
            "isGroupNameRequired": false,
            "isGroupTypeRequired": false,
            "isClientRequired": false,
            "islanguageRquired": false,
            "isUserRequired": false
        };

        $scope.EditDLForm = {
            "isGroupNameRequired": false,
            "isGroupTypeRequired": false,
            "isClientRequired": false,
            "islanguageRquired": false,
            "isUserRequired": false
        };

        $scope.Selectedclients = [];

        //make client dropdown blank
        $('.client_str').html('Select Client(s)');
        $('.client_str').attr('title', 'Select Client(s)')
        //reset client selected
        $('.dropdown-menu li a span').each(function () {
            $(this).removeClass('icon-ok pull-right');
        });

        $scope.objLangUser.selectLang = [];
        $scope.objLangUser.userListArray = [];
        $scope.objLangUser.selectUsers = [];


        if (!role) {
            $scope.forApproverAndTranslators = true;
        }
        else {
            if (role.RoleName == "Admin" || role.RoleName == "Super Admin") {
                $scope.forAdmin = false;
                var DistributionListFilterData = {}
                DistributionListFilterData.UserId = $scope.userId;
                DistributionListFilterData.RoleId = role.RoleId;
                DistributionListFilterData.FilteredClientList = null;
                DistributionListFilterData.FilteredLanguageList = null;
                DistributionListFilterData.IsUsersWithAllLanguages = false;
                DistributionListService.retrieveUsersByClientsAndLanguages(DistributionListFilterData, function (distributionUser) {
                    var UsersArray = distributionUser;

                    //showing unique elements
                    $scope.objLangUser.userListArray = _.uniq(UsersArray, function (p) { return p.UserId; });
                });
            }
            else {
                $scope.objLangUser.userListArray = [];
                $scope.forAdmin = true;
            }
            if (role.RoleName == "Approver" || role.RoleName == "Translator") {
                DistributionListService.getDistributionList($scope.userId, function (dlDataOnLoad) {
                    $scope.langList = dlDataOnLoad.LanguageList;
                });
                $scope.objLangUser.unSelectLang = $scope.langList;
                $scope.forApproverAndTranslators = true;
            }
            else {
                $scope.forApproverAndTranslators = false;
            }
        }
    };
   
     /**
     * @ngdoc
     * @name langCheked
     * @methodOf DistributionList.controller:DistributionListController
     * @description
     * This function is called on click of language checkbox on add/edit DL popup.This function is used to show users who has knowledge of all the selected languages.
     * @returns {undefined} This method does not return.
     */
    $scope.langCheked = function () {
        $scope.objLangUser.selectUsers = [];
        getUsersForApproverTranslator();
    };
   
   /**
     * @ngdoc
     * @name selectLangClick
     * @methodOf DistributionList.controller:DistributionListController
     * @param {Object} selectedLang This is object containing all the details about selected language from select box.
     * @description
     * This function is used for selecting languages and pushing to the right side of the list from left side.
     * @returns {undefined} This method does not return.
     */
    $scope.selectLangClick = function (selectedLang) {
        if (!selectedLang) {
            $scope.AddDLForm.islanguageRquired = true;
            $scope.EditDLForm.islanguageRquired = true;
        }
        else {
            $scope.AddDLForm.islanguageRquired = false;
            $scope.EditDLForm.islanguageRquired = false;

            //Adding the selected languages to the left side of the List
            for (var i = 0; i < selectedLang.length; i++) {
                $scope.objLangUser.selectLang.push(selectedLang[i]);
                var index = $scope.objLangUser.unSelectLang.indexOf(selectedLang[i]);
                if (index > -1) {
                    $scope.objLangUser.unSelectLang.splice(index, 1);
                }
            }

            //service to get userlist
            getUsersForApproverTranslator();

        }
    };

    /**
     * @ngdoc
     * @name getUsersForApproverTranslator
     * @methodOf DistributionList.controller:DistributionListController
     * @description
     * This function is used to get users list for approver and translator DL.
     * @returns {undefined} This method does not return.
     */
    var getUsersForApproverTranslator = function () {

        var DistributionListFilterData = {}
        DistributionListFilterData.UserId = $scope.userId;
        DistributionListFilterData.RoleId = $scope.RoleName.RoleId
        DistributionListFilterData.FilteredClientList = $scope.Selectedclients;
        DistributionListFilterData.FilteredLanguageList = $scope.objLangUser.selectLang;

        DistributionListFilterData.IsUsersWithAllLanguages = $scope.IsUsersWithAllLanguages;
        DistributionListService.retrieveUsersByClientsAndLanguages(DistributionListFilterData, function (distributionUser) {
            var UsersArray = distributionUser;
            //showing unique elements
            $scope.objLangUser.userListArray = _.uniq(UsersArray, function (p) { return p.UserId; });
            //showing only those users in Users multiselect
            for (var i = 0; i < $scope.objLangUser.selectUsers.length; i++) {
                for (var j = 0; j < $scope.objLangUser.userListArray.length; j++) {
                    if ($scope.objLangUser.userListArray[j].UserId == $scope.objLangUser.selectUsers[i].UserId) {
                        $scope.objLangUser.userListArray.splice(j, 1);
                    }
                }
            }
        });
    };

    //show users for client admin and Client users
    $scope.$on('ClientSelected', function (event, clients) {
        $scope.Selectedclients = clients;
        var DistributionListFilterData = {}
        DistributionListFilterData.UserId = $scope.userId;
        DistributionListFilterData.RoleId = $scope.RoleName.RoleId
        DistributionListFilterData.FilteredClientList = $scope.Selectedclients;
        DistributionListFilterData.FilteredLanguageList = null;
        DistributionListFilterData.IsUsersWithAllLanguages = false;
        DistributionListService.retrieveUsersByClientsAndLanguages(DistributionListFilterData, function (distributionUser) {
            var UsersArray = distributionUser;
            //showing unique elements
            $scope.objLangUser.userListArray = _.uniq(UsersArray, function (p) { return p.UserId; });
        });
    });


    /**
     * @ngdoc
     * @name UnSelectLangClick
     * @methodOf DistributionList.controller:DistributionListController
     * @param {Object} unSelectedLang This is object containing all the details about selected language from select box.
     * @description
     * This function is used for deselecting selected languages and pushing to the left side of the list from right side
     * @returns {undefined} This method does not return.
     */
    $scope.UnSelectLangClick = function (unSelectedLang) {
        //Removing all the deselected items from the Native Language Array
        for (var i = 0; i < unSelectedLang.length; i++) {
            $scope.objLangUser.unSelectLang.push(unSelectedLang[i]);
            var index = $scope.objLangUser.selectLang.indexOf(unSelectedLang[i]);
            if (index > -1) {
                $scope.objLangUser.selectLang.splice(index, 1);
            }
        }

        //check ischeck box on Add DL is checked
        if ($scope.objLangUser.selectLang.length < 2) {
            $scope.IsUsersWithAllLanguages = false;
        }

        //service to get userlist
        var FilteredClientList = [];
        FilteredClientList = $scope.Selectedclients;

        var FilteredLanguageList = [];
        FilteredLanguageList = $scope.objLangUser.selectLang;
        var DistributionListFilterData = {}
        DistributionListFilterData.UserId = $scope.userId;
        DistributionListFilterData.RoleId = $scope.RoleName.RoleId
        DistributionListFilterData.FilteredClientList = FilteredClientList;
        DistributionListFilterData.FilteredLanguageList = FilteredLanguageList;


        DistributionListFilterData.IsUsersWithAllLanguages = $scope.IsUsersWithAllLanguages;
        DistributionListService.retrieveUsersByClientsAndLanguages(DistributionListFilterData, function (distributionUser) {
            var UsersArray = distributionUser;
            //showing unique elements
            $scope.objLangUser.userListArray = _.uniq(UsersArray, function (p) { return p.UserId; });
            //showing only those users in Users multiselect
            for (var i = 0; i < $scope.objLangUser.selectUsers.length; i++) {
                for (var j = 0; j < $scope.objLangUser.userListArray.length; j++) {
                    if ($scope.objLangUser.userListArray[j].UserId == $scope.objLangUser.selectUsers[i].UserId) {
                        $scope.objLangUser.userListArray.splice(j, 1);
                    }
                }
            }
        });
    };

    /**
     * @ngdoc
     * @name selectUserClick
     * @methodOf DistributionList.controller:DistributionListController
     * @param {Object} selectedUsers This is object containing all the details about selected user from select box.
     * @description
     * This function is used for selecting users and move user from left select box to right select box.
     * @returns {undefined} This method does not return.
     */
    $scope.selectUserClick = function (selectedUsers) {
        //Adding the selected users to the left side of the List
        for (var i = 0; i < selectedUsers.length; i++) {
            $scope.objLangUser.selectUsers.push(selectedUsers[i]);
            var index = $scope.objLangUser.userListArray.indexOf(selectedUsers[i]);
            if (index > -1) {
                $scope.objLangUser.userListArray.splice(index, 1);
            }
        }
    };

   /**
     * @ngdoc
     * @name UnSelectUserClick
     * @methodOf DistributionList.controller:DistributionListController
     * @param {Object} unSelectedUser This is object containing all the details about selected user from right select box.
     * @description
     * This function is used for selecting users and move user from right select box to left select box.
     * @returns {undefined} This method does not return.
     */
    $scope.UnSelectUserClick = function (unSelectedUser) {
        //Removing all the deselected items from the Native Language Array
        for (var i = 0; i < unSelectedUser.length; i++) {
            $scope.objLangUser.userListArray.push(unSelectedUser[i]);
            var index = $scope.objLangUser.selectUsers.indexOf(unSelectedUser[i]);
            if (index > -1) {
                $scope.objLangUser.selectUsers.splice(index, 1);
            }
        }
    };

   /**
     * @ngdoc
     * @name saveDistributionList
     * @methodOf DistributionList.controller:DistributionListController
     * @description
     * This function is used to add new distribution list.
     * @returns {undefined} This method does not return.
     */
    var saveDistributionList = function () {
        var AssignedClientList = [];
        AssignedClientList = $scope.Selectedclients;
        var AssignedUserList = [];
        AssignedUserList = $scope.objLangUser.selectUsers;
        $scope.ObjNewDL = {
            DistributionListId: 0,
            DistributionListName: $scope.DistributionListName,
            DistributionListType: $scope.RoleName.RoleId,
            UserId: $scope.userDetails.UserId,
            DistributionListTypeName: $scope.RoleName.RoleName,
            IsActive: true,
            CreatedDate: "",
            CreatedById: 1,
            CreatedBy: "",
            UpdatedDate: "",
            UpdatedById: 1,
            UpdatedBy: "",
            AssignedClientList: AssignedClientList,
            AssignedUserList: AssignedUserList,
            IsUsersWithAllLanguages: $scope.IsUsersWithAllLanguages
        };
        $("#addNewDL").modal('hide');
        $('.modal-backdrop.fade.in').css('display', 'none');
        $scope.showLoader = true;
        if ($scope.RoleName.RoleName == "Admin" || $scope.RoleName.RoleName == "Super Admin") {
            $scope.ObjNewDL.AssignedClientList = null;
            DistributionListService.addDistributionList($scope.ObjNewDL, function (success) {
                $scope.success = success;
                resetData();
                $route.reload();
            });
        } else if ($scope.RoleName.RoleName == "Client Admin" || $scope.RoleName.RoleName == "Client User") {
            DistributionListService.addDistributionList($scope.ObjNewDL, function (success) {
                $scope.success = success;
                resetData();
                $route.reload();
            });
        }
        else {
            DistributionListService.addDistributionList($scope.ObjNewDL, function (success) {
                $scope.success = success;
                resetData();
                $route.reload();
            })
        }
        setTimeout(function () { dynamicScreenHeight(); }, 500);
    };

       /**
     * @ngdoc
     * @name resetData
     * @methodOf DistributionList.controller:DistributionListController
     * @description
     * This function is used to reset newDL popup data
     * @returns {undefined} This method does not return.
     */
    var resetData = function () {
        $scope.DistributionListName = "";
        $scope.RoleName = $scope.dlDataOnLoad.RoleList[-1];
        $scope.Selectedclients = $scope.dlDataOnLoad.ClientList[-1];
        $scope.objLangUser.selectLang = [];
        $scope.objLangUser.userListArray = [];
        $scope.objLangUser.selectUsers = [];
    };

    //Cancel button click function
    $scope.cancelBtn = function () {
        resetData();
        $("#addNewDL").modal('hide');
        $('.modal-backdrop.fade.in').css('display', 'none');
        $route.reload();
    };

     /**
     * @ngdoc
     * @name editDL
     * @methodOf DistributionList.controller:DistributionListController
     * @param {Object} DLlist This is selected distribution list to be updated. 
     * @description
     * This function is used to open editDL popup
     * @returns {undefined} This method does not return.
     */
    $scope.editDL = function (DLlist) {
        if (DLlist.DistributionListTypeName == "Super Admin" || DLlist.DistributionListTypeName == "Admin") {
            $scope.forAdmin = false;
            $scope.forApproverAndTranslators = false;
            var DistributionListId = DLlist.DistributionListId;
            var AssignedClientList = DLlist.AssignedClientList;
            DLlistSelected = DLlist;
            $scope.DistributionListName = DLlist.DistributionListName;
            var DistributionListType = DLlist.DistributionListType;
            var DistributionListTypeName = DLlist.DistributionListTypeName;
            for (var i = 0; i < $scope.dlDataOnLoad.RoleList.length; i++) {
                if ($scope.dlDataOnLoad.RoleList[i].RoleName === DistributionListTypeName) { $scope.RoleName = $scope.dlDataOnLoad.RoleList[i]; break; }
            }

            //show users in UsersArray
            var DistributionListFilterData = {}
            DistributionListFilterData.UserId = $scope.userId;
            DistributionListFilterData.RoleId = DLlist.DistributionListType //roleID
            DistributionListFilterData.FilteredClientList = null;
            DistributionListFilterData.FilteredLanguageList = null;
            DistributionListFilterData.IsUsersWithAllLanguages = false;
            DistributionListService.retrieveUsersByClientsAndLanguages(DistributionListFilterData, function (distributionUser) {
                var UsersArray = distributionUser;

                //showing unique elements
                $scope.objLangUser.userListArray = _.uniq(UsersArray, function (p) { return p.UserId; });

                //showing only those users in Users multiselect
                for (var i = 0; i < $scope.objLangUser.selectUsers.length; i++) {
                    for (var j = 0; j < $scope.objLangUser.userListArray.length; j++) {
                        if ($scope.objLangUser.userListArray[j].UserId == $scope.objLangUser.selectUsers[i].UserId) {
                            $scope.objLangUser.userListArray.splice(j, 1);
                        }
                    }
                }
            });

            $scope.objLangUser.selectUsers = DLlist.AssignedUserList;
            var AssignedUserList = DLlist.AssignedUserList;
            var IsActive = DLlist.IsActive;
            $('#editDL').modal({ backdrop: 'static', keyboard: false });
            $('#editDL').modal('show');
        }
        else if (DLlist.DistributionListTypeName == "Client Admin" || DLlist.DistributionListTypeName == "Client User") {
            $scope.forAdmin = true;
            $scope.forApproverAndTranslators = false;
            var DistributionListId = DLlist.DistributionListId;
            var AssignedClientList = DLlist.AssignedClientList;

            $scope.Selectedclients = AssignedClientList
            DLlistSelected = DLlist;
            $scope.DistributionListName = DLlist.DistributionListName;
            var DistributionListType = DLlist.DistributionListType;
            var DistributionListTypeName = DLlist.DistributionListTypeName;
            for (var i = 0; i < $scope.dlDataOnLoad.RoleList.length; i++) {
                if ($scope.dlDataOnLoad.RoleList[i].RoleName === DistributionListTypeName) { $scope.RoleName = $scope.dlDataOnLoad.RoleList[i]; break; }
            }

            //disable client select doprdown
            $('.dropdown-menu  li:first-child, .dropdown-menu li:nth-child(2), .dropdown-menu li:nth-child(3)').css('display', 'none');
            $('.dropdown-menu  li ').css('pointer-events', 'none');
            $('.ms-dropdown-style').css('color', '#999999')
            $('.dropdown-menu  li a ').css('color', '#999999');
            $('.icon-ok').css('color', '#999999');

            //show check box to selected clients only
            $('.dropdown-menu li a span').each(function () {
                for (var j = 0; j < $scope.Selectedclients.length; j++) {
                    if ($scope.Selectedclients[j].ClientName == $(this).parent().text()) {
                        $(this).addClass('icon-ok pull-right');
                    }
                }
            });

            //show clients above dropdown
            var client_str = '';
            for (var i = 0; i < $scope.AllClientLlist.length; i++) {
                for (var j = 0; j < $scope.Selectedclients.length; j++) {
                    if ($scope.Selectedclients[j].ClientId == $scope.AllClientLlist[i].ClientId) {
                        if (client_str != '') {
                            client_str = client_str + ',' + $scope.Selectedclients[j].ClientName;
                        }
                        else {
                            client_str = $scope.Selectedclients[j].ClientName;
                        }
                        $('.client_str').html(client_str);
                        $('.client_str').attr('title', client_str);
                    }
                }
            }



            //show users in UsersArray
            var DistributionListFilterData = {}
            DistributionListFilterData.UserId = $scope.userId;
            DistributionListFilterData.RoleId = DLlist.DistributionListType //roleID
            DistributionListFilterData.FilteredClientList = $scope.Selectedclients;
            DistributionListFilterData.FilteredLanguageList = null;
            DistributionListFilterData.IsUsersWithAllLanguages = false;
            DistributionListService.retrieveUsersByClientsAndLanguages(DistributionListFilterData, function (distributionUser) {
                var UsersArray = distributionUser;
                //showing unique elements
                $scope.objLangUser.userListArray = _.uniq(UsersArray, function (p) { return p.UserId; });

                //showing only those users in Users multiselect
                for (var i = 0; i < $scope.objLangUser.selectUsers.length; i++) {
                    for (var j = 0; j < $scope.objLangUser.userListArray.length; j++) {
                        if ($scope.objLangUser.userListArray[j].UserId == $scope.objLangUser.selectUsers[i].UserId) {
                            $scope.objLangUser.userListArray.splice(j, 1);
                        }
                    }
                }
            });

            $scope.objLangUser.selectUsers = DLlist.AssignedUserList;
            var AssignedUserList = DLlist.AssignedUserList;
            var IsActive = DLlist.IsActive;
            $('#editDL').modal({ backdrop: 'static', keyboard: false });
            $('#editDL').modal('show');
        }
        else {
            $scope.forAdmin = true;
            $scope.forApproverAndTranslators = true;
            var DistributionListId = DLlist.DistributionListId;
            var AssignedClientList = DLlist.AssignedClientList;
            $scope.Selectedclients = AssignedClientList;
            //$scope.SelectedOptions = AssignedClientList;

            DLlistSelected = DLlist;
            $scope.DistributionListName = DLlist.DistributionListName;
            var DistributionListType = DLlist.DistributionListType;
            var DistributionListTypeName = DLlist.DistributionListTypeName;
            for (var i = 0; i < $scope.dlDataOnLoad.RoleList.length; i++) {
                if ($scope.dlDataOnLoad.RoleList[i].RoleName === DistributionListTypeName) { $scope.RoleName = $scope.dlDataOnLoad.RoleList[i]; break; }
            }

            //disable client select doprdown
            $('.dropdown-menu  li:first-child, .dropdown-menu li:nth-child(2), .dropdown-menu li:nth-child(3)').css('display', 'none');
            $('.dropdown-menu  li ').css('pointer-events', 'none');
            $('.ms-dropdown-style').css('color', '#999999')
            $('.dropdown-menu  li a ').css('color', '#999999');
            $('.icon-ok').css('color', '#999999');

            //show check box to selected clients only
            $('.dropdown-menu li a span').each(function () {
                for (var j = 0; j < $scope.Selectedclients.length; j++) {
                    if ($scope.Selectedclients[j].ClientName == $(this).parent().text()) {
                        $(this).addClass('icon-ok pull-right');
                    }
                }

            });
            //show clients above dropdown
            var client_str = '';
            for (var i = 0; i < $scope.AllClientLlist.length; i++) {
                for (var j = 0; j < $scope.Selectedclients.length; j++) {
                    if ($scope.Selectedclients[j].ClientId == $scope.AllClientLlist[i].ClientId) {
                        if (client_str != '') {
                            client_str = client_str + ',' + $scope.Selectedclients[j].ClientName;
                        }
                        else {
                            client_str = $scope.Selectedclients[j].ClientName;
                        }
                        $('.client_str').html(client_str);
                        $('.client_str').attr('title', client_str);
                    }
                }
            }

            $scope.objLangUser.selectUsers = DLlist.AssignedUserList;
            var AssignedUserList = DLlist.AssignedUserList;
            var IsActive = DLlist.IsActive;
            $('#editDL').modal({ backdrop: 'static', keyboard: false });
            $('#editDL').modal('show');
        }
    };

   /**
     * @ngdoc
     * @name EditDistributionList
     * @methodOf DistributionList.controller:DistributionListController
     * @description
     * This function is used to update DL information
     * @returns {undefined} This method does not return.
     */
    var EditDistributionList = function () {
        var AssignedClientList = [];
        var AssignedUserList = [];
        AssignedUserList = $scope.objLangUser.selectUsers;
        AssignedClientList = $scope.Selectedclients;

        $scope.ObjUpdatedDL = {
            DistributionListId: DLlistSelected.DistributionListId,
            DistributionListName: $scope.DistributionListName,
            DistributionListType: $scope.RoleName.RoleId,
            UserId: $scope.userDetails.UserId,
            DistributionListTypeName: $scope.RoleName.RoleName,
            IsActive: true,
            CreatedDate: "",
            CreatedById: 1,
            CreatedBy: "",
            UpdatedDate: "",
            UpdatedById: $scope.userDetails.UserId,
            UpdatedBy: $scope.userDetails.UserName,
            AssignedClientList: AssignedClientList,
            AssignedUserList: AssignedUserList,
            IsUsersWithAllLanguages: $scope.IsUsersWithAllLanguages
        };

        //return false;
        //service to edit DL
        $("#editDL").modal('hide');
        $('.modal-backdrop.fade.in').css('display', 'none');
        $scope.showLoader = true;
        DistributionListService.editDistributionList($scope.ObjUpdatedDL, function (success) {
            $scope.success = success;
            resetData();
            $route.reload();
        });
    };

    /**
     * @ngdoc
     * @name changeDLstatus
     * @methodOf DistributionList.controller:DistributionListController
     * @param {Object} DLlist This is selected distribution list to be deleted. 
     * @description
     * This function is used to delete/inactive DL. This function is called on delete icon on DL table
     * @returns {undefined} This method does not return.
     */
    $scope.changeDLstatus = function (DLlist) {
        $scope.DistributionListId = DLlist.DistributionListId;
        $scope.DistributionListName = DLlist.DistributionListName;
        $('#deleteModal').modal('show');
    };

      /**
     * @ngdoc
     * @name changeDLstatusActiv
     * @methodOf DistributionList.controller:DistributionListController
     * @param {Object} DLlist This is selected distribution list to be activated. 
     * @description
     * This function is used to activate DL. This function is called on activate icon in DL table
     * @returns {undefined} This method does not return.
     */
    $scope.changeDLstatusActiv = function (DLlist) {
        $scope.DistributionListId = DLlist.DistributionListId;
        $scope.DistributionListName = DLlist.DistributionListName;
        //Service to chanhe ctatus
        DistributionListService.changeDistributionListStatus($scope.userId, $scope.DistributionListId, function (status) {
            if (status) {
                $scope.deleteValidationMsg = "The selected Distribution List is activated";
                $('#deleteValidationMsgDiv').css('display', 'block');
                $timeout(function () { $('#deleteValidationMsgDiv').css('display', 'none') }, 3000);
                init();
            }
            else {
                $scope.deleteValidationMsg = "The selected Distribution List could not be activated";
            }
        });
    };

    /**
     * @ngdoc
     * @name confirmDeleteDLButton
     * @methodOf DistributionList.controller:DistributionListController
     * @description
     * This function is used to delete DL. This function is called on ok button on confirmation popup.
     * @returns {undefined} This method does not return.
     */
    $scope.confirmDeleteDLButton = function () {
        //Service to chanhe ctatus
        DistributionListService.changeDistributionListStatus($scope.userId, $scope.DistributionListId, function (status) {
            if (status) {
                $scope.deleteValidationMsg = "The selected Distribution List is deactivated";
                $('#deleteValidationMsgDiv').css('display', 'block');
                $timeout(function () { $('#deleteValidationMsgDiv').css('display', 'none') }, 3000);
                init();
            }
            else {
                $scope.deleteValidationMsg = "The selected Distribution List could not be deactivated";
            }
            setTimeout(function () { dynamicScreenHeight(); }, 500);
        });
    };

    /**
     * @ngdoc
     * @name showStatusWiseDitributionlist
     * @methodOf DistributionList.controller:DistributionListController
     * @param {String} DLStatus This is selected status filter.
     * @description
     * This function is used to filter DLs status wise. This function is called on status filter change (Active/Inactive).
     * @returns {undefined} This method does not return.
     */
    $scope.showStatusWiseDitributionlist = function (DLStatus) {
        $scope.distributionListCurrent = [];
        $scope.DistrubutionListStatus = DLStatus;
        setTimeout(function () { dynamicScreenHeight(); }, 500);
        if (DLStatus == "") {
            $scope.IsActiveFilter = true;
            $scope.IsInActiveFilter = false;
            $scope.ShowAllFilter = false;
            $scope.distributionListCurrent = $scope.distributionListAll.true;
            if (!$scope.distributionListCurrent) {
                $scope.noDLAvailable = true;
            } else {
                $scope.noDLAvailable = false;
            }
        }
        else if (DLStatus == "inactive") {
            $scope.IsActiveFilter = false;
            $scope.IsInActiveFilter = true;
            $scope.ShowAllFilter = false;
            $scope.distributionListCurrent = $scope.distributionListAll.false;
            if (!$scope.distributionListCurrent) {
                $scope.noDLAvailable = true;
            } else {
                $scope.noDLAvailable = false;
            }
        }
        else {
            $scope.IsActiveFilter = false;
            $scope.IsInActiveFilter = false;
            $scope.ShowAllFilter = true;
            $scope.distributionListCurrent = $scope.dlDataOnLoad.AssignedDistributionListInformation;
            if (!$scope.distributionListCurrent) {
                $scope.noDLAvailable = true;
            } else {
                $scope.noDLAvailable = false;
            }
        }
    };

    /**
     * @ngdoc
     * @name showRoleWiseDistributionist
     * @methodOf DistributionList.controller:DistributionListController
     * @param {String} DLStatus This is selected status filter.
     * @param {String} selectedRoleName This is selected role filter.
     * @description
     * This function is used to filter DLs role wise. This function is called on role filter change.
     * @returns {undefined} This method does not return.
     */
    $scope.showRoleWiseDistributionist = function (DLstatus, selectedRoleName) {
        var distributionListAllByRole = [];
        $scope.showStatusWiseDitributionlist($scope.DistrubutionListStatus);
        //$scope.distributionListTrue = $scope.distributionListAll.true;
        //$scope.distributionListFalse = $scope.distributionListAll.false;
        $scope.distributionList = $scope.dlDataOnLoad.AssignedDistributionListInformation;
        switch (selectedRoleName) {
            case 'Admin':
                var DLlistAdmin = [];
                if (DLstatus == 'inactive') {
                    distributionListAllByRole = _.groupBy($scope.distributionListCurrent, 'DistributionListTypeName');
                    DLlistAdmin = distributionListAllByRole.Admin;
                    if (!DLlistAdmin) {
                        $scope.distributionListCurrent = [];
                        $scope.noDLAvailable = true;
                    }
                    else {
                        $scope.distributionListCurrent = DLlistAdmin;
                        $scope.noDLAvailable = false;
                    }
                }
                else if (DLstatus == '') {
                    distributionListAllByRole = _.groupBy($scope.distributionListCurrent, 'DistributionListTypeName');
                    DLlistAdmin = distributionListAllByRole.Admin;
                    if (!DLlistAdmin) {
                        $scope.distributionListCurrent = [];
                        $scope.noDLAvailable = true;
                    }
                    else {
                        $scope.distributionListCurrent = DLlistAdmin;
                        $scope.noDLAvailable = false;
                    }
                }
                else {
                    distributionListAllByRole = _.groupBy($scope.distributionListCurrent, 'DistributionListTypeName');
                    DLlistAdmin = distributionListAllByRole.Admin;
                    if (!DLlistAdmin) {
                        $scope.distributionListCurrent = [];
                        $scope.noDLAvailable = true;
                    }
                    else {
                        $scope.distributionListCurrent = DLlistAdmin;
                        $scope.noDLAvailable = false;
                    }
                }

                break;

            case 'Approver':
                var DLlistApprover = [];
                if (DLstatus == 'inactive') {
                    distributionListAllByRole = _.groupBy($scope.distributionListCurrent, 'DistributionListTypeName');
                    DLlistApprover = distributionListAllByRole.Approver;
                    if (!DLlistApprover) {
                        $scope.distributionListCurrent = [];
                        $scope.noDLAvailable = true;
                    }
                    else {
                        $scope.distributionListCurrent = DLlistApprover;
                        $scope.noDLAvailable = false;
                    }
                }
                else if (DLstatus == '') {
                    distributionListAllByRole = _.groupBy($scope.distributionListCurrent, 'DistributionListTypeName');
                    DLlistApprover = distributionListAllByRole.Approver;
                    if (!DLlistApprover) {
                        $scope.distributionListCurrent = [];
                        $scope.noDLAvailable = true;
                    }
                    else {
                        $scope.distributionListCurrent = DLlistApprover;
                        $scope.noDLAvailable = false;
                    }
                }
                else {
                    distributionListAllByRole = _.groupBy($scope.distributionListCurrent, 'DistributionListTypeName');
                    DLlistApprover = distributionListAllByRole.Approver;
                    if (!DLlistApprover) {
                        $scope.distributionListCurrent = [];
                        $scope.noDLAvailable = true;
                    }
                    else {
                        $scope.distributionListCurrent = DLlistApprover;
                        $scope.noDLAvailable = false;
                    }
                }
                break;

            case 'Translator':
                var DLlistTranslator = [];
                if (DLstatus == 'inactive') {
                    distributionListAllByRole = _.groupBy($scope.distributionListCurrent, 'DistributionListTypeName');
                    DLlistTranslator = distributionListAllByRole.Translator;
                    if (!DLlistTranslator) {
                        $scope.distributionListCurrent = [];
                        $scope.noDLAvailable = true;
                    }
                    else {
                        $scope.distributionListCurrent = DLlistTranslator;
                        $scope.noDLAvailable = false;
                    }
                }
                else if (DLstatus == '') {
                    distributionListAllByRole = _.groupBy($scope.distributionListCurrent, 'DistributionListTypeName');
                    DLlistTranslator = distributionListAllByRole.Translator;
                    if (!DLlistTranslator) {
                        $scope.distributionListCurrent = [];
                        $scope.noDLAvailable = true;
                    }
                    else {
                        $scope.distributionListCurrent = DLlistTranslator;
                        $scope.noDLAvailable = false;
                    }
                }
                else {
                    distributionListAllByRole = _.groupBy($scope.distributionListCurrent, 'DistributionListTypeName');
                    DLlistTranslator = distributionListAllByRole.Translator;
                    if (!DLlistTranslator) {
                        $scope.distributionListCurrent = [];
                        $scope.noDLAvailable = true;
                    }
                    else {
                        $scope.distributionListCurrent = DLlistTranslator;
                        $scope.noDLAvailable = false;
                    }
                }
                break;

            case 'Client Admin':
                var DLlistCAdmin = [];
                if (DLstatus == 'inactive') {
                    distributionListAllByRole = _.groupBy($scope.distributionListCurrent, 'DistributionListTypeName');
                    DLlistCAdmin = distributionListAllByRole['Client Admin'];
                    if (!DLlistCAdmin) {
                        $scope.distributionListCurrent = [];
                        $scope.noDLAvailable = true;
                    }
                    else {
                        $scope.distributionListCurrent = DLlistCAdmin;
                        $scope.noDLAvailable = false;
                    }
                }
                else if (DLstatus == '') {
                    distributionListAllByRole = _.groupBy($scope.distributionListCurrent, 'DistributionListTypeName');
                    DLlistCAdmin = distributionListAllByRole['Client Admin'];
                    if (!DLlistCAdmin) {
                        $scope.distributionListCurrent = [];
                        $scope.noDLAvailable = true;
                    }
                    else {
                        $scope.distributionListCurrent = DLlistCAdmin;
                        $scope.noDLAvailable = false;
                    }
                }
                else {
                    distributionListAllByRole = _.groupBy($scope.distributionListCurrent, 'DistributionListTypeName');
                    DLlistCAdmin = distributionListAllByRole['Client Admin'];
                    if (!DLlistCAdmin) {
                        $scope.distributionListCurrent = [];
                        $scope.noDLAvailable = true;
                    }
                    else {
                        $scope.distributionListCurrent = DLlistCAdmin;
                        $scope.noDLAvailable = false;
                    }
                }
                break;

            case 'Super Admin':
                var DLlistSuperAdmin = [];
                if (DLstatus == 'inactive') {
                    distributionListAllByRole = _.groupBy($scope.distributionListCurrent, 'DistributionListTypeName');
                    DLlistSuperAdmin = distributionListAllByRole['Super Admin'];
                    if (!DLlistSuperAdmin) {
                        $scope.distributionListCurrent = [];
                        $scope.noDLAvailable = true;
                    }
                    else {
                        $scope.distributionListCurrent = DLlistSuperAdmin;
                        $scope.noDLAvailable = false;
                    }
                }
                else if (DLstatus == '') {
                    distributionListAllByRole = _.groupBy($scope.distributionListCurrent, 'DistributionListTypeName');
                    DLlistSuperAdmin = distributionListAllByRole['Super Admin'];
                    if (!DLlistSuperAdmin) {
                        $scope.distributionListCurrent = [];
                        $scope.noDLAvailable = true;
                    }
                    else {
                        $scope.distributionListCurrent = DLlistSuperAdmin;
                        $scope.noDLAvailable = false;
                    }
                }
                else {
                    distributionListAllByRole = _.groupBy($scope.distributionListCurrent, 'DistributionListTypeName');
                    DLlistSuperAdmin = distributionListAllByRole['Super Admin'];
                    if (!DLlistSuperAdmin) {
                        $scope.distributionListCurrent = [];
                        $scope.noDLAvailable = true;
                    }
                    else {
                        $scope.distributionListCurrent = DLlistSuperAdmin;
                        $scope.noDLAvailable = false;
                    }
                }
                break;

            case 'Client User':
                var DLlistCUser = [];
                if (DLstatus == 'inactive') {
                    distributionListAllByRole = _.groupBy($scope.distributionListCurrent, 'DistributionListTypeName');
                    DLlistCUser = distributionListAllByRole['Client User'];
                    if (!DLlistCUser) {
                        $scope.distributionListCurrent = [];
                        $scope.noDLAvailable = true;
                    }
                    else {
                        $scope.distributionListCurrent = DLlistCUser;
                        $scope.noDLAvailable = false;
                    }
                }
                else if (DLstatus == '') {
                    distributionListAllByRole = _.groupBy($scope.distributionListCurrent, 'DistributionListTypeName');
                    DLlistCUser = distributionListAllByRole['Client User'];
                    if (!DLlistCUser) {
                        $scope.distributionListCurrent = [];
                        $scope.noDLAvailable = true;
                    }
                    else {
                        $scope.distributionListCurrent = DLlistCUser;
                        $scope.noDLAvailable = false;
                    }
                }
                else {
                    distributionListAllByRole = _.groupBy($scope.distributionListCurrent, 'DistributionListTypeName');
                    DLlistCUser = distributionListAllByRole['Client User'];
                    if (!DLlistCUser) {
                        $scope.distributionListCurrent = [];
                        $scope.noDLAvailable = true;
                    }
                    else {
                        $scope.distributionListCurrent = DLlistCUser;
                        $scope.noDLAvailable = false;
                    }
                }
                break;
            //else display by default only the active users by making the active flag true
            default:
                distributionListAllByRole = _.groupBy($scope.distributionListCurrent, 'DistributionListTypeName');
                break;
        }
    };


    //reset Role select box
    $scope.resetDLType = function () {
        $scope.selectedRoleName = $scope.RoleList[-1];
    };

    $scope.reloadPage = function () {
        $route.reload();
    };

    $scope.dynamicScreenHeightCall = function () {
        dynamicScreenHeight();
    }

    //For Client Multi select dropdown
    $scope.$on('selectedModel', function (event, myData) {
        if (myData.length == 0) {
            $scope.AddDLForm.isClientRequired = true;
            $('.client_str').html('Select Client(s)');
            $('.client_str').attr('title', 'Select Client(s)')
        } else {
            $scope.AddDLForm.isClientRequired = false;
            $scope.myDataClientId = myData;
            $scope.client_str = '';
            for (j = 0; j < $scope.myDataClientId.length; j++) {
                for (i = 0; i < $scope.AllClientLlist.length; i++) {
                    if ($scope.AllClientLlist[i].ClientId == $scope.myDataClientId[j]) {
                        if ($scope.client_str != '') {
                            $scope.client_str = $scope.client_str + ', ' + $scope.AllClientLlist[i].ClientName;
                        } else {
                            $scope.client_str = $scope.client_str + $scope.AllClientLlist[i].ClientName;
                        }
                        $('.client_str').html($scope.client_str);
                        $('.client_str').attr('title', $scope.client_str);
                    }
                }
            }
        }
        $scope.IsUsersWithAllLanguages = false;
    });

    //Add popup valiations
   /**
     * @ngdoc
     * @name saveNewAdaminAndSuperAdminDL
     * @methodOf DistributionList.controller:DistributionListController
     * @description
     * This function is used to validate add new DL form for admin and super admin users
     * @returns {undefined} This method does not return.
     */
    $scope.saveNewAdaminAndSuperAdminDL = function () {
        if (!$scope.DuplicateValidation($scope.DistributionListName)) {
            return false;
        }
        else {
            var AdminValid = validateDLdata().AdminValid;
            if (AdminValid) {
                saveDistributionList();
            }
        }
    };

   /**
     * @ngdoc
     * @name saveNewApproverAndTranslatorDL
     * @methodOf DistributionList.controller:DistributionListController
     * @description
     * This function is used to validate add new DL form for approver and translators users
     * @returns {undefined} This method does not return.
     */
    $scope.saveNewApproverAndTranslatorDL = function () {
        if (!$scope.DuplicateValidation($scope.DistributionListName)) {
            return false;
        }
        else {
            var AdminValid = validateDLdata().AdminValid;
            var AppoverValid = validateDLdata().AppoverValid;
            if (AppoverValid && AdminValid) {
                saveDistributionList();
            }
        }
    };

   /**
     * @ngdoc
     * @name saveNewClientAdminAndClientUserDL
     * @methodOf DistributionList.controller:DistributionListController
     * @description
     * This function is used to validate add new DL form for client admins and client users
     * @returns {undefined} This method does not return.
     */
    $scope.saveNewClientAdminAndClientUserDL = function () {
        if (!$scope.DuplicateValidation($scope.DistributionListName)) {
            return false;
        }
        else {
            var AdminValid = validateDLdata().AdminValid;
            var ClientAdminValid = validateDLdata().ClientAdminValid;
            if (ClientAdminValid && AdminValid) {
                saveDistributionList();
            }
        }
    };

    //Edit popup validations
    /**
     * @ngdoc
     * @name updateAdaminAndSuperAdminDL
     * @methodOf DistributionList.controller:DistributionListController
     * @description
     * This function is used to validate add edit DL form for admin and super admin users
     * @returns {undefined} This method does not return.
     */
    $scope.updateAdaminAndSuperAdminDL = function () {
        var AdminValid = validateDLdata().AdminValid;
        if (AdminValid) {
            EditDistributionList();
        }
    };

    /**
     * @ngdoc
     * @name updateApproverAndTranslatorDL
     * @methodOf DistributionList.controller:DistributionListController
     * @description
     * This function is used to validate add edit DL form for approver and translators users
     * @returns {undefined} This method does not return.
     */
    $scope.updateApproverAndTranslatorDL = function () {
        var AdminValid = validateDLdata().AdminValid;
        var AppoverValid = validateDLdata().AppoverValid;
        if (AppoverValid && AdminValid) {
            EditDistributionList();
        }
    };

    /**
     * @ngdoc
     * @name updateClientAdminAndClientUserDL
     * @methodOf DistributionList.controller:DistributionListController
     * @description
     * This function is used to validate add edit DL form for client admins and client users
     * @returns {undefined} This method does not return.
     */
    $scope.updateClientAdminAndClientUserDL = function () {
        var AdminValid = validateDLdata().AdminValid;
        var ClientAdminValid = validateDLdata().ClientAdminValid;
        if (ClientAdminValid && AdminValid) {
            EditDistributionList();
        }
    };

    //validation object
    var validateObj = {};
    validateObj.AdminValid = false;
    validateObj.AppoverValid = false;
    validateObj.ClientAdminValid = false;

    /**
     * @ngdoc
     * @name DuplicateValidation
     * @methodOf DistributionList.controller:DistributionListController
     * @param {String} DistributionListName this is distribution list name.
     * @description
     * This function is used to validate DL name for unique name.
     * @returns {undefined} This method does not return.
     */
    $scope.DuplicateValidation = function (DistributionListName) {
        if (!$scope.DistributionListName) {
            $scope.AddDLForm.isGroupNameRequired = true;
            $scope.EditDLForm.isGroupNameRequired = true;
            $scope.isGroupNameDuplicate = false;
            return false;
        }
        else {
            var txtDistributionListName = DistributionListName.toLowerCase().trim();
            txtDistributionListName = txtDistributionListName.replace(/\s+/g, " ");
            for (var i = 0; i < $scope.dlDataOnLoad.AssignedDistributionListInformation.length; i++) {
                if ($scope.dlDataOnLoad.AssignedDistributionListInformation[i].DistributionListName.toLowerCase() === txtDistributionListName) {
                    $scope.isGroupNameDuplicate = true;
                    return false;
                }
            }
            $scope.isGroupNameDuplicate = false;
            return true;
        }
    };


    var validateDLdata = function () {

        //groupname validation
        if (!$scope.DistributionListName) {
            $scope.AddDLForm.isGroupNameRequired = true;
            $scope.EditDLForm.isGroupNameRequired = true;
            validateObj.AdminValid = false;
            validateObj.AppoverValid = false;
            validateObj.ClientAdminValid = false;
            return validateObj;
        }
        else {
            $scope.EditDLForm.isGroupNameRequired = false;
            $scope.AddDLForm.isGroupNameRequired = false;
            validateObj.AdminValid = true;
            validateObj.AppoverValid = true;
            validateObj.ClientAdminValid = true;
        }

        //client selected validation
        if ($scope.Selectedclients.length == 0) {
            $scope.AddDLForm.isClientRequired = true;
            $scope.EditDLForm.isClientRequired = true;
            validateObj.AppoverValid = false;
            validateObj.ClientAdminValid = false;
            return validateObj;
        }
        else {
            $scope.AddDLForm.isClientRequired = false;
            $scope.EditDLForm.isClientRequired = false;
            validateObj.AppoverValid = true;
            validateObj.ClientAdminValid = true;
        }
        //selected user validate
        if ($scope.objLangUser.selectUsers.length == 0) {
            if ($scope.objLangUser.selectLang.length == 0) {
                $scope.AddDLForm.islanguageRquired = true;
                $scope.EditDLForm.islanguageRquired = true;
            }
            $scope.AddDLForm.isUserRequired = true;
            $scope.EditDLForm.isUserRequired = true;
            validateObj.AdminValid = false;
            validateObj.AppoverValid = false;
            validateObj.ClientAdminValid = false;
            return validateObj;
        }
        else {
            $scope.AddDLForm.islanguageRquired = false;
            $scope.EditDLForm.islanguageRquired = false;
            $scope.AddDLForm.isUserRequired = false;
            $scope.EditDLForm.isUserRequired = false;
            validateObj.AdminValid = true;
            validateObj.AppoverValid = true;
            validateObj.ClientAdminValid = true;

        }
        return validateObj;
    };

     /**
     * @ngdoc
     * @name validateDLdataOnChange
     * @methodOf DistributionList.controller:DistributionListController
     * @param {String} model This is DL form field, which need to be validated
     * @description
     * This function is used to validate DL inputs on change.
     * @returns {undefined} This method does not return.
     */
    $scope.validateDLdataOnChange = function (model) {
        switch (model) {
            case 'DLName':
                if (!$scope.DistributionListName) {
                    $scope.AddDLForm.isGroupNameRequired = true;
                    $scope.EditDLForm.isGroupNameRequired = true;
                }
                else {

                    $scope.AddDLForm.isGroupNameRequired = false;
                    $scope.EditDLForm.isGroupNameRequired = false;
                }
                break;

            case 'role':
                if (!$scope.RoleName) {
                    $scope.AddDLForm.isGroupTypeRequired = true;
                    $scope.EditDLForm.isGroupTypeRequired = true;
                }
                else {
                    $scope.AddDLForm.isGroupTypeRequired = false
                    $scope.EditDLForm.isGroupTypeRequired = false
                }

                break;
            case 'users':
                if ($scope.objLangUser.selectUsers.length == 0) {
                    $scope.AddDLForm.isUserRequired = true;
                    $scope.EditDLForm.isUserRequired = true;
                }
                else {
                    $scope.AddDLForm.isUserRequired = false;
                    $scope.EditDLForm.isUserRequired = false;
                }
                break;
            case 'lang':
                if ($scope.objLangUser.selectLang.length == 0) {
                    $scope.AddDLForm.islanguageRquired = true;
                    $scope.EditDLForm.islanguageRquired = true;
                }
                else {
                    $scope.AddDLForm.islanguageRquired = false;
                    $scope.EditDLForm.islanguageRquired = false;
                }
                break;
        }
    };

    /**
     * @ngdoc
     * @name sort
     * @methodOf DistributionList.controller:DistributionListController
     * @param {String} keyname This is column name of column which is need to be sorted
     * @description
     * This function is used to sort list of DLs.
     * @returns {undefined} This method does not return.
     */
    $scope.sort = function (keyname) {
        $scope.sortKey = keyname;   //set the sortKey to the param passed
        $scope.reverse = !$scope.reverse; //if true make it false and vice versa
    };

    /**
     * @ngdoc
     * @name init
     * @methodOf DistributionList.controller:DistributionListController
     * @description
     * This function is called initially when page is loaded. This function is used for initialisation of the variables on page load.
     * @returns {undefined} This method does not return.
     */
    var init = function () {
        $scope.showLoader = true;
        var userDetails = commonService.getLocalData('userDetails');
        $scope.userDetails = userDetails;
        $scope.userId = $scope.userDetails.UserId;

        //Service to get client,brands,categories,sections list
        DistributionListService.getDistributionList($scope.userId, function (dlDataOnLoad) {
            $scope.dlDataOnLoad = dlDataOnLoad;
            $scope.RoleList = dlDataOnLoad.RoleList;
            $scope.AllClientLlist = dlDataOnLoad.ClientList;
            $scope.member = { AllClientLlist: [] };
            $scope.AssignedClientList = [];

            //load languages in language dropdown filter
            $scope.langList = dlDataOnLoad.LanguageList;

            $scope.distributionList = $scope.dlDataOnLoad.AssignedDistributionListInformation;
            $scope.distributionListAll = _.groupBy($scope.distributionList, 'IsActive');
            $scope.distributionListCurrent = $scope.distributionListAll.true;
            //$scope.distributionListFalse = $scope.distributionListAll.false;
            $scope.showLoader = false;

            if ($scope.distributionList) {
                if ($scope.distributionList.length > 0) {
                    $scope.noDLAvailable = false;
                }
            }
            $scope.objLangUser.unSelectLang = dlDataOnLoad.LanguageList;
            dynamicScreenHeight();
        });

    };
    init();
}]);