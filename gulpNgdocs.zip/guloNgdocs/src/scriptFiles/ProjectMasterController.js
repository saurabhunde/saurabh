/**
 * @ngdoc controller
 * @name Projects.controller:ProjectMasterController
 * @element div
 *
 * @description
 * This Controller is responsible for showing content on project source setup page.
 *
 * @requires AngularJS.$scope
 * @requires AngularJS.$http
 * @requires AngularJS.$location
 * @requires AngularJS.$route
 * @requires AngularJS.$timeout
 * @requires AngularJS.$interval
 * @requires common.commonService
 * @requires Projects.LandingPageData
 * @requires Projects.ProjectMaster
 * 
 * @property {Object} userDetails:Object This is object stores the user details received from backend when user is logged in. 
 * @property {Object} ProjectInfo:Object This is object stores the basic info of project received from backend on page load. 
 * @property {Object} selectedGroup:Object This is object stores the selected sections(from dropdown) information of the project. 
 * @property {Object} selectedGroupCopy:Object This is copy of object selectedGroup. 
 * @property {Number} ProjectHeaderId:Number This is id of selected section . 
 * @property {Number} sectionType:Number This is used to store section type, 1 for default 2 for NTL. 
 * @property {Number} modeType:Number This is used to store mode type, 0 for default 1 for review mode. 
 * @property {Boolean} Isowner:Boolean This is boolean value, true if user is project owner else false.
 * @property {String} projectId:String This property is encrypted project id.
 * @property {Array} headers:Array This property contains all list of sections shown in dropdown of section ;
 * @property {Array} displayingSelectedGroup:Array This property is array which contains all sections information to be displayed on source setup table;
 * @property {String} buttonlabel:String This property is label on section dropdown button .
 * @property {String} noSecAvalableMsg:String This property is to show message if there is not any section present.
 * @property {Boolean} isAddedImageDetails:Boolean This is boolean value, true if any image is added to term.
 * @property {Array} myImageData:Array This property is array which contains all uploaded images in the section.
 * @property {Array} reviewPanel:Array This property is array which contains all the suggestions on apply suggestion popup
 * @property {Boolean} isSecretChanged:Boolean This is boolean value, depends on secret section checkbox.
 * @property {Boolean} showValidation:Boolean This is boolean value, used to show validation message on move term popup.
 * @property {Boolean} isSequenceChanged:Boolean This is boolean value, set to true if sequence od term is changed.
 * @property {Boolean} isAddRowButtonDisabled:Boolean This is boolean value, used to disable add new row button.
 * @property {String} validationMsg:String This property is validation message..
 * @property {Array} sectionList:Array This property is array which contains all sections list (assigned as well as unassigned) on add/edit section popup;
 * @property {String} textEditBulkSection:String This property is used on text box of edit section name popup on Add/Edit bulk section
 * @property {Array} headerstoMigrate:Array This property is array which contains all headers list which is displayed on migrate section popup. 
 * @property {Array} selectedSectionsList:Array This property is array which contains all selected section list on edit brands popup and edit additional info options popup  
 * @property {Array} unselectedSectionsList:Array This property is array which contains all not (on left) selected section list on edit brands popup and edit additional info options popup 
 * @property {Boolean} hideInfoColumns:Boolean This is boolean value, used to hide additional info columns.
 * @property {Boolean} hideTermUniqueID:Boolean This is boolean value, used to hide unique ID column.
 * @property {Boolean} hideStarred:Boolean This is boolean value, used to hide starred column.
 * 
 */
Projects.controller('projectMasterController', ['$scope', '$http', '$route', '$location', 'ProjectMaster', 'commonService', '$routeParams', 'LandingPageData', 'ProjectIdService', '$filter', 'ngTableParams', '$timeout', '$rootScope', '$interval', function ($scope, $http, $route, $location, ProjectMaster, commonService, $routeParams, LandingPageData, ProjectIdService, $filter, ngTableParams, $timeout, $rootScope, $interval) {
    //declaring all the variables
    $scope.buttonlabel = "Select Any Section to update any record";
    $scope.noSecAvalableMsg = "No sections Available";
    $scope.errorHeaderText = false;
    var projectId = commonService.getSessionData('projectIBreadCrumb');
    var totalRowsAdded = 0;
    $scope.showLoader = false;
    var isAddedImageDetails = false;
    $scope.Isowner = false;
    $scope.modeWidth = 6;
    var userDetails;
    var myImageData = [];
    $scope.reviewPanel = [];
    var masterGlossaryIdForImage;
    $scope.errorMessage;
    $scope.successMessage;
    $scope.successMessageTitle;
    $scope.lockInput = false;
    var isSecretChanged = false;
    var isHeaderAdded = false;
    $scope.showValidation = false;
    var isSequenceChanged = false;
    $scope.isAddRowButtonDisabled = false;
    var isUpdateTableChanged = false;
    $scope.validationMsg = '';
    var selectedGroupCopy = {};
    var modifiedHeaderData = [];
    $scope.SourceInfo = [];
    var TermsAddedBrandsCopy = [];
    var TermsRemovedBrandsCopy = [];
    var initialRowCount;
    var headerId;
    var projectHeader = {};
    $scope.importSript = false;
    $scope.isRecordDisplayed = false;
    $scope.origImage = '';
    $scope.CropImage = '';
    $scope.ssize = 100;
    var attachedFiles = [];
    var editProjectData = {};
    var insertedRowlength;
    var deletedSectionIndex;
    var deletedImageList = [
          {
              MasterGlossaries: []
          }
    ];
    $scope.ProjectMasterJson = {
        TableData: []
    };
    $scope.projectMasterFromDb = {
        TableData: []
    };
    $scope.updatedListOfHeaderData = [
     {
         "HeaderText": null,
         "ProjectHeaderId": -1,
         "MasterGlossaries": []
     }
    ];
    $scope.newListOfHeaderData = [
     {
         "HeaderText": null,
         "ProjectHeaderId": -1,
         "MasterGlossaries": []
     }
    ];
    $scope.displayingSelectedGroup = [];
    var copyOfDisplayingSelectedGroup = [];
    $scope.categories = [];
    $scope.categoriesAll = [];
    $scope.headers = [];
    $scope.deletedRowsList = [
       {
           "MasterGlossaries": []
       }
    ];
    var addedNewRowsList = [];
    $scope.headerToBeMoved = [];
    var isHeaderChanged = false;
    $scope.noOfCategories;
    var isValidField = true;
    var rowIndexToBeMoved;
    $scope.sortingLog = [];
    $scope.unselectedSectionsList = [];
    $scope.selectedSectionsList = [];
    $scope.unselectedBrandsList = [];
    $scope.sectionBrandsToBeSaved = {
        "ProjectSelectedSections": [],
        "ProjectAddedBrands": [],
        "ProjectRemovedBrands": []
    };
    $scope.TermBrandViewModel = {
        "ProjectId": projectId,
        "MasterGlossaryId": -1,
        "TermAddedBrands": [],
        "TermRemovedBrands": []
    }
    var TermAddedBrands = [];
    var TermRemovedBrands = [];
    var GlossaryBrandsHeaderWise = [];

    var CategoryAdded = [];
    var CategoryRemoved = [];
    $scope.categoryValidationMsgShow = false;
    $scope.categoryWarningMsgShow = false;
    var addNewSectionBtnClicked = false;
    var duplicateTermValidationMsg = "Term(s) already exists within this section of the glossary";
    var duplicateRemovedTermValidationMsg = "Term(s) already exists as removed within this section of the glossary";
    $scope.categoryValidationMsg = "*Mandatory Fields are required";

    var TermImage = [];

    //for auto save functionality
    var MasterGlossaryCategoryModel = {};
    var IsMasterTermUpdated = false;

    var rowDataAfterSequenceChange = {};
    var projectHeaderIdForImage;

    //ntl section GLMGR-757
    $scope.defaultSectionType = true;
    $scope.ntlSectionType = false;
    $scope.sectionType = 1;
    $scope.saveSectionButtonName = 'Save Section';
    $scope.updateSectionButtonName = 'Save Section Name';
    var validationDefaultSection = 'Default Section name should not have "NTL - ", "FD - ", "NTL-", "FD-", "Localization List", "Localisation List", "Foreign Dialogue", "Foreign Dialog" in UPPERCASE or lowercase. Instead, use the NTL/FD Sections Tab for this.';
    var validationNTLSection = 'Section name should not have "NTL - ", "FD - ", "NTL-", "FD-", "Localization List", "Localisation List", "Foreign Dialogue", "Foreign Dialog" in UPPERCASE or lowercase.';

    //GLMGR-893
    $scope.submitMigrationError = false;
    $scope.submitMigrationButton = true;

    var cancelSectionClicked = false; //GLMGR-956
    var IsDataExistInSection = false; //GLMGR-806
    $scope.showRemovedTerms = false; //GLMGR-1240/1274/1266
    $scope.isShowRemovedTerms = false; //GLMGR-1240/1274/1266

    var sectionCompleteGotoGlossary = false;
    var sectionCompleteAddNewSection = false;
    var sectionCompleteChangeSection = false;

    $scope.sectionCompleteReminderInfo = false; //GLMGR-1360
    $scope.sectionCompleteReminderFlag = false; //GLMGR-1360
    $scope.showDeleteSectionSuccessOKButton = false;

    var watcherDataCopy = {}; //save original watchers data on init
    var objSectionStatus = {};
    var masterTextBoxEnteredFlag = false;

    //set hashURL for GLMGR-1189
    sessionStorage.setItem('hashURL', window.location.hash);
    var linkToGoNext;
    /* Functionalities  start */

      /**
     * @ngdoc
     * @name changeView
     * @methodOf Projects.controller:ProjectMasterController
     * @param {string} new_path The Name of the view bound with element on which this function is called.

     * @description
     * This function is called to change views and loads respective html page.Below are some views
     * Glossary, Source Setup, Add project, Edit Project,Project Permissions,Project Info
     * @returns {undefined} This method does not return.
     */
    $scope.changeView = function (new_path) {
        switch (new_path) {
            case "glossary":
                if ($scope.reviewModeStored === false && $scope.IsSectionCompleteReminderFlag) {
                    if (!$scope.displayingSelectedGroup[0].MasterGlossaries[0].MasterText) {
                        $scope.errorMessage = '';
                        $scope.errorMessage = 'Please enter the Master Term for the section. If you wish to add Master Term later, please click "Close" button at the bottom of the section.';
                        $('#errorModal').modal('show');
                        return false;
                    }
                    sectionCompleteGotoGlossary = true;
                    $('#sectionCompleteReminder').modal({ backdrop: 'static', keyboard: false });
                    $('#sectionCompleteReminder').modal('show');
                } else if ($scope.reviewMode && checkEmailFlagOnSuggestion()) {
                    $('#reviewCompleteReminderBeforeGlossary').modal({ backdrop: 'static', keyboard: false });
                    $('#reviewCompleteReminderBeforeGlossary').modal('show');
                }
                else {
                    if (sessionStorage.getItem('ActiveSectionType')) {
                        $scope.lockInput = false; //GLMGR-956
                        cancelSectionClickedFunction(); //GLMGR-956
                        if (sessionStorage.getItem('ActiveSectionType') === "1") {
                            var temp = 'default';
                            sessionStorage.setItem('glossaryTab', JSON.stringify(temp));
                        }
                        else if (sessionStorage.getItem('ActiveSectionType') === "2") {
                            var temp = 'ntl';
                            sessionStorage.setItem('glossaryTab', JSON.stringify(temp));
                        }
                        else {
                            var temp = 'default';
                            sessionStorage.setItem('glossaryTab', JSON.stringify(temp));
                        }
                    }

                    if (($scope.headers.length === 0)) {
                        $scope.errorMessage = 'No Glossary Available for the selected project!';
                        $('#errorModal').modal('show');
                    } else {
                        $('.modal-backdrop.fade.in').css('display', 'none');
                        $location.path('/sourceSetup/glossary');
                    }
                }



                break;
        }
    };

    
      /**
     * @ngdoc
     * @name proceedToGlossary
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This function is called on proceed to glossary button on submit Suggestion reminder popup
     * @returns {undefined} This method does not return.
     */
    $scope.proceedToGlossary = function () {
        $('#reviewCompleteReminderBeforeGlossary').modal('hide');
        $('.modal-backdrop.fade.in').css('display', 'none');
        $scope.reviewMode = false;
        $scope.changeView("glossary");

    };

    //For sorting (moving) rows in the table
    $scope.sortableOptions = {
        start: function (e, ui) { },

        update: function (e, ui) { },
        axis: 'y',
        stop: function (e, ui) {
            var logEntry = {
                ID: $scope.sortingLog.length + 1,
                Text: 'Moved element: ' + ui.item.sortable.model.MasterText,
            };
            $scope.sortingLog.push(logEntry);
            isSequenceChanged = true;
            rowDataAfterSequenceChange = ui.item.sortable.model;
            $scope.showLoader = true;
            if ($scope.ProjectMasterJson.TableData.length > 0) {
                for (var i = 0; i < $scope.ProjectMasterJson.TableData.length; i++) {
                    var flag = false
                    for (var j = 0; j < $scope.ProjectMasterJson.TableData[i].MasterGlossaries.length; j++) {
                        if ($scope.ProjectMasterJson.TableData[i].MasterGlossaries[j].MasterGlossaryId === ui.item.sortable.model.MasterGlossaryId) {
                            projectHeader.Id = $scope.ProjectMasterJson.TableData[i].ProjectHeaderId;
                            break;
                            flag = true;
                        }
                    }
                    if (flag === true) {
                        break;
                    }
                }
            }
            autoSaveAfterSequenceChanged(projectHeader.Id, rowDataAfterSequenceChange);
        }
    };

     /**
     * @ngdoc
     * @name openmoveTermToPopup
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Object} rowData This is object contains all row data. 
     * @description
     * This function is called to open popup to move term to other section
     * @returns {undefined} This method does not return.
     */
    $scope.openmoveTermToPopup = function (rowData, index) {
        if (!rowData.MasterText) {
            $scope.errorMessage = 'Please Enter the Master Term';
            $('#errorModal').modal('show');
            return false;
        }
        $scope.validationMsg = '';
        $scope.showValidation = false;
        angular.copy($scope.headers, $scope.headerToBeMoved);
        for (var i = 0; i < $scope.headerToBeMoved.length; i++) {
            if ($scope.selectedGroup.Id === $scope.headerToBeMoved[i].Id) {
                $scope.headerToBeMoved.splice(i, 1);
            }
        }
        $('#moveTerm').modal('show');
        $scope.MaterGlossaryId = rowData.MasterGlossaryId;
        rowIndexToBeMoved = index;
    };

    
     /**
     * @ngdoc
     * @name getSectionToBeMovedOnChange
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This function to get the changed Section Id on Change on move term popup.
     * @returns {undefined} This method does not return.
     */
    $scope.getSectionToBeMovedOnChange = function () {
        //service to compare the categories in Origin(Source) Section and Destination(Target) Section
        ProjectMaster.CheckSectionCategories($scope.selectedGroup.Id, $scope.TermToBeMovedSection.Id, $scope.MaterGlossaryId, projectId, function (status) {
            if (status.WarningFlag) {
                $scope.categoryWarningMsgShow = true;
            }
            else {
                $scope.categoryWarningMsgShow = false;
            }
        });
    };

      /**
     * @ngdoc
     * @name moveTermToOtherSection
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This function to move term to other section on move term popup.
     * @returns {undefined} This method does not return.
     */
    $scope.moveTermToOtherSection = function () {
        var originaluser;
        if (!$scope.adminUser) {
            originaluser = null;
        }
        else {
            originaluser = $scope.adminUser.UserId
        }
        if (!$scope.TermToBeMovedSection) {
            $scope.validationMsg = 'Please Select the Section from below';
            $scope.showValidation = true;
            return false;
        }
        $scope.GlossaryGroupId = $scope.TermToBeMovedSection.Id;
        $scope.showLoader = true;
        ProjectMaster.moveTermToOtherSection($scope.GlossaryGroupId, $scope.MaterGlossaryId, userDetails.UserId, originaluser, function (status) {
            if (status) {
                //dissapearing the moved term row from the table
                for (var j = 0; j < $scope.displayingSelectedGroup[0].MasterGlossaries.length; j++) {
                    if (j === rowIndexToBeMoved) {
                        deletedRow = $scope.displayingSelectedGroup[0].MasterGlossaries.splice(j, 1);
                        if ($scope.displayingSelectedGroup[0].MasterGlossaries.length < 1) {
                            //create sequence from the master glossary id received in response
                            var masterGlossarySequence = [];
                            for (var i = 0; i < $scope.displayingSelectedGroup[0].MasterGlossaries.length; i++) {
                                masterGlossarySequence.push($scope.displayingSelectedGroup[0].MasterGlossaries[i].MasterGlossaryId);
                            }

                            var sequenceLength = masterGlossarySequence.length;
                            for (var j = 0; j < sequenceLength - 1; j++) {
                                for (var k = j + 1; k < sequenceLength; k++) {
                                    if (masterGlossarySequence[j] === masterGlossarySequence[k]) {
                                        masterGlossarySequence.splice(k, 1);
                                        sequenceLength = sequenceLength - 1;
                                    }
                                }
                            }
                            //Service call for sequencing of the table row
                            ProjectMaster.changeRowSequence($scope.selectedGroup.Id, masterGlossarySequence.toString(), userDetails.UserId, originaluser, function (sequenceStatus) {
                                if (sequenceStatus) {
                                    //Service call for sending Master Glossary Id to changed header for sequencing of the changed header
                                    ProjectMaster.glossarySequenceForMoveTerm($scope.GlossaryGroupId, $scope.MaterGlossaryId, projectId, userDetails.UserId, originaluser, function (status) {
                                        if (status) {
                                            $scope.showLoader = false;
                                            $('#moveTerm').modal('hide');
                                            $scope.categoryWarningMsgShow = false;
                                            $('.modal-backdrop.fade.in').css('display', 'none');
                                            $scope.successMessageTitle = 'Move term to another section';
                                            $scope.successMessage = "Selected term from " + $scope.selectedGroup.GlossaryGroupHeader + " is moved";
                                            $('#successModal').modal('show');
                                            $scope.reviewModeStored = true;
                                            sessionStorage.setItem('reviewModeStored', $scope.reviewModeStored);
                                            $scope.reloadSection();
                                        }
                                    });
                                }
                            });
                            break;
                        }
                        else {
                            //create sequence from the master glossary id received in response
                            var masterGlossarySequence = [];
                            for (var i = 0; i < $scope.displayingSelectedGroup[0].MasterGlossaries.length; i++) {
                                masterGlossarySequence.push($scope.displayingSelectedGroup[0].MasterGlossaries[i].MasterGlossaryId);
                            }
                            var sequenceLength = masterGlossarySequence.length;
                            for (var j = 0; j < sequenceLength - 1; j++) {
                                for (var k = j + 1; k < sequenceLength; k++) {
                                    if (masterGlossarySequence[j] === masterGlossarySequence[k]) {
                                        masterGlossarySequence.splice(k, 1);
                                        sequenceLength = sequenceLength - 1;
                                    }
                                }
                            }
                            //Service call for sequencing of the table row
                            ProjectMaster.changeRowSequence($scope.selectedGroup.Id, masterGlossarySequence.toString(), userDetails.UserId, originaluser, function (sequenceStatus) {
                                if (sequenceStatus) {
                                    //Service call for sending Master Glossary Id to changed header for sequencing of the changed header
                                    ProjectMaster.glossarySequenceForMoveTerm($scope.GlossaryGroupId, $scope.MaterGlossaryId, projectId, userDetails.UserId, originaluser, function (status) {
                                        $('#moveTerm').modal('hide');
                                        $scope.categoryWarningMsgShow = false;
                                        $('.modal-backdrop.fade.in').css('display', 'none');
                                        $scope.successMessageTitle = 'Move term to another section';
                                        $scope.successMessage = "Selected term is moved from " + $scope.selectedGroup.GlossaryGroupHeader + " to another section.";
                                        $('#successModal').modal('show');
                                        $scope.showLoader = false;
                                    });
                                }
                            });
                        }
                    }
                }
            }
            else {
                $scope.validationMsg = 'This term already exists within the selected section of the glossary : ' + $scope.TermToBeMovedSection.GlossaryGroupHeader;
                $scope.showValidation = true;
                $scope.showLoader = false;
            }
        });
    };

      /**
     * @ngdoc
     * @name getHeaderListAndCategoryList
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This function to get Categories List and Header List from the backend.
     * @returns {undefined} This method does not return.
     */
    var getHeaderListAndCategoryList = function () {
        $scope.categoriesAll = [];
        ProjectMaster.getCategoriesAndHeaderList(projectId, $scope.sectionType, function (projectMasterJson) {
            $scope.SourceInfo = [];
            //Copying all the Source Info in the Source Info Array for Auto Suggestion
            for (var i = 0; i < projectMasterJson.ProjectSourceInfo.length; i++) {
                for (var j = 0; j < projectMasterJson.ProjectSourceInfo[i].SourceVal.length; j++) {
                    $scope.SourceInfo.push(projectMasterJson.ProjectSourceInfo[i].SourceVal[j]);
                }
            }
            //Copying the Categories object for loading the selected sections
            if ($scope.displayingSelectedGroup.length > 0) {
                $scope.categories = $scope.displayingSelectedGroup[0].SectionCategories;
            }
            else {
                $scope.categories = projectMasterJson.ProjectCategories;
            }
            angular.copy(projectMasterJson.ProjectCategories, $scope.categoriesAll);
            $scope.headers = projectMasterJson.ProjectHeaders;

            //update the value of current section
            if (sessionStorage.getItem('SourceSetupActiveSection')) {
                $scope.selectedGroup = commonService.getSessionData('SourceSetupActiveSection');
                if ($scope.headers) {
                    for (i = 0; i < $scope.headers.length; i++) {
                        if ($scope.selectedGroup.Id === $scope.headers[i].Id) {
                            sessionStorage.setItem('SourceSetupActiveSection', JSON.stringify($scope.headers[i]));
                            $scope.selectedGroup = commonService.getSessionData('SourceSetupActiveSection');
                            break;
                        }
                    }
                }
            } 
            // for GLMGR-893/894
            $scope.headerstoMigrate = projectMasterJson.ProjectHeaders;
            for (var i = 0; i < $scope.headerstoMigrate.length; i++) {
                $scope.headerstoMigrate[i].SectionType = 1;
                $scope.headerstoMigrate[i].SectionSubType = 0;
            }
            $scope.ProjectNonAssignedSections = projectMasterJson.Sections.ProjectNonAssignedSections;
            $scope.noOfCategories = $scope.categories.length;
            angular.copy(projectMasterJson.ProjectHeaders, $scope.unselectedSectionsList);
        });

    };

     /**
     * @ngdoc
     * @name importSourceFile
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Object} group current selected section's data
     * @description
     * This function to import script.
     * @returns {undefined} This method does not return.
     */
    $scope.importSourceFile = function (group) {
        $timeout(function(){
            if (masterTextBoxEnteredFlag) {
                masterTextBoxEnteredFlag = false;
                return false;
            } else {
                if (group.MasterGlossaries.length === 1 && !group.MasterGlossaries[0].MasterText) {
                    IsDataExistInSection = false; //GLMGR-806
                    $scope.importheaderText = $scope.headerforImport;
                    $scope.previewTitle = "";
                    $scope.importgroupsource = group;
                    $scope.importSript = true;
                } else {
                    //GLMGR-806 popup
                    IsDataExistInSection = true;
                    $scope.IsAppendStart = false;
                    $('#importScriptAppend').modal({
                        backdrop: 'static',
                        keyboard: false
                    });
                    $('#importScriptAppend').modal('show');
                    $scope.importgroupsource = group;
                    $scope.importSript = true;
                }
            }
        }, 1000);
    };

    $scope.$on('addedFileDetails', function (event, myData, fileid) {
        var index = myData[0].filename.lastIndexOf(".");
        var validateFilename = myData[0].filename.substring(index, myData[0].filename.length);
        if (validateFilename === '.docx') {
            $scope['attachedFile' + fileid] = myData[0].filename;
            $('#' + fileid).html($scope['attachedFile' + fileid]).css('color', '#333');
            attachedFiles.push(myData[0]);
        } else if (validateFilename === '.doc') {
            $('#importError .modal-body').html('Please upload .docx only. To do so, re-save the .doc file in MS Word as Docx!');
            $('#importError .modal-title').html('File Type error');
            $('#importError').modal('show');
        } else {
            $('#importError .modal-body').html('Please upload .docx files only!');
            $('#importError .modal-title').html('File Type error');
            $('#importError').modal('show');
        }

    });

      /**
     * @ngdoc
     * @name deleteFile
     * @methodOf Projects.controller:ProjectMasterController
     * @param {number} fileId is id of attached file.
     * @description
     * This funtion is called on delete button on file upload page of import script wizard.
     *@return {undefined} This method doed not return.
     */
    deleteFile = function (fileId) {
        for (i = 0; i < attachedFiles.length; i++) {
            if (attachedFiles[i].filename === $scope['attachedFile' + fileId]) {
                $scope.index = i;
                break;
            }
        }
        attachedFiles.splice($scope.index, 1);
        $scope['attachedFile' + fileId] = '';
        $('#' + fileId).html($scope['attachedFile' + fileId]);

    };

     /**
     * @ngdoc
     * @name UploadAttachments
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     *This method is used to upload script file in import script wizard.
     *@return {undefined} This method does not return.
     */
    $scope.UploadAttachments = function () {

        var uploadFile = {};
        uploadFile['SectionId'] = $scope.importgroupsource.ProjectHeaderId
        uploadFile['ProjectId'] = projectId;
        uploadFile['Files'] = attachedFiles;
        uploadFile['UserId'] = userDetails.UserId;

        if (!$scope.adminUser) {
            uploadFile['OriginalUserId'] = null;
        }
        else {
            uploadFile['OriginalUserId'] = $scope.adminUser.UserId
        }

        var jasonFile = {};
        if (uploadFile['Files'].length > 0) {
            ProjectMaster.uploadScriptDB(uploadFile, function (data) {

                if (typeof (data) === 'string') {
                    $('#importCommit .modal-body').html(data);
                    $('#importCommit .modal-title').html('File error');
                    $scope.uploadSuccess = false;
                    $scope.columnEmpty = false;
                    $scope.fileError = true;
                    $('#importCommit').modal('show');
                } else {
                    $scope.jasonFile = data;
                    attachedFiles = [];
                    $scope.previewTitle = "";
                    $scope.sourceColumnMap = true;
                    $scope.fileRow = [];
                    var noOfRows = 2;
                    if ($scope.jasonFile.DocMasterData.length < 2) {
                        noOfRows = 1;
                    }
                    for (var j = 0; j < noOfRows; j++) {
                        var tarray = [];
                        for (var i = 0; i < $scope.jasonFile.DocMasterData[j].DocumentData.length; i++) {
                            var obj = {};
                            var c = i + 1;
                            var str = 'column';
                            obj['id'] = str.concat(c.toString());
                            obj['text'] = $scope.jasonFile.DocMasterData[j].DocumentData[i];
                            tarray.push(obj);
                        }
                        $scope.fileRow.push(tarray);
                    }

                    $scope.importSectionCat = $scope.jasonFile.ProjectCategories;
                }

            });
        } else {
            $('#importError .modal-body').html('No Script to upload!');
            $('#importError .modal-title').html('Upload Script');
            $('#importError').modal('show');
        }

    };

    /**
     * @ngdoc
     * @name preeview
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is used to show the preview of uploaded script.
     * @return {undefined} This method does not return.
     */
    $scope.preeview = function () {
        var tempdata = [];
        $scope.predata = [];
        var validFail = false;
        $scope.previewTitle = "Preview of Uploaded Script";
        for (var j = 0; j < $scope.fileRow.length; j++) {
            var tarray = [];
            for (var i = 0; i < $scope.fileRow[j].length; i++) {

                var obj = {};
                obj['text'] = $scope.fileRow[j][i].text;
                obj['colId'] = $scope.fileRow[j][i].id;
                obj['ProjectCategoryId'] = parseInt($("#" + $scope.fileRow[j][i].id).val());
                tarray.push(obj);
            }
            tempdata.push(tarray);
        }
        for (var h = 0; h < tempdata[0].length - 1; h++) {
            var flag = false;
            for (var g = h + 1; g < tempdata[0].length; g++) {
                if (tempdata[0][h].ProjectCategoryId === tempdata[0][g].ProjectCategoryId) {
                    flag = true;
                    break;
                }
            }
            if (flag === true) {
                $scope.previewTitle = "";
                $('#importError .modal-body').html('Please select distinct Additional Info for different columns!');
                $('#importError .modal-title').html('Column mapping error');
                $('#importError').modal('show');
                validFail = true;
                break;
            }
        }
        if (validFail === false) {
            for (var h = 0; h < tempdata[0].length; h++) {
                var flag = false;
                if (tempdata[0][h].ProjectCategoryId === 0) {
                    flag = true;
                    break;
                }
            }
            if (flag === false) {
                $scope.previewTitle = "";
                $('#importError .modal-body').html('Please select source term against one of the columns!');
                $('#importError .modal-title').html('Column mapping error');
                $('#importError').modal('show');
                validFail = true;
            }

        }

        if (validFail === false) {
            $scope.sourcePreview = true;
            $scope.sourceColumnMap = false;
            var noOfRows = 2;
            if (tempdata.length < 2) {
                noOfRows = 1;
            }
            for (var k = 0; k < noOfRows; k++) {
                var tarray = [];
                for (var i = 0; i < $scope.importSectionCat.length; i++) {
                    var flag = false;
                    obj = {};
                    obj['colId'] = i + 1;
                    for (var j = 0; j < tempdata[k].length; j++) {

                        if ($scope.importSectionCat[i].ProjectCategoryId === tempdata[k][j].ProjectCategoryId) {
                            obj['text'] = tempdata[k][j].text;
                            tarray.push(obj);
                            flag = true;
                            break;
                        }
                    }
                    if (flag === false) {
                        var blankstring = "";
                        obj['text'] = blankstring;
                        tarray.push(obj);
                    }
                }
                for (var j = 0; j < tempdata[k].length; j++) {
                    if (tempdata[k][j].ProjectCategoryId === 0) {
                        obj = {};
                        obj['colId'] = tarray.length;
                        obj['text'] = tempdata[k][j].text;
                        tarray.push(obj);
                        mastercol = true;
                        break;
                    }
                }
                $scope.predata.push(tarray);
            }
        }
    };

    /**
     * @ngdoc
     * @name backFromPreview
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called on back button on preview page.
     * @return {undefined} This method does not return.
     */
    $scope.backFromPreview = function () {
        $scope.previewTitle = "";
        $scope.sourcePreview = false;
        $scope.sourceColumnMap = true;
    };

    /**
     * @ngdoc
     * @name gotoUploadScript
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called on ok button on popup preview page. which will redirect to upload script page.
     * @return {undefined} This method does not return.
     */
    $scope.gotoUploadScript = function () {
        $scope.previewTitle = "";
        $scope.sourcePreview = false;
        $scope.sourceColumnMap = false;
        deleteFile('1');
        $scope.importSript = true;
    };

    /**
     * @ngdoc
     * @name commitScript
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called on import button on preview page.This is used to commit the upload script
     * @return {undefined} This method does not return.
     */
    $scope.commitScript = function () {
        var data = {};
        data['SectionId'] = $scope.importgroupsource.ProjectHeaderId
        data['ProjectId'] = projectId;
        data['MasterDataInsert'] = $scope.jasonFile;
        data['UserId'] = userDetails.UserId;
        var tempdata = [];
        for (var i = 0; i < $scope.fileRow[0].length; i++) {
            var obj = {};
            obj['ColumnId'] = i;
            obj['ProjectCategoryId'] = parseInt($("#" + $scope.fileRow[0][i].id).val());
            tempdata.push(obj);

        }

        data['ProjectCategoriesMapping'] = tempdata;
        data['SectionType'] = $scope.sectionType;
        data['IsDataExistInSection'] = IsDataExistInSection; //GLMGR-806
        data['IsAppendStart'] = $scope.IsAppendStart; //GLMGR-806
        data['IsSectionComplete'] = $scope.selectedGroup.IsSectionComplete;
        data['IsSectionUnlock'] = $scope.selectedGroup.IsSectionUnlock;
        //GLMGR-1103
        if (!$scope.adminUser) {
            data['OriginalUserId'] = null;
        }
        else {
            data['OriginalUserId'] = $scope.adminUser.UserId
        }
        $scope.dataImport = data;
        if ($scope.sectionType === 1) {
            ProjectMaster.commitScriptDB(data, function (data) {
                $('#importCommit .modal-body').html(data);
                $('#importCommit .modal-title').html('Import Script Message');
                if (data === "Source Term text is blank" || data === "Aborting Import as all terms present in Import script are already exist in selected section" || data.includes("Source Term contains duplicate terms")) {
                    $scope.uploadSuccess = false;
                    $scope.fileError = false;
                    $scope.columnEmpty = true;
                } else {
                    $scope.uploadSuccess = true;
                    $scope.fileError = false;
                    $scope.columnEmpty = false;
                }
               
                $('#importCommit').modal('show');
            });
        }
        else if ($scope.sectionType === 2) {
            ProjectMaster.commitScriptDBNTL(data, function (data) {
                if (data !== 'Success') {
                    $('#allowDuplicatePopUpImport .modal-body .criteria').html(data);
                    $('#allowDuplicatePopUpImport').modal('show');
                } else {
                    ProjectMaster.commitScriptDB($scope.dataImport, function (data) {
                        $('#importCommit .modal-body').html(data);
                        $('#importCommit .modal-title').html('Import Script Message');
                        if (data === "Source Term text is blank" || data === "Aborting Import as all terms present in Import script are already exist in selected section" || data.includes("Source Term contains duplicate terms")) {
                            $scope.uploadSuccess = false;
                            $scope.fileError = false;
                            $scope.columnEmpty = true;
                        } else {
                            $scope.uploadSuccess = true;
                            $scope.fileError = false;
                            $scope.columnEmpty = false;
                        }
                        $('#importCommit').modal('show');
                    });
                }
            });
        }
    };

    /**
     * @ngdoc
     * @name allowDuplicateMasterTextInfoImport
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is used to allow duplicates Import in NTL.
     * @return {undefined} This method does not return.
     */
    $scope.allowDuplicateMasterTextInfoImport = function (dataImport) {
        dataImport['IsStarred'] = true; //GLMGR-986 removed starred checkbox and marked duplicate as starred automatically dataImport['IsStarred'] = $scope.IsStarred;
        ProjectMaster.commitScriptDB(dataImport, function (data) {
            $('#importCommit .modal-body').html(data);
            $('#importCommit .modal-title').html('Import Script Message');
            $('#importCommit').modal('show');
        });
        $scope.showLoader = false;
    };

    /**
     * @ngdoc
     * @name cancelScriptUpload
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is used to cancel upload script.
     * @return {undefined} This method does not return.
     */
    $scope.cancelScriptUpload = function () {
        $route.reload();
        $('.modal-backdrop.fade.in').css('display', 'none');
    };

    /**
     * @ngdoc
     * @name starredStatePopup
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is used to open starred term popup on click of star icon on source setup page.
     * @return {undefined} This method does not return.
     */
    $scope.starredStatePopup = function (rowData) {
        $scope.rowDataStarred = rowData;
        $('#starUnstar').modal({
            backdrop: 'static',
            keyboard: false
        });
        if (rowData.IsStarred) {
            $('#starUnstar .modal-title').html('Make UnStarred');
            $('#starUnstar .modal-body').html('Do you want to mark this term as UnStarred?');
            $('#starUnstar').modal('show');
        } else {
            $('#starUnstar .modal-title').html('Make Starred');
            $('#starUnstar .modal-body').html('Do you want to mark this term as Starred?');
            $('#starUnstar').modal('show');
        }
    };

      /**
     * @ngdoc
     * @name changeStarredState
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is used to change starred/unstarred status, on click of star icon on source setup page
     * @return {undefined} This method does not return.
     */
    $scope.changeStarredState = function () {
        $scope.showLoader = true;
        if ($scope.rowDataStarred.IsStarred === true) {
            $scope.rowDataStarred.IsStarred = false;
            $scope.rowDataStarred.IsEligibleForStar = true;
        } else {
            $scope.rowDataStarred.IsStarred = true;
        }
        var changeStarredStateObj = {};
        changeStarredStateObj.GlossaryAddedBrands = $scope.rowDataStarred.GlossaryAddedBrands;
        changeStarredStateObj.IsStarred = $scope.rowDataStarred.IsStarred;
        changeStarredStateObj.MasterGlossaryId = $scope.rowDataStarred.MasterGlossaryId;
        changeStarredStateObj.ProjectId = projectId;
        changeStarredStateObj.UserId = userDetails.UserId;


        if (!$scope.adminUser) {
            changeStarredStateObj.OriginalUserId = null;
        }
        else {
            changeStarredStateObj.OriginalUserId = $scope.adminUser.UserId
        }
        ProjectMaster.ChangeStarredState(changeStarredStateObj, function (data) {
            $('#starUnstar').modal('hide');
            $scope.showLoader = false;
        });
    };

      /**
     * @ngdoc
     * @name starredDetailsPopup
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Object} rowData This is whole row data passed as argument to this function. 
     * @description
     * This method is called on info icon on source setup page to show starred term details.
     * @return {undefined} This method does not return.
     */
    $scope.starredDetailsPopup = function (rowData) {
        $('#starredDetails').modal({
            backdrop: 'static',
            keyboard: false
        });

        BrandIdList = [];
        var BrandNameList = '';

        for (var i = 0; i < rowData.GlossaryAddedBrands.length; i++) {
            BrandIdList.push(rowData.GlossaryAddedBrands[i].BrandId);
            BrandNameList = BrandNameList + rowData.GlossaryAddedBrands[i].BrandName + ', ';
        }
        $scope.starredTerm = rowData.MasterText;
        $scope.BrandNameList = BrandNameList.replace(/,\s*$/, "");

        $scope.showLoader = true;
        ProjectMaster.GetStarredTermInfo(rowData.MasterGlossaryId, rowData.userId, userDetails.UserRoles[0].UserRoleName, BrandIdList, function (data) {
            $scope.starredTermDetails = data.StarredProjectDetails;
            $scope.starredTermDetailsGroups = _.groupBy($scope.starredTermDetails, "ProjectName");
            $('#starredDetails').modal('show');
            $scope.showLoader = false;
        });
    };

    
    /*bulk add/edit section Functionality Starts*/

     /**
     * @ngdoc
     * @name bulkAddeditPopup
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called on bulk add/edit button on source setup page.This method is used to get initial data to show on popup.
     * @return {undefined} This method does not return.
     */
    $scope.bulkAddeditPopup = function () {
        ProjectMaster.getBulkSectionData(projectId, userDetails.UserId, $scope.sectionType, function (bulkSection) {
            $scope.sectionList = bulkSection;
            $scope.addBulkSectionName = "";
            $scope.popUpshowLoader = false;
            $scope.textEditBulkSection = "";
            $(".initialSectionBody").show();
            $(".editSectionBody").hide();
            $('#addEditSections').modal('show');
        },
            function (e) {
                console.log(e);
            });
    };

    /**
     * @ngdoc
     * @name editSectionName
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Array} selectBulkSection This seclected section from left select box. 
     * @param {Boolean} editLeft This boolean value passed, true if section need to to be edited is from left select box. If from right select box it is set as false.This function is called on both edit button on bulk Add/edit sections popup 
     * @description
     * This method is called on left edit button on bulk add/edit popup.This method is used to edit the name of selected section from left.
     * @return {undefined} This method does not return.
     */
    $scope.editSectionName = function (selectBulkSection, editLeft) {
        if (selectBulkSection.length === 1 && selectBulkSection[0].IsGlobal === false) {
            $(".initialSectionBody").hide(1000);
            $(".editSectionBody").show(1000);
            $scope.sectionEditModel = selectBulkSection[0];
            $scope.textEditBulkSection = selectBulkSection[0].SectionName;
            $scope.editLeft = editLeft;

        } else {
            $scope.validationMsg = "Select only One Non-Global Section";
            $('#failValidationMsgDiv').css('display', 'block');
            $timeout(function () { $('#failValidationMsgDiv').css('display', 'none') }, 3000);

        }
    };

    /**
     * @ngdoc
     * @name saveEditBulkSection
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called on save button on bulk add/edit popup. This method saves edited section names.
     * @return {undefined} This method does not return.
     */
    $scope.saveEditBulkSection = function () {
        if (checkDuplicateBulkSection($scope.textEditBulkSection, $scope.sectionEditModel.SectionId)) {
            var editdata = {};
            editdata['ProjectId'] = projectId;
            editdata['GlossaryGroupId'] = $scope.sectionEditModel.GlossaryGroupId;
            editdata['SectionId'] = $scope.sectionEditModel.SectionId;
            editdata['SectionName'] = $scope.textEditBulkSection;
            editdata['IsGlobal'] = $scope.sectionEditModel.IsGlobal;
            editdata['IsHavingTerms'] = $scope.sectionEditModel.IsHavingTerms;
            editdata['InsertedByUserId'] = userDetails.UserId;
            editdata['SectionType'] = $scope.sectionType;
            if (!$scope.adminUser) {
                editdata['OriginalUserId'] = null;
            }
            else {
                editdata['OriginalUserId'] = $scope.adminUser.UserId
            }
            if ($scope.sectionType === 1) {
                if (($scope.textEditBulkSection.toLowerCase().indexOf("ntl -")) >= 0 ||
                    ($scope.textEditBulkSection.toLowerCase().indexOf("fd -")) >= 0 ||
                    ($scope.textEditBulkSection.toLowerCase().indexOf("ntl-")) >= 0 ||
                    ($scope.textEditBulkSection.toLowerCase().indexOf("fd-")) >= 0 ||
                    ($scope.textEditBulkSection.toLowerCase().indexOf("localization list")) >= 0 ||
                    ($scope.textEditBulkSection.toLowerCase().indexOf("localisation list")) >= 0 ||
                    ($scope.textEditBulkSection.toLowerCase().indexOf("foreign dialogue")) >= 0 ||
                    ($scope.textEditBulkSection.toLowerCase().indexOf("foreign dialog")) >= 0
                    ) {
                    $('#addEditSections').modal('hide');
                    $scope.errorMessage = '';
                    $scope.errorMessage = validationDefaultSection;
                    $('#errorModal').modal('show');
                    return false;
                }
            }
            ProjectMaster.saveEditedBulkSection(editdata, function (bulkSectionId) {

                if ($scope.editLeft === true) {
                    for (var i = 0; i < $scope.sectionList.ProjectNonAssignedSections.length; i++) {
                        if ($scope.sectionEditModel.GlossaryGroupId === $scope.sectionList.ProjectNonAssignedSections[i].GlossaryGroupId) {
                            $scope.sectionList.ProjectNonAssignedSections[i].SectionName = $scope.textEditBulkSection;
                            $scope.sectionList.ProjectNonAssignedSections[i].SectionId = bulkSectionId.SectionId;
                            /*logic here is done to force ng-repeat to run so that directive for color on global section run again. 
                            Here simply emptying the array and then repopulating it after 20ms since digest cycle after every 10ms*/
                            var temp = [];
                            angular.copy($scope.sectionList.ProjectNonAssignedSections, temp);
                            $scope.sectionList.ProjectNonAssignedSections = [];
                            $timeout(function () { $scope.sectionList.ProjectNonAssignedSections = temp }, 20);
                            break;
                        }
                    }
                    $scope.selectedBulkSections = [];
                } else {
                    for (var i = 0; i < $scope.sectionList.ProjectAssignedSections.length; i++) {
                        if ($scope.sectionEditModel.GlossaryGroupId === $scope.sectionList.ProjectAssignedSections[i].GlossaryGroupId) {
                            $scope.sectionList.ProjectAssignedSections[i].SectionName = $scope.textEditBulkSection;
                            $scope.sectionList.ProjectAssignedSections[i].SectionId = bulkSectionId.SectionId;
                            /*logic here is done to force ng-repeat to run so that directive for color on global section run again. 
                            Here simply emptying the array and then repopulating it after 20ms since digest cycle after every 10ms*/
                            var temp = [];
                            angular.copy($scope.sectionList.ProjectAssignedSections, temp);
                            $scope.sectionList.ProjectAssignedSections = [];
                            $timeout(function () { $scope.sectionList.ProjectAssignedSections = temp }, 20);
                            break;
                        }
                    }
                    $scope.removedBulkSections = [];
                }


                if (!bulkSectionId.Result) {
                    if (bulkSectionId.ResultMessage !== '') {
                        $('#addEditSections').modal('hide');
                        $scope.errorMessage = '';
                        $scope.errorMessage = bulkSectionId.ResultMessage;
                        $('#errorModal').modal('show');
                        return false;
                    } else if (bulkSectionId.ResultMessage === null) {
                        $('#addEditSections').modal('hide');
                        $scope.errorMessage = '';
                        $scope.errorMessage = validationNTLSection;
                        $('#errorModal').modal('show');
                        return false;
                    }
                    else {
                        $('#addEditSections').modal('hide');
                        $scope.errorMessage = 'This section already exists in this glossary';
                        $('#errorModal').modal('show');
                        return false;
                    }
                } else {
                    $scope.textEditBulkSection = "";
                    $scope.validationMsg = "Section Name Successfully Edited";
                    $('#successValidationMsgDiv').css('display', 'block');
                    $timeout(function () { $('#successValidationMsgDiv').css('display', 'none') }, 3000);
                    $(".initialSectionBody").show(1000);
                    $(".editSectionBody").hide(1000);
                }
            },
            function (e) {
                console.log(e);
            });

        } else {
            $scope.validationMsg = "This section already exists in this glossary";
            $('#failNameValidationMsgDiv').css('display', 'block');
            $timeout(function () { $('#failNameValidationMsgDiv').css('display', 'none') }, 2000);
        }
    };

     /**
     * @ngdoc
     * @name checkDuplicateBulkSection
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called in side addBulkSection() method, This is validation method to check if section name entered is already present in system.
     * @return {undefined} This method does not return.
     */
    var checkDuplicateBulkSection = function (name, id) {
        //condition to check any duplicate entries of the same section name while editing/creating the section
        for (var i = 0; i < $scope.sectionList.ProjectNonAssignedSections.length; i++) {
            if ($scope.sectionList.ProjectNonAssignedSections[i].SectionId !== id) {
                if (name.toLowerCase().trim() === $scope.sectionList.ProjectNonAssignedSections[i].SectionName.toLowerCase().trim()) {
                    return false;
                }
            }
        }
        for (var i = 0; i < $scope.sectionList.ProjectAssignedSections.length; i++) {
            if ($scope.sectionList.ProjectAssignedSections[i].SectionId !== id) {
                if (name.toLowerCase().trim() === $scope.sectionList.ProjectAssignedSections[i].SectionName.toLowerCase().trim()) {
                    return false;
                }
            }
        }
        return true;
    };

    //going back to main popup from edit section name mode
    $scope.backBulkSection = function () {
        $(".initialSectionBody").show(1000);
        $(".editSectionBody").hide(1000);
    };

      /**
     * @ngdoc
     * @name moveSelectedSections
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Array} selectedBulkSections This is array of selected sections from left select box
     * @description
     * This method is called on move button on add/edit section popup.This method is used for moving section(s) left to right.
     * @return {undefined} This method does not return.
     */
    $scope.moveSelectedSections = function (selectedBulkSections) {
        for (var i = 0 ; i < selectedBulkSections.length ; i++) {
            $scope.sectionList.ProjectAssignedSections.push(selectedBulkSections[i]);
            var index = $scope.sectionList.ProjectNonAssignedSections.indexOf(selectedBulkSections[i]);
            if (index > -1) {
                $scope.sectionList.ProjectNonAssignedSections.splice(index, 1);
            }
        }
        $scope.selectedBulkSections = [];
    };

    /**
     * @ngdoc
     * @name moveUnSelectedSections
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Array} removedBulkSections This is array of sections to be removed from right select box
     * @description
     * This method is called on move button on add/edit section popup.This method is used for moving section(s) right to left.
     * @return {undefined} This method does not return.
     */
    $scope.moveUnSelectedSections = function (removedBulkSections) {
        var flag = false;
        for (var i = 0; i < removedBulkSections.length; i++) {
            if (removedBulkSections[i].IsHavingTerms) {
                flag = true;
                break;
            }
            if (removedBulkSections[i].IsSuggestionExist) {
                flag = true;
                break;
            }
        }
        if (flag === true) {
            $('#failValidationMsgDiv span').html('You cannot remove these section(s) from the Glossary since there are already terms and/or translations which have been added to it. <br/> You will have to first either move the term(s) to another section and/or simply remove them from the sections.')
            $('#failValidationMsgDiv').css('display', 'block');
            $timeout(function () { $('#failValidationMsgDiv').css('display', 'none') }, 6000);
        } else {
            for (var i = 0 ; i < removedBulkSections.length ; i++) {
                $scope.sectionList.ProjectNonAssignedSections.push(removedBulkSections[i]);
                var index = $scope.sectionList.ProjectAssignedSections.indexOf(removedBulkSections[i]);
                if (index > -1) {
                    $scope.sectionList.ProjectAssignedSections.splice(index, 1);
                }
            }
            $scope.removedBulkSections = [];
        }
    };

     /**
     * @ngdoc
     * @name addBulkSection
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called on add button on add/edit section popup.This method is used add new sections to the project.
     * @return {undefined} This method does not return.
     */ 
    $scope.addBulkSection = function () {
        if ($scope.ErrorSectionNamePopup === true) {
            return false;
        }
        //GLMGR-757
        if (($scope.addBulkSectionName.toLowerCase().indexOf("ntl -")) >= 0 ||
        ($scope.addBulkSectionName.toLowerCase().indexOf("fd -")) >= 0 ||
        ($scope.addBulkSectionName.toLowerCase().indexOf("ntl-")) >= 0 ||
        ($scope.addBulkSectionName.toLowerCase().indexOf("fd-")) >= 0 ||
        ($scope.addBulkSectionName.toLowerCase().indexOf("localization list")) >= 0 ||
        ($scope.addBulkSectionName.toLowerCase().indexOf("localisation list")) >= 0 ||
        ($scope.addBulkSectionName.toLowerCase().indexOf("foreign dialogue")) >= 0 ||
        ($scope.addBulkSectionName.toLowerCase().indexOf("foreign dialog")) >= 0
        ) {
            $('#addEditSections').modal('hide');
            $scope.errorMessage = '';
            if ($scope.sectionType === 1) {
                $scope.errorMessage = validationDefaultSection;
            }
            else {
                $scope.errorMessage = validationNTLSection;
            }
            $('#errorModal').modal('show');
            return false;
        }

        if ($scope.sectionType === 2) {
            if ($('#ntlBulk').prop("checked") === true) {
                $scope.addBulkSectionName = 'NTL - ' + $scope.addBulkSectionName;
                $scope.sectionSubType = 1;
            } else if ($('#fdBulk').prop("checked") === true) {
                $scope.addBulkSectionName = 'FD - ' + $scope.addBulkSectionName;
                $scope.sectionSubType = 2;
            } else {
                return false;
            }
        } else {
            $scope.sectionSubType = 0;
        }

        if (checkDuplicateBulkSection($scope.addBulkSectionName, 0)) {
            $scope.popUpshowLoader = true;
            var newSecdata = {};
            newSecdata['ProjectId'] = projectId;
            newSecdata['GlossaryGroupId'] = 0;
            newSecdata['SectionId'] = 0;
            newSecdata['SectionName'] = $scope.addBulkSectionName;
            newSecdata['IsGlobal'] = false;
            newSecdata['IsHavingTerms'] = false;
            newSecdata['InsertedByUserId'] = userDetails.UserId;
            newSecdata['SectionType'] = $scope.sectionType;
            newSecdata['SectionSubType'] = $scope.sectionSubType;

            if (!$scope.adminUser) {
                newSecdata['OriginalUserId'] = null;
            }
            else {
                newSecdata['OriginalUserId'] = $scope.adminUser.UserId
            }
            ProjectMaster.saveNewBulkSection(newSecdata, function (newId) {

                if (!newId.Result) {
                    if (newId.ResultMessage !== '') {
                        $('#addEditSections').modal('hide');
                        $scope.errorMessage = '';
                        $scope.errorMessage = newId.ResultMessage;
                        $('#errorModal').modal('show');
                        return false;
                    } else if (newId.ResultMessage === null) {
                        $('#addEditSections').modal('hide');
                        $scope.errorMessage = '';
                        $scope.errorMessage = validationDefaultSection;
                        $('#errorModal').modal('show');
                        return false;
                    }
                    else {
                        $('#addEditSections').modal('hide');
                        $scope.errorMessage = 'This section already exists in this glossary';
                        $('#errorModal').modal('show');
                        return false;
                    }
                }
                ProjectMaster.getBulkSectionData(projectId, userDetails.UserId, $scope.sectionType, function (bulkSection) {
                    for (var i = 0; i < bulkSection.ProjectAssignedSections.length; i++) {
                        if (bulkSection.ProjectAssignedSections[i].GlossaryGroupId === newId.GlossaryGroupId) {
                            $scope.sectionList.ProjectAssignedSections.push(bulkSection.ProjectAssignedSections[i]);
                            break;
                        }
                    }
                    $scope.addBulkSectionName = "";
                    $scope.popUpshowLoader = false;
                    $scope.validationMsg = "New Section Successfully Saved";
                    $('#successValidationMsgDiv').css('display', 'block');
                    $timeout(function () { $('#successValidationMsgDiv').css('display', 'none') }, 2000);
                    $(".initialSectionBody").show();
                    $(".editSectionBody").hide();
                },
            function (e) {
                console.log(e);
            });
            },
            function (e) {
                console.log(e);
            });

        } else {
            $scope.addBulkSectionName = "";
            $scope.validationMsg = "This section already exists in this glossary";
            $('#failValidationMsgDiv').css('display', 'block');
            $timeout(function () { $('#failValidationMsgDiv').css('display', 'none') }, 2000);
        }
    };

    /**
     * @ngdoc
     * @name deleteBulkSection
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Array} selectBulkSection This is array of sections to be deleted from left select box
     * @description
     * This method is called on delete button on add/edit section popup.This method is used to delete section from the project.
     * @return {undefined} This method does not return.
     */
    $scope.deleteBulkSection = function (selectBulkSection) {
        if (selectBulkSection.length === 1 && selectBulkSection[0].IsGlobal === false) {
            $scope.popUpshowLoader = true;
            var originaluser;
            if (!$scope.adminUser) {
                originaluser = null;
            }
            else {
                originaluser = $scope.adminUser.UserId
            }

            ProjectMaster.deleteSection(selectBulkSection[0].GlossaryGroupId, userDetails.UserId, originaluser, function (status) {
                $scope.popUpshowLoader = false;
                if (status) {
                    var index = $scope.sectionList.ProjectNonAssignedSections.indexOf(selectBulkSection[0]);
                    if (index > -1) {
                        $scope.sectionList.ProjectNonAssignedSections.splice(index, 1);
                    }
                    $scope.validationMsg = "Section Deleted Successfully!";
                    $('#successValidationMsgDiv').css('display', 'block');
                    $timeout(function () { $('#successValidationMsgDiv').css('display', 'none') }, 2000);
                } else {
                    $scope.validationMsg = "You cannot remove this section from the Glossary since there are already terms and/or translations which have been added to it. In order to remove this from the Glossary, you will either have to move the term(s) to another section and/or simply remove this term/row from the section.";
                    $('#successValidationMsgDiv').css('display', 'block');
                    $timeout(function () { $('#successValidationMsgDiv').css('display', 'none') }, 2000);
                }
                $(".initialSectionBody").show();
                $(".editSectionBody").hide();
            });
        } else {
            $scope.validationMsg = "Select only One Non-Global Section";
            $('#failValidationMsgDiv').css('display', 'block');
            $timeout(function () { $('#failValidationMsgDiv').css('display', 'none') }, 3000);
        }
    };

    /**
     * @ngdoc
     * @name saveBulkSection
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called on save button on bulk add/edit popup.This method saves edited section names.
     * @return {undefined} This method does not return.
     */
    $scope.saveBulkSection = function () {
        $scope.sectionList.ProjectId = projectId;
        $scope.sectionList.SectionType = $scope.sectionType;
        $scope.sectionList.UserId = commonService.getLocalData('userDetails').UserId;

        var originaluser;
        if (!$scope.adminUser) {
            originaluser = null;
        }
        else {
            originaluser = $scope.adminUser.UserId
        }

        $scope.sectionList.OriginalUserId = originaluser;
        $scope.showLoader = true;
        ProjectMaster.saveEntireSections($scope.sectionList, function (backData) {
            $scope.validationMsg = "Changes Successfully Saved";
            $('#successValidationMsgDiv').css('display', 'block');
            $timeout(function () {
                $scope.closeSection();
                $scope.showLoader = false;
            }, 1000);

        },
            function (e) {
                console.log(e);
            });

    };

     /**
     * @ngdoc
     * @name cancelBulkSection
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called on cancel button on bulk add/edit popup.This method cancels the recent changes and closes the popup
     * @return {undefined} This method does not return.
     */
    $scope.cancelBulkSection = function () {
        $scope.addBulkSectionName = "";
        $scope.popUpshowLoader = false;
        $scope.textEditBulkSection = "";
        $scope.closeSection();
    };
    /*bulk add/edit section Functionality  Ends*/

     /**
     * @ngdoc
     * @name addNewGroup
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called on Add new section button, This mothod give internal call to insertTableInUI method which is responsible for creating new table.  
     * @return {undefined} This method does not return.
     */
    $scope.addNewGroup = function () {
        if ($scope.reviewModeStored === false && $scope.IsSectionCompleteReminderFlag) {
            if (!$scope.displayingSelectedGroup[0].MasterGlossaries[0].MasterText) {
                $scope.errorMessage = '';
                $scope.errorMessage = 'Please enter the Master Term for the section. If you wish to add Master Term later, please click "Close" button at the bottom of the section.';
                $('#errorModal').modal('show');
                return false;
            }
            if ($scope.displayingSelectedGroup.length !== 0 || $scope.ProjectMasterJson.TableData.length !== 0) { 
                sectionCompleteAddNewSection = true;
                $('#sectionCompleteReminder').modal({ backdrop: 'static', keyboard: false });
                $('#sectionCompleteReminder').modal('show');
            }
        } else {
            if ($scope.isSectionOpen) {
                $scope.errorMessage = 'You can add only 1 section at a time.';
                $('#errorModal').modal('show');
                return false;
            }
            if ($scope.displayingSelectedGroup.length > 0 || $scope.ProjectMasterJson.TableData.length > 0) {
                if (isSecretChanged || isHeaderChanged) {
                    isUpdateTableChanged = true;
                }
                //show appropriate popup message according to the update table change
                if (!isUpdateTableChanged || $scope.ProjectMasterJson.TableData.length > 0) {
                    $scope.confirmSaveRecordsToAddNewSection();
                    $scope.isShowRemovedTerms = false;
                }
            }
            else {
                insertTableInUI();
                $scope.isShowRemovedTerms = false;
            }
        }
    };

    /**
     * @ngdoc
     * @name insertTableInUI
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is responsible for creating new table.  
     * @return {undefined} This method does not return.
     */
    var insertTableInUI = function myfunction() {
        $scope.isRecordDisplayed = false;
        $scope.isSectionOpen = true;
        var newTableObject = {
            "ProjectHeaderId": 0 - ($scope.ProjectMasterJson.TableData.length + 1),
            'SectionId': 0 - ($scope.ProjectMasterJson.TableData.length + 1),
            "ProjectId": projectId,
            "HeaderText": null,
            "IsSecret": false,
            "IsHeaderAdded": false,
            "UserId": userDetails.UserId,
            "MasterGlossaries": []
        }
        var newRowObject = {
            "MasterGlossaryId": -1,
            "MasterText": null,
            "MasterNote": null,
            "userId": userDetails.UserId,
            "ProjectCategories": [],
            "GlossaryAddedBrands": [],
            "GlossaryRemovedBrands": []
        };

        //Copying the Categories object for loading the selected sections 
        $scope.showLoader = true;
        ProjectMaster.getCategoriesAndHeaderList(projectId, $scope.sectionType, function (projectMasterJson) {
            if (addNewSectionBtnClicked) {
                $scope.headers = [];
                $scope.headers = projectMasterJson.ProjectHeaders;
                $scope.ProjectNonAssignedSections = projectMasterJson.Sections.ProjectNonAssignedSections;
            }
            $scope.categories = projectMasterJson.ProjectCategories;
            $scope.categoriesAll = projectMasterJson.ProjectCategories;
            $scope.noOfCategories = $scope.categories.length;

            angular.forEach($scope.categories, function (category) {
                var newColumnObject = {
                    "CategoryId": category.CategoryId,
                    "ProjectId": projectId,
                    "ProjectCategoryId": category.ProjectCategoryId,
                    "CategoryName": category.CategoryName,
                    "userId": userDetails.UserId,
                    "CategoryText": null
                }
                newRowObject.ProjectCategories.push(newColumnObject);
            });
            angular.copy($scope.ProjectInfo.ProjectBrands, newRowObject.GlossaryAddedBrands);
            newTableObject.MasterGlossaries.push(newRowObject);
            $scope.ProjectMasterJson.TableData.push(newTableObject);
            sessionStorage.setItem('SourceSetupActiveSection', '');
            $scope.reviewModeStored = false;
            sessionStorage.setItem('reviewModeStored',$scope.reviewModeStored);
            $scope.showLoader = false;
        });
    };

    //Adding a new row for new section
    $scope.addNewRowForNewSection = function (groupId, index, parent, rowData) {
        tempRowDataList = [];
        //Check if the table is newly added
        for (var i = 0; i < $scope.ProjectMasterJson.TableData.length; i++) {
            if (i === parent) {
                var length = $scope.ProjectMasterJson.TableData.filter(function (group) {
                    return group.ProjectHeaderId == groupId;
                })[0].MasterGlossaries.length;
                break;
            }
        }

        $scope.isAddRowButtonDisabled = true;
        //check if the no. of rows newly entered to update the table are lesss than 20  
        var temp = 0;
        var newRowObject = {
            "MasterGlossaryId": -1,
            "MasterText": null,
            "MasterNote": null,
            "userId": userDetails.UserId,
            "ProjectCategories": [],
            "GlossaryAddedBrands": [],
            "GlossaryRemovedBrands": []
        };

        angular.forEach($scope.categories, function (category) {
            var newColumnObject = {
                "CategoryId": category.CategoryId,
                "ProjectId": projectId,
                "ProjectCategoryId": category.ProjectCategoryId,
                "CategoryName": category.CategoryName,
                "userId": userDetails.UserId,
                "CategoryText": null
            }
            newRowObject.ProjectCategories.push(newColumnObject);
        });
        angular.copy($scope.ProjectInfo.ProjectBrands, newRowObject.GlossaryAddedBrands);
        for (var i = 0; i < $scope.ProjectMasterJson.TableData.length; i++) {
            if (i === parent) {
                $scope.ProjectMasterJson.TableData[i].MasterGlossaries.splice(index + 1, 0, newRowObject);
                break;
            }
        }
        window.scrollBy(0, 200);

        insertedRowlength = $scope.ProjectMasterJson.TableData.filter(function (group) {
            return group.ProjectHeaderId == groupId;
        })[0].MasterGlossaries.length;

        for (var i = 0; i < $scope.ProjectMasterJson.TableData[parent].MasterGlossaries.length; i++) {
            if ($scope.ProjectMasterJson.TableData[parent].MasterGlossaries[i].MasterGlossaryId < 0) {
                tempRowDataList.push($scope.ProjectMasterJson.TableData[parent].MasterGlossaries[i]);
            }
        }
        addNewRowsToDB($scope.ProjectMasterJson.TableData[parent], parent, rowData);
    };

      /**
     * @ngdoc
     * @name addNewRow
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Number} groupId This is section id of selected section.
     * @param {Number} index This is index row below which user want to add new row.
     * @param {Object} rowData This is object contains all the data of selected row.
     * @description
     * This method is responsible for adding new row to table of section.This method gives internal call to addNewRowsToDB() method
     * @return {undefined} This method does not return.
     */
    $scope.addNewRow = function (groupId, index, parent, rowData) {
        if ($scope.selectedGroup !== undefined) {
            checkSectionStatus();
            ProjectMaster.checkSectionStatus(objSectionStatus, function (status) {
                if (status) {
                    $('#sectionStatePopup').modal({ backdrop: 'static', keyboard: false });
                    $('#sectionStatePopup').modal('show');
                } else {
                    tempRowDataList = [];
                    $scope.isAddRowButtonDisabled = true;
                    //check if the no. of rows newly entered to update the table are lesss than 20  
                    var temp = 0;

                    var newRowObject = {
                        "MasterGlossaryId": -1,
                        "MasterText": null,
                        "MasterNote": null,
                        "userId": userDetails.UserId,
                        "ProjectCategories": [],
                        "GlossaryAddedBrands": [],
                        "GlossaryRemovedBrands": [],
                        "IsSuggestionExist": null
                    };

                    angular.forEach($scope.categories, function (category) {
                        var newColumnObject = {
                            "CategoryId": category.CategoryId,
                            "ProjectId": projectId,
                            "ProjectCategoryId": category.ProjectCategoryId,
                            "CategoryName": category.CategoryName,
                            "userId": userDetails.UserId,
                            "CategoryText": null
                        }
                        newRowObject.ProjectCategories.push(newColumnObject);
                    });
                    angular.copy(GlossaryBrandsHeaderWise, newRowObject.GlossaryAddedBrands);
                    $scope.projectMasterFromDb.TableData.filter(function (group) {
                        return group.ProjectHeaderId == groupId;
                    })[0].MasterGlossaries.splice(index + 1, 0, newRowObject);

                    insertedRowlength = $scope.projectMasterFromDb.TableData.filter(function (group) {
                        return group.ProjectHeaderId == groupId;
                    })[0].MasterGlossaries.length;

                    for (var i = 0; i < $scope.projectMasterFromDb.TableData[0].MasterGlossaries.length; i++) {
                        if ($scope.projectMasterFromDb.TableData[0].MasterGlossaries[i].MasterGlossaryId < 0) {
                            tempRowDataList.push($scope.projectMasterFromDb.TableData[0].MasterGlossaries[i]);
                        }
                    }
                    addNewRowsToDB($scope.displayingSelectedGroup[0], 0, rowData);
                }
            })
        } 
      
    };

     /**
     * @ngdoc
     * @name addNewRowsToDB
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Number} TableData This is object which contains master glossary table data on source setup page.
     * @param {Number} parent This is index row below which user want to add new row.
     * @param {Object} rowData This is object contains all the data of selected row.
     * @description
     * This method is responsible for adding new row to table of section in db.This method is called in above addNewRow() method.  
     * @return {undefined} This method does not return.
     */
    var addNewRowsToDB = function (TableData, parent, rowData) {
        //if a new row is added in an exsting table
        for (var i = 0; i < TableData.MasterGlossaries.length; i++) {
            //if a new row is added i.e. if the Master Glossary Id of the object is -1
            if (TableData.MasterGlossaries[i].MasterGlossaryId === -1) {
                if (addedNewRowsList.indexOf(addedNewRowsList[i]) === -1) {
                    addedNewRowsList.push(TableData.MasterGlossaries[i]);
                    break;
                }
                else {
                    continue;
                }
            }
        }
        //Adding the newly added rows to an array that is to be sent to the Service
        for (var i = 0; i < addedNewRowsList.length; i++) {
            $scope.newListOfHeaderData[0].HeaderText = TableData.HeaderText;
            $scope.newListOfHeaderData[0].IsSecret = TableData.IsSecret;
            $scope.newListOfHeaderData[0].ProjectHeaderId = TableData.ProjectHeaderId;
            $scope.newListOfHeaderData[0].MasterGlossaries.push(addedNewRowsList[i]);
        }
        ++totalRowsAdded;
        $scope.showLoader = true;
        //Calling Service for saving the newly added row
        ProjectMaster.saveHeaderDataToDb(projectId, $scope.newListOfHeaderData, function (masterGlossaryId) {
            //reinitialising the object to be sent to the DB
            addedNewRowsList = [];
            $scope.newListOfHeaderData = [
                      {
                          "HeaderText": null,
                          "ProjectHeaderId": -1,
                          "userId": userDetails.UserId,
                          "MasterGlossaries": []
                      }];

            //create sequence from the master glossary id received in response
            var masterGlossarySequence = [];
            if ($scope.displayingSelectedGroup.length > 0) {
                for (var i = 0; i < $scope.displayingSelectedGroup[0].MasterGlossaries.length; i++) {
                    if ($scope.displayingSelectedGroup[0].MasterGlossaries[i].MasterGlossaryId === -1) {
                        $scope.displayingSelectedGroup[0].MasterGlossaries[i].MasterGlossaryId = masterGlossaryId;
                        $scope.displayingSelectedGroup[0].MasterGlossaries[i].isChanged = true;
                    }
                    masterGlossarySequence.push($scope.displayingSelectedGroup[0].MasterGlossaries[i].MasterGlossaryId);
                }

            }
            else {
                for (var i = 0; i < $scope.ProjectMasterJson.TableData[parent].MasterGlossaries.length; i++) {
                    if ($scope.ProjectMasterJson.TableData[parent].MasterGlossaries[i].MasterGlossaryId === -1) {
                        $scope.ProjectMasterJson.TableData[parent].MasterGlossaries[i].MasterGlossaryId = masterGlossaryId;
                    }
                    masterGlossarySequence.push($scope.ProjectMasterJson.TableData[parent].MasterGlossaries[i].MasterGlossaryId);
                }
            }
            var sequenceLength = masterGlossarySequence.length;
            for (var j = 0; j < sequenceLength - 1; j++) {
                for (var k = j + 1; k < sequenceLength; k++) {
                    if (masterGlossarySequence[j] === masterGlossarySequence[k]) {
                        masterGlossarySequence.splice(k, 1);
                        sequenceLength = sequenceLength - 1;
                    }
                }
            }
            $scope.showLoader = false;
            $scope.isAddRowButtonDisabled = false;
        });
    };

    //generate a header id on click of Save Section button near Section Text

    
     /**
     * @ngdoc
     * @name getGroupId
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Object} header This is object which contains section details
     * @param {String} headerText This is section name entered.
     * @param {Boolean} IsSecret This is IsSecret check box value.
     * @param {Number} tableIndex This is index of newly added section table. 
     * @description
     * This method is responsible for saving newly added section name, called on save button on add new section. This method generates a header id on click of Save Section button near Section Text
     * @return {undefined} This method does not return.
     */
    $scope.getGroupId = function (header, headerText, IsSecret, tableIndex) {
        //impersonate original user
        var originaluser;
        if (!$scope.adminUser) {
            originaluser = null;
        }
        else {
            originaluser = $scope.adminUser.UserId
        }

        $scope.NTLheader = header;
        $scope.NTLheaderText = headerText;
        $scope.NTLIsSecret = IsSecret;
        $scope.NTLtableIndex = tableIndex;
        //GLMGR-757 NTL section type selection
        if ((headerText.toLowerCase().indexOf("ntl -")) >= 0 ||
            (headerText.toLowerCase().indexOf("fd -")) >= 0 ||
            (headerText.toLowerCase().indexOf("ntl-")) >= 0 ||
            (headerText.toLowerCase().indexOf("fd-")) >= 0 ||
            (headerText.toLowerCase().indexOf("localization list")) >= 0 ||
            (headerText.toLowerCase().indexOf("localisation list")) >= 0 ||
            (headerText.toLowerCase().indexOf("foreign dialogue")) >= 0 ||
            (headerText.toLowerCase().indexOf("foreign dialog")) >= 0
            ) {
            $scope.errorMessage = '';
            if ($scope.sectionType === 1) {
                $scope.errorMessage = validationDefaultSection;
            } else if ($scope.sectionType === 2) {
                $scope.errorMessage = validationNTLSection;
            }
            $('#errorModal').modal('show');
            header.IsHeaderAdded = false;
            return false;
        }

        if ($scope.sectionType === 2) {
            if (!headerText) {
                $scope.errorMessage = '';
                $scope.errorMessage = 'Please enter the Section Text';
                $('#errorModal').modal('show');
                header.IsHeaderAdded = false;
                return false;
            }

            $scope['saveName' + tableIndex] = true;
            $('#saveNTLSection').modal('show');
            header.IsHeaderAdded = false;
        }

        if (!headerText) {
            $scope.errorMessage = '';
            $scope.errorMessage = 'Please enter the Section Text';
            $('#errorModal').modal('show');
            header.IsHeaderAdded = false;
        }

        if (!checkDuplicateSection(header)) {
            return false;
        }
        $scope.sectionSubType = 0;

        if (headerText && $scope.sectionType === 1 && !$scope.errorHeaderText) {

            ProjectMaster.getProjectHeaderId(projectId, headerText, IsSecret, userDetails.UserId, $scope.sectionType, $scope.sectionSubType, originaluser, function (headerId) {
                if (headerId.GlossaryGroupId !== 0) {
                    header.ProjectHeaderId = headerId.GlossaryGroupId;
                    $scope.selectedGroupIdStored = headerId.GlossaryGroupId;
                    header.SectionId = headerId.SectionId;
                    header.IsHeaderAdded = true;
                    $scope.successMessage = "Section Saved Successfully";
                    $('#saveNewTableModal').modal('show');
                    $scope.headerforImport = headerText;

                    //created newCreatedGroup{} object similar to selectedGroup and called function $scope.showSelectedGroups() to reload newly created section; this solves problem of showing removed rows in new section
                    newCreatedGroup = {};
                    newCreatedGroup.GlossaryGroupHeader = headerText;
                    newCreatedGroup.GlossaryGroupRowVersion = null;
                    newCreatedGroup.Id = headerId.GlossaryGroupId;
                    newCreatedGroup.IsSecret = IsSecret;
                    newCreatedGroup.IsSectionComplete = false;
                    newCreatedGroup.ProjectId = projectId;
                    newCreatedGroup.SectionId = headerId.SectionId;
                    newCreatedGroup.SectionSubType = $scope.sectionSubType;
                    newCreatedGroup.SectionType = $scope.sectionType;
                    sessionStorage.setItem('SourceSetupActiveSection', JSON.stringify(newCreatedGroup));
                    $('.modal-backdrop.fade.in').css('display', 'none');
                    $route.reload();
                    //end
                }
                else if (!headerId.Result) {
                    if (headerId.ResultMessage !== '') {
                        $scope.errorMessage = '';
                        $scope.errorMessage = headerId.ResultMessage;
                        $('#errorModal').modal('show');
                        header.IsHeaderAdded = false;
                        return false;
                    } else if (headerId.ResultMessage === null) {
                        $scope.errorMessage = '';
                        $scope.errorMessage = validationDefaultSection;
                        $('#errorModal').modal('show');
                        header.IsHeaderAdded = false;
                        return false;
                    }
                    else {
                        $scope.errorMessage = 'This section already exists in this glossary';
                        $('#errorModal').modal('show');
                        header.IsHeaderAdded = false;
                        return false;
                    }
                }

            });
        }
    };

    
     /**
     * @ngdoc
     * @name saveNTLSectionType
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Object} header This is object which contains NTL section details
     * @param {String} headerText This is section name entered.
     * @param {Boolean} IsSecret This is IsSecret check box value.
     * @param {Number} tableIndex This is index of newly added section table. 
     * @description
     * This method is responsible for saving newly added NTL section name, called on save button on add new section. This method generates a header id on click of Save NTL Section button near Section Text
     * @return {undefined} This method does not return.
     */
    $scope.saveNTLSectionType = function (header, headerText, IsSecret, tableIndex) {

        //impersonate original user
        var originaluser;
        if (!$scope.adminUser) {
            originaluser = null;
        }
        else {
            originaluser = $scope.adminUser.UserId
        }


        if ($('#ntl').prop("checked") === true) {
            header.HeaderText = 'NTL - ' + header.HeaderText;
            headerText = 'NTL - ' + headerText;
            $scope.sectionSubType = 1;
        } else if ($('#fd').prop("checked") === true) {
            header.HeaderText = 'FD - ' + header.HeaderText;
            headerText = 'FD - ' + headerText;
            $scope.sectionSubType = 2;
        } else {
            return false;
        }

        if (headerText && $scope.sectionType === 2 && !$scope.errorHeaderText) {
            ProjectMaster.getProjectHeaderId(projectId, headerText, IsSecret, userDetails.UserId, $scope.sectionType, $scope.sectionSubType, originaluser, function (headerId) {
                if (headerId.GlossaryGroupId !== 0) {
                    header.ProjectHeaderId = headerId.GlossaryGroupId;
                    $scope.selectedGroupIdStored = headerId.GlossaryGroupId;
                    header.SectionId = headerId.SectionId;
                    header.IsHeaderAdded = true;
                    $scope.successMessage = "Section Saved Successfully";
                    $('#saveNewTableModal').modal('show');
                    $scope.headerforImport = headerText;
                    $scope['saveName' + tableIndex] = true;
                    $scope.reviewModeStored = false;
                    sessionStorage.setItem('reviewModeStored',$scope.reviewModeStored);

                    //created newCreatedGroup{} object similar to selectedGroup and called function $scope.showSelectedGroups() to reload newly created section; this solves problem of showing removed rows in new section
                    newCreatedGroup = {};
                    newCreatedGroup.GlossaryGroupHeader = headerText;
                    newCreatedGroup.GlossaryGroupRowVersion = null;
                    newCreatedGroup.Id = headerId.GlossaryGroupId;
                    newCreatedGroup.IsSecret = IsSecret;
                    newCreatedGroup.IsSectionComplete = false;
                    newCreatedGroup.ProjectId = projectId;
                    newCreatedGroup.SectionId = headerId.SectionId;
                    newCreatedGroup.SectionSubType = $scope.sectionSubType;
                    newCreatedGroup.SectionType = $scope.sectionType;
                    sessionStorage.setItem('SourceSetupActiveSection', JSON.stringify(newCreatedGroup));
                    $('.modal-backdrop.fade.in').css('display', 'none');
                    $route.reload();
                    //end
                }
                else if (!headerId.Result) {
                    if (headerId.ResultMessage !== '') {
                        $scope.errorMessage = '';
                        $scope.errorMessage = headerId.ResultMessage;
                        $('#errorModal').modal('show');
                        header.IsHeaderAdded = false;
                        $scope['saveName' + tableIndex] = false;
                        if ($('#ntl').prop("checked") === true) {
                            header.HeaderText = header.HeaderText.substring(6);
                            headerText = headerText.substring(6);
                        } else if ($('#fd').prop("checked") === true) {
                            header.HeaderText = header.HeaderText.substring(5);
                            headerText = headerText.substring(5);
                        }
                        return false;
                    } else if (headerId.ResultMessage === null) {
                        $scope.errorMessage = '';
                        $scope.errorMessage = validationNTLSection;
                        $('#errorModal').modal('show');
                        header.IsHeaderAdded = false;
                        $scope['saveName' + tableIndex] = false;
                        if ($('#ntl').prop("checked") === true) {
                            header.HeaderText = header.HeaderText.substring(6);
                            headerText = headerText.substring(6);
                        } else if ($('#fd').prop("checked") === true) {
                            header.HeaderText = header.HeaderText.substring(5);
                            headerText = headerText.substring(5);
                        }
                        return false;
                    }
                    else {
                        if ($('#ntl').prop("checked") === true) {
                            header.HeaderText = header.HeaderText.substring(6);
                            headerText = headerText.substring(6);
                        } else if ($('#fd').prop("checked") === true) {
                            header.HeaderText = header.HeaderText.substring(5);
                            headerText = headerText.substring(5);
                        }
                        $scope.errorMessage = 'This section already exists in this glossary';
                        $('#errorModal').modal('show');
                        header.IsHeaderAdded = false;
                        $scope['saveName' + tableIndex] = false;
                        return false;
                    }
                }

            });
        }
    };

    //GLMGR-757 lock NTL - or FD - 
    $scope.lockNTLSectionPrefixCallNewSection = function (secName, index) {
        if ($scope['saveName' + $scope.NTLtableIndex]) {
            if (secName && secName.indexOf("-") > -1) {
                var secName = secName.substring(0, secName.indexOf("-") + 2);
                var readOnlyLength = secName.length;
            }
            $('#lockNTLSectionPrefix' + index).on('keypress, keydown', function (event) {
                var $lockNTLSectionPrefix = $(this);
                if ((event.which !== 37 && (event.which !== 39))
                    && ((this.selectionStart < readOnlyLength)
                    || ((this.selectionStart == readOnlyLength) && (event.which == 8)))) {
                    return false;
                }
            });
        }
    };

    /**
     * @ngdoc
     * @name lockNTLSectionPrefixCall
     * @methodOf Projects.controller:ProjectMasterController
     * @param {String} secName This is section name entered.
     * @description
     * This method is responsible for adding NTL/FD prefix to section name entered.
     * @return {undefined} This method does not return.
     */
    $scope.lockNTLSectionPrefixCall = function (secName) {
        var secName = secName.substring(0, secName.indexOf("-") + 2);
        var readOnlyLength = secName.length;
        $('#lockNTLSectionPrefix').on('keypress, keydown', function (event) {
            var $lockNTLSectionPrefix = $(this);
            if ((event.which !== 37 && (event.which !== 39))
                && ((this.selectionStart < readOnlyLength)
                || ((this.selectionStart == readOnlyLength) && (event.which == 8)))) {
                return false;
            }
        });
    };

    $scope.lockNTLSectionPrefixCallBulk = function (secName) {
        var secName = secName.substring(0, secName.indexOf("-") + 2);
        var readOnlyLength = secName.length;
        $('#lockNTLSectionPrefixBulk').on('keypress, keydown', function (event) {
            var $lockNTLSectionPrefixBulk = $(this);
            if ((event.which !== 37 && (event.which !== 39))
                && ((this.selectionStart < readOnlyLength)
                || ((this.selectionStart == readOnlyLength) && (event.which == 8)))) {
                return false;
            }
        });
    };

    $scope.closePopup = function () {
        $scope['saveName' + $scope.NTLtableIndex] = false;
    };

       /**
     * @ngdoc
     * @name checkDuplicateSection
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Object} header This is newly added section object contains all the information of section eg. section name
     * @description
     * This method is responsible for checking duplicate section names while adding new section
     * @return {undefined} This method does not return.
     */
    var checkDuplicateSection = function (header) {
        //condition to check any duplicate entries of the same section name while adding new section
        if ($scope.displayingSelectedGroup.length < 1) {
            for (var i = 0; i < $scope.headers.length; i++) {
                if ($scope.headers[i].Id !== header.ProjectHeaderId) {
                    if ($scope.headers[i].GlossaryGroupHeader.toLowerCase().trim() === header.HeaderText.toLowerCase().trim()) {
                        $scope.errorMessage = 'This section already exists in this glossary';
                        $('#errorModal').modal('show');
                        header.IsHeaderAdded = false;
                        return false;
                    }
                }
            }
            for (var i = 0; i < $scope.ProjectNonAssignedSections.length; i++) {
                if ($scope.ProjectNonAssignedSections[i].GlossaryGroupId !== header.ProjectHeaderId) {
                    if ($scope.ProjectNonAssignedSections[i].SectionName.toLowerCase().trim() === header.HeaderText.toLowerCase().trim()) {
                        $scope.errorMessage = 'This section already exists in this glossary, but it is not yet assigned. Please click on the "Bulk Add/Edit Section" in order to assign it to this project.';
                        $('#errorModal').modal('show');
                        header.IsHeaderAdded = false;
                        return false;
                    }
                }
            }
            return true;
        }
            //Check for duplicate header names for existing section
        else {
            for (var i = 0; i < $scope.headers.length; i++) {
                if ($scope.headers[i].Id !== header.ProjectHeaderId) {
                    if ($scope.headers[i].GlossaryGroupHeader.toLowerCase().trim() === header.HeaderText.toLowerCase().trim()) {
                        $scope.errorMessage = 'This section already exists in this glossary';
                        $('#errorModal').modal('show');
                        header.IsHeaderAdded = false;
                        isHeaderAdded = true;
                        return false;
                    }
                }
            }
            for (var i = 0; i < $scope.ProjectNonAssignedSections.length; i++) {
                if ($scope.ProjectNonAssignedSections[i].GlossaryGroupId !== header.ProjectHeaderId) {
                    if ($scope.ProjectNonAssignedSections[i].SectionName.toLowerCase().trim() === header.HeaderText.toLowerCase().trim()) {
                        $scope.errorMessage = 'This section already exists in this glossary, but it is not yet assigned. Please click on the "Bulk Add/Edit Section" in order to assign it to this project.';
                        $('#errorModal').modal('show');
                        header.IsHeaderAdded = false;
                        isHeaderAdded = true;
                        return false;
                    }
                }
            }
            return true;
        }
    };

    /**
     * @ngdoc
     * @name updateHeaderText
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Object} header This is section object contains all the information of section eg. section name,Masterglossaries in section
     * @param {String} headerText This is updated name of section 
     * @param {boolean} IsSecret This is secret checkbox value. If section is secret then value is true else it is  false.
     * @description
     * This method is responsible for updating section details eg. section name.
     * @return {undefined} This method does not return.
     */
    $scope.updateHeaderText = function (header, headerText, IsSecret) {

        //impersonate original user
        var originaluser;
        if (!$scope.adminUser) {
            originaluser = null;
        }
        else {
            originaluser = $scope.adminUser.UserId
        }

        header.IsHeaderAdded = true;
        isHeaderAdded = true;
        if ($scope.sectionType === 2) {
            var str = headerText.substring(0, headerText.indexOf("-") + 2);
            str1 = headerText.replace(str, "");
            if (!str1) {
                $scope.errorMessage = '';
                $scope.errorMessage = 'Please enter the Section Text';
                $('#errorModal').modal('show');
                header.IsHeaderAdded = false;
                isHeaderAdded = true;
                return false;
            }
            if ((str1.toLowerCase().indexOf("ntl -")) >= 0 ||
                (str1.toLowerCase().indexOf("fd -")) >= 0 ||
                (str1.toLowerCase().indexOf("ntl-")) >= 0 ||
                (str1.toLowerCase().indexOf("fd-")) >= 0
                ) {
                $scope.errorMessage = '';
                $scope.errorMessage = validationNTLSection;
                $('#errorModal').modal('show');
                header.IsHeaderAdded = false;
                return false;
            }
        }

        if ($scope.sectionType === 1) {
            if ((headerText.toLowerCase().indexOf("ntl -")) >= 0 ||
                (headerText.toLowerCase().indexOf("fd -")) >= 0 ||
                (headerText.toLowerCase().indexOf("ntl-")) >= 0 ||
                (headerText.toLowerCase().indexOf("fd-")) >= 0 ||
                (headerText.toLowerCase().indexOf("localization list")) >= 0 ||
                (headerText.toLowerCase().indexOf("localisation list")) >= 0 ||
                (headerText.toLowerCase().indexOf("foreign dialogue")) >= 0 ||
                (headerText.toLowerCase().indexOf("foreign dialog")) >= 0
                ) {
                $scope.errorMessage = '';
                $scope.errorMessage = validationDefaultSection;
                $('#errorModal').modal('show');
                header.IsHeaderAdded = false;
                return false;
            }
        }

        if (!headerText) {
            $scope.errorMessage = '';
            $scope.errorMessage = 'Please enter the Section Text';
            $('#errorModal').modal('show');
            header.IsHeaderAdded = false;
            isHeaderAdded = true;
        }
        else {
            if (!checkDuplicateSection(header)) {
                return false;
            }
            else {
                ProjectMaster.updateGlossaryGroupHeader(projectId, header.ProjectHeaderId, headerText, IsSecret, header.SectionId, userDetails.UserId, $scope.sectionType, originaluser, function (status) {
                    if (!status.Result) {
                        if (status.ResultMessage !== '' && status.ResultMessage !== 'There is no Glossary Group available for this Section' && $scope.sectionType === 1) {
                            $('#addEditSections').modal('hide');
                            $scope.errorMessage = '';
                            $scope.errorMessage = status.ResultMessage;
                            $('#errorModal').modal('show');
                            return false;
                        } else if (status.ResultMessage === null) {
                            $('#addEditSections').modal('hide');
                            $scope.errorMessage = '';
                            $scope.errorMessage = validationNTLSection;
                            $('#errorModal').modal('show');
                            return false;
                        }
                        else {
                            $('#addEditSections').modal('hide');
                            $scope.errorMessage = 'There is no change in Section Name';
                            $('#errorModal').modal('show');
                            return false;
                        }
                    } else {
                        isSecretChanged = false;
                        isHeaderChanged = false;
                        $scope.successMessage = "Section Updated Successfully";
                        $('#saveNewTableModal').modal('show');
                        $scope.isSectionNameUpdated = true;
                    }
                });
            }
        }
    };

     /**
     * @ngdoc
     * @name showSelectedGroups
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Object} selectedGroup This is selected section object contains all the information of section eg. section name,isSecret
     * @description
     * This method is responsible for showing selected section's (from dropdown) data. 
     * @return {undefined} This method does not return.
     */
    $scope.showSelectedGroups = function (selectedGroup) {
        $scope.selectedGroup = selectedGroup;
        sessionStorage.setItem('SourceSetupActiveSection', JSON.stringify($scope.selectedGroup));
        if ($scope.reviewModeStored === false && $scope.IsSectionCompleteReminderFlag) {

            if (!$scope.displayingSelectedGroup[0].MasterGlossaries[0].MasterText) {
                $scope.errorMessage = '';
                $scope.errorMessage = 'Please enter the Master Term for the section. If you wish to add Master Term later, please click "Close" button at the bottom of the section.';
                $('#errorModal').modal('show');
                return false;
            }

            sectionCompleteChangeSection = true;
            $('#sectionCompleteReminder').modal({ backdrop: 'static', keyboard: false });
            $('#sectionCompleteReminder').modal('show');
        } else {
            $scope.lockInput = false; //GLMGR-956
            cancelSectionClicked === true;
            cancelSectionClickedFunction(); //GLMGR-956
            if ($scope.selectedGroup === null) {
                $scope.displayingSelectedGroup = [];
                $scope.isRecordDisplayed = false;
            }
            else {
                if ($scope.selectedGroup.IsSectionComplete === true) {
                    $scope.reviewModeSection = $scope.selectedGroup;
                }
                $scope.isRecordDisplayed = true;
                headerId = $scope.selectedGroup.Id;
                projectHeader = $scope.selectedGroup;
                angular.copy($scope.selectedGroup, selectedGroupCopy);
                $scope.displayingSelectedGroup = [];
                addedNewRowsList = [];
                $scope.updatedListOfHeaderData = [
           {
               "HeaderText": null,
               "ProjectHeaderId": -1,
               "UserId": userDetails.UserId,
               "MasterGlossaries": []
           }
                ];
                $scope.newListOfHeaderData = [
           {
               "HeaderText": null,
               "ProjectHeaderId": -1,
               "UserId": userDetails.UserId,
               "MasterGlossaries": []
           }
                ];
                $scope.projectMasterFromDb.TableData = [];

                //checking if the mode is to edit the saved header or adding a new header
                if ($scope.ProjectMasterJson.TableData.length > 0) {
                    return false;
                }
                else {
                    //getHeaderListAndCategoryList();
                    $scope.GlossaryBrandName = [];
                    var modeType = 0;
                    if ($scope.reviewModeSec === true) {
                        $scope.reviewModeSec = false;
                        modeType = 1;
                    } else {
                        $scope.modeButtonText = 'Switch to Review Mode';
                        $scope.reviewMode = false;
                    }
                    //Calling Service to get the saved headers from DB
                    ProjectMaster.getSavedHeadersFromDb(projectId, headerId, $scope.sectionType, modeType, function (headers) {
                        $scope.Isowner = false;
                        for (var i = 0; i < headers.UserHavingAccess.length; i++) {
                            if (headers.UserHavingAccess[i].UserId === $scope.userDetails.UserId) {
                                $scope.Isowner = true;
                                break;
                            }
                        }
                        $scope.ProjectNonAssignedSections = headers.Sections.ProjectNonAssignedSections;
                        $scope.isRecordDisplayed = false;
                        $scope.projectMasterFromDb.TableData.push(headers);
                        $scope.categoriesForSection = $scope.projectMasterFromDb.TableData[0].SectionCategories;
                        //Add the Header Data from the DB to the displayingGroup Array
                        for (var i = 0; i < $scope.projectMasterFromDb.TableData.length; i++) {
                            if (headerId === $scope.projectMasterFromDb.TableData[i].ProjectHeaderId) {
                                $scope.displayingSelectedGroup.push($scope.projectMasterFromDb.TableData[i]);
                            }
                        }

                        $scope.OnlyIsRemovedTerms = false;
                        //check if section has any un-removed term with master text
                        for (var i = 0; i < $scope.displayingSelectedGroup[0].MasterGlossaries.length; i++) {
                            if (!$scope.displayingSelectedGroup[0].MasterGlossaries[i].MasterText && $scope.displayingSelectedGroup[0].MasterGlossaries[i].IsRemoved === false) {
                                $scope.OnlyIsRemovedTerms = true; //hide section complete button
                            }
                        }

                        //check if section has at least on removed term
                        $scope.isShowRemovedTerms = false;
                        for (var i = 0; i < $scope.displayingSelectedGroup[0].MasterGlossaries.length; i++) {
                            if ($scope.displayingSelectedGroup[0].MasterGlossaries[i].IsRemoved === true) {
                                $scope.isShowRemovedTerms = true; //show 'Show Removed Terms' check box
                                sessionStorage.setItem('isShowRemovedTermsFlag', $scope.showRemovedTerms);
                                break;
                            }
                        }

                        //Reset the Category Headers on change of section
                        $scope.categories = $scope.displayingSelectedGroup[0].SectionCategories;

                        for (var i = 0; i < $scope.displayingSelectedGroup[0].MasterGlossaries.length; i++) {
                            $scope.displayingSelectedGroup[0].MasterGlossaries[i].userId = userDetails.UserId;
                            for (var j = 0; j < $scope.displayingSelectedGroup[0].MasterGlossaries[i].ProjectCategories.length; j++) {
                                $scope.displayingSelectedGroup[0].MasterGlossaries[i].ProjectCategories[j].userId = userDetails.UserId;
                            }
                        }
                        //setting the updateTableChanged flag to false to re-initialise it
                        isUpdateTableChanged = false;
                        //Copying for displaying the default brands on the newly added rows.
                        angular.copy($scope.displayingSelectedGroup[0].ProjectAssignedBrands, GlossaryBrandsHeaderWise);
                        //Copying for displaying maintaining a copy of the array so that the old values are available
                        angular.copy($scope.displayingSelectedGroup[0], copyOfDisplayingSelectedGroup);
                        //creating initial row count for checking 
                        initialRowCount = $scope.displayingSelectedGroup[0].MasterGlossaries.length;
                        //Copy the List of Master Glossary Data(Rows) to an array for furthur purposes
                        modifiedHeaderData = $scope.displayingSelectedGroup[0].MasterGlossaries;

                        // store details of current section to call section complete service
                        $scope.reviewModeStored = $scope.selectedGroup.IsSectionComplete;
                        sessionStorage.setItem('reviewModeStored', $scope.reviewModeStored);
                        $scope.selectedGroupIdStored = $scope.selectedGroup.Id;

                        //check if user is super admin, project owner or who added master term in section then set showApplyBulkSuggestions = true
                        $scope.showApplyBulkSuggestions = false;
                        for (var i = 0; i < headers.UserHavingAccess.length; i++) {
                            if (headers.UserHavingAccess[i].UserId === userDetails.UserId) {
                                $scope.showApplyBulkSuggestions = true;
                            }
                        }
                        if ($scope.showApplyBulkSuggestions && !$scope.reviewMode) {
                            $scope.reviewPanel = [];
                            $scope.hideApplySuggestions = true;
                            for (var i = 0; i < $scope.displayingSelectedGroup[0].MasterGlossaries.length; i++) {
                                var x = $scope.displayingSelectedGroup[0].MasterGlossaries[i];
                                if ((x.SuggestionType === 'Suggested Text Update' && x.SuggestedText != '') || (x.SuggestionType === 'Suggested Addition to Section' && x.SuggestedText !== '') || (x.SuggestionType === 'Suggested Term to Remove') || x.SuggestionType === 'Suggested Term to Restore') $scope.reviewPanel.push(x);
                            }
                            if ($scope.reviewPanel.length === 0) {
                                $scope.hideApplySuggestions = true;
                            } else {
                                $scope.hideApplySuggestions = false;
                                $('#showPendingSuggestionsPopup').modal({ backdrop: 'static', keyboard: false });
                                $('#showPendingSuggestionsPopup').modal('show');
                            }
                        }

                    });
                }
            }
        }
    };

    /**
     * @ngdoc
     * @name applySuggestionsButton
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is used to hide the 'apply Suggestions' button when there are no suggestions
     * @return {undefined} This method does not return.
     */
    var applySuggestionsButton = function () {
        $scope.reviewPanel = [];
        $scope.hideApplySuggestions = true;
        for (var i = 0; i < $scope.displayingSelectedGroup[0].MasterGlossaries.length; i++) {
            var x = $scope.displayingSelectedGroup[0].MasterGlossaries[i];
            if ((x.SuggestionType === 'Suggested Text Update' && x.SuggestedText != '') || (x.SuggestionType === 'Suggested Addition to Section' && x.SuggestedText !== '') || (x.SuggestionType === 'Suggested Term to Remove') || x.SuggestionType === 'Suggested Term to Restore') $scope.reviewPanel.push(x);
        }
        if ($scope.reviewPanel.length === 0) {
            $scope.hideApplySuggestions = true;
        } else {
            $scope.hideApplySuggestions = false;
        }
    };

    /**
     * @ngdoc
     * @name getIsSecretOnChange
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Boolean} IsSecret This is boolean value, If checkbox checked then true else false 
     * @param {Number} index This is index of selected section table
     * @description
     * This method is used to change the IsSecret flag for saving the secret section.
     * @return {undefined} This method does not return.
     */
    $scope.getIsSecretOnChange = function (IsSecret, index) {
        isSecretChanged = true;
        //Adding IsSecret flag as per the change in the checkbox when a new section is added
        for (var i = 0; i < $scope.ProjectMasterJson.TableData.length; i++) {
            if (i === index) {
                $scope.ProjectMasterJson.TableData[i].IsSecret = IsSecret;
            }
        }
        //Adding IsSecret flag as per the change in the checkbox when a section is updated
        for (var i = 0; i < $scope.displayingSelectedGroup.length; i++) {
            if (i === index) {
                $scope.displayingSelectedGroup[i].IsSecret = IsSecret;
            }
        }
    };

    //To Disable the Add Group or Select Dropdown
    $scope.disableButton = function (group) {
        if (group.length > 0) {
            return true;
        }
        else {
            return false;
        }
    };

    //Monitor if there any element changes and update the array accordingly to enable it to get updated.
    
    /**
     * @ngdoc
     * @name monitorElementChange
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Object} rowData This is object contains all the data of selected row.
     * @param {Number} rowIndex This is index of selected row in table
     * @description
     * This method is used to monitor if there any element changes and update the array accordingly to enable it to get updated.
     * @return {undefined} This method does not return.
     */
    $scope.monitorElementChange = function (rowData, rowIndex) {
        //if the table that is operated is for the existing section
        if ($scope.displayingSelectedGroup.length > 0) {
            for (var i = 0; i < $scope.displayingSelectedGroup[0].MasterGlossaries.length; i++) {
                if (rowData.MasterGlossaryId === $scope.displayingSelectedGroup[0].MasterGlossaries[i].MasterGlossaryId) {
                    $scope.displayingSelectedGroup[0].MasterGlossaries[i].isChanged = true;
                }
            }
        }
        else {
            modifiedHeaderData[rowIndex].isChanged = true;
        }
    };

    /**
     * @ngdoc
     * @name checkMaxLen
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called on change event of section name. This method is responsible for checking max length of section name.
     * @return {undefined} This method does not return.
     */
    $scope.checkMaxLen = function () {
        if ($scope.addBulkSectionName && $scope.addBulkSectionName.length > 40 ) {
            $scope.ErrorSectionNamePopup=true;
        } else if ($scope.addBulkSectionName && $scope.addBulkSectionName.length <= 40) {
            $scope.ErrorSectionNamePopup = false;
        }
    };

    //monitor change in Section text (monitor Section text updation)
    $scope.monitorHeaderTextChange = function (headerText) {
        isHeaderChanged = true;
        if ($scope.defaultSectionType) {
            if (headerText.length > 40){
                $scope.errorHeaderText = true;
            } else {
                $scope.errorHeaderText = false;
            }
        }else{
            if (headerText.length > 33) {
                $scope.errorHeaderText = true;
            } else {
                $scope.errorHeaderText = false;
            }
        }
    };

     /**
     * @ngdoc
     * @name sectionSubmit
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is used to load the header list in the dropdown after the section is submitted. Called on click of ok button in section migration popup
     * @return {undefined} This method does not return.
     */
    $scope.sectionSubmit = function () {
        if ($scope.ProjectMasterJson.TableData.length === 0) {
            if (addNewSectionBtnClicked) {
                $scope.headers = [];
                insertTableInUI();
                $scope.displayingSelectedGroup = [];
            }
            $('#saveNewTableModal').modal('hide');
            $('.modal-backdrop.fade.in').css('display', 'none');
            $scope.reviewModeStored = false;
            sessionStorage.setItem('reviewModeStored', $scope.reviewModeStored);
        }
    };

    
    $scope.imageDeleteConfirmation = function (rowData, parentIndex) {
        $scope.deleteTermImage = rowData;
        $scope.parentIndex = parentIndex;
        $('#deleteTermImage .modal-body').html('Are you sure, you want to delete the Term Image?');
        $('#deleteTermImage .modal-title').html('Delete Term Image Confirmation');
        $('#deleteTermImage').modal('show');
    };

    /**
     * @ngdoc
     * @name imageDelete
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * Delete the term Image
     * @return {undefined} This method does not return.
     */
    $scope.imageDelete = function () {
        deletedImageList = [
          {
              MasterGlossaries: []
          }
        ];
        if ($scope.ProjectMasterJson.TableData.length > 0) {
            for (var i = 0; i < TermImage.length; i++) {
                if ($scope.parentIndex === TermImage[i].sectionIndex) {
                    if (TermImage[i].mastertext.toLowerCase().trim() === $scope.deleteTermImage.MasterText.toLowerCase().trim()) {
                        TermImage.splice(i, 1);
                        break;
                    }
                }
            }
            for (var i = 0; i < $scope.ProjectMasterJson.TableData[$scope.parentIndex].MasterGlossaries.length; i++) {
                if ($scope.ProjectMasterJson.TableData[$scope.parentIndex].MasterGlossaries[i].MasterText) {
                    if ($scope.deleteTermImage.MasterText.toLowerCase().trim() === $scope.ProjectMasterJson.TableData[$scope.parentIndex].MasterGlossaries[i].MasterText.toLowerCase().trim()) {
                        $scope.ProjectMasterJson.TableData[$scope.parentIndex].MasterGlossaries[i].TermImage = null;
                        break;
                    }
                }
            }
        }
        else {
            for (var i = 0; i < TermImage.length; i++) {
                if (TermImage[i].MasterGlossaryId === $scope.deleteTermImage.MasterGlossaryId) {
                    TermImage.splice(i, 1);
                    break;
                }
            }
            for (var i = 0; i < $scope.displayingSelectedGroup[0].MasterGlossaries.length; i++) {
                if ($scope.displayingSelectedGroup[0].MasterGlossaries[i].MasterText) {
                    if ($scope.deleteTermImage.MasterText.toLowerCase().trim() === $scope.displayingSelectedGroup[0].MasterGlossaries[i].MasterText.toLowerCase().trim()) {
                        $scope.displayingSelectedGroup[0].MasterGlossaries[i].TermImage = null;
                        $scope.displayingSelectedGroup[0].MasterGlossaries[i].MasterImageUrl = null;
                        $scope.displayingSelectedGroup[0].MasterGlossaries[i].isAddedImageDetails = false;
                        break;
                    }
                }
            }
        }
        deletedImageList[0].MasterGlossaries.push($scope.deleteTermImage);
        $scope.deleteTermImage.MasterImageUrl = null;
        var originaluser;
        if (!$scope.adminUser) {
            originaluser = null;
        }
        else {
            originaluser = $scope.adminUser.UserId
        }
        //service to delete image from server
        ProjectMaster.DeleteTermImage(projectId, deletedImageList, userDetails.UserId, originaluser, function (status) {
            if (status) {
                $('#importError .modal-body').html('Term Image is deleted successfully.');
                $('#importError .modal-title').html('Delete Term Image');
                $('#importError').modal('show');
            }
            else {
                $('#importError .modal-body').html('Term Image could not be deleted ');
                $('#importError .modal-title').html('Delete Term Image');
                $('#importError').modal('show');
            }
        });
    };

    /**
     * @ngdoc
     * @name imagePreview
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Object} rowData This is object contains all the data of selected row.
     * @param {Number} sectionIndex This is index of selected section in div
     * @param {Number} ProjectHeaderId This is selected section id.
     * 
     * @description
     * This method is responsible for showing preview of term image.
     * @return {undefined} This method does not return.
     */
    $scope.imagePreview = function (rowData, sectionIndex, ProjectHeaderId) {
        if ($scope.ProjectMasterJson.TableData.length > 0) {
            //preview current images in new added sections
            for (var i = 0; i < $scope.ProjectMasterJson.TableData[sectionIndex].MasterGlossaries.length; i++) {
                if ($scope.ProjectMasterJson.TableData[sectionIndex].ProjectHeaderId === ProjectHeaderId) {
                    if ($scope.ProjectMasterJson.TableData[sectionIndex].MasterGlossaries[i].MasterText) {
                        if ($scope.ProjectMasterJson.TableData[sectionIndex].MasterGlossaries[i].MasterText.toLowerCase().trim() === rowData.MasterText.toLowerCase().trim()) {
                            $scope.currentRowImage = $scope.ProjectMasterJson.TableData[sectionIndex].MasterGlossaries[i].TermImage.filedata;
                            $('#previewTermImage .modal-body').html('<div class="imagePreview"><img class="term-image" src="data:image/jpeg;base64,' + $scope.currentRowImage + '"/></div> <div class="master-text">Master Term: ' + rowData.MasterText + '</div>');
                            $('#previewTermImage').modal('show');
                            break;
                        }
                    }
                }
            }
            $scope.showLoader = false;
        }
        else {
            if (rowData.MasterImageUrl) {
                //service to get image to preview from server
                $scope.showLoader = true;
                ProjectMaster.getPreviewTermImage(projectId, rowData.MasterGlossaryId, function (status) {
                    if (status) {
                        $scope.showLoader = false;
                        $('#previewTermImage .modal-body').html('<div class="imagePreview"><img class="term-image" src="' + status + '"/></div> <div class="master-text">Master Term: ' + rowData.MasterText + '</div>');
                        $('#previewTermImage').modal('show');
                    }
                });
            } else {
                //preview current images in update sections
                for (var i = 0; i < TermImage.length; i++) {
                    if (TermImage[i].MasterGlossaryId === rowData.MasterGlossaryId) {
                        $scope.currentRowImage = TermImage[i].filedata;
                        $('#previewTermImage .modal-body').html('<div class="imagePreview"><img class="term-image" src="data:image/jpeg;base64,' + $scope.currentRowImage + '"/></div> <div class="master-text">Master Term: ' + rowData.MasterText + '</div>');
                        $('#previewTermImage').modal('show');
                        break;
                    }
                }
                $scope.showLoader = false;
            }
        }
    };

    $scope.imagePreviewClose = function () {
        $('#previewTermImage').modal('hide');
    };

    //Getting the master glossary id for uploading image
    $scope.getMasterGlossaryId = function (rowData, group) {
        masterGlossaryIdForImage = rowData.MasterGlossaryId;
        projectHeaderIdForImage = group.ProjectHeaderId;
    };

    $scope.$on('addedImageDetails', function (event, myData) {
        myImageData = myData;
        if (myData[0].fileext !== 'png' && myData[0].fileext !== 'jpeg' && myData[0].fileext !== 'jpg') {
            $('#importError .modal-body').html('Only image files with extension .png, .jpeg, .jpg are allowed');
            $('#importError .modal-title').html('Invalid image format');
            $('#importError').modal('show');
        }
        else {
            $scope.origImage = '';
            $scope.CropImage = '';
            $('#imagePopup').modal('show');
            $timeout(function () {
                $scope.origImage = myData[0].image;
            }, 1000);

        }
    });

    /**
     * @ngdoc
     * @name saveCropImage
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is responsible for saving image after crop to upload for term image.
     * @return {undefined} This method does not return.
     */
    $scope.saveCropImage = function () {
        var myData = myImageData;
        var sectionIndex = myData[0].sectionIndex;
        var f = new File([$scope.CropImage], "filename");
        myData[0].filedata = $scope.CropImage.split(',')[1];
        myData[0].filesize = f.size;
        myData[0].filetype = 'png';
        if ($scope.ProjectMasterJson.TableData.length > 0) {
            for (var i = 0; i < $scope.ProjectMasterJson.TableData[sectionIndex].MasterGlossaries.length; i++) {
                if ($scope.ProjectMasterJson.TableData[sectionIndex].MasterGlossaries[i].MasterText) {
                    if (myData[0].mastertext.toLowerCase().trim() === $scope.ProjectMasterJson.TableData[sectionIndex].MasterGlossaries[i].MasterText.toLowerCase().trim()) {
                        $scope.ProjectMasterJson.TableData[sectionIndex].MasterGlossaries[i].isAddedImageDetails = true;
                        $scope.ProjectMasterJson.TableData[sectionIndex].MasterGlossaries[i].TermImage = myData[0];
                        if (!$scope.$$phase) {
                            $scope.$apply();
                        }
                    }
                }
            }
            TermImage.push(myData[0]);
        }

        autoSaveTermImage(myData);
    };

    /**
     * @ngdoc
     * @name deleteRow
     * @methodOf Projects.controller:ProjectMasterController
     * @param {object} rowData this is selected row data, conatins all data in row
     * @param {number} index this is index of row
     * @param {number} parentIndex this is index of section in div
     * @param {object} group is section object which contains all details of section.
     * @description
     * This method is responsible for deleting row in section table
     * @return {undefined} This method does not return.
     */
    $scope.deleteRow = function (rowData, index, parentIndex, group) {
        if ($scope.selectedGroup !== undefined) {
            checkSectionStatus();
            ProjectMaster.checkSectionStatus(objSectionStatus, function (status) {
                if (status) {
                    $('#sectionStatePopup').modal({ backdrop: 'static', keyboard: false });
                    $('#sectionStatePopup').modal('show');
                } else {
                    $scope.deleteRowIndex = index;
                    $scope.deleteHeaderIndex = parentIndex;
                    $scope.deletedRowsList = [];
                    $scope.group = group;
                    $scope.deletedRowData = rowData;
                    $scope.deletedRowsListForUpdate = [{ MasterGlossaries: [] }];
                    var originaluser;
                    if (!$scope.adminUser) {
                        originaluser = null;
                    }
                    else {
                        originaluser = $scope.adminUser.UserId;
                    }
                    var deletedRow = {};
                    //check if the Master Text is null or empty
                    if (!rowData.MasterText) {
                        if ($scope.displayingSelectedGroup.length > 0) {
                            $scope.deletedRowsList = $scope.displayingSelectedGroup[0].MasterGlossaries;
                            for (var j = 0; j < $scope.displayingSelectedGroup[0].MasterGlossaries.length; j++) {
                                if (j === index) {
                                    deletedRow = $scope.displayingSelectedGroup[0].MasterGlossaries.splice(j, 1);
                                    break;
                                }
                            }
                        }
                        else {
                            $scope.deletedRowsList = $scope.ProjectMasterJson.TableData[parentIndex].MasterGlossaries;
                            for (var i = 0; i < $scope.ProjectMasterJson.TableData[parentIndex].MasterGlossaries.length; i++) {
                                if (i === index) {
                                    deletedRow = $scope.ProjectMasterJson.TableData[parentIndex].MasterGlossaries.splice(i, 1);
                                    break;
                                }
                            }
                        }
                        //create sequence from the master glossary id received in response
                        var masterGlossarySequence = [];
                        for (var i = 0; i < $scope.deletedRowsList.length; i++) {
                            masterGlossarySequence.push($scope.deletedRowsList[i].MasterGlossaryId);
                        }
                        --totalRowsAdded;

                        var sequenceLength = masterGlossarySequence.length;
                        for (var j = 0; j < sequenceLength - 1; j++) {
                            for (var k = j + 1; k < sequenceLength; k++) {
                                if (masterGlossarySequence[j] === masterGlossarySequence[k]) {
                                    masterGlossarySequence.splice(k, 1);
                                    sequenceLength = sequenceLength - 1;
                                }
                            }
                        }
                        if (rowData.MasterGlossaryId !== -1) {
                            //Pushing the deleted object into a deleted list
                            for (var i = 0; i < deletedRow.length; i++) {
                                $scope.deletedRowsListForUpdate[0].MasterGlossaries.push(deletedRow[i]);
                            }

                            //Call the service to delete the data
                            ProjectMaster.deleteRecordsFromHeader(projectId, $scope.deletedRowsListForUpdate, userDetails.UserId, originaluser, $scope.selectedGroup.IsSectionComplete, $scope.selectedGroup.IsSectionUnlock, function (status) {
                                if (status) {
                                    if ($scope.displayingSelectedGroup.length > 0) {
                                        ProjectMaster.changeRowSequence($scope.selectedGroup.Id, masterGlossarySequence.toString(), userDetails.UserId, originaluser, function (sequenceStatus) {
                                            if (sequenceStatus) {
                                                $scope.showLoader = false;
                                                if ($scope.displayingSelectedGroup[0].MasterGlossaries.length === 0) {
                                                    $scope.showSelectedGroups(projectHeader);
                                                }
                                            }
                                        });
                                    }
                                    else {
                                        ProjectMaster.changeRowSequence($scope.group.ProjectHeaderId, masterGlossarySequence.toString(), userDetails.UserId, originaluser, function (sequenceStatus) {
                                            if (sequenceStatus) {
                                                $scope.showLoader = false;
                                                if ($scope.ProjectMasterJson.TableData[parentIndex].MasterGlossaries.length === 0) {
                                                    $scope.addNewRowForNewSection($scope.group.ProjectHeaderId, index, parentIndex, deletedRow);
                                                }
                                            }
                                        });
                                    }
                                }
                            });
                        }
                    }
                    else {
                        $('#deleteModal').modal('show');
                    }
                }
            })
        }
    };

    //Called on click of yes button from the delete popup
    $scope.deleteRowData = function () {
        var deletedRow = {};
        var index = $scope.deleteRowIndex;
        var parentIndex = $scope.deleteHeaderIndex;

        $scope.deletedRowsList = [];
        $scope.deletedRowsListForUpdate = [{ MasterGlossaries: [] }];

        var originaluser;
        if (!$scope.adminUser) {
            originaluser = null;
        }
        else {
            originaluser = $scope.adminUser.UserId;
        }

        //if the row deleted is from the newly added table
        if ($scope.displayingSelectedGroup.length < 1) {
            $scope.deletedRowsList = $scope.ProjectMasterJson.TableData[parentIndex].MasterGlossaries;
            for (var j = 0; j < $scope.ProjectMasterJson.TableData[parentIndex].MasterGlossaries.length; j++) {
                if (j === index) {
                    deletedRow = $scope.ProjectMasterJson.TableData[parentIndex].MasterGlossaries.splice(j, 1);
                    break;
                }
            }
            //Pushing the deleted object into a deleted list
            for (var i = 0; i < deletedRow.length; i++) {
                $scope.deletedRowsListForUpdate[0].MasterGlossaries.push(deletedRow[i]);
            }
        }
            //if the deleting record is from the existing record
        else {
            $scope.deletedRowsList = $scope.displayingSelectedGroup[0].MasterGlossaries;
            for (var j = 0; j < $scope.displayingSelectedGroup[0].MasterGlossaries.length; j++) {
                if (j === index) {
                    deletedRow = $scope.displayingSelectedGroup[0].MasterGlossaries.splice(j, 1);
                    break;
                }
            }


            //Pushing the deleted object into a deleted list
            for (var i = 0; i < deletedRow.length; i++) {
                $scope.deletedRowsListForUpdate[0].MasterGlossaries.push(deletedRow[i]);
            }
        }
        //create sequence from the master glossary id received in response
        var masterGlossarySequence = [];
        for (var i = 0; i < $scope.deletedRowsList.length; i++) {
            masterGlossarySequence.push($scope.deletedRowsList[i].MasterGlossaryId);
        }
        --totalRowsAdded;

        var sequenceLength = masterGlossarySequence.length;
        for (var j = 0; j < sequenceLength - 1; j++) {
            for (var k = j + 1; k < sequenceLength; k++) {
                if (masterGlossarySequence[j] === masterGlossarySequence[k]) {
                    masterGlossarySequence.splice(k, 1);
                    sequenceLength = sequenceLength - 1;
                }
            }
        }

        //Call the service to delete the data
        $scope.showLoader = true;
        ProjectMaster.deleteRecordsFromHeader(projectId, $scope.deletedRowsListForUpdate, userDetails.UserId, originaluser, $scope.selectedGroup.IsSectionComplete, $scope.selectedGroup.IsSectionUnlock, function (status) {
            if (status) {
                if ($scope.displayingSelectedGroup.length > 0) {
                    ProjectMaster.changeRowSequence($scope.selectedGroup.Id, masterGlossarySequence.toString(), userDetails.UserId, originaluser, function (sequenceStatus) {
                        if (sequenceStatus) {
                            $scope.showLoader = false;

                            if ($scope.displayingSelectedGroup.length > 0) {
                                if ($scope.displayingSelectedGroup[0].MasterGlossaries.length === 0) {
                                    $scope.showSelectedGroups(projectHeader);
                                }
                            }
                        }
                    });
                }
                else {
                    ProjectMaster.changeRowSequence($scope.group.ProjectHeaderId, masterGlossarySequence.toString(), userDetails.UserId, originaluser, function (sequenceStatus) {
                        if (sequenceStatus) {
                            $scope.showLoader = false;
                            if ($scope.ProjectMasterJson.TableData[parentIndex].MasterGlossaries.length === 0) {
                                $scope.addNewRowForNewSection($scope.group.ProjectHeaderId, index, parentIndex, deletedRow);
                            }
                        }
                    });
                }
            }
            $scope.reviewModeStored = true;
            sessionStorage.setItem('reviewModeStored',$scope.reviewModeStored);
            $scope.reloadSection(); //page reload to get the status of starred mark and show/hide star, mark term as disabled using isRemoved flag
        });
    };

    /**
     * @ngdoc
     * @name cancelSection
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is responsible for closing the current open section.
     * @return {undefined} This method does not return.
     */
    $scope.cancelSection = function (index) {
        cancelSectionClicked = true; //GLMGR-956
        if ($scope.displayingSelectedGroup.length !== 0 && $scope.displayingSelectedGroup[0].MasterGlossaries[0].MasterText && $scope.reviewModeStored === false && $scope.IsSectionCompleteReminderFlag) {
            $('#sectionCompleteReminder').modal({ backdrop: 'static', keyboard: false });
            $('#sectionCompleteReminder').modal('show');
        } else {
            $scope.closeSection();
        }
    };

        /**
     * @ngdoc
     * @name newcancelSection
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is responsible for closing the new section.
     * @return {undefined} This method does not return.
     */
    $scope.newcancelSection = function (index) {
        cancelSectionClicked = true;
        if ($scope.ProjectMasterJson.TableData[0].HeaderText && $scope.ProjectMasterJson.TableData.length !== 0 && $scope.reviewModeStored === false && $scope.IsSectionCompleteReminderFlag) {
            $('#sectionCompleteReminder').modal({ backdrop: 'static', keyboard: false });
            $('#sectionCompleteReminder').modal('show');
        } else {
            $scope.closeSection();
        }

    };

    //close popup
    $scope.dismissPopUp = function () {
        if (!addNewSectionBtnClicked) {
            $scope.showSelectedGroups(projectHeader);
            isUpdateTableChanged = false;
            isHeaderChanged = false;
            $('.modal-backdrop.fade.in').css('display', 'none');
        }
        else {
            $('.modal-backdrop.fade.in').css('display', 'none');
            $scope.headers = [];
            getHeaderListAndCategoryList();
        }
    };

    /**
     * @ngdoc
     * @name getProjectBasicInfoOnLoad
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is responsible to get the project's basic information like title, source.
     * @return {undefined} This method does not return.
     */
    var getProjectBasicInfoOnLoad = function () {
        $http.get('Projects/GetProjectInfoPermission/' + projectId + '/' + userDetails.UserId)
          .success(function (projectinfo) {
              if (projectinfo.accessRes) {
                  if (projectinfo.accessRes === "AccessDenied") {
                      commonService.deniedRedirect();
                  }
              }
              else {
                  hideColors = false;
                  $scope.ProjectInfo = projectinfo;

                  if ($scope.ProjectInfo.UserProfileTranslationDetails === null) {
                      $scope.IsSectionCompleteReminderFlag = true;
                  } else if ($scope.ProjectInfo.UserProfileTranslationDetails.IsSectionCompleteReminder === null) {
                      $scope.IsSectionCompleteReminderFlag = true;
                  } else {
                      $scope.IsSectionCompleteReminderFlag = $scope.ProjectInfo.UserProfileTranslationDetails.IsSectionCompleteReminder; // to know if user has set 'show section complete: reminder' popup
                  }

                  sessionStorage.setItem('IsSectionCompleteReminderFlag', $scope.IsSectionCompleteReminderFlag);
                  $scope.client_str = '';
                  for (var i = 0; i < $scope.ProjectInfo.Clients.length; i++) {
                      $scope.client_str = $scope.client_str + $scope.ProjectInfo.Clients[i].ClientName + ', ';
                  }
                  $scope.client_str = $scope.client_str.slice(0, -2);

                  $scope.brand_str = '';
                  for (var i = 0; i < $scope.ProjectInfo.ProjectBrands.length; i++) {
                      $scope.brand_str = $scope.brand_str + $scope.ProjectInfo.ProjectBrands[i].BrandName + ', ';
                  }
                  $scope.brand_str = $scope.brand_str.slice(0, -2);

                  //for right to left languages
                  if ($scope.ProjectInfo.IsRLT) {
                      $scope.rtlData = 'rtl';
                  } else {
                      $scope.rtlData = 'ltr';
                  }
              }
              $scope.showLoader = false;
          })

     .error(function (e) { });
    };

    /**
     * @ngdoc
     * @name showDeleteSectionPopup
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is used to show delete section popup.Called on delete icon on section header 
     * @return {undefined} This method does not return.
     */
    $scope.showDeleteSectionPopup = function (header, index) {
        $scope.headerToBeDeleted = {};
        $scope.headerToBeDeleted = header;
        deletedSectionIndex = index;
        if (!$scope.reviewMode) {
            $('#deleteSectionModal').modal('show');
        }
        return false;
    };

    /**
     * @ngdoc
     * @name deleteSection
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is responsible for deleting the section.
     * @return {undefined} This method does not return.
     */
    $scope.deleteSection = function () {
        var originaluser;
        if (!$scope.adminUser) {
            originaluser = null;
        }
        else {
            originaluser = $scope.adminUser.UserId
        }
        ProjectMaster.deleteSection($scope.headerToBeDeleted.ProjectHeaderId, userDetails.UserId, originaluser, function (status) {
            if (status) {
                $scope.showDeleteSectionSuccessOKButton = true;
                $('#importError').modal({ backdrop: 'static', keyboard: false });
                $('#importError .modal-title').html('Success Message');
                $('#importError .modal-body').html('Section Deleted Successfully!');
                $('#importError').modal('show');
                return false;
            } else {
                $scope.errorMessage = "";
                $('#deleteSectionError label').html("You cannot remove this section from the Glossary since there are already terms and/or translations which have been added to it. In order to remove this from the Glossary, you will either have to move the term(s) to another section and/or simply remove this term/row from the section and/or if there are any pending suggestions against terms, you have to approve/reject them.<ul><li>To remove a row/term(s) from this section, be sure to press the 'X' button next to the term.<ul><li>This will remove the row</li></ul></li><li>To move the term(s) to another section use the 'arrow' button next to the term.<ul><li>Follow the instructions to move the term to another section</li></ul></li><li>To approve/reject suggestion against terms<ul><li>Click on the icon in 'version' column in that row.</li></ul></li></ul><br/> ");
                $('#deleteSectionError').modal('show');
                return false;
            }
        });
    };

    /**
     * @ngdoc
     * @name deleteSection
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called on click of edit brands button.This method is used to get data for all sections and brands list
     * @return {undefined} This method does not return.
     */
    $scope.getAllSectionsBrands = function () {
        $scope.brandsValidationMsg = '';
        $scope.selectedSectionsList = [];
        $scope.unselectedBrandsList = [];
        $scope.sectionBrandsToBeSaved.ProjectAddedBrands = [];
        $scope.sectionBrandsToBeSaved.ProjectRemovedBrands = [];
        ProjectMaster.getSectionsBrandsList(projectId, $scope.sectionType, function (sectionsBrandsList) {
            if (sectionsBrandsList.ProjectALLSections.length > 0) {
                if (sectionsBrandsList.ProjectALLBrands.length > 0) {
                    $('#addBrandsToAllSection').modal('show');
                }
                else {
                    $scope.errorMessage = 'There is no brand available to this project.';
                    $('#errorModal').modal('show');
                    return false;
                }
            }
            else {
                $scope.errorMessage = 'There is no section available to this project. Please add section(s) first.';
                $('#errorModal').modal('show');
                return false;
            }
            $scope.sectionsBrandsList = sectionsBrandsList;
            angular.copy(sectionsBrandsList.ProjectALLSections, $scope.unselectedSectionsList);
            angular.copy(sectionsBrandsList.ProjectALLBrands, $scope.unselectedBrandsList);
        });
    };

     /**
     * @ngdoc
     * @name saveAllSectionsBrands
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called on click of apply button on edit brands popup.This method is used to save data for selected sections and brands list
     * @return {undefined} This method does not return.
     */
    $scope.saveAllSectionsBrands = function () {
        angular.copy($scope.selectedSectionsList, $scope.sectionBrandsToBeSaved.ProjectSelectedSections);
        $scope.sectionBrandsToBeSaved.ProjectId = $scope.sectionsBrandsList.ProjectId;
        $scope.sectionBrandsToBeSaved.UserId = userDetails.UserId;

        if (!$scope.adminUser) {
            $scope.sectionBrandsToBeSaved.OriginalUserId = null;
        }
        else {
            $scope.sectionBrandsToBeSaved.OriginalUserId = $scope.adminUser.UserId
        }

        if ($scope.selectedSectionsList.length < 1 || ($scope.sectionBrandsToBeSaved.ProjectRemovedBrands.length < 1 && $scope.sectionBrandsToBeSaved.ProjectAddedBrands.length < 1)) {
            $scope.brandsValidationMsg = "*Mandatory Fields are required";
            return false;
        } else if ($scope.sectionBrandsToBeSaved.ProjectAddedBrands.length < 1) {
            $scope.brandsValidationMsg = "*Minimum One brand is to be associated with Sections";
            return false;
        }
        else {
            $scope.brandsValidationMsg = "";
            $scope.showLoader = true;
            ProjectMaster.saveSectionsBrandsList(projectId, $scope.sectionBrandsToBeSaved, function (status) {

                $scope.showLoader = false;
                $('#addBrandsToAllSection').modal('hide');
                $('.modal-backdrop.fade.in').css('display', 'none');
                $route.reload();
            });
        }
    };

      /**
     * @ngdoc
     * @name addBrandIdFromRadioBtn
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called on click of radio button on edit brands popup.This method is used to get the brands to be added.
     * @return {undefined} This method does not return.
     */
    $scope.addBrandIdFromRadioBtn = function (brand) {
        var addFlag = false;
        if ($scope.sectionBrandsToBeSaved.ProjectAddedBrands.length === 0) {
            $scope.sectionBrandsToBeSaved.ProjectAddedBrands.push(brand);
        }
        else {
            for (var i = 0; i < $scope.sectionBrandsToBeSaved.ProjectAddedBrands.length; i++) {
                if (($scope.sectionBrandsToBeSaved.ProjectAddedBrands[i].BrandId === brand.BrandId) &&
                    ($scope.sectionBrandsToBeSaved.ProjectAddedBrands[i].ProjectBrandId === brand.ProjectBrandId)) {
                    addFlag = true;
                    return false;
                }
            }
            if (!addFlag) {
                $scope.sectionBrandsToBeSaved.ProjectAddedBrands.push(brand);
            }
        }
        for (var i = 0; i < $scope.sectionBrandsToBeSaved.ProjectRemovedBrands.length; i++) {
            if (($scope.sectionBrandsToBeSaved.ProjectRemovedBrands[i].BrandId === brand.BrandId) &&
           ($scope.sectionBrandsToBeSaved.ProjectRemovedBrands[i].ProjectBrandId === brand.ProjectBrandId)) {
                $scope.sectionBrandsToBeSaved.ProjectRemovedBrands.splice(i, 1);
            }
        }
    };

    /**
     * @ngdoc
     * @name removeBrandIdFromRadioBtn
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called on click of radio button on edit brands popup.This method is used to get the brands to be removed
     * @return {undefined} This method does not return.
     */
    $scope.removeBrandIdFromRadioBtn = function (brand) {
        var removeFlag = false;
        if ($scope.sectionBrandsToBeSaved.ProjectRemovedBrands.length === 0) {
            $scope.sectionBrandsToBeSaved.ProjectRemovedBrands.push(brand);
        }
        else {
            for (var i = 0; i < $scope.sectionBrandsToBeSaved.ProjectRemovedBrands.length; i++) {
                if (($scope.sectionBrandsToBeSaved.ProjectRemovedBrands[i].BrandId === brand.BrandId) &&
                    ($scope.sectionBrandsToBeSaved.ProjectRemovedBrands[i].ProjectBrandId === brand.ProjectBrandId)) {
                    removeFlag = true;
                    return false;
                }
            }
            if (!removeFlag) {
                $scope.sectionBrandsToBeSaved.ProjectRemovedBrands.push(brand);
            }
        }
        for (var i = 0; i < $scope.sectionBrandsToBeSaved.ProjectAddedBrands.length; i++) {
            if (($scope.sectionBrandsToBeSaved.ProjectAddedBrands[i].BrandId === brand.BrandId) &&
           ($scope.sectionBrandsToBeSaved.ProjectAddedBrands[i].ProjectBrandId === brand.ProjectBrandId)) {
                $scope.sectionBrandsToBeSaved.ProjectAddedBrands.splice(i, 1);
            }
        }
    };

       /**
     * @ngdoc
     * @name getRowWiseBrands
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Object} rowData This is object contains all the data of selected row.
     * @param {Object} group current selected section's data
     * 
     * @description
     * This method is called on click of edit icon on brands column in section table.This method is used to get Row wise brands and assign it as checked in checkbox of the popup
     * @return {undefined} This method does not return.
     */
    $scope.getRowWiseBrands = function (rowData, group) {
        $scope.brandsValidationMsg = "";
        $scope.GlossaryBrands = [];
        $scope.MasterGlossaryId = rowData.MasterGlossaryId;
        $scope.RowData = rowData;
        $scope.SectionData = group;

        if (!rowData.MasterText) {//GLMGR-1095
            $scope.lockInput = false;
            $scope.errorMessage = '';
            $scope.errorMessage = 'Please enter the Master Term for the section';
            $('#errorModal').modal('show');
            return false;
        }

        //GLMGR-1014
        if (group.ProjectAssignedBrands.length === 0) {
            $scope.lockInput = false;
            $scope.errorMessage = '';
            $scope.errorMessage = 'No Brands are assigned to this project/term.';
            $('#errorModal').modal('show');
            return false;
        }

        angular.copy(group, copyOfDisplayingSelectedGroup);


        ProjectMaster.getSectionsBrandsList(projectId, $scope.sectionType, function (sectionsBrandsList) {
            if (sectionsBrandsList) {
                $scope.sectionsBrandsList = sectionsBrandsList;
                angular.copy(sectionsBrandsList.ProjectALLBrands, $scope.GlossaryBrands);
                for (var i = 0; i < $scope.GlossaryBrands.length; i++) {
                    for (var j = 0; j < rowData.GlossaryAddedBrands.length; j++) {
                        if ($scope.GlossaryBrands[i].BrandId === rowData.GlossaryAddedBrands[j].BrandId) {
                            $scope.GlossaryBrands[i].isCheckedBrand = true;
                        }
                    }
                }
                $('#addBrandsToTerms').modal('show');
            }
        });
    };

     /**
     * @ngdoc
     * @name saveRowWiseBrand
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called on click of apply button edit row-wise brands popup.This method is used to save the term-wise brand List
     * @return {undefined} This method does not return.
     */
    $scope.saveRowWiseBrand = function () {
        TermAddedBrands = [];
        TermRemovedBrands = [];
        $scope.RowData.GlossaryAddedBrands = [];
        $scope.RowData.GlossaryRemovedBrands = [];
        for (var i = 0; i < $scope.GlossaryBrands.length; i++) {
            if ($scope.GlossaryBrands[i].isCheckedBrand) {
                var TermsAddedBrandsCopy = {
                    "MasterGlossaryId": $scope.MasterGlossaryId,
                    "ProjectBrandId": -1
                };
                TermsAddedBrandsCopy.ProjectBrandId = $scope.GlossaryBrands[i].ProjectBrandId;
                $scope.RowData.GlossaryAddedBrands.push($scope.GlossaryBrands[i]);
                TermAddedBrands.push(TermsAddedBrandsCopy);
            }
            else {
                var TermsRemovedBrandsCopy = {
                    "MasterGlossaryId": $scope.MasterGlossaryId,
                    "ProjectBrandId": -1
                };
                TermsRemovedBrandsCopy.ProjectBrandId = $scope.GlossaryBrands[i].ProjectBrandId;
                $scope.RowData.GlossaryRemovedBrands.push($scope.GlossaryBrands[i]);
                TermRemovedBrands.push(TermsRemovedBrandsCopy);
            }
        }
        //validation if there are no brands selected
        if (TermRemovedBrands.length === $scope.GlossaryBrands.length) {
            $scope.brandsValidationMsg = "*Minimum One brand is to be associated with the term";
            //Adding the default glossary brands added to that row.
            for (var i = 0; i < copyOfDisplayingSelectedGroup.MasterGlossaries.length; i++) {
                if ($scope.MasterGlossaryId === copyOfDisplayingSelectedGroup.MasterGlossaries[i].MasterGlossaryId) {
                    angular.copy(copyOfDisplayingSelectedGroup.MasterGlossaries[i].GlossaryAddedBrands, $scope.RowData.GlossaryAddedBrands);
                }
            }
            $scope.RowData.GlossaryRemovedBrands = [];
            TermRemovedBrands = [];
            return false;
        }
        else {
            $scope.brandsValidationMsg = "";
            $('#addBrandsToTerms').modal('hide');
            if ($scope.RowData.GlossaryAddedBrands.length > 0 || $scope.RowData.GlossaryRemovedBrands.length > 0) {
                $scope.showLoader = true;
                var MasterGlossaryBrandsModel = {};
                MasterGlossaryBrandsModel.MasterGlossaryId = $scope.RowData.MasterGlossaryId;
                MasterGlossaryBrandsModel.UserId = userDetails.UserId;
                MasterGlossaryBrandsModel.RowVersion = $scope.RowData.RowVersion;
                MasterGlossaryBrandsModel.GlossaryAddedBrands = $scope.RowData.GlossaryAddedBrands;
                MasterGlossaryBrandsModel.GlossaryRemovedBrands = $scope.RowData.GlossaryRemovedBrands;

                if (!$scope.adminUser) {
                    MasterGlossaryBrandsModel.OriginalUserId = null;
                }
                else {
                    MasterGlossaryBrandsModel.OriginalUserId = $scope.adminUser.UserId
                }

                ProjectMaster.autoSaveGlossaryBrands(MasterGlossaryBrandsModel, function (autoSaveResult) {
                    $scope.showLoader = false;
                });
            }
            else {
                $scope.showLoader = false;
            }
        }
    };

   /**
     * @ngdoc
     * @name getAllSectionsCategory
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called on click of edit info columns button.This method is used to show/reset section categories popup
     * @return {undefined} This method does not return.
     */
    $scope.getAllSectionsCategory = function () {
        $scope.selectedSectionsList = [];
        $scope.categoriesAll = [];
        //Service call to update the model to show all categories in the project
        ProjectMaster.getCategoriesAndHeaderList(projectId, $scope.sectionType, function (projectMasterJson) {
            angular.copy(projectMasterJson.ProjectCategories, $scope.categoriesAll);
            angular.copy(projectMasterJson.ProjectHeaders, $scope.unselectedSectionsList);
            $scope.ProjectNonAssignedSections = projectMasterJson.Sections.ProjectNonAssignedSections;
            if (projectMasterJson.ProjectCategories.length > 0) {
                $('#addCategoriesToAllSection').modal('show');
            }
            else {
                $scope.errorMessage = 'There are no additional information options assigned to this project.';
                $('#errorModal').modal('show');
                return false;
            }
        });
    };


    /**
     * @ngdoc
     * @name saveSectionsCategories
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called on click of Apply button edit info columns popup .This method is used to edit Categories for selected sections
     * @return {undefined} This method does not return.
     */
    $scope.saveSectionsCategories = function (index) {
        if ($scope.selectedSectionsList.length < 1 || (CategoryAdded.length < 1 && CategoryRemoved.length < 1)) {
            $scope.categoryValidationMsgShow = true;
            return false;
        } else {
            $scope.categoryValidationMsgShow = false;
        }

        var originaluser;
        if (!$scope.adminUser) {
            originaluser = null;
        }
        else {
            originaluser = $scope.adminUser.UserId
        }
        //convert data from object to list
        var CategoryAddedIds = [];
        var CategoryRemovedIds = [];
        var SelectedSectionIds = [];
        for (i = 0; i < CategoryAdded.length; i++) {
            CategoryAddedIds.push(CategoryAdded[i].ProjectCategoryId);
        }
        for (i = 0; i < CategoryRemoved.length; i++) {
            CategoryRemovedIds.push(CategoryRemoved[i].ProjectCategoryId);
        }
        for (i = 0; i < $scope.selectedSectionsList.length; i++) {
            SelectedSectionIds.push($scope.selectedSectionsList[i].Id);
        }
        //send the category info to server
        ProjectMaster.saveSectionsCategoryList(projectId, SelectedSectionIds, CategoryAddedIds, CategoryRemovedIds, userDetails.UserId, originaluser, function (status) {
            $scope.showLoader = false;
            $('#addCategoriesToAllSection').modal('hide');
            $('.modal-backdrop.fade.in').css('display', 'none');
            $route.reload();
        });
    };

      /**
     * @ngdoc
     * @name addSectionsCategories
     * @methodOf Projects.controller:ProjectMasterController
     * @param {object} category This is category to be added.
     * @description
     * This method is called on click of add radio button edit info columns popup .This method is used to add section categories
     * @return {undefined} This method does not return.
     */
    $scope.addSectionsCategories = function (category) {
        var addFlag = false;
        if (CategoryAdded.length === 0) {
            CategoryAdded.push(category);
        }
        else {
            for (var i = 0; i < CategoryAdded.length; i++) {
                if (CategoryAdded[i].CategoryId === category.CategoryId) {
                    addFlag = true;
                    return false;
                }
            }
            if (!addFlag) {
                CategoryAdded.push(category);
            }

        }
        for (i = 0; i < CategoryRemoved.length; i++) {
            if (CategoryRemoved[i].CategoryId === category.CategoryId) {
                CategoryRemoved.splice(i, 1);
            }
        }
    };

         /**
     * @ngdoc
     * @name removeSectionsCategories
     * @methodOf Projects.controller:ProjectMasterController
     * @param {object} category This is category to be removed.
     * @description
     * This method is called on click of remove radio button edit info columns popup .This method is used to remove section categories
     * @return {undefined} This method does not return.
     */
    $scope.removeSectionsCategories = function (category) {
        var removeFlag = false;
        if (CategoryRemoved.length === 0) {
            CategoryRemoved.push(category);
        }
        else {
            for (var i = 0; i < CategoryRemoved.length; i++) {
                if (CategoryRemoved[i].CategoryId === category.CategoryId) {
                    removeFlag = true;
                    return false;
                }
            }
            if (!removeFlag) {
                CategoryRemoved.push(category);
            }
        }

        for (i = 0; i < CategoryAdded.length; i++) {
            if (CategoryAdded[i].CategoryId === category.CategoryId) {
                CategoryAdded.splice(i, 1);
            }
        }
    };

    //function to add new section only after the records are saved for the selected section
    $scope.confirmSaveRecordsToAddNewSection = function () {
        addNewSectionBtnClicked = true;
        $scope.isRecordDisplayed = false;
        //Mandatory Validations
        if (!$scope.displayingSelectedGroup[0].HeaderText) {
            $scope.errorMessage = '';
            $scope.errorMessage = 'Please enter the Section Text and Save';
            $('#errorModal').modal('show');
            return false;
        }
        if (!$scope.displayingSelectedGroup[0].MasterGlossaries[0].MasterText) {
            $scope.errorMessage = '';
            $scope.errorMessage = 'Please enter the Master Term for the section';
            $('#errorModal').modal('show');
            return false;
        }
        //call update function to update the records
        if (isUpdateTableChanged) {
            $scope.updateHeaderText($scope.displayingSelectedGroup[0], $scope.displayingSelectedGroup[0].HeaderText, $scope.displayingSelectedGroup[0].IsSecret);
            $scope.displayingSelectedGroup = [];
            $scope.headers = [];
            insertTableInUI();
        }
        else {
            $scope.displayingSelectedGroup = [];
            $scope.headers = [];
            insertTableInUI();
        }
    };

    $scope.disableAddNewSectionbuttonClickFlag = function () {
        addNewSectionBtnClicked = false;
        isUpdateTableChanged = false;
        $scope.isRecordDisplayed = false;
    };

    /* Auto Save functionality starts */

       /**
     * @ngdoc
     * @name saveCategoryInfo
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Object} rowData This is object contains all the data of selected row.
     * @param {object} category This is category on which updating is done.
     * @param {number} glossaryGroupId This is section id.
     * @description
     * This method is used to save the category information on lost focus of category text area
     * @return {undefined} This method does not return.
     */
    $scope.saveCategoryInfo = function (rowData, category, glossaryGroupId) {
        $scope.lockInput = true;
        MasterGlossaryCategoryModel.ProjectId = projectId;
        //MasterGlossaryCategoryModel.GlossaryGroupId = glossaryGroupId;
        MasterGlossaryCategoryModel.ProjectCategoryData = category;
        MasterGlossaryCategoryModel.MasterGlossaryId = rowData.MasterGlossaryId;
        MasterGlossaryCategoryModel.UserId = userDetails.UserId;
        MasterGlossaryCategoryModel.RowVersion = category.RowVersion;
        MasterGlossaryCategoryModel.GlossaryAddedBrands = rowData.GlossaryAddedBrands;
        if (!$scope.adminUser) {
            MasterGlossaryCategoryModel.OriginalUserId = null;
        }
        else {
            MasterGlossaryCategoryModel.OriginalUserId = $scope.adminUser.UserId
        }
        $scope.showLoader = true;
        ProjectMaster.autoSaveCategoryInfo(MasterGlossaryCategoryModel, function (autoSaveResult) {
            autoSaveAfterSequenceChanged(glossaryGroupId, rowData);
            $scope.lockInput = false; //GLMGR-956
        });
    };

    $scope.restoreMasterTextInfo = function (rowData, glossaryGroupId, tableID, rowID) {
        if ($scope.selectedGroup !== undefined) {
            checkSectionStatus();
            ProjectMaster.checkSectionStatus(objSectionStatus, function (status) {
                if (status) {
                    $('#sectionStatePopup').modal({ backdrop: 'static', keyboard: false });
                    $('#sectionStatePopup').modal('show');
                } else {
                    $scope.reloadAfterRestoreMasterTextInfoFunction = true;
                    var IsRestoredFlag = true;
                    $scope.saveMasterTextInfo(rowData, glossaryGroupId, tableID, rowID, IsRestoredFlag);
                }
            })
        }
    };

    //Auto save master text info
    
    /**
     * @ngdoc
     * @name saveMasterTextInfo
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Object} rowData This is object contains all the data of selected row.
     * @param {number} glossaryGroupId This is section id.
     * @param {number} tableID This is section table index.
     * @param {number} rowID This is row index.
     * @param {boolean} IsRestoredFlag This is boolean value  to set IsRestoredFlag flag.
     * @description
     * This method is used to auto save master text info
     * @return {undefined} This method does not return.
     */
    $scope.saveMasterTextInfo = function (rowData, glossaryGroupId, tableID, rowID, IsRestoredFlag) {
        if ($scope.selectedGroup !== undefined) {
            checkSectionStatus();
            ProjectMaster.checkSectionStatus(objSectionStatus, function (status) {
                if (status) {
                    $('#sectionStatePopup').modal({ backdrop: 'static', keyboard: false });
                    $('#sectionStatePopup').modal('show');
                } else {
                    $scope.rowDataForCancelClick = rowData; //GLMGR-956
                    $scope.glossaryGroupIdForCancelClick = glossaryGroupId; //GLMGR-956
                    $scope.tableID = tableID; 
                    $scope.rowID = rowID; 
                    $scope.lockInput = true;
                    IsMasterTermUpdated = false;
                    var AutoSaveMasterTermModel = {};
                    AutoSaveMasterTermModel.ProjectBrandIds = [];
                    AutoSaveMasterTermModel.BrandIds = [];
                    if (!rowData.MasterText) {
                        $scope.lockInput = false;
                        masterTextBoxEnteredFlag = true;
                        $scope.errorMessage = '';
                        $scope.errorMessage = 'Please enter the Master Term for the section';
                        $('#errorModal').modal({ backdrop: 'static', keyboard: false });
                        $('#errorModal').modal('show');
                        return false;
                    }

                    AutoSaveMasterTermModel.ProjectId = projectId;
                    AutoSaveMasterTermModel.GlossaryGroupId = glossaryGroupId;
                    AutoSaveMasterTermModel.MasterText = rowData.MasterText.trim();
                    AutoSaveMasterTermModel.MasterGlossaryId = rowData.MasterGlossaryId;
                    AutoSaveMasterTermModel.UpdatedByUserId = userDetails.UserId;
                    AutoSaveMasterTermModel.IsStarred = rowData.IsStarred;
                    AutoSaveMasterTermModel.RowVersion = rowData.RowVersion;
                    AutoSaveMasterTermModel.sectionType = $scope.sectionType;
                    AutoSaveMasterTermModel.IsSectionUnlock = $scope.selectedGroup.IsSectionUnlock;
                    AutoSaveMasterTermModel.IsSectionComplete = $scope.selectedGroup.IsSectionComplete;
                    AutoSaveMasterTermModel.IsRestored = IsRestoredFlag;
                    var originaluser;
                    if (!$scope.adminUser) {
                        originaluser = null;
                    }
                    else {
                        originaluser = $scope.adminUser.UserId
                    }
                    AutoSaveMasterTermModel.OriginalUserId = originaluser;

                    for (var i = 0; i < rowData.GlossaryAddedBrands.length; i++) {
                        AutoSaveMasterTermModel.ProjectBrandIds.push(rowData.GlossaryAddedBrands[i].ProjectBrandId);
                        if (rowData.GlossaryAddedBrands[i].BrandId) {
                            AutoSaveMasterTermModel.BrandIds.push(rowData.GlossaryAddedBrands[i].BrandId);
                        } else {
                            AutoSaveMasterTermModel.BrandIds.push(rowData.GlossaryAddedBrands[i].Id);
                        }
                    }
                    $scope.showLoader = true;
                    $scope.AutoSaveMasterTermModelCopy = angular.copy(AutoSaveMasterTermModel);

                    //GLMGR-960 starred term implementation
                    if ($scope.sectionType === 1) {
                        ProjectMaster.CheckStarredTerm(AutoSaveMasterTermModel, function (autoSaveResult) {
                            if (autoSaveResult.Result.toLowerCase().trim() === duplicateTermValidationMsg.toLowerCase().trim()) {
                                $scope.lockInput = false;
                                masterTextBoxEnteredFlag = true;
                                $scope.errorMessage = 'This term already exists within this section of the glossary.';
                                $('#duplicateTermDefaultSection').modal({ backdrop: 'static', keyboard: false });
                                $('#duplicateTermDefaultSection').modal('show');
                                $scope.showLoader = false;
                                return false;
                            } else if (autoSaveResult.Result.toLowerCase().trim() === duplicateRemovedTermValidationMsg.toLowerCase().trim()) {
                                $scope.lockInput = false;
                                masterTextBoxEnteredFlag = true;
                                $scope.errorMessage = '';
                                $('#duplicateErrorMessage').html('Duplicate term detected.<br/> This term already exists in this section but was previously removed.<br/> To add back the original term: <br/> Click "Show removed terms" and then press the "restore" button on that term.');
                                $('#duplicateTermDefaultSection').modal({ backdrop: 'static', keyboard: false });
                                $('#duplicateTermDefaultSection').modal('show');
                                $scope.showLoader = false;
                                return false;
                            }
                            else {
                                if (autoSaveResult.Result === 'DuplicateNo') {
                                    AutoSaveMasterTermModel.IsStarred = false;
                                    rowData.IsStarred = false;
                                } else {
                                    AutoSaveMasterTermModel.IsStarred = true;
                                    rowData.IsStarred = true;
                                }
                                ProjectMaster.autoSaveMasterTerm(AutoSaveMasterTermModel, function (autoSaveResult) {
                                    //unlock section mode-- reload page if term is updated/added
                                    if ($scope.selectedGroup.IsSectionComplete === false && $scope.selectedGroup.IsSectionUnlock === true && autoSaveResult.Result === 'Master Glossary Updated Successfully in unlock mode') {
                                        if (isNaN(rowData.MasterGlossaryVersion)) {
                                            rowData.MasterGlossaryVersion = 0;
                                        }
                                        rowData.MasterGlossaryVersion++;
                                        rowData.IsSuggestionExist = true;
                                    }
                                    autoSaveAfterSequenceChanged(glossaryGroupId, rowData);
                                    $scope.lockInput = false;
                                    $scope.OnlyIsRemovedTerms = false; //show section complete button
                                    if ($scope.reloadAfterRestoreMasterTextInfoFunction) {
                                        $scope.reloadAfterRestoreMasterTextInfoFunction = false;
                                        $scope.showRemovedTerms = commonService.getSessionData('isShowRemovedTermsFlag');
                                        $scope.reviewModeStored = true;
                                        sessionStorage.setItem('reviewModeStored', $scope.reviewModeStored);
                                        $scope.reloadSection();
                                    }
                                });
                            }
                        });
                    }
                    //GLMGR-758 Allow Duplicates in NTL section; GLMGR-960 starred term implementation
                    if ($scope.sectionType === 2) {
                        ProjectMaster.CheckStarredTerm(AutoSaveMasterTermModel, function (autoSaveResult) {
                            if (autoSaveResult.Result === 'DuplicateNo') {
                                AutoSaveMasterTermModel.IsStarred = false;
                                rowData.IsStarred = false;
                            } else {
                                AutoSaveMasterTermModel.IsStarred = true;
                                rowData.IsStarred = true;
                            }
                            ProjectMaster.autoSaveMasterTerm(AutoSaveMasterTermModel, function (autoSaveResult) {
                                //unlock section mode-- update version when term is add/updated
                                if ($scope.selectedGroup.IsSectionComplete === false && $scope.selectedGroup.IsSectionUnlock === true && autoSaveResult.Result === 'Master Glossary Updated Successfully in unlock mode') {
                                    if (isNaN(rowData.MasterGlossaryVersion)) {
                                        rowData.MasterGlossaryVersion = 0;
                                    }
                                    rowData.MasterGlossaryVersion++;
                                    rowData.IsSuggestionExist = true;
                                }
                                autoSaveAfterSequenceChanged(glossaryGroupId, rowData);
                                $scope.lockInput = false;
                                $scope.OnlyIsRemovedTerms = false; //show section complete button
                                if ($scope.reloadAfterRestoreMasterTextInfoFunction) {
                                    $scope.reloadAfterRestoreMasterTextInfoFunction = false;
                                    $scope.showRemovedTerms = commonService.getSessionData('isShowRemovedTermsFlag');
                                    $scope.reviewModeStored = true;
                                    sessionStorage.setItem('reviewModeStored', $scope.reviewModeStored);
                                    $scope.reloadSection();
                                }
                            });
                        });
                    }
                }
            })
        } 
    };

    //GLMGR-956
    var cancelSectionClickedFunction = function () {
        if (cancelSectionClicked === true && $scope.IsSectionCompleteReminderFlag) {
            $('#sectionCompleteReminder').modal({ backdrop: 'static', keyboard: false });
            $('#sectionCompleteReminder').modal('show');
        }
    };

     /**
     * @ngdoc
     * @name autoSaveAfterSequenceChanged
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Object} rowData This is object contains all the data of selected row.
     * @param {number} glossaryGroupId This is section id.
     * @description
     * This method is used to auto save after sequence changed
     * @return {undefined} This method does not return.
     */
    var autoSaveAfterSequenceChanged = function (glossaryGroupId, rowData) {
        if (rowData) {
            if (!rowData.MasterText && $scope.reviewMode === false) {
                $scope.errorMessage = '';
                $scope.errorMessage = 'Please enter the Master Term for the section';
                $('#errorModal').modal('show');
                $scope.showLoader = false;
                return false;
            }
        }
        if ($scope.reviewMode === true && !rowData.SuggestedText) {
            $scope.errorMessage = '';
            $scope.errorMessage = 'Please enter the Suggestion Term for the section';
            $('#errorModal').modal('show');
            $scope.showLoader = false;
            return false;
        }
        var masterGlossarySequence = [];
        //creating an array of changed sequence of Master Glossary Ids (rows)
        if ($scope.displayingSelectedGroup.length > 0) {
            for (var i = 0; i < $scope.displayingSelectedGroup[0].MasterGlossaries.length; i++) {
                masterGlossarySequence.push($scope.displayingSelectedGroup[0].MasterGlossaries[i].MasterGlossaryId);
            }
        } else {
            for (var i = 0; i < $scope.ProjectMasterJson.TableData.length; i++) {
                if ($scope.ProjectMasterJson.TableData[i].ProjectHeaderId === glossaryGroupId) {
                    for (var j = 0; j < $scope.ProjectMasterJson.TableData[i].MasterGlossaries.length; j++) {
                        masterGlossarySequence.push($scope.ProjectMasterJson.TableData[i].MasterGlossaries[j].MasterGlossaryId);
                    }
                    break;
                }
            }
        }
        var SourceSetupSequence = {};
        SourceSetupSequence.GlossaryGroupId = glossaryGroupId;
        SourceSetupSequence.MasterGlossaryId = masterGlossarySequence.toString();
        SourceSetupSequence.UserId = userDetails.UserId;

        if (!$scope.adminUser) {
            SourceSetupSequence.OriginalUserId = null;
        }
        else {
            SourceSetupSequence.OriginalUserId = $scope.adminUser.UserId
        }

        ProjectMaster.autoSaveRowSequence(SourceSetupSequence, function (autoSaveResult) {
            $scope.lockInput = false; //GLMGR-956
            $scope.showLoader = false;
        });
    };

    /**
     * @ngdoc
     * @name autoSaveTermImage
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Object} myData This is object contains all the data of file.
     * @description
     * This method is used to auto save for term images
     * @return {undefined} This method does not return.
     */
    var autoSaveTermImage = function (myData) {
        var ImageUploadMasterTermModel = {
            TermImage: {}
        };

        ImageUploadMasterTermModel.MasterGlossaryId = masterGlossaryIdForImage;
        ImageUploadMasterTermModel.presentUserId = userDetails.UserId;
        ImageUploadMasterTermModel.ProjectId = projectId;
        ImageUploadMasterTermModel.GlossaryGroupId = projectHeaderIdForImage;
        ImageUploadMasterTermModel.TermImage.FileName = myData[0].filename;
        ImageUploadMasterTermModel.TermImage.Filesize = myData[0].filesize;
        ImageUploadMasterTermModel.TermImage.Filetype = myData[0].filetype;
        ImageUploadMasterTermModel.TermImage.Filedata = myData[0].filedata;
        ImageUploadMasterTermModel.TermImage.Fileext = myData[0].fileext;

        if (!$scope.adminUser) {
            ImageUploadMasterTermModel.OriginalUserId = null;
        }
        else {
            ImageUploadMasterTermModel.OriginalUserId = $scope.adminUser.UserId
        }
        $scope.showLoader = true;

        ProjectMaster.autoSaveTermImage(ImageUploadMasterTermModel, function (autoSaveResult) {
            if ($scope.ProjectMasterJson.TableData.length > 0) {
                for (var i = 0; i < $scope.ProjectMasterJson.TableData[myData[0].sectionIndex].MasterGlossaries.length; i++) {
                    if ($scope.ProjectMasterJson.TableData[myData[0].sectionIndex].MasterGlossaries[i].MasterText) {
                        if (myData[0].mastertext.trim().toLowerCase() === $scope.ProjectMasterJson.TableData[myData[0].sectionIndex].MasterGlossaries[i].MasterText.trim().toLowerCase()) {
                            $scope.ProjectMasterJson.TableData[myData[0].sectionIndex].MasterGlossaries[i].isAddedImageDetails = true;
                            $scope.ProjectMasterJson.TableData[myData[0].sectionIndex].MasterGlossaries[i].TermImage = myData[0];
                        }
                    }
                }
                TermImage.push(myData[0]);
                $scope.showLoader = false;
            }
            else {
                for (var i = 0; i < $scope.displayingSelectedGroup[0].MasterGlossaries.length; i++) {
                    if (masterGlossaryIdForImage === $scope.displayingSelectedGroup[0].MasterGlossaries[i].MasterGlossaryId) {
                        $scope.displayingSelectedGroup[0].MasterGlossaries[i].isAddedImageDetails = true;
                        break;
                    }
                }
                TermImage.push(myData[0]);
                myData[0].MasterGlossaryId = masterGlossaryIdForImage;
            }
            isAddedImageDetails = true;
            autoSaveAfterSequenceChanged(projectHeaderIdForImage);
        });
    };

    /**
     * @ngdoc
     * @name proceedToTabChange
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is used to proceed on tab change 
     * @return {undefined} This method does not return.
     */
    $scope.proceedToTabChange = function () {
        $('#reviewCompleteReminderBeforeTabChange').modal('hide');
        $('.modal-backdrop.fade.in').css('display', 'none');
        $scope.reviewMode = false;
        $scope.isShowRemovedTerms = false;
        if ($scope.defaultSectionType) {
            $scope.ntlSection();
        } else {
            $scope.defaultSection();
        }

    };

    $scope.changeTableHeight = function () {
        sessionStorage.setItem('isShowRemovedTermsFlag', $scope.showRemovedTerms);
        dynamicScreenHeight();
    };

   /**
     * @ngdoc
     * @name hideInfoColumnsColumn
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is used to hide category column
     * @return {undefined} This method does not return.
     */
    $scope.hideInfoColumnsColumn = function () {
        sessionStorage.setItem('hideInfoColumns', $scope.hideInfoColumns);
        if ($scope.hideInfoColumns) {
            $scope.noOfCategories = 0;
        } else {
            $scope.noOfCategories = $scope.categories.length;
        }
    };

     /**
     * @ngdoc
     * @name hideTermUniqueIDColumn
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is used to hide unique id column
     * @return {undefined} This method does not return.
     */
    $scope.hideTermUniqueIDColumn = function () {
        sessionStorage.setItem('hideTermUniqueID', $scope.hideTermUniqueID);
        if ($scope.hideTermUniqueID) {
            $scope.modeWidth--;
        } else {
            $scope.modeWidth++;
        }
    };


    $scope.hideStarredColumnPopup = function () {
        if ($scope.hideStarred) {
            $scope.starredColFlag = false;
            for (var i = 0; i < $scope.displayingSelectedGroup[0].MasterGlossaries.length; i++) {
                if ($scope.displayingSelectedGroup[0].MasterGlossaries[i].IsRemoved === false && $scope.displayingSelectedGroup[0].MasterGlossaries[i].IsStarred === true) {
                    $scope.starredColFlag = true;
                    break;
                }
            }
            if ($scope.starredColFlag) {
                $('#hideStarredColumnPopup').modal({ backdrop: 'static', keyboard: false });
                $('#hideStarredColumnPopup').modal('show');
            } else {
                $scope.hideStarredColumn();
            }
        } else {
            $scope.hideStarredColumn();
        }
    };

    $scope.donthideStarredColumn = function () {
        $scope.hideStarred = false;
        $('#hideStarredColumnPopup').modal('hide');
    };

    /**
     * @ngdoc
     * @name hideStarredColumn
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is used to hide starred term column
     * @return {undefined} This method does not return.
     */
    $scope.hideStarredColumn = function () {
        sessionStorage.setItem('hideStarred', $scope.hideStarred);
        $('#hideStarredColumnPopup').modal('hide');
        if ($scope.hideStarred) {
            $scope.ishideStarred = true;
            $scope.modeWidth--;
        } else {
            $scope.ishideStarred = false;
            $scope.modeWidth++;
        }
        sessionStorage.setItem('ishideStarred', $scope.ishideStarred);
    };

        /**
     * @ngdoc
     * @name clearSourceSetupFilters
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is used to clear filters, session values are cleared
     * @return {undefined} This method does not return.
     */
    $scope.clearSourceSetupFilters = function () {// Not Used Keep for reference
        //below code is used in $scope.changeView() methods of landing page, edit project, glossary, translation, approval pages 
        sessionStorage.setItem('SourceSetupActiveSection', '');
        sessionStorage.setItem('isShowRemovedTermsFlag', '0');
        sessionStorage.setItem('hideInfoColumns', '0');
        sessionStorage.setItem('hideTermUniqueID', '0');
        sessionStorage.setItem('hideStarred', '0');
        sessionStorage.setItem('ishideStarred', '0');
    };

    /**
     * @ngdoc
     * @name getSourceSetupFilters
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is used to get filter values from session storage.
     * @return {undefined} This method does not return.
     */
    var getSourceSetupFilters = function () {
        $scope.hideInfoColumns = commonService.getSessionData('hideInfoColumns');
        $scope.hideTermUniqueID = commonService.getSessionData('hideTermUniqueID');
        $scope.hideStarred = commonService.getSessionData('hideStarred');
        $scope.ishideStarred = commonService.getSessionData('ishideStarred');
        $scope.showRemovedTerms = commonService.getSessionData('isShowRemovedTermsFlag');
    };

    /**
     * @ngdoc
     * @name defaultSection
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is used to open default section.This method is called on default tab click.
     * @return {undefined} This method does not return.
     */
    $scope.defaultSection = function () {
        $scope.errorHeaderText = false;
        if ($scope.reviewModeStored === false && $scope.IsSectionCompleteReminderFlag) {
            if (!$scope.displayingSelectedGroup[0].MasterGlossaries[0].MasterText) {
                $scope.errorMessage = '';
                $scope.errorMessage = 'Please enter the Master Term for the section. If you wish to add Master Term later, please click "Close" button at the bottom of the section.';
                $('#errorModal').modal('show');
                return false;
            }
            $scope.sectionCompleteGotoDefaultTab = true;
            $('#sectionCompleteReminder').modal({ backdrop: 'static', keyboard: false });
            $('#sectionCompleteReminder').modal('show');
        } else if ($scope.reviewMode && checkEmailFlagOnSuggestion()) {
            $('#reviewCompleteReminderBeforeTabChange').modal('show');
        } else {
            //sessionStorage.setItem('SourceSetupActiveSection', '');
            cancelSectionClickedFunction(); //GLMGR-956
            $scope.isShowRemovedTerms = false;
            $('.source-setup-new-table').hide();
            $scope.isSectionOpen = false;
            $scope.ProjectMasterJson.TableData.length = 0;
            $scope.defaultSectionType = true;
            $scope.ntlSectionType = false;
            $scope.modeWidth = 6;
            $scope.reviewMode = false;
            $scope.reviewModeSec = false;
            $scope.modeButtonText = 'Switch to Review Mode';
            $scope.sectionType = 1;
            sessionStorage.setItem('ActiveSectionType', $scope.sectionType);
            $scope.saveSectionButtonName = 'Save Section';
            $scope.saveSectionButtonNameTooltip = 'Save Section';
            $scope.updateSectionButtonName = 'Update Section Name';
            $scope.updateSectionButtonNameTooltip = 'Update Section Name';
            getHeaderListAndCategoryList();
        }
    };

    /**
     * @ngdoc
     * @name ntlSection
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is used to open NTL section.This method is called on NTL tab click.
     * @return {undefined} This method does not return.
     */
    $scope.ntlSection = function () {
        $scope.errorHeaderText = false;
        if ($scope.reviewModeStored === false && $scope.IsSectionCompleteReminderFlag) {
            if (!$scope.displayingSelectedGroup[0].MasterGlossaries[0].MasterText) {
                $scope.errorMessage = '';
                $scope.errorMessage = 'Please enter the Master Term for the section. If you wish to add Master Term later, please click "Close" button at the bottom of the section.';
                $('#errorModal').modal('show');
                return false;
            }
            $scope.sectionCompleteGotoNTLTab = true;
            $('#sectionCompleteReminder').modal({ backdrop: 'static', keyboard: false });
            $('#sectionCompleteReminder').modal('show');
        } else if ($scope.reviewMode && checkEmailFlagOnSuggestion()) {
            $('#reviewCompleteReminderBeforeTabChange').modal('show');
        } else {
            //sessionStorage.setItem('SourceSetupActiveSection', '');
            cancelSectionClickedFunction(); //GLMGR-956
            $scope.isShowRemovedTerms = false;
            $('.source-setup-new-table').hide();
            $scope.isSectionOpen = false;
            $scope.ProjectMasterJson.TableData.length = 0;
            $scope.selectedGroup = $scope.headers[0];
            $scope.defaultSectionType = false;
            $scope.ntlSectionType = true;
            $scope.modeWidth = 6;
            $scope.reviewMode = false;
            $scope.reviewModeSec = false;
            $scope.modeButtonText = 'Switch to Review Mode';
            $scope.sectionType = 2;
            sessionStorage.setItem('ActiveSectionType', $scope.sectionType);
            $scope.saveSectionButtonName = 'Create as NTL/FD Section';
            $scope.saveSectionButtonNameTooltip = 'Create as Narrative Title List/Foreign Dialogue';
            $scope.updateSectionButtonName = 'Update Section Name: NTL/FD Section';
            $scope.updateSectionButtonNameTooltip = 'Update Section Name: Narrative Title List/Foreign Dialogue';
            getHeaderListAndCategoryList();
        }

    };

    $scope.dissmissDuplicatePopup = function () {
        $scope.lockInput = false;
        $scope.showLoader = false;
        masterTextBoxEnteredFlag = false;
    };

    /**
     * @ngdoc
     * @name changeSectionType
     * @methodOf Projects.controller:ProjectMasterController
     * @param {String} SectionSubType This is string to which section is need to migrated (NTL/FD).  
     * @param {Number} rowIndex This is index of row in section list table on popup
     * @description
     * This method is used to change section type on section migration popup.This is called on click of radio buttons.
     * @return {undefined} This method does not return.
     */
    $scope.changeSectionType = function (rowIndex, SectionSubType) {

        var sectionChangeFlag = false;
        if (SectionSubType === 'NTL') {
            $scope.headerstoMigrate[rowIndex].SectionType = 2;
            $scope.headerstoMigrate[rowIndex].SectionSubType = 1;
        } else if (SectionSubType === 'FD') {
            $scope.headerstoMigrate[rowIndex].SectionType = 2;
            $scope.headerstoMigrate[rowIndex].SectionSubType = 2;
        } else {
            $scope.headerstoMigrate[rowIndex].SectionType = 1;
            $scope.headerstoMigrate[rowIndex].SectionSubType = 0;
        }

        //no NTL/FD selected
        for (var i = 0; i < $scope.headerstoMigrate.length; i++) {
            if ($scope.headerstoMigrate[i].SectionType === 2) {
                var sectionChangeFlag = true;
                break;
            }
        }

        if (!sectionChangeFlag) {
            $scope.submitMigrationError = true;
            $scope.submitMigrationButton = true;
        } else {
            $scope.submitMigrationError = false;
            $scope.submitMigrationButton = false;
        }
    };

    //submitMigration
    $scope.submitMigration = function () {
        $('#saveDefaultToNTL').modal('show');
    };

     /**
     * @ngdoc
     * @name cancelMigration
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is used to cancel section migration.
     * @return {undefined} This method does not return.
     */
    $scope.cancelMigration = function () {
        for (var i = 0; i < $scope.headerstoMigrate.length; i++) {
            $scope.headerstoMigrate[i].SectionType = 1;
            $scope.headerstoMigrate[i].SectionSubType = 0;
        }
        $scope.submitMigrationError = false;
        $scope.submitMigrationButton = true;
        init();
    };

       /**
     * @ngdoc
     * @name saveMigration
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is used to save section migration.
     * @return {undefined} This method does not return.
     */
    $scope.saveMigration = function () {
        $('#saveDefaultToNTL').modal('hide');
        for (var i = 0; i < $scope.headerstoMigrate.length; i++) {
            if ($scope.headerstoMigrate[i].SectionSubType === 1) {
                $scope.headerstoMigrate[i].SectionName = 'NTL - ' + $scope.headerstoMigrate[i].GlossaryGroupHeader;
            }
            if ($scope.headerstoMigrate[i].SectionSubType === 2) {
                $scope.headerstoMigrate[i].SectionName = 'FD - ' + $scope.headerstoMigrate[i].GlossaryGroupHeader;
            }
        }

        $scope.headerstoMigrateToNTL = [];
        for (var i = 0; i < $scope.headerstoMigrate.length; i++) {
            if ($scope.headerstoMigrate[i].SectionType === 2) {
                $scope.headerstoMigrateToNTL.push($scope.headerstoMigrate[i]);
            }
        }
        $scope.showLoader = true;
        //Serivce to MIgrate Default to NTL
        ProjectMaster.ConvertDefaultSectionToNTLSection($scope.headerstoMigrateToNTL, projectId, function (status) {
            if (status.Result) {
                $scope.successMessage = "Default Section(s) is(are) successfully migrated to NTL Section Tab.";
            } else if (!status.Result && status.ResultMessage) {
                $scope.successMessage = status.ResultMessage;
            }
            $('#saveNewTableModal .modal-title').html('Migration Message');
            $('#saveNewTableModal').modal('show');
            $scope.showLoader = false;
            $scope.submitMigrationError = false;
            $scope.submitMigrationButton = true;
            init();
        });

    };

    //cancelSaveMigration
    $scope.cancelSaveMigration = function () {
        $('#saveDefaultToNTL').modal('hide');
        $('#migrateDefaultToNTL').modal('show');
    };

    $scope.closeReviewMode = function () {
        $('#reviewCompleteReminder').modal('hide');
        $scope.reviewMode = false;
        $scope.modeWidth = 6;
        $scope.modeButtonText = 'Switch to Review Mode';
        $scope.showSelectedGroups($scope.reviewModeSection);
    };

    var checkEmailFlagOnSuggestion = function () {
        var emailNotSentflag = false;
        for (var i = 0; i < $scope.displayingSelectedGroup[0].MasterGlossaries.length; i++) {
            var x = $scope.displayingSelectedGroup[0].MasterGlossaries[i];
            if (((x.SuggestionType === 'Suggested Text Update' && x.SuggestedText !== "") || x.SuggestionType === 'Suggested Addition to Section' || x.SuggestionType === 'Suggested Term to Remove' || x.SuggestionType === 'Suggested Term to Restore') && x.IsEmailSent !== true) emailNotSentflag = true;
        }
        return emailNotSentflag;
    };

        /**
     * @ngdoc
     * @name switchMode
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is used to switch mode (default/review)
     * @return {undefined} This method does not return.
     */
    $scope.switchMode = function () {

        if ($scope.selectedGroup !== undefined) {
            checkSectionStatus();
            ProjectMaster.checkSectionStatus(objSectionStatus, function (status) {
                if (status) {
                    $('#sectionStatePopup').modal({ backdrop: 'static', keyboard: false });
                    $('#sectionStatePopup').modal('show');
                } else {
                    if ($scope.reviewMode) {
                        if (checkEmailFlagOnSuggestion()) {
                            $('#reviewCompleteReminder').modal({ backdrop: 'static', keyboard: false });
                            $('#reviewCompleteReminder').modal('show');
                        } else {
                            $scope.reviewMode = false;
                            $scope.modeWidth = 6;
                            $scope.modeButtonText = 'Switch to Review Mode';
                            $scope.reviewPanelDialog = false;
                            $scope.showSelectedGroups($scope.reviewModeSection);
                        }
                    } else {
                        $scope.reviewMode = true;
                        $scope.reviewModeSec = true;
                        $scope.modeWidth = 9;
                        $scope.modeButtonText = 'Switch to Default Mode';
                        $scope.IsSectionCompleteReminderFlag = false;
                        sessionStorage.setItem('IsSectionCompleteReminderFlag', $scope.IsSectionCompleteReminderFlag);
                        $scope.showSelectedGroups($scope.reviewModeSection);
                    }
                }
            })
        } 
    };
     
       /**
     * @ngdoc
     * @name reviewModeSuggText
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Object} rowData This is object contains all the data of selected row.
     * @description
     * This method is called on blur of suggestion text box in review mode
     * @return {undefined} This method does not return.
     */
    $scope.reviewModeSuggText = function (rowData) {

        if ($scope.selectedGroup !== undefined) {
            checkSectionStatus();
	        ProjectMaster.checkSectionStatus(objSectionStatus, function (status) {
		        if (status) {
			        $('#sectionStatePopup').modal({ backdrop: 'static', keyboard: false });
			        $('#sectionStatePopup').modal('show');
		        } else {
		            var originaluser;
                    if (!$scope.adminUser) {
                        originaluser = null;
                    }
                    else {
                        originaluser = $scope.adminUser.UserId
                    }
                    $scope.lockInput = true;
                    $scope.showLoader = true;
                    if (!rowData.SuggestedText) {
                        rowData.SuggestedText = rowData.OriginalSuggestedText;
                        if ($scope.reviewPanelDialog === true) {
                            $scope.errorPop = true;
                            $scope.errorPopMsg = "Empty Sugesstion is not allowed."
                            $timeout(function () {
                                $scope.errorPop = false;
                            }, 3000);
                            $scope.lockInput = false;
                        } else {
                            $scope.emptySuggestionMessage = 'Empty Sugesstion is not allowed.';
                            $('#emptyTermSuggPopup').modal({ backdrop: 'static', keyboard: false });
                            $('#emptyTermSuggPopup').modal('show');
                        }
                        $scope.showLoader = false;
                        return false;
                    }
                    if (rowData.OriginalSuggestedText) {
                        if (rowData.SuggestedText.toLowerCase().trim() === rowData.OriginalSuggestedText.toLowerCase().trim()) {
                            $scope.lockInput = false;
                            $scope.showLoader = false;
                            return false;
                        }
                    }
                    if ($scope.sectionType === 1) {
                        for (var i = 0; i < $scope.displayingSelectedGroup[0].MasterGlossaries.length; i++) {
                            if ($scope.displayingSelectedGroup[0].MasterGlossaries[i].MasterText) {
                                if ($scope.displayingSelectedGroup[0].MasterGlossaries[i].MasterText.toLowerCase().trim() === rowData.SuggestedText.toLowerCase().trim() && $scope.displayingSelectedGroup[0].MasterGlossaries[i].IsRemoved === true) {
                                    $scope.lockInput = false;
                                    $scope.errorMessage = '';
                                    $('#duplicateErrorMessage').html('Duplicate term detected.<br/> This term already exists in this section but was previously removed.<br/> To add back the original term: <br/> Click "Show removed terms" and then press the "restore" button on that term.');
                                    $('#duplicateTermDefaultSection').modal('show');
                                    $scope.showLoader = false;
                                    rowData.SuggestedText = '';
                                    return false;
                                }
                            }

                            if ($scope.displayingSelectedGroup[0].MasterGlossaries[i].MasterGlossaryId !== rowData.MasterGlossaryId) {
                                if ($scope.displayingSelectedGroup[0].MasterGlossaries[i].SuggestedText) {
                                    if (rowData.SuggestedText.toLowerCase().trim() === $scope.displayingSelectedGroup[0].MasterGlossaries[i].SuggestedText.toLowerCase().trim()) {
                                        if ($scope.reviewPanelDialog === true) {
                                            $scope.errorPop = true;
                                            $scope.errorPopMsg = "Duplicate Sugesstion is not allowed in default section";
                                            $timeout(function () {
                                                $scope.errorPop = false;
                                            }, 3000);
                                            $scope.lockInput = false;
                                            $scope.showLoader = false;
                                        } else {
                                            $scope.errorMessage = 'This term already exists within this section of the glossary.';
                                            $('#duplicateTermDefaultSection').modal('show');
                                        }

                                        rowData.SuggestedText = rowData.OriginalSuggestedText;
                                        $scope.showLoader = false;
                                        return false;
                                    }
                                }
                                if ($scope.displayingSelectedGroup[0].MasterGlossaries[i].MasterText) {
                                    if (rowData.SuggestedText.toLowerCase().trim() === $scope.displayingSelectedGroup[0].MasterGlossaries[i].MasterText.toLowerCase().trim()) {
                                        if ($scope.reviewPanelDialog === true) {
                                            $scope.errorPop = true;
                                            $scope.errorPopMsg = "Duplicate Sugesstion is not allowed in default section"
                                            $timeout(function () {
                                                $scope.errorPop = false;
                                            }, 3000);
                                            $scope.lockInput = false;
                                            $scope.showLoader = false;
                                        } else {
                                            $scope.errorMessage = 'This term already exists within this section of the glossary.';
                                            $('#duplicateTermDefaultSection').modal('show');
                                        }

                                        rowData.SuggestedText = rowData.OriginalSuggestedText;
                                        $scope.showLoader = false;
                                        return false;
                                    }

                                }
                            }
                        }
                    }
                    ProjectMaster.suggestedTextAutoSave(rowData.MasterGlossaryId, rowData.SuggestedText, rowData.Comment, originaluser, function (status) {
                        for (var i = 0; i < $scope.displayingSelectedGroup[0].MasterGlossaries.length; i++) {
                            if ($scope.displayingSelectedGroup[0].MasterGlossaries[i].MasterGlossaryId === status.MasterGlossaryId) {
                                $scope.displayingSelectedGroup[0].MasterGlossaries[i].Comment = status.Comment;
                                $scope.displayingSelectedGroup[0].MasterGlossaries[i].SuggestedStatusId = status.SuggestedStatusId;
                                $scope.displayingSelectedGroup[0].MasterGlossaries[i].IsEmailSent = false;
                                $scope.displayingSelectedGroup[0].MasterGlossaries[i].SuggestedText = status.SuggestedText;
                                $scope.displayingSelectedGroup[0].MasterGlossaries[i].OriginalSuggestedText = status.SuggestedText;
                                rowData.OriginalSuggestedText = status.SuggestedText;
                                $scope.displayingSelectedGroup[0].MasterGlossaries[i].SuggestionType = status.SuggestedStatusInReviewMode;
                                $scope.displayingSelectedGroup[0].MasterGlossaries[i].IsSuggestionExist = false;
                                $scope.displayingSelectedGroup[0].MasterGlossaries[i].UpdatedDateString = status.SuggestionDateTime;
                                $scope.displayingSelectedGroup[0].MasterGlossaries[i].SuggestedUserName = status.UserName;
                                $scope.displayingSelectedGroup[0].MasterGlossaries[i].SuggestedUserEmailId = status.UserEmailId;
                                $scope.groupHeader = $scope.displayingSelectedGroup[0].ProjectHeaderId;
                                break;
                            }
                        }
                        if ($scope.reviewPanel.length > 0) {
                            for (var i = 0; i < $scope.reviewPanel.length; i++) {
                                if ($scope.reviewPanel[i].MasterGlossaryId === status.MasterGlossaryId) {
                                    $scope.reviewPanel[i].Comment = status.Comment;
                                    $scope.reviewPanel[i].SuggestedStatusId = status.SuggestedStatusId;
                                    $scope.reviewPanel[i].SuggestedText = status.SuggestedText;
                                    $scope.reviewPanel[i].SuggestionType = status.SuggestedStatusInReviewMode;
                                    $scope.reviewPanel[i].UpdatedDateString = status.SuggestionDateTime;
                                    $scope.reviewPanel[i].SuggestedUserName = status.UserName;
                                    $scope.reviewPanel[i].SuggestedUserEmailId = status.UserEmailId;
                                    break;
                                }
                            }
                        }

                        autoSaveAfterSequenceChanged($scope.groupHeader, rowData);
                        $scope.lockInput = false;
                        $scope.showLoader = false;

                    });
		        }
	        })
        }
        
    };

           /**
     * @ngdoc
     * @name reviewModeCommentText
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Object} rowData This is object contains all the data of selected row.
     * @description
     * This method is called on blur of comment text box in review mode
     * @return {undefined} This method does not return.
     */
    $scope.reviewModeCommentText = function (rowData) {

        if ($scope.selectedGroup !== undefined) {
	        checkSectionStatus();
	        ProjectMaster.checkSectionStatus(objSectionStatus, function (status) {
		        if (status) {
			        $('#sectionStatePopup').modal({ backdrop: 'static', keyboard: false });
			        $('#sectionStatePopup').modal('show');
		        } else {
		            $scope.lockInput = true;
                    $scope.showLoader = false;
                    var originaluser;
                    if (!$scope.adminUser) {
                        originaluser = null;
                    }
                    else {
                        originaluser = $scope.adminUser.UserId
                    }

                    ProjectMaster.commentTextAutoSave(rowData.MasterGlossaryId, rowData.SuggestedText, rowData.Comment, originaluser, function (status) {

                        for (var i = 0; i < $scope.displayingSelectedGroup[0].MasterGlossaries.length; i++) {
                            if ($scope.displayingSelectedGroup[0].MasterGlossaries[i].MasterGlossaryId === status.MasterGlossaryId) {
                                $scope.displayingSelectedGroup[0].MasterGlossaries[i].Comment = status.Comment;
                                $scope.displayingSelectedGroup[0].MasterGlossaries[i].SuggestedText = status.SuggestedText;
                                $scope.displayingSelectedGroup[0].MasterGlossaries[i].IsEmailSent = false;
                                $scope.displayingSelectedGroup[0].MasterGlossaries[i].UpdatedDateString = status.SuggestionDateTime;
                                $scope.displayingSelectedGroup[0].MasterGlossaries[i].SuggestedUserName = status.UserName;
                                $scope.displayingSelectedGroup[0].MasterGlossaries[i].SuggestedUserEmailId = status.UserEmailId;
                                $scope.groupHeader = $scope.displayingSelectedGroup[0].ProjectHeaderId;
                                break;
                            }
                        }
                        if ($scope.reviewPanel.length > 0) {
                            for (var i = 0; i < $scope.reviewPanel.length; i++) {
                                if ($scope.reviewPanel[i].MasterGlossaryId === status.MasterGlossaryId) {
                                    $scope.reviewPanel[i].Comment = status.Comment;
                                    $scope.reviewPanel[i].SuggestedStatusId = status.SuggestedStatusId;
                                    $scope.reviewPanel[i].SuggestedText = status.SuggestedText;
                                    $scope.reviewPanel[i].UpdatedDateString = status.SuggestionDateTime;
                                    $scope.reviewPanel[i].SuggestedUserName = status.UserName;
                                    $scope.reviewPanel[i].SuggestedUserEmailId = status.UserEmailId;

                                    break;
                                }
                            }
                        }
                        $scope.lockInput = false;
                        $scope.showLoader = false;
                    });
		        }
	        })
        }
    };

          /**
     * @ngdoc
     * @name reviewModeDelete
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Object} rowData This is object contains all the data of selected row.
     * @param {number} glossaryGroupId This is section id.
     * @param {number} tableID This is section table index.
     * @param {number} rowID This is row index.
     * 
     * @description
     * This method is called on delete row icon in review mode.this is used to delete whole row
     * @return {undefined} This method does not return.
     */
    $scope.reviewModeDelete = function (rowData, glossaryGroupId, tableID, rowID) {

        if ($scope.selectedGroup !== undefined) {
            checkSectionStatus();
            ProjectMaster.checkSectionStatus(objSectionStatus, function (status) {
                if (status) {
                    $('#sectionStatePopup').modal({ backdrop: 'static', keyboard: false });
                    $('#sectionStatePopup').modal('show');
                } else {
                    var originaluser;
                    if (!$scope.adminUser) {
                        originaluser = null;
                    }
                    else {
                        originaluser = $scope.adminUser.UserId
                    }
                    ProjectMaster.reviewModeDelete(rowData.MasterGlossaryId, originaluser, function (status) {
                        for (var i = 0; i < $scope.displayingSelectedGroup[0].MasterGlossaries.length; i++) {
                            if ($scope.displayingSelectedGroup[0].MasterGlossaries[i].MasterGlossaryId === status.MasterGlossaryId) {
                                if (status.MasterText === "Temp Data") {
                                    $scope.displayingSelectedGroup[0].MasterGlossaries.splice(i, 1);
                                } else {
                                    $scope.displayingSelectedGroup[0].MasterGlossaries[i].Comment = status.Comment;
                                    $scope.displayingSelectedGroup[0].MasterGlossaries[i].SuggestedStatusId = status.SuggestedStatusId;
                                    $scope.displayingSelectedGroup[0].MasterGlossaries[i].SuggestedText = status.SuggestedText;
                                    $scope.displayingSelectedGroup[0].MasterGlossaries[i].IsEmailSent = false;
                                    $scope.displayingSelectedGroup[0].MasterGlossaries[i].IsSuggestionExist = false;
                                    $scope.displayingSelectedGroup[0].MasterGlossaries[i].SuggestionType = status.SuggestedStatusInReviewMode;
                                    $scope.displayingSelectedGroup[0].MasterGlossaries[i].UpdatedDateString = status.SuggestionDateTime;
                                    $scope.displayingSelectedGroup[0].MasterGlossaries[i].SuggestedUserName = status.UserName;
                                    $scope.displayingSelectedGroup[0].MasterGlossaries[i].SuggestedUserEmailId = status.UserEmailId;
                                }
                                break;
                            }
                        }
                    });
                }
            })
        }
    };

    /**
     * @ngdoc
     * @name reviewModeRestore
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Object} rowData This is object contains all the data of selected row.
     * 
     * @description
     * This method is called on restore button in review mode to restore the deleted master term
     * @return {undefined} This method does not return.
     */
    $scope.reviewModeRestore = function (rowData) {
        if ($scope.selectedGroup !== undefined) {
            checkSectionStatus();
	        ProjectMaster.checkSectionStatus(objSectionStatus, function (status) {
		        if (status) {
			        $('#sectionStatePopup').modal({ backdrop: 'static', keyboard: false });
			        $('#sectionStatePopup').modal('show');
		        } else {
		            var originaluser;
                    if (!$scope.adminUser) {
                        originaluser = null;
                    }
                    else {
                        originaluser = $scope.adminUser.UserId
                    }
                    ProjectMaster.reviewModeRestore(rowData.MasterGlossaryId, originaluser, function (status) {
                        for (var i = 0; i < $scope.displayingSelectedGroup[0].MasterGlossaries.length; i++) {
                            if ($scope.displayingSelectedGroup[0].MasterGlossaries[i].MasterGlossaryId === status.MasterGlossaryId) {
                                $scope.displayingSelectedGroup[0].MasterGlossaries[i].Comment = status.Comment;
                                $scope.displayingSelectedGroup[0].MasterGlossaries[i].SuggestedStatusId = status.SuggestedStatusId;
                                $scope.displayingSelectedGroup[0].MasterGlossaries[i].SuggestedText = status.SuggestedText;
                                $scope.displayingSelectedGroup[0].MasterGlossaries[i].IsEmailSent = false;
                                $scope.displayingSelectedGroup[0].MasterGlossaries[i].IsSuggestionExist = false;
                                $scope.displayingSelectedGroup[0].MasterGlossaries[i].SuggestionType = status.SuggestedStatusInReviewMode;
                                $scope.displayingSelectedGroup[0].MasterGlossaries[i].UpdatedDateString = status.SuggestionDateTime;
                                $scope.displayingSelectedGroup[0].MasterGlossaries[i].UserName = status.UserName;
                                break;
                            }
                        }
                    });
		        }
	        })
        }
    };

    $scope.applySuggestions = function () {
        $('#applySuggestionsPopup').modal({ backdrop: 'static', keyboard: false });
        $('#applySuggestionsPopup').modal('show');
    };

       /**
     * @ngdoc
     * @name reviewPanelCheckbox
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Object} suggestion This is object which has accept /reject values.
     *       
     * @description
     * This method is called on checkboxes on review Suggestion popup 
     * @return {undefined} This method does not return.
     */
    $scope.reviewPanelCheckbox = function (chckboxString, suggestion) {
        if ($scope.showMessage === true) {
            $scope.showMessage = false;
            $scope.messgPop = true;
            $timeout(function () {
                $scope.messgPop = false;
            }, 6000)

        }
        if (chckboxString === 'accept') {
            if (suggestion.accept === true) {
                suggestion.accept = true;
                suggestion.reject = false;
            } else {
                suggestion.accept = false;
                suggestion.reject = false;

            }

        } else if (chckboxString === 'reject') {
            if (suggestion.reject === true) {
                suggestion.accept = false;
                suggestion.reject = true;

            } else {
                suggestion.accept = false;
                suggestion.reject = false;
            }
        }
    };

       /**
     * @ngdoc
     * @name watcherList
     * @methodOf Projects.controller:ProjectMasterController
     *       
     * @description
     * This method is called on click of watcher list button. This is used to load data in watchers list popup
     * @return {undefined} This method does not return.
     */
    $scope.watcherList = function () {
        var ClientIds = [];
        for (var i = 0; i < $scope.ProjectInfo.Clients.length; i++) {
            ClientIds.push($scope.ProjectInfo.Clients[i].Id);
        }
        ProjectMaster.getWatcherListData(projectId, $scope.selectedGroup.Id, ClientIds, function (data) {
            $scope.watcherData = data;
            watcherDataCopy = data.UnSelectedWatchers;
            $('#addWatcherList').modal('show');
        },
         function (e) {
             console.log(e);
         });
    };

     /**
     * @ngdoc
     * @name moveSelectedWatcher
     * @methodOf Projects.controller:ProjectMasterController
     * @param {object} selectedWatchers selected watcher to be added
     *       
     * @description
     * This method is called on click of move button . This is used to select watcher and move to right
     * @return {undefined} This method does not return.
     */
    $scope.moveSelectedWatcher = function (selectedWatchers) {
        for (var i = 0 ; i < selectedWatchers.length ; i++) {
            if ($scope.unSelectedDLGroup && $scope.selectedDLGroup) {
                if ($scope.unSelectedDLGroup.DistributionListId === $scope.selectedDLGroup.DistributionListId) {
                    selectedWatchers[i].DisplayFlag = true;
                }
            }

            $scope.watcherData.SelectedWatchers.push(selectedWatchers[i]);
            var index = $scope.watcherData.UnSelectedWatchers.indexOf(selectedWatchers[i]);
            if (index > -1) {
                $scope.watcherData.UnSelectedWatchers.splice(index, 1);
            }
        }
        $scope.selectedBulkSections = [];
    };

    /**
     * @ngdoc
     * @name moveUnSelectedWatcher
     * @methodOf Projects.controller:ProjectMasterController
     * @param {object} removedWatcher selected watcher to be removed
     * @description
     * This method is called on click of move button . This is used to remove the watcher and move to left
     * @return {undefined} This method does not return.
     */
    $scope.moveUnSelectedWatcher = function (removedWatcher) {
        for (var i = 0 ; i < removedWatcher.length ; i++) {
            $scope.watcherData.UnSelectedWatchers.push(removedWatcher[i]);
            var index = $scope.watcherData.SelectedWatchers.indexOf(removedWatcher[i]);
            if (index > -1) {
                $scope.watcherData.SelectedWatchers.splice(index, 1);
            }
        }
    };

        /**
     * @ngdoc
     * @name saveWatcherList
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called on click of save button on watchers popup. This is used to save the watcher list
     * @return {undefined} This method does not return.
     */
    $scope.saveWatcherList = function () {
        var setWatcherData = {};
        setWatcherData.ProjectId = projectId;
        setWatcherData.GlossaryGroupId = $scope.selectedGroup.Id;
        setWatcherData.LoginUserId = commonService.getLocalData('userDetails').UserId;
        setWatcherData.WachersUserId = [];

        if (!$scope.adminUser) {
            setWatcherData.OriginalUserId = null;
        }
        else {
            setWatcherData.OriginalUserId = $scope.adminUser.UserId;
        }

        for (var i = 0 ; i < $scope.watcherData.SelectedWatchers.length ; i++) {
            setWatcherData.WachersUserId.push($scope.watcherData.SelectedWatchers[i].UserId);

        }
        ProjectMaster.setWatchers(setWatcherData, function (data) {

            $('#addWatcherList').modal('hide');
        },
         function (e) {
             console.log(e);
         });
    };

    
        /**
     * @ngdoc
     * @name getUnassignedWatcherByGroup
     * @methodOf Projects.controller:ProjectMasterController
     * @param {object} unSelectedDLGroup selected watcher Distribution list data.
     * @description
     * This method is called on click of options in unassigned watchers by group select box. This is used to populate list of unassigned watchers in the left select box
     * @return {undefined} This method does not return.
     */
    $scope.getUnassignedWatcherByGroup = function (unSelectedDLGroup) {
        if (unSelectedDLGroup) {
            ProjectMaster.getDistibutionListUsers(unSelectedDLGroup.DistributionListId, function (data) {
                $scope.watcherData.UnSelectedWatchers = data;
                for (var i = $scope.watcherData.UnSelectedWatchers.length - 1; i >= 0; i--) {
                    for (var j = 0; j < $scope.watcherData.SelectedWatchers.length; j++) {
                        if ($scope.watcherData.UnSelectedWatchers[i] && $scope.watcherData.UnSelectedWatchers[i].UserId === $scope.watcherData.SelectedWatchers[j].UserId) {
                            $scope.watcherData.UnSelectedWatchers.splice(i, 1);
                        }
                    }
                }
            });
        } else {//if no DL group is selected
            for (var i = 0; i < watcherDataCopy.length; i++) {
                for (var j = 0; j < $scope.watcherData.SelectedWatchers.length; j++) {
                    if (watcherDataCopy[i].UserId === $scope.watcherData.SelectedWatchers[j].UserId) {
                        watcherDataCopy.splice(i, 1);
                    }
                }
            }
            $scope.watcherData.UnSelectedWatchers = watcherDataCopy;
        }
    };

    /**
     * @ngdoc
     * @name getAssignedWatcherByGroup
     * @methodOf Projects.controller:ProjectMasterController
     * @param {object} selectedDLGroup selected watcher Distribution list data.
     * @description
     * This method is called on click of options in unassigned watchers by group select box. This is used to populate list of Assigned watchers in the right select box
     * @return {undefined} This method does not return.
     */
    $scope.getAssignedWatcherByGroup = function (selectedDLGroup) {
        var SelectedWatchersOld = $scope.watcherData.SelectedWatchers; // copy SelectedWatchers to SelectedWatchersOld
        $scope.watcherData.SelectedWatchers = []; // empty SelectedWatchers
        if (selectedDLGroup) {
            ProjectMaster.getDistibutionListUsers(selectedDLGroup.DistributionListId, function (data) {
                if (SelectedWatchersOld) {
                    for (var i = 0; i < SelectedWatchersOld.length; i++) {
                        SelectedWatchersOld[i].DisplayFlag = false;
                        for (var j = 0; j < data.length; j++) {//to check exiting ussigned DL users
                            if (SelectedWatchersOld[i].UserId === data[j].UserId) {
                                SelectedWatchersOld[i].DisplayFlag = true;
                            }
                        }

                        for (var j = 0; j < $scope.watcherData.UnSelectedWatchers.length; j++) {//to check just added un-ussigned DL users
                            if (SelectedWatchersOld[i].UserId === $scope.watcherData.UnSelectedWatchers[j].UserId) {
                                SelectedWatchersOld[i].DisplayFlag = true;
                            }
                        }

                        $scope.watcherData.SelectedWatchers.push(SelectedWatchersOld[i]); // add user in SelectedWatchers
                    }
                }
            });
        } else {
            for (var i = 0; i < SelectedWatchersOld.length; i++) {
                SelectedWatchersOld[i].DisplayFlag = false;
                $scope.watcherData.SelectedWatchers.push(SelectedWatchersOld[i]); // add user in SelectedWatchers
            }
        }

        // $scope.watcherData.SelectedWatchers = SelectedWatchersOld; // copy SelectedWatchersOld to SelectedWatchers
    };

   /**
     * @ngdoc
     * @name reviewSuggestion
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called on click of review suggestion button in review mode. This is used to open review Suggestion popup.
     * @return {undefined} This method does not return.
     */
    $scope.reviewSuggestion = function () {
        if ($scope.selectedGroup !== undefined) {
            checkSectionStatus();
            ProjectMaster.checkSectionStatus(objSectionStatus, function (status) {
                if (status) {
                    $('#sectionStatePopup').modal({ backdrop: 'static', keyboard: false });
                    $('#sectionStatePopup').modal('show');
                } else {
                    var delayCall = $interval(function () {
                    if ($scope.lockInput === false) {
                        $interval.cancel(delayCall);
                        $scope.reviewPanel = [];
                        $scope.reviewPanelDialog = true;
                        $scope.showMessage = true;
                        $('#reviewCompleteReminder').modal('hide');
                        $('#reviewCompleteReminderBeforeGlossary').modal('hide');
                        $('#reviewCompleteReminderBeforeTabChange').modal('hide');
                        for (var i = 0; i < $scope.displayingSelectedGroup[0].MasterGlossaries.length; i++) {
                            var x = $scope.displayingSelectedGroup[0].MasterGlossaries[i];
                            if (((x.SuggestionType === 'Suggested Text Update' && x.SuggestedText !== "") || x.SuggestionType === 'Suggested Addition to Section' || x.SuggestionType === 'Suggested Term to Remove' || x.SuggestionType === 'Suggested Term to Restore') && x.IsEmailSent !== true) $scope.reviewPanel.push(JSON.parse(JSON.stringify(x)));
                        }
                        if ($scope.reviewPanel.length === 0) {
                            $scope.errorMessage = 'There is no suggestion available for review in this section.';
                            $('#errorModal').modal('show');
                        } else {
                            $('#reviewTermSuggestionsPopup').modal({ backdrop: 'static', keyboard: false });
                            $('#reviewTermSuggestionsPopup').modal('show');
                        }
                    }
                }, 100);
                $scope.approveRejectFlag = true;
                }
            });
        }
    };

       /**
     * @ngdoc
     * @name submitSuggestions
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called on click of submit suggestion button on review Suggestion popup. This is used to submit Suggestions
     * @return {undefined} This method does not return.
     */
    $scope.submitSuggestions = function () {
        var AutoSaveMasterTermModel = {};
        AutoSaveMasterTermModel.SaveMasterTermModelInReview = [];
        AutoSaveMasterTermModel.ProjectId = projectId;
        AutoSaveMasterTermModel.GlossaryGroupId = $scope.selectedGroup.Id;
        AutoSaveMasterTermModel.UserId = userDetails.UserId;
        AutoSaveMasterTermModel.IsSecret = $scope.selectedGroup.IsSecret;
        AutoSaveMasterTermModel.GlossaryGroupName = $scope.selectedGroup.GlossaryGroupHeader;

        if (!$scope.adminUser) {
            AutoSaveMasterTermModel.OriginalUserId = null;
        }
        else {
            AutoSaveMasterTermModel.OriginalUserId = $scope.adminUser.UserId
        }

        var counter = 0;
        $('#reviewTermSuggestionsPopup').modal('hide');

        for (var j = 0; j < $scope.reviewPanel.length; j++) {

            if ($scope.reviewPanel[j].accept === true || $scope.reviewPanel[j].reject === true) {
                AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter] = {};
                AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter].GlossaryGroupId = $scope.selectedGroup.Id;
                if ($scope.reviewPanel[j].MasterText) AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter].MasterText = $scope.reviewPanel[j].MasterText.trim();

                AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter].MasterGlossaryId = $scope.reviewPanel[j].MasterGlossaryId;
                AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter].UpdatedByUserId = userDetails.UserId;
                AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter].LoginUserId = userDetails.UserId;
                AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter].IsStarred = $scope.reviewPanel[j].IsStarred;
                AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter].RowVersion = [];
                AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter].ApproverComment = $scope.reviewPanel[j].ApproverComment;
                AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter].RowVersion = $scope.reviewPanel[j].MasterGlossaryRowversion;
                AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter].sectionType = $scope.sectionType;
                AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter].SuggestedText = $scope.reviewPanel[j].SuggestedText;
                AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter].SuggestedStatusId = $scope.reviewPanel[j].SuggestedStatusId;
                AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter].Comment = $scope.reviewPanel[j].Comment;
                AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter].ReviewBy = userDetails.UserId;
                AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter].Version = $scope.reviewPanel[j].MasterGlossaryVersion;
                AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter].IsAccepted = $scope.reviewPanel[j].accept;
                AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter].IsRejected = $scope.reviewPanel[j].reject;
                if ($scope.reviewPanel[j].accept === true && $scope.reviewPanel[j].reject === false) {
                    AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter].ReviewStatusId = 1;

                } else if ($scope.reviewPanel[j].accept === false && $scope.reviewPanel[j].reject === true) {
                    AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter].ReviewStatusId = 2;

                } else {
                    AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter].ReviewStatusId = 0;
                }
                AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter].BrandIds = [];
                AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter].ProjectBrandIds = [];
                for (var i = 0; i < $scope.reviewPanel[j].GlossaryAddedBrands.length; i++) {
                    AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter].ProjectBrandIds.push($scope.reviewPanel[j].GlossaryAddedBrands[i].ProjectBrandId);
                    if ($scope.reviewPanel[j].GlossaryAddedBrands[i].BrandId) {
                        AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter].BrandIds.push($scope.reviewPanel[j].GlossaryAddedBrands[i].BrandId);
                    } else {
                        AutoSaveMasterTermModel.SaveMasterTermModelInReview[counter].BrandIds.push($scope.reviewPanel[j].GlossaryAddedBrands[i].Id);
                    }
                }
                counter++;
            }
        }
        $scope.showLoader = true;
        ProjectMaster.submitTermSuggestions(AutoSaveMasterTermModel, function (status) {
            $scope.showLoader = false;
            $scope.reviewPanelDialog = false;
            $scope.reloadSection();
        });
    };

     /**
     * @ngdoc
     * @name cancelSuggestions
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called on click of close button on review Suggestion popup. This is used to cancel Suggestions
     * @return {undefined} This method does not return.
     */
    $scope.cancelSuggestions = function () {
        $scope.reviewPanelDialog = false;
    };

       /**
     * @ngdoc
     * @name applyBulkSuggestionsPopup
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called on click of yes pending Suggestions reminder popup. This is used to open apply Suggestion popup
     * @return {undefined} This method does not return.
     */
    $scope.applyBulkSuggestionsPopup = function () {
        $('#showPendingSuggestionsPopup').modal('hide');
        $scope.reviewPanel = [];
        for (var i = 0; i < $scope.displayingSelectedGroup[0].MasterGlossaries.length; i++) {
            var x = $scope.displayingSelectedGroup[0].MasterGlossaries[i];
            if ((x.SuggestionType === 'Suggested Text Update' && x.SuggestedText !== '') || (x.SuggestionType === 'Suggested Addition to Section' && x.SuggestedText !== '') || (x.SuggestionType === 'Suggested Term to Remove') || (x.SuggestionType === 'Suggested Term to Restore')) $scope.reviewPanel.push(x);
        }

        if ($scope.reviewPanel.length === 0) {
            $scope.errorMessage = 'There is no suggestion available for Master Terms in this section.';
            $('#errorModal').modal('show');
        } else {
            $('#applyBulkSuggestionsPopup').modal({ backdrop: 'static', keyboard: false });
            $('#applyBulkSuggestionsPopup').modal('show');
        }
    };

        /**
     * @ngdoc
     * @name applyBulkSuggestions
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called on click of apply Suggestions button on apply Suggestion popup. This is used to save Suggestions in bulk.
     * @return {undefined} This method does not return.
     */
    $scope.applyBulkSuggestions = function (reviewPanelmodified) {
        $scope.reviewPanelModified = reviewPanelmodified;
        $scope.approveRejectCount = 0;
        for (var i = 0; i < $scope.reviewPanel.length; i++) {
            $scope.reviewPanelModified[i].ApproveRejectComment = $('#approverComment' + [i]).val();
            $scope.reviewPanelModified[i].IsApproved = $('#approve' + [i]).is(':checked');
            $scope.reviewPanelModified[i].IsRejected = $('#reject' + [i]).is(':checked');
            if ($scope.reviewPanelModified[i].IsApproved || $scope.reviewPanelModified[i].IsRejected) {
                $scope.approveRejectCount = $scope.approveRejectCount + 1;
            }
        }

        //object creation to send for update
        $scope.ApplySuggestionHistoryForBulkModel = {};

        $scope.ApplySuggestionHistoryForBulkModel.projectId = projectId;
        $scope.ApplySuggestionHistoryForBulkModel.LoginUserId = userDetails.UserId;
        $scope.ApplySuggestionHistoryForBulkModel.GlossaryGroupId = $scope.selectedGroup.Id;
        $scope.ApplySuggestionHistoryForBulkModel.ApplySuggestionPerMasterGlossary = $scope.reviewPanelModified;
        $scope.ApplySuggestionHistoryForBulkModel.IsSecret = $scope.selectedGroup.IsSecret;
        if (!$scope.adminUser) {
            $scope.ApplySuggestionHistoryForBulkModel.OriginalUserId = null;
        }
        else {
            $scope.ApplySuggestionHistoryForBulkModel.OriginalUserId = $scope.adminUser.UserId
        }
        if ($scope.approveRejectCount > 0) {
            ProjectMaster.applyBulkSuggestions($scope.ApplySuggestionHistoryForBulkModel, function (status) {
                $('#applyBulkSuggestionsPopup').modal('hide');
                $scope.reloadSection();
            });
        }
    };

      /**
     * @ngdoc
     * @name rejectSuggestion
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called on click of  reject checkbox apply Suggestion popup.
     * @return {undefined} This method does not return.
     */
    $scope.rejectSuggestion = function (index) {
        if ($('#approve' + [index]).is(':checked') === true) {
            $('#approve' + [index]).prop('checked', false);
        }
    };

    /**
     * @ngdoc
     * @name approveSuggestion
     * @methodOf Projects.controller:ProjectMasterController
     * @description
     * This method is called on click of approve checkbox apply Suggestion popup.
     * @return {undefined} This method does not return.
     */
    $scope.approveSuggestion = function (index) {
        if ($('#reject' + [index]).is(':checked') === true) {
            $('#reject' + [index]).prop('checked', false);
        }
    };

    /**
     * @ngdoc
     * @name getTermSuggestions
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Object} rowData This is object contains all row data. 
     * @param {Number} rowIndex This is index of selected row in table.
     * 
     * @description
     * This method is called on click of Suggestion icon to get pending Suggestions on term 
     * @return {undefined} This method does not return.
     */
    $scope.getTermSuggestions = function (rowData, rowIndex) {
        $scope.OriginalTerm = rowData.MasterText;
        $scope.showHideHistory = false;
        ProjectMaster.getTermSuggestions(projectId, rowData.MasterGlossaryId, $scope.selectedGroup.Id, function (status) {
            $scope.suggestionsHistoryFilter = _.groupBy(status, 'IsApproveReject');
            $scope.suggestionsHistoryTrue = $scope.suggestionsHistoryFilter.true;
            $scope.suggestionsHistoryFalse = $scope.suggestionsHistoryFilter.false;
            $scope.ApproveRejectComment = '';
            $('#applyTermSuggestionsPopup').modal({ backdrop: 'static', keyboard: false });
            $('#applyTermSuggestionsPopup').modal('show');
            $scope.IsAccepted = true;
        });

        $scope.applyTermSuggestions = function (IsAccepted, ApproveRejectComment) {
            $scope.appliedSuggestion = {};
            $scope.appliedSuggestion = $scope.suggestionsHistoryTrue[0];
            $scope.appliedSuggestion.projectId = projectId;
            $scope.appliedSuggestion.IsAccepted = IsAccepted;
            $scope.appliedSuggestion.GlossaryGroupId = $scope.selectedGroup.Id;
            $scope.appliedSuggestion.MasterGlossaryId = rowData.MasterGlossaryId;
            $scope.appliedSuggestion.SuggestionType = rowData.SuggestionType;
            $scope.appliedSuggestion.ApproveRejectComment = ApproveRejectComment;
            $scope.appliedSuggestion.LoginUserId = userDetails.UserId;
            $scope.appliedSuggestion.UserName = $scope.suggestionsHistoryTrue[0].UserName;
            $scope.appliedSuggestion.UserEmailId = $scope.suggestionsHistoryTrue[0].UserEmailId;
            $scope.appliedSuggestion.Comment = $scope.suggestionsHistoryTrue[0].Comment;
            $scope.appliedSuggestion.IsSecret = $scope.selectedGroup.IsSecret;

            if (IsAccepted === true) {
                rowData.MasterText = $scope.suggestionsHistoryTrue[0].SuggestedTerm;
            }

            if (!$scope.adminUser) {
                $scope.appliedSuggestion.OriginalUserId = null;
            }
            else {
                $scope.appliedSuggestion.OriginalUserId = $scope.adminUser.UserId
            }
            ProjectMaster.applyTermSuggestions($scope.appliedSuggestion, function (status) {

                //remove deleted row from UI only
                if ($scope.suggestionsHistoryTrue[0].SuggestionType === 'Suggested Term to Remove' && IsAccepted === true) {
                    $scope.projectMasterFromDb.TableData[0].MasterGlossaries.splice(rowIndex, 1);
                    rowData.IsRemoved = true;
                } else if ($scope.suggestionsHistoryTrue[0].SuggestionType === 'Suggested Addition to Section' && IsAccepted === false) {
                    $scope.projectMasterFromDb.TableData[0].MasterGlossaries.splice(rowIndex, 1);
                    rowData.MasterGlossaryVersion = 1;
                } else if ($scope.suggestionsHistoryTrue[0].SuggestionType === 'Suggested Term to Restore' && IsAccepted === true) {
                    rowData.MasterText = $scope.suggestionsHistoryTrue[0].MasterText;
                    rowData.IsRemoved = false;
                }
                else {
                }
                //change version and flag fron UI
                if (IsAccepted === false) {
                    rowData.IsSuggestionExist = true;
                } else {
                    rowData.IsSuggestionExist = true;
                    rowData.MasterGlossaryVersion = rowData.MasterGlossaryVersion + 1;
                }
                rowData.SuggestionType = '';
                applySuggestionsButton();
            });
        }
    };

    $scope.setlabel = function (labelItem) {
        $scope.buttonlabel = labelItem;
    }

    
    /**
     * @ngdoc
     * @name removeSuggestion
     * @methodOf Projects.controller:ProjectMasterController
     * @param {Number} MasterGlossaryId This is master glossary id
     * 
     * @description
     * This method is used to remove suggestion. this is called on remove button in review suggestion popup
     * @return {undefined} This method does not return.
     */
    $scope.removeSuggestion = function (MasterGlossaryId) {

        var originaluser;
        if (!$scope.adminUser) {
            originaluser = null;
        }
        else {
            originaluser = $scope.adminUser.UserId
        }

        ProjectMaster.removeSuggestions(MasterGlossaryId, originaluser, function (status) {
            for (var i = 0; i < $scope.reviewPanel.length; i++) {
                if ($scope.reviewPanel[i].MasterGlossaryId === MasterGlossaryId) {
                    $scope.reviewPanel.splice(i, 1);
                    break;
                }
            }
            for (var i = 0; $scope.displayingSelectedGroup[0].MasterGlossaries.length; i++) {
                if ($scope.displayingSelectedGroup[0].MasterGlossaries[i].MasterGlossaryId === MasterGlossaryId) {
                    var x = $scope.displayingSelectedGroup[0].MasterGlossaries[i];
                    if (x.SuggestionType === 'Suggested Text Update') {
                        $scope.displayingSelectedGroup[0].MasterGlossaries[i].SuggestionType = "";
                        $scope.displayingSelectedGroup[0].MasterGlossaries[i].SuggestedText = "";
                        $scope.displayingSelectedGroup[0].MasterGlossaries[i].Comment = "";
                        if ($scope.displayingSelectedGroup[0].MasterGlossaries[i].MasterGlossaryVersion === 1) {
                            $scope.displayingSelectedGroup[0].MasterGlossaries[i].IsSuggestionExist = null;
                        } else {
                            $scope.displayingSelectedGroup[0].MasterGlossaries[i].IsSuggestionExist = true;
                        }
                        break;
                    }
                    if (x.SuggestionType === 'Suggested Addition to Section') {
                        $scope.displayingSelectedGroup[0].MasterGlossaries.splice(i, 1);
                        break;
                    }
                    if (x.SuggestionType === 'Suggested Term to Remove') {
                        $scope.displayingSelectedGroup[0].MasterGlossaries[i].SuggestionType = "";
                        $scope.displayingSelectedGroup[0].MasterGlossaries[i].SuggestedText = "";
                        $scope.displayingSelectedGroup[0].MasterGlossaries[i].Comment = "";
                        if ($scope.displayingSelectedGroup[0].MasterGlossaries[i].MasterGlossaryVersion === 1) {
                            $scope.displayingSelectedGroup[0].MasterGlossaries[i].IsSuggestionExist = null;
                        } else {
                            $scope.displayingSelectedGroup[0].MasterGlossaries[i].IsSuggestionExist = true;
                        }
                        break;
                    }
                    if (x.SuggestionType === 'Suggested Term to Restore') {
                        $scope.displayingSelectedGroup[0].MasterGlossaries[i].SuggestionType = "";
                        $scope.displayingSelectedGroup[0].MasterGlossaries[i].Comment = "";
                        if ($scope.displayingSelectedGroup[0].MasterGlossaries[i].MasterGlossaryVersion === 1) {
                            $scope.displayingSelectedGroup[0].MasterGlossaries[i].IsSuggestionExist = null;
                        } else {
                            $scope.displayingSelectedGroup[0].MasterGlossaries[i].IsSuggestionExist = true;
                        }
                        break;
                    }
                    $scope.reviewPanel.splice(i, 1);
                    break;
                }
            }

        });
    };
 
    /**
     * @ngdoc
     * @name sectionCompleteConfirmation
     * @methodOf Projects.controller:ProjectMasterController
     * 
     * @description
     * This method is used to open section complete confirmation popup.this is called onclick of section complete button.
     * @return {undefined} This method does not return.
     */
    $scope.sectionCompleteConfirmation = function () {
        $('#sectionCompleteConfirmation').modal({ backdrop: 'static', keyboard: false });
        $('#sectionCompleteConfirmation').modal('show');
    };

     /**
     * @ngdoc
     * @name sectionComplete
     * @methodOf Projects.controller:ProjectMasterController
     * 
     * @description
     * This method is called on click of yes on section complete confirmation poup.This function sets sections as complete in DB
     * @return {undefined} This method does not return.
     */
    $scope.sectionComplete = function () {
        var delayCall = $interval(function () {
            if ($scope.lockInput === false) {
                $interval.cancel(delayCall);
                var originaluser;
                if (!$scope.adminUser) {
                    originaluser = null;
                }
                else {
                    originaluser = $scope.adminUser.UserId
                }
                ProjectMaster.sectionComplete($scope.selectedGroup.Id, projectId, userDetails.UserId, originaluser, $scope.selectedGroup.IsSectionComplete, $scope.selectedGroup.IsSectionUnlock, function (status) {
                    sessionStorage.setItem('SourceSetupActiveSection', '');
                    $route.reload();
                    $('.modal-backdrop.fade.in').css('display', 'none');
                });
            }
        }, 100);
    };

        /**
     * @ngdoc
     * @name sectionCompleteReminderSettings
     * @methodOf Projects.controller:ProjectMasterController
     * 
     * @description
     * This method is called on click of "Don't remind me next time" check box on section complete reminder popup. This is just used to open Section Complete Reminder Settings popup
     * @return {undefined} This method does not return.
     */
    $scope.sectionCompleteReminderSettings = function () {
        if ($scope.sectionCompleteReminderFlag) {
            $('#sectionCompleteReminderSettings').modal({ backdrop: 'static', keyboard: false });
            $('#sectionCompleteReminderSettings').modal('show');
        }
    };

       /**
     * @ngdoc
     * @name sectionCompleteReminderSettingsService
     * @methodOf Projects.controller:ProjectMasterController
     * 
     * @description
     * This method is called on click of buttons on section complete remove confirmation popup. This is used to not remind user to complete section in future.
     * @return {undefined} This method does not return.
     */
    $scope.sectionCompleteReminderSettingsService = function (IsSectionCompleteReminder) {

        if (IsSectionCompleteReminder === undefined) {
            IsSectionCompleteReminder = false;
        }
        if (IsSectionCompleteReminder) {
            $scope.sectionCompleteReminderFlag = false;
            $scope.IsSectionCompleteReminderFlag = true;
        } else {
            $scope.sectionCompleteReminderFlag = true;
            $scope.IsSectionCompleteReminderFlag = false;
        }

        sessionStorage.setItem('IsSectionCompleteReminderFlag',$scope.IsSectionCompleteReminderFlag);
        var data = {};
        if ($scope.ProjectInfo.UserProfileTranslationDetails) {
            if ($scope.ProjectInfo.UserProfileTranslationDetails.IsRememberUserNextTime) {
                data['IsRememberUserNextTime'] = $scope.ProjectInfo.UserProfileTranslationDetails.IsRememberUserNextTime;
            } else {
                data['IsRememberUserNextTime'] = false;
            }
        } else {
            data['IsRememberUserNextTime'] = false;
        }

        data['IsSectionCompleteReminder'] = IsSectionCompleteReminder;
        data['UserId'] = commonService.getLocalData('userDetails').UserId;
        var forgerytoken;
        $('#sectionCompleteReminderSettings').modal('hide');
        commonService.getToken(function (token) {
            forgerytoken = token;
            $http({
                method: 'POST',
                url: "Users/UpdateUserConfirmationForNextTime",
                data: data,
                headers: {
                    '__RequestVerificationToken': forgerytoken
                }
            })
            .success(function (data) {

            })
            .error(function (e) {
            })
        });
    };

          /**
     * @ngdoc
     * @name sectionCompleteReminderInfoToggle
     * @methodOf Projects.controller:ProjectMasterController
     * 
     * @description
     * This method is called on click of link "click more for details" on section complete reminder popup. This is used to show more info on section complete reminder.
     * @return {undefined} This method does not return.
     */
    $scope.sectionCompleteReminderInfoToggle = function () {
        if ($scope.sectionCompleteReminderInfo === true) {
            $scope.sectionCompleteReminderInfo = false;
        } else {
            $scope.sectionCompleteReminderInfo = true;
        }
    };

     /**
     * @ngdoc
     * @name showHideHistoryToggle
     * @methodOf Projects.controller:ProjectMasterController
     * 
     * @description
     * This method is called on click of link "View history of this term" on suggestion history popup. This is used to show history of the term
     * @return {undefined} This method does not return.
     */
    $scope.showHideHistoryToggle = function (showHideHistory) {
        if (showHideHistory) {
            $scope.showHideHistory = false;
        } else {
            $scope.showHideHistory = true;
        }
    };

       /**
     * @ngdoc
     * @name callSectionComplete
     * @methodOf Projects.controller:ProjectMasterController
     * 
     * @description
     * This function is called to navigate to previous function after completing current section. This function is called on complete button on section complete reminder popup 
     * @return {undefined} This method does not return.
     */
    $scope.callSectionComplete = function () {
        if (sectionCompleteGotoGlossary) {
            var originaluser;
            if (!$scope.adminUser) {
                originaluser = null;
            }
            else {
                originaluser = $scope.adminUser.UserId
            }
            ProjectMaster.sectionComplete($scope.selectedGroupIdStored, projectId, userDetails.UserId, originaluser, $scope.selectedGroup.IsSectionComplete, $scope.selectedGroup.IsSectionUnlock, function (status) {
                $scope.reviewModeStored = true;
                sessionStorage.setItem('reviewModeStored', $scope.reviewModeStored);
                sectionCompleteGotoGlossary = false;
                $('.modal-backdrop.fade.in').css('display', 'none');
                $scope.changeView("glossary");
            });
        } else if (sectionCompleteAddNewSection) {
            var originaluser;
            if (!$scope.adminUser) {
                originaluser = null;
            }
            else {
                originaluser = $scope.adminUser.UserId
            }
            ProjectMaster.sectionComplete($scope.selectedGroupIdStored, projectId, userDetails.UserId, originaluser, $scope.selectedGroup.IsSectionComplete, $scope.selectedGroup.IsSectionUnlock, function (status) {
                $scope.reviewModeStored = true;
                sessionStorage.setItem('reviewModeStored',$scope.reviewModeStored);
                sectionCompleteAddNewSection = false;
                $scope.isSectionOpen = false;
                $('.modal-backdrop.fade.in').css('display', 'none');
                $scope.addNewGroup();
            });
        } else if (sectionCompleteChangeSection) {
            var originaluser;
            if (!$scope.adminUser) {
                originaluser = null;
            }
            else {
                originaluser = $scope.adminUser.UserId
            }
            ProjectMaster.sectionComplete($scope.selectedGroupIdStored, projectId, userDetails.UserId, originaluser, $scope.selectedGroup.IsSectionComplete, $scope.selectedGroup.IsSectionUnlock, function (status) {
                $scope.reviewModeStored = true;
                sessionStorage.setItem('reviewModeStored',$scope.reviewModeStored);
                sectionCompleteChangeSection = false;
                $('.modal-backdrop.fade.in').css('display', 'none');
                $route.reload();
            });
        } else if ($scope.sectionCompleteGotoNTLTab) {
            ProjectMaster.sectionComplete($scope.selectedGroupIdStored, projectId, userDetails.UserId, originaluser, $scope.selectedGroup.IsSectionComplete, $scope.selectedGroup.IsSectionUnlock, function (status) {
                $scope.reviewModeStored = true;
                sessionStorage.setItem('reviewModeStored',$scope.reviewModeStored);
                $scope.sectionCompleteGotoNTLTab = false;
                $('.modal-backdrop.fade.in').css('display', 'none');
                sessionStorage.setItem('SourceSetupActiveSection', '');
                sessionStorage.setItem('isShowRemovedTermsFlag', '0');
                $scope.ntlSection();
            });
        } else if ($scope.sectionCompleteGotoDefaultTab) {
            ProjectMaster.sectionComplete($scope.selectedGroupIdStored, projectId, userDetails.UserId, originaluser, $scope.selectedGroup.IsSectionComplete, $scope.selectedGroup.IsSectionUnlock, function (status) {
                $scope.reviewModeStored = true;
                sessionStorage.setItem('reviewModeStored', $scope.reviewModeStored);
                $scope.sectionCompleteGotoDefaultTab = false;
                $('.modal-backdrop.fade.in').css('display', 'none');
                sessionStorage.setItem('SourceSetupActiveSection', '');
                sessionStorage.setItem('isShowRemovedTermsFlag', '0');
                $scope.defaultSection();
            });
        } else if (linkToGoNext) {
            console.log($scope.selectedGroupIdStored, projectId, userDetails.UserId, originaluser, $scope.selectedGroup.IsSectionComplete, $scope.selectedGroup.IsSectionUnlock);
            ProjectMaster.sectionComplete($scope.selectedGroupIdStored, projectId, userDetails.UserId, originaluser, $scope.selectedGroup.IsSectionComplete, $scope.selectedGroup.IsSectionUnlock, function (status) {
                console.log("status",status)
            });
            setTimeout(function () {
                $scope.reviewModeStored = true;
                sessionStorage.setItem('reviewModeStored', $scope.reviewModeStored);
                $('.modal-backdrop.fade.in').css('display', 'none');
                sessionStorage.setItem('linkToGoNext', null);
                window.location = linkToGoNext;
            }, 2500);
        } else if ($scope.reviewModeStored === false) {
            ProjectMaster.sectionComplete($scope.selectedGroupIdStored, projectId, userDetails.UserId, originaluser, $scope.selectedGroup.IsSectionComplete, $scope.selectedGroup.IsSectionUnlock, function (status) {
                $scope.closeSection();
            });
            $('.modal-backdrop.fade.in').css('display', 'none');
        } else {
            $scope.closeSection();
            $('.modal-backdrop.fade.in').css('display', 'none');
        }
    };

    $scope.closeSection = function () {
        sessionStorage.setItem('SourceSetupActiveSection', '');
        sessionStorage.setItem('isShowRemovedTermsFlag', '0');
        $route.reload();
        $('.modal-backdrop.fade.in').css('display', 'none');
    };

    /**
     * @ngdoc
     * @name reloadSectionAfterPopup
     * @methodOf Projects.controller:ProjectMasterController
     * 
     * @description
     * This function is called to navigate to previous function WITHOUT marking current section as 'Section Complete'
     * @return {undefined} This method does not return.
     */
    $scope.reloadSectionAfterPopup = function () { //this function is called to navigate to previous function WITHOUT marking current section as 'Section Complete'
        if (sectionCompleteGotoGlossary) {
            $scope.reviewModeStored = true;
            sessionStorage.setItem('reviewModeStored', $scope.reviewModeStored);
            sectionCompleteGotoGlossary = false;
            $('.modal-backdrop.fade.in').css('display', 'none');
            $scope.changeView("glossary");
        } else if (sectionCompleteAddNewSection) {
            $scope.reviewModeStored = true;
            sessionStorage.setItem('reviewModeStored', $scope.reviewModeStored);
            sectionCompleteAddNewSection = false;
            $('.modal-backdrop.fade.in').css('display', 'none');
            $scope.addNewGroup();
        } else if ($scope.sectionCompleteGotoNTLTab) {
            $scope.reviewModeStored = true;
            sessionStorage.setItem('reviewModeStored',$scope.reviewModeStored);
            $scope.sectionCompleteGotoNTLTab = false;
            $('.modal-backdrop.fade.in').css('display', 'none');
            sessionStorage.setItem('SourceSetupActiveSection', '');
            sessionStorage.setItem('isShowRemovedTermsFlag', '0');
            $scope.ntlSection();
        } else if ($scope.sectionCompleteGotoDefaultTab) {
            $scope.reviewModeStored = true;
            sessionStorage.setItem('reviewModeStored',$scope.reviewModeStored);
            $scope.sectionCompleteGotoDefaultTab = false;
            $('.modal-backdrop.fade.in').css('display', 'none');
            sessionStorage.setItem('SourceSetupActiveSection', '');
            sessionStorage.setItem('isShowRemovedTermsFlag', '0');
            $scope.defaultSection();
        } else if (sectionCompleteChangeSection) {
            $scope.reviewModeStored = true;
            sessionStorage.setItem('reviewModeStored',$scope.reviewModeStored);
            sectionCompleteChangeSection = false;
            $('.modal-backdrop.fade.in').css('display', 'none');
            $scope.selectedGroup = commonService.getSessionData('SourceSetupActiveSection');
            $scope.showSelectedGroups(commonService.getSessionData('SourceSetupActiveSection'));
        } else if (cancelSectionClicked === true) {
            $scope.closeSection();
        } else if (linkToGoNext) {
            $scope.reviewModeStored = true;
            sessionStorage.setItem('reviewModeStored', $scope.reviewModeStored);
            $('.modal-backdrop.fade.in').css('display', 'none');
            sessionStorage.setItem('linkToGoNext',null);
            window.location = linkToGoNext;
        }else {
            $route.reload();
            $('.modal-backdrop.fade.in').css('display', 'none');
        }

    };

    $scope.reloadSection = function () {
        $route.reload();
        $scope.reviewMode = false;
        $('.modal-backdrop.fade.in').css('display', 'none');
    };

       /**
     * @ngdoc
     * @name unlockSectionPopup
     * @methodOf Projects.controller:ProjectMasterController
     * 
     * @description
     * This function is called on click of unlock section. This is used to show popup.
     * @return {undefined} This method does not return.
     */
    $scope.unlockSectionPopup = function () {
        var isSuggestionExistsInSection = false;
        for (var i = 0; i < $scope.displayingSelectedGroup[0].MasterGlossaries.length; i++) {
            if ($scope.displayingSelectedGroup[0].MasterGlossaries[i].IsSuggestionExist === false) {
                $('#unlockSectionPopup').modal({ backdrop: 'static', keyboard: false });
                $('#unlockSectionPopup').modal('show');
                isSuggestionExistsInSection = true;
                break;
            }
        }
        var originaluser;
        if (!$scope.adminUser) {
            originaluser = null;
        }
        else {
            originaluser = $scope.adminUser.UserId
        }
        if (!isSuggestionExistsInSection) {
            //service call
            $scope.selectedGroupUnlocked = $scope.selectedGroup;
            $scope.selectedGroupUnlocked.IsSectionComplete = false;
            $scope.selectedGroupUnlocked.IsSectionUnlock = true;
            sessionStorage.setItem('SourceSetupActiveSection', '');
            ProjectMaster.unlockSection($scope.selectedGroup.Id, userDetails.UserId, originaluser, function (status) {
                sessionStorage.setItem('SourceSetupActiveSection', JSON.stringify($scope.selectedGroupUnlocked));
                $scope.selectedGroup = commonService.getSessionData('SourceSetupActiveSection');
                $scope.showSelectedGroups(commonService.getSessionData('SourceSetupActiveSection'));
            });
        }
    };

     /**
     * @ngdoc
     * @name checkSectionStatus
     * @methodOf Projects.controller:ProjectMasterController
     * 
     * @description
     * This function is used to check current section status default/completed/unlocked
     * @return {undefined} This method does not return.
     */
    var checkSectionStatus = function () {
        objSectionStatus.GlossaryGroupId = $scope.selectedGroup.Id;
        objSectionStatus.ProjectId = projectId;
        objSectionStatus.IsSectionComplete = $scope.selectedGroup.IsSectionComplete;
        objSectionStatus.IsSectionUnlocked = $scope.selectedGroup.IsSectionUnlock;
        return objSectionStatus;
    };

       /**
     * @ngdoc
     * @name init
     * @methodOf Projects.controller:ProjectMasterController
     * 
     * @description
     * This function is used for initialisation of the variables on page load
     * @return {undefined} This method does not return.
     */
    var init = function () {
        var sectionCompleteReminderOnMenuClick = JSON.parse(sessionStorage.getItem('sectionCompleteReminderOnMenuClick'));
        linkToGoNext = sessionStorage.getItem('linkToGoNext');
        $scope.showLoader = true;
        dynamicScreenHeight();
        sessionStorage.setItem("filterStatus", "undefined");
        sessionStorage.setItem("filterImage", "undefined");
        sessionStorage.setItem("pendingTranslationsFilter", "0");
        sessionStorage.setItem("pendingApprovalsFilter", "0");
        sessionStorage.setItem("approvedFilter", "0");
        sessionStorage.setItem("rejectedFilter", "0");
        sessionStorage.setItem("filterOnStatus", "0");

        $scope.reviewModeStored = true;
        sessionStorage.setItem('reviewModeStored', $scope.reviewModeStored);
        var resorceIdx = 4;
        sessionStorage.setItem('resourcePageId', JSON.stringify(resorceIdx));
        userDetails = commonService.getLocalData('userDetails');
        getSourceSetupFilters();
        getProjectBasicInfoOnLoad();
        if (sessionStorage.getItem('ActiveSectionType')) {
            if (sessionStorage.getItem('ActiveSectionType') === "1") {
                $scope.defaultSection();
            }
            else if (sessionStorage.getItem('ActiveSectionType') === "2") {
                $scope.ntlSection();
            }
            else {
                $scope.defaultSection();
            }
        }

        if (sessionStorage.getItem('SourceSetupActiveSection')) {
            $scope.selectedGroup = commonService.getSessionData('SourceSetupActiveSection');
            $scope.showSelectedGroups(commonService.getSessionData('SourceSetupActiveSection'));
            $scope.buttonlabel = $scope.selectedGroup.GlossaryGroupHeader
        }
        if (sectionCompleteReminderOnMenuClick === true) {
            setTimeout(function () {
                sessionStorage.setItem('sectionCompleteReminderOnMenuClick', false);
                sessionStorage.setItem('hashURL', null);
                $('#sectionCompleteReminder').modal({ backdrop: 'static', keyboard: false });
                $('#sectionCompleteReminder').modal('show');
            }, 2000);
        }
    };

    init();
}]);// End of Controller
