/**
* @ngdoc directive
* @name common.directive:multiSelectDragLeftRight
* @restrict 'E'
* @element select 
* @scope
* @description 
* This is custom directive for multi select drag left to right and vice versa.
**/
angular.module('common', ['projectIdService', 'ng-breadcrumbs'])
.directive('multiSelectDragLeftRight', function () {
    return {
        restrict: 'E',
        scope: {
            selectedModel: '=',
            leftList: '=',
            rightList: '=',
            tranSourceLeftList: '=',
            tranSourceRightList: '=',
            langdrop: '=',
            unselectedModel: '='
        },
        template: 
         "<button type='button' class='btn btn-default btn-forward'  ng-click='moveRight()' >&gt;&gt;</button>" +
                 "<button type='button' class='btn btn-default btn-backward' ng-click='moveLeft()' >&lt;&lt;</button>",
        controller: ['$scope', '$timeout', function (scope,$timeout) {
            scope.moveRight = function(){
                for (var i = 0 ; i < scope.selectedModel.length ; i++) {
                    if (scope.langdrop == true) {
                        scope.selectedModel[i].TranslationSourceRequired = false;
                    }
                    scope.rightList.push(scope.selectedModel[i]);
                    for (var j = 0; j < scope.leftList.length; j++) {
                        if (scope.leftList[j].Id === scope.selectedModel[i].Id) {
                            scope.leftList.splice(j, 1);
                            break;
                        }
                    }

                }
                var temp = [];
                angular.copy(scope.rightList, temp);
                scope.rightList = [];
                $timeout(function () { scope.rightList = temp }, 20);
                 
            };
            scope.moveLeft = function(){
                for (var i = 0 ; i < scope.unselectedModel.length ; i++) {
                    if (scope.langdrop == true) {
                        scope.unselectedModel[i].TranslationSourceRequired = false;
                    }
                    scope.leftList.push(scope.unselectedModel[i]);
                    var flag = false;
                    for (var j = 0; j < scope.rightList.length; j++) {
                        if (scope.rightList[j].Id === scope.unselectedModel[i].Id) {
                            scope.rightList.splice(j, 1);
                            break;
                        }
                    }
                    if (scope.langdrop == true) {
                    for (var j = 0; j < scope.tranSourceLeftList.length; j++) {
                        if (scope.tranSourceLeftList[j].Id === scope.unselectedModel[i].Id) {
                            scope.tranSourceLeftList.splice(j, 1);
                            flag = true;
                            break;
                        }
                    }
                    if (flag === false) {
                        for (var j = 0; j < scope.tranSourceRightList.length; j++) {
                            if (scope.tranSourceRightList[j].Id === scope.unselectedModel[i].Id) {
                                scope.tranSourceRightList.splice(j, 1);
                                break;
                            }
                        }
                    }
                 }
                }

                var temp = [];
                angular.copy(scope.rightList, temp);
                scope.rightList = [];
                $timeout(function () { scope.rightList = temp }, 20);
            };
        }
        ]
        
    }
});


/**
* @ngdoc directive
* @name common.directive:attachFiles
* @restrict 'A'
* @element input
* @scope
* @description 
* This is custom directive used on file upload. This is used to get file data(name,size,type)
**/
angular.module('common', ['projectIdService', 'ng-breadcrumbs'])
.directive('attachFiles', ['$rootScope', function ($rootScope) {
    return {
        scope: {
            fileid: '='
        },
        link: function (scope, element, attrs) {
            element.on("click", function () {
                this.value = null;
            });
            

            element.on('change', function (evt) {
                   var fileData = '';
                   scope.audioDetailsObj = [];
                   var reader = new FileReader();
                   reader.readAsDataURL(evt.target.files[0]);
                   
                   reader.onload = function () {
                       fileData = reader.result;
                       scope.audioDetailsObj[0] = {
                           filename: evt.target.files[0].name,
                           filesize: evt.target.files[0].size,
                           filetype: evt.target.files[0].type,
                           filedata: fileData.split(',')[1]
                       };
                       $rootScope.$broadcast('addedFileDetails', scope.audioDetailsObj, scope.fileid);
                   }; 
            });
        }
    }
}]);

/**
* @ngdoc directive
* @name common.directive:attachImages
* @restrict 'A'
* @element input
* @scope
* @description 
* This is custom directive used on image file upload on source setup page. This is used to get file data(name,size,type)
**/
angular.module('common', ['projectIdService', 'ng-breadcrumbs'])
.directive('attachImages', ['$rootScope', function ($rootScope) {
    return {
        scope: {
            fileid: '=',
            mastertext: '=',
            sectionindex: "="
            //showimgbtns: '@showimgbtns'
        },        
        link: function (scope, element, attrs) {
            element.on("click", function () {
                this.value = null;
            });
           

            element.on('change', function (evt) {
                   var fileData = '';
                   scope.audioDetailsObj = [];
                   var reader = new FileReader();
                   reader.readAsDataURL(evt.target.files[0]);
                  
                   reader.onload = function () {
                       fileData = reader.result;
                       scope.audioDetailsObj[0] = {
                           filename: evt.target.files[0].name,
                           filesize: evt.target.files[0].size,
                           filetype: evt.target.files[0].type,
                           filedata: fileData.split(',')[1],
                           fileext: evt.target.files[0].name.split('.').pop(),
                           mastertext: scope.mastertext,
                           sectionIndex: scope.sectionindex,
                           image: fileData
                       };
                       $rootScope.$broadcast('addedImageDetails', scope.audioDetailsObj);
                   }; 
            });
        }
    }
}]);

/**
* @ngdoc directive
* @name common.directive:brandDropdown
* @restrict 'E'
* @element
* @scope
* @description 
* This is custom directive used for multi select dropdown for brands.
**/
angular.module('common', ['projectIdService', 'ng-breadcrumbs'])
Common.directive('brandDropdown', ['$rootScope', function ($rootScope) {
    return {
        restrict: 'E',
        scope: {
            model: '=',
            options: '=',
            pre_selected: '=preSelected'
        },
        template: "<div class='btn-group' data-ng-class='{open: open}'>" +
         "<button class='brand_str btn btn-small btn-width ms-dropdown-style' data-ng-click='open=!open;openDropdown()'>Select Brand(s)</button>" +
                 "<button class='btn btn-small dropdown-toggle' data-ng-click='open=!open;openDropdown()'><span ng-class=\"open ? 'caret-close-dropdown' : 'caret' \"></span></button>" +
                 "<ul class='dropdown-menu' aria-labelledby='dropdownMenu'>" +
                     "<li><a data-ng-click='selectAll()'><i class='icon-ok-sign'></i>  Check All</a></li>" +
                     "<li><a data-ng-click='deselectAll();'><i class='icon-remove-sign'></i>  Uncheck All</a></li>" +
                     "<li><a><input ng-model='filter' type='text' /></a></li>"+
                     "<li class='divider'></li>" +
                     "<li data-ng-repeat='option in options | orderBy:\"BrandName\" | filter:{BrandName:filter}'> <a data-ng-click='setSelectedItem()' title={{option.BrandName}}>{{option.BrandName}}<span data-ng-class='isChecked(option.Id)'></span></a></li>" +
                 "</ul>" +
             "</div>",
        controller: ['$scope',function ($scope) {

            $scope.openDropdown = function () {
                $('.new-project-dropdown div').removeClass('open');
                $('.new-project-dropdown div button span').removeClass('caret-close-dropdown');
                $('.new-project-dropdown div button span').addClass('caret');
                $scope.ObjectId2 = [];
                for (var i = 0; i < $scope.pre_selected.length; i++) {
                    $scope.ObjectId2.push($scope.pre_selected[i].id);
                }
                $rootScope.$broadcast('brandselectedModel', $scope.model);
                $scope.filter = '';
            };

            $scope.selectAll = function () {
         
                $scope.model = _.pluck($scope.options , 'Id');
                
                $rootScope.$broadcast('brandselectedModel', $scope.model);
            };
            $scope.deselectAll = function () {
            
                var warning = confirm("Warning - By modifying the brand association for this project, you may be breaking pre-existing brand associations for some sections and/or terms. Are you sure you wish to continue?");
                if (warning == true) {
                    $scope.model = [];
                    $rootScope.$broadcast('brandselectedModel', $scope.model);
                } else {
                }
                
                
            };
            $scope.setSelectedItem = function () {
                var optionSelected = this.option.Id;

                if (_.contains($scope.model, optionSelected)) {
                    var warning = confirm("Warning - By modifying the brand association for this project, you may be breaking pre-existing brand associations for some sections and/or terms. Are you sure you wish to continue?");
                    if (warning == true) {
                        $scope.model = _.without($scope.model, optionSelected);
                        $rootScope.$broadcast('brandselectedModel', $scope.model);
                        return false;
                    } else {
                    }
                } else {
                    $scope.model.push(optionSelected);
                }
                
                $rootScope.$broadcast('brandselectedModel', $scope.model);
                return false;
            };
            
            $scope.isChecked = function (Id) {
                if (_.contains($scope.model, Id)) {
                    return 'icon-ok pull-right';
                }
                return false;
            };

        }
    ]}
}]);

/**
* @ngdoc directive
* @name common.directive:distributionlistClientDropdown
* @restrict 'E'
* @element
* @scope
* @description 
* This is custom directive used on distribution list page for multiselect dropdown for clients.
**/
angular.module('common', ['projectIdService', 'ng-breadcrumbs'])
.directive('distributionlistClientDropdown', ['$rootScope', function ($rootScope) {
    return {
        restrict: 'E',
        scope: {
            model: '=',
            options: '=',
            pre_selected: '=preSelected',
            resetdata: '=',
            dltype:'='
        },
        template: "<div class='btn-group' data-ng-class='{open: open}'>" +
         "<button class='client_str btn btn-small btn-width ms-dropdown-style' data-ng-mouseover='open=!open;openDropdown()' data-ng-mouseleave='open=!open;openDropdown()'>Select Client(s)</button>" +
                 "<button class='btn btn-small dropdown-toggle' data-ng-mouseover='open=!open;openDropdown()' data-ng-mouseleave='open=!open;openDropdown()'><span class='caret'></span></button>" +
                 "<ul class='dropdown-menu' aria-labelledby='dropdownMenu' data-ng-mouseleave='open=!open;openDropdown()'>" +
                     "<li><a data-ng-click='selectAll()'><i class='icon-ok-sign'></i>  Check All</a></li>" +
                     "<li><a data-ng-click='deselectAll();'><i class='icon-remove-sign'></i>  Uncheck All</a></li>" +
                     "<li class='divider'></li>" +
                     "<li data-ng-repeat='option in options'> <a data-ng-click='setSelectedItem()'>{{option.ClientName}}<span data-ng-class='isChecked(option.ClientId)'></span></a></li>" +
                 "</ul>" +
             "</div>",
        controller: ['$scope', function ($scope) {

        
            $scope.openDropdown = function () {
               
                $scope.AssignedClientList = [];
                for (var i = 0; i < $scope.pre_selected.length; i++) {
                    $scope.AssignedClientList.push($scope.pre_selected[i]);
                }
                //  $rootScope.$broadcast('selectedModel', $scope.model);
            };

            //reset lang users data
            var resetData = function () {
                for (var i = 0 ; i < $scope.resetdata.selectLang.length; i++) {
                    $scope.resetdata.unSelectLang.push($scope.resetdata.selectLang[i]);
                }
                $scope.resetdata.selectLang = [];
                $scope.resetdata.userListArray = [];
                $scope.resetdata.selectUsers = [];
            };

            $scope.selectAll = function () {
                    resetData();
                    angular.copy($scope.options, $scope.model);
                    $scope.clientIDs = _.pluck($scope.model, 'ClientId');
                    if ($scope.dltype == "Client Admin" || $scope.dltype == "Client User") {
                        $rootScope.$broadcast('ClientSelected', $scope.model);
                    }
                    $rootScope.$broadcast('selectedModel', $scope.clientIDs);
            };
            $scope.deselectAll = function () {
                resetData();
                var warning = confirm("Are you sure you wish to remove all client from this Distribution List?");
                if (warning == true) {
                    $scope.model = [];
                    $scope.clientIDs = [];

                    if ($scope.dltype == "Client Admin" || $scope.dltype == "Client User") {
                        $rootScope.$broadcast('ClientSelected', $scope.model);
                    }
                    $rootScope.$broadcast('selectedModel',  $scope.clientIDs);
                }
                else {

                }
            };

            $scope.setSelectedItem = function () {
                if ($scope.model === undefined || $scope.clientIDs === undefined)
                {
                    $scope.model = [];
                    $scope.clientIDs = [];
                }
                if ($scope.model.length == 0)
                {
                    $scope.clientIDs = [];
                }
                 resetData(); 
                var optionSelected = this.option.ClientId;
                
                if (_.contains( $scope.clientIDs, optionSelected)) {
                    var warning = confirm("Are you sure you wish to remove this client from this Distribution List?");
                    if (warning == true) {
                       for (var i = 0; i < $scope.model.length; i++) {
                            if($scope.model[i].ClientId==optionSelected)
                            {
                                $scope.model.splice(i, 1);
                            }
                       }
                       $scope.clientIDs = _.without($scope.clientIDs, optionSelected);
                       $rootScope.$broadcast('selectedModel', $scope.clientIDs);
                       if ($scope.dltype == "Client Admin" || $scope.dltype == "Client User" ) {
                           $rootScope.$broadcast('ClientSelected', $scope.model);
                       }
                        return false;
                    } else {
                        
                    }
                    
                } else {
                    
                    $scope.clientIDs.push(optionSelected);
                    $scope.model.push(this.option);
                }
                
                if ($scope.dltype == "Client Admin" || $scope.dltype == "Client User") {
                    $rootScope.$broadcast('ClientSelected', $scope.model);
                }
                $rootScope.$broadcast('selectedModel', $scope.clientIDs);
                return false;
            };
            
            $scope.isChecked = function (Id) {
                if (_.contains($scope.clientIDs, Id)) {
                    return 'icon-ok pull-right';
                }
                return false;
            };

        }
    ]}
}]);

/**
* @ngdoc directive
* @name common.directive:dropdownMultiselect
* @restrict 'E'
* @element
* @scope
* @description 
* This is custom directive used on add project page for multiselect dropdown for clients.
**/
angular.module('common', ['projectIdService', 'ng-breadcrumbs'])
.directive('dropdownMultiselect', ['$rootScope', function ($rootScope) {
    return {
        restrict: 'E',
        scope: {
            model: '=',
            options: '=',
            pre_selected: '=preSelected'
        },
        template: "<div class='btn-group' data-ng-class='{open: open}'>" +
         "<button class='client_str btn btn-small btn-width' data-ng-click='open=!open;openDropdown()'>Select Client(s)</button>" +
                 "<button class='btn btn-small dropdown-toggle' data-ng-click='open=!open;openDropdown()'><span ng-class=\"open ? 'caret-close-dropdown' : 'caret' \"></span></button>" +
                 "<ul class='dropdown-menu' aria-labelledby='dropdownMenu'>" +
                     "<li><a data-ng-click='selectAll()'><i class='icon-ok-sign'></i>  Check All</a></li>" +
                     "<li><a data-ng-click='deselectAll();'><i class='icon-remove-sign'></i>  Uncheck All</a></li>" +
                     "<li><a><input ng-model='filter' type='text' /></a></li>"+
                     "<li class='divider'></li>" +
                     "<li data-ng-repeat='option in options | orderBy:\"ClientName\" | filter:{ClientName:filter}'> <a data-ng-click='setSelectedItem()' title={{option.ClientName}}>{{option.ClientName}}<span data-ng-class='isChecked(option.Id)'></span></a></li>" +
                 "</ul>" +
             "</div>",
        controller: ['$scope',function ($scope) {

            $scope.openDropdown = function () {
                $('.new-project-dropdown div').removeClass('open');
                $('.new-project-dropdown div button span').removeClass('caret-close-dropdown');
                $('.new-project-dropdown div button span').addClass('caret');
                $scope.ObjectId = [];
                for (var i = 0; i < $scope.pre_selected.length; i++) {
                    $scope.ObjectId.push($scope.pre_selected[i].id);
                }
                $scope.filter = '';
            };

            $scope.selectAll = function () {
                $scope.model = _.pluck($scope.options, 'Id');
                $rootScope.$broadcast('selectedModel', $scope.model);
            };
            $scope.deselectAll = function () {
                var warning = confirm("Are you sure you wish to remove this client from this project? If you continue, it will lose related brands in the brands dropdown.");
                if (warning == true) {
                    $scope.model = [];
                    $rootScope.$broadcast('selectedModel', $scope.model);
                } else {
                }
            };
            $scope.setSelectedItem = function () {
                var Id = this.option.Id;


                if (_.contains($scope.model, Id)) {
                    var warning = confirm("Are you sure you wish to remove this client from this project? If you continue, it will lose related brands in the brands dropdown.");
                    if (warning == true) {
                        $scope.model = _.without($scope.model, Id);
                        $rootScope.$broadcast('selectedModel', $scope.model);
                        return false;
                    } else {
                    }
                } else {
                    $scope.model.push(Id);
                }

                $rootScope.$broadcast('selectedModel', $scope.model);
                return false;
            };
            $scope.isChecked = function (Id) {
                if (_.contains($scope.model, Id)) {
                    return 'icon-ok pull-right';
                }
                return false;
            };
        }
    ]}
}]);

/**
* @ngdoc directive
* @name common.directive:multiSelectDragLeftRightProjectEdit
* @restrict 'E'
* @element select 
* @scope
* @description 
* This is custom directive for multi select drag left to right and vice versa on project Edit page.
**/
angular.module('common', ['projectIdService', 'ng-breadcrumbs'])
.directive('multiSelectDragLeftRightProjectEdit', function () {
    return {
        restrict: 'E',
        scope: {
            selectedModel: '=',
            leftList: '=',
            rightList: '=',
            unselectedModel: '=',
            tranSourceLeftList: '=',
            tranSourceRightList: '=',
            langdrop: '=',
            confirmationMsg: '='
        },
        template:
         "<button type='button' class='btn btn-default btn-forward'  ng-click='moveRight()' >&gt;&gt;</button>" +
                 "<button type='button' class='btn btn-default btn-backward' ng-click='moveLeft()' >&lt;&lt;</button>",
        controller: ['$scope', '$timeout', function (scope, $timeout) {
            scope.moveRight = function () {
                for (var i = 0 ; i < scope.selectedModel.length ; i++) {
                    if (scope.langdrop == true) {
                        scope.selectedModel[i].TranslationSourceRequired = false;
                    }
                    scope.rightList.push(scope.selectedModel[i]);
                    var index = scope.leftList.indexOf(scope.selectedModel[i]);
                    if (index > -1) {
                        scope.leftList.splice(index, 1);
                    }
                }

                var temp = [];
                angular.copy(scope.rightList, temp);
                scope.rightList = [];
                $timeout(function () { scope.rightList = temp }, 20);

            };
            scope.moveLeft = function () {
                if (scope.langdrop == true) {
                    if (scope.unselectedModel != undefined && scope.unselectedModel.length > 0) {
                        $('#languageRemove .modal-body').html('Data may be associated with selected language(s). Do you still want to remove it?');
                        $('#languageRemove').modal('show');
                    }
                } else {
                    $('#categoryRemove .modal-body').html('Data may be associated with the Additional Information option(s). Do you still want to remove it?');
                    $('#categoryRemove').modal('show');
                }

                //for (var i = 0 ; i < scope.unselectedModel.length ; i++) {
                //    scope.leftList.push(scope.unselectedModel[i]);
                //    var index = scope.rightList.indexOf(scope.unselectedModel[i]);
                //    if (index > -1) {
                //        scope.rightList.splice(index, 1);
                //    }
                //}
            };
        }
        ]

    }
});

/**
* @ngdoc directive
* @name common.directive:multiSelectDragLeftRightSourceSetup
* @restrict 'E'
* @element select 
* @scope
* @description 
* This is custom directive for multi select drag left to right and vice versa on source setup page.
**/
angular.module('common', ['projectIdService', 'ng-breadcrumbs'])
.directive('multiSelectDragLeftRightSourceSetup', function () {
    return {
        restrict: 'E',
        scope: {
            selectedModel: '=',
            leftList: '=',
            rightList: '=',
            unselectedModel: '='
        },
        template:
         "<button type='button' class='permission-template-button btn btn-default btn-open'  ng-click='moveRight()' >&gt;&gt;</button>" +
                 "<button type='button' class='permission-template-button btn btn-default btn-open' ng-click='moveLeft()' >&lt;&lt;</button>",
        controller: ['$scope', function (scope) {
            scope.moveRight = function () {
                for (var i = 0 ; i < scope.selectedModel.length ; i++) {
                    scope.rightList.push(scope.selectedModel[i]);
                    var index = scope.leftList.indexOf(scope.selectedModel[i]);
                    if (index > -1) {
                        scope.leftList.splice(index, 1);
                    }
                }

            };
            scope.moveLeft = function () {
                for (var i = 0 ; i < scope.unselectedModel.length ; i++) {
                    scope.leftList.push(scope.unselectedModel[i]);
                    var index = scope.rightList.indexOf(scope.unselectedModel[i]);
                    if (index > -1) {
                        scope.rightList.splice(index, 1);
                    }
                }
            };
        }
        ]

    }
});

/**
* @ngdoc directive
* @name common.directive:ownerDropdown
* @restrict 'E'
* @element select 
* @scope
* @description 
* This is custom directive for multi select dropdown for project owners on add/edit project.
**/
angular.module('common', ['projectIdService', 'ng-breadcrumbs'])
.directive('ownerDropdown', ['$rootScope', function ($rootScope) {
    return {
        restrict: 'E',
        scope: {
            model: '=',
            options: '=',
            pre_selected: '=preSelected'
        },
        template: "<div id='OwnerDD' class='btn-group' data-ng-class='{open: open}'>" +
         "<button class='owner_str btn btn-small btn-width' data-ng-click='open=!open;openDropdown()'>Select Owner(s)</button>" +
                 "<button class='btn btn-small dropdown-toggle' data-ng-click='open=!open;openDropdown()'><span ng-class=\"open ? 'caret-close-dropdown' : 'caret' \"></span></button>" +
                 "<ul class='dropdown-menu' aria-labelledby='dropdownMenu'>" +
                     "<li><a><input ng-model='filter' type='text' /></a></li>"+
                     "<li data-ng-repeat='option in options | orderBy:\"OwnerName\" | filter:{OwnerName:filter}'> <a data-ng-click='setSelectedItem()' title={{option.OwnerName}}-{{option.OwnerMailId}}>{{option.OwnerName}} - {{option.OwnerMailId}}<span data-ng-class='isChecked(option)'></span></a></li>" +
                 "</ul>" +
             "</div>",
        controller: ['$scope',function ($scope) {

            $scope.openDropdown = function () {
                $('.new-project-dropdown div').removeClass('open');
                $('.new-project-dropdown div button span').removeClass('caret-close-dropdown');
                $('.new-project-dropdown div button span').addClass('caret');
                $scope.ObjectId1 = [];
                for (var i = 0; i < $scope.pre_selected.length; i++) {
                    $scope.ObjectId1.push($scope.pre_selected[i]);
                }
                $scope.filter = '';
            };

            $scope.selectAll = function () {
                $scope.model = $scope.options;
                
                $rootScope.$broadcast('ownerselectedModel', $scope.model);
            };
            $scope.deselectAll = function () {
                $scope.model = [];
                
                $rootScope.$broadcast('ownerselectedModel', $scope.model);
            };
            $scope.setSelectedItem = function () {
                var optionSelected = this.option;
                if (_.contains($scope.model, optionSelected)) {
                    $scope.model = _.without($scope.model, optionSelected);
                } else {
                    $scope.model.push(optionSelected);
                }
                
                $rootScope.$broadcast('ownerselectedModel', $scope.model);
                return false;
            };
            $scope.isChecked = function (Id) {
                if (_.contains($scope.model, Id)) {
                    return 'icon-ok pull-right';
                }
                return false;
            };
        }
    ]}
}]);

/**
* @ngdoc directive
* @name common.directive:searchDropDown
* @restrict 'E'
* @element select 
* @scope
* @description 
* This is custom directive for multi select dropdowns on search page.
**/
angular.module('common', ['projectIdService', 'ng-breadcrumbs'])
.directive('searchDropDown', ['$rootScope', function ($rootScope) {
    return {
        restrict: 'E',
        scope: {
            allcolumns: '=',
            addinfcolist: '=',
            sectioncollist: '=',
            sourcetermlist: '=',
            languagelist: '=',
            alllangcolumns: '=',
            importfunc: '&',
            allselect:'&',
            clientitems: '=',
            branditems: '=',
            projectitems: '=',
            langitems: '=',
            transitems: '=',
            prop: '@',
            func: '&',
            clist: '=',
            blist: '=',
            plist: '=',
            tlist: '=',
            status: '=',
            id: '@',
            buttonlabel: '=',
            selecttype: '@'
        },
        template: "<div class='btn-group' data-ng-class='{open: open, divPaddingForNetflix : netflix}'>" +
         "<button class='client_str btn btn-small btn-width ms-dropdown-style ms-dropdown-style-search' data-ng-class='{widthfornetflix : netflix}' data-ng-mouseleave='open=!open;' data-ng-mouseenter='open=!open;' >{{buttonlabel}}</button>" +
         "<button class='btn btn-small dropdown-toggle' data-ng-mouseleave='open=!open;' data-ng-mouseenter='open=!open;'><span class='caret'></span></button>" +
         "<ul id='{{id}}' class='dropdown-menu' aria-labelledby='dropdownMenu' data-ng-mouseleave='open=!open;'>" +
                     "<li data-ng-hide='singleSelect'><a data-ng-click='selectAll()'><i class='icon-ok-sign'></i>  Check All</a></li>" +
                     "<li data-ng-hide='singleSelect'><a data-ng-click='deselectAll();'><i class='icon-remove-sign'></i>  Uncheck All</a></li>" +
                     "<li><a data-ng-class='{inputPaddingTop: singleSelect}' ><input ng-model='propFilter' type='text' /></a></li>" +
                     "<li class='divider'></li>" +
                     "<li data-ng-repeat='item in items | filter:propFilter' >" +
                     "<a data-ng-click='pushItem(item);' title={{item[prop]}}>{{item[prop]}}<span data-ng-class='isChecked(item)'></span></a>" +
                    "</li>" +
                 "</ul>" +
             "</div>",

        controller: ['$scope', function ($scope) {
            $scope.clist = [];
            $scope.blist = [];
            $scope.plist = [];
            $scope.tlist = [];
            $scope.items = [];
            //for dropdowns of netflix KNP import
            $scope.addinfcolist = [];
            $scope.sectioncollist = [];
            $scope.sourcetermlist = [];
            $scope.languagelist = [];
            $scope.singleSelect = false;
            $scope.netflix = false;
        }],

        link: function (scope, elem, attrs) {

            //hide select all and deselect all options for single select dropdown
            if (attrs.selecttype && attrs.selecttype == "single") {
                scope.singleSelect = true;
            }

            //set dropdown width different for netflix
            if (["addInfoColumnNames", "sectionColumnName", "sourceTermColumnName", "languageColumnNames"].includes(attrs.prop)) {
                scope.netflix = true;
            }
                var arrayToBeUpdated = [];
                //check for which dropdown user is on
                switch (attrs.prop) {
                    case "ClientName":
                        arrayToBeUpdated = scope["clist"];
                       
                        scope.$watch('clientitems', function (newValue, oldValue, scope) {
                            scope.items = newValue;
                        }); 
                        
                        break;

                    case "BrandName":
                        arrayToBeUpdated = scope["blist"];
                        
                        scope.$watch('branditems', function (newValue, oldValue, scope) {
                            scope.items = newValue;
                        });
                        break;

                    case "ProjectTitle":
                        arrayToBeUpdated = scope["plist"];
                        scope.$watch('projectitems', function (newValue, oldValue, scope) {
                            scope.items = newValue;
                        });
                        
                        break;

                    case "LanguageName":
                        arrayToBeUpdated = scope["tlist"];
                        scope.$watch('langitems', function (newValue, oldValue, scope) {
                            scope.items = newValue;
                        });
                        
                        break;

                    case "TranslationStatusText":
                        arrayToBeUpdated = scope["status"];

                        scope.$watch('transitems', function (newValue, oldValue, scope) {
                            scope.items = newValue;
                        });
                        break;

                        //for dropdowns of netflix KNP import
                    case "addInfoColumnNames":
                        arrayToBeUpdated = scope["addinfcolist"];
                        
                        scope.$watch('allcolumns', function (newValue, oldValue, scope) {
                            scope.items = newValue;

                            //below code is to check/tick in dropdown if SOURCE TERM NOTES and FREQUENCY column is present in excel file 
                            if (scope.items && arrayToBeUpdated.length === 0) {
                                let sourceNotesCol = { addInfoColumnNames: "SOURCE TERM NOTES", sectionColumnName: "SOURCE TERM NOTES", sourceTermColumnName: "SOURCE TERM NOTES", languageColumnNames:"SOURCE TERM NOTES"};
                                let frequencyCol = { addInfoColumnNames: "FREQUENCY", sectionColumnName: "FREQUENCY", sourceTermColumnName: "FREQUENCY", languageColumnNames:"FREQUENCY"};
                                for (var i = 0; i < scope.items.length; i++) {
                                    if (angular.equals(scope.items[i], sourceNotesCol) || angular.equals(scope.items[i], frequencyCol)) {
                                        arrayToBeUpdated.push(scope.items[i]);
                                    }
                                }
                            }

                            //check only selected items
                            checkSelectedItems();
                        });
                        
                        break;

                    case "sectionColumnName":
                        arrayToBeUpdated = scope["sectioncollist"];

                        scope.$watch('allcolumns', function (newValue, oldValue, scope) {
                            scope.items = newValue;

                            //below code is to check/tick in dropdown if TYPE column is present in excel file 
                            if (scope.items && arrayToBeUpdated.length === 0) {
                                let typeCol = { addInfoColumnNames: "TYPE", sectionColumnName: "TYPE", sourceTermColumnName: "TYPE",languageColumnNames: "TYPE"};
                                for (var i = 0; i < scope.items.length; i++) {
                                    if (angular.equals(scope.items[i], typeCol)) {
                                        arrayToBeUpdated.push(scope.items[i]);
                                    }
                                }
                            }

                            //check only selected items
                            checkSelectedItems();
                        });
                        break;

                    case "sourceTermColumnName":
                        arrayToBeUpdated = scope["sourcetermlist"];

                        scope.$watch('allcolumns', function (newValue, oldValue, scope) {
                            scope.items = newValue;

                            //below code is to check/tick in dropdown if NAME column is present in excel file 
                            if (scope.items && arrayToBeUpdated.length === 0) {
                                let nameCol = { addInfoColumnNames: "NAME", sectionColumnName: "NAME", sourceTermColumnName: "NAME",languageColumnNames: "NAME" };
                                for (var i = 0; i < scope.items.length; i++) {
                                    if (angular.equals(scope.items[i], nameCol)) {
                                        arrayToBeUpdated.push(scope.items[i]);
                                    }
                                }
                            }

                            //check only selected items
                            checkSelectedItems();
                        });
                        break;

                    case "languageColumnNames":
                        arrayToBeUpdated = scope["languagelist"];

                        scope.$watch('alllangcolumns', function (newValue, oldValue, scope) {
                            scope.items = newValue;
                        });
                        break; 

                }

            //function to check/tick selected items
                var checkSelectedItems = function () {
                    //check only selected items
                    $('#' + scope.id + ' .dropdown-menu li a span').each(function () {
                        for (var i = 0; i < arrayToBeUpdated.length; i++) {
                            if (arrayToBeUpdated[scope.prop] === $(this).parent().text()) {
                                $(this).addClass('icon-ok pull-right');
                            }
                        }
                    });
                    //set button label for alredy tiked items
                    setButtonLabel();
                };

            //sets button label
                var setButtonLabel = function () {
                    //button label-show selected items on button label
                    if (arrayToBeUpdated.length > 0) {
                        scope.buttonlabel = "";
                        for (var i = 0; i < arrayToBeUpdated.length; i++) {
                            if (scope.buttonlabel.length === 0) {
                                scope.buttonlabel = arrayToBeUpdated[i][scope.prop];
                            } else if (scope.buttonlabel.length > 0) {
                                scope.buttonlabel += ", " + arrayToBeUpdated[i][scope.prop];
                            }

                        }
                    }
                };


               

           

            //cancel close function
            scope.cancelClose = function ($event) {
                $event.stopPropagation();
            };

            
           
            //select/unselct item function
            scope.pushItem = function (item) {
                
                //select/unselect item from dropdown list
                var isFound = false;
                var index = -1;
                for (var i = 0; i < arrayToBeUpdated.length; i++) {
                    if (angular.equals(arrayToBeUpdated[i], item)) {
                        isFound = true;
                        index = i;
                        break;
                    }
                }
                if (isFound) {
                    arrayToBeUpdated.splice(index, 1);
                    checkSelectedItems();
                } else {
                    if (["addInfoColumnNames", "sectionColumnName", "sourceTermColumnName","languageColumnNames"].includes(attrs.prop)) {
                        if (scope.importfunc()(item, attrs.prop) === false) {
                            return;
                        } 
                    }

                    if (attrs.selecttype == "single") {
                        if (arrayToBeUpdated.length > 0) {
                            arrayToBeUpdated.length = 0;
                        } 
                    }
                    arrayToBeUpdated.push(item);
                }

                //call set button label
                setButtonLabel();

                //call func only when its present in attribute
                if (attrs.func) {
                    scope.func()(attrs.prop);
                }
            };

            //select all function
            scope.selectAll = function () {
                arrayToBeUpdated.length = 0;

                //function if user checks select all from addtional info column those options will not be ticked which are already in other dropdowns
                if (attrs.prop === "addInfoColumnNames" || attrs.prop === "languageColumnNames") {
                    //creating new items array which does not contain already selected items in other two dropdowns
                    let newItems = scope.allselect()(scope.items, attrs.prop);
                    angular.copy(newItems, arrayToBeUpdated);
                } else {
                    angular.copy(scope.items, arrayToBeUpdated);
                }

                //call set button label
                setButtonLabel();

                if (attrs.func) {
                    scope.func()(attrs.prop);
                }

            };

            //unselect all function
            scope.deselectAll = function () {
                arrayToBeUpdated.length = 0;
                $('#' + scope.id + ' .dropdown-menu li a span').each(function () {
                    $(this).removeClass('icon-ok pull-right');
                });
               
                if (attrs.func) {
                    scope.func()(attrs.prop);
                }
            };

            //ischecked function
            scope.isChecked = function (item) {
                //select/unselect item from dropdown list
                var isFound = false;
                for (var i = 0; i < arrayToBeUpdated.length; i++) {
                    if (angular.equals(arrayToBeUpdated[i], item)) {
                        isFound = true;
                        break;
                    }
                }

                if (isFound) {
                    return 'icon-ok pull-right';
                }
                return false;
            };

        }
    }

}]);

/**
* @ngdoc directive
* @name common.directive:translatorClientDropdown
* @restrict 'E'
* @element select 
* @scope
* @description 
* This is custom directive for multi select dropdown for clients list on translation page.
**/
angular.module('common', ['projectIdService', 'ng-breadcrumbs'])
.directive('translatorClientDropdown', ['$rootScope', function ($rootScope) {
    return {
        restrict: 'E',
        scope: {
            model: '=',
            options: '=',
            pre_selected: '=preSelected'
        },
        template: "<div class='btn-group' data-ng-class='{open: open}'>" +
         "<button class='client_str btn btn-small btn-width' data-ng-click='open=!open;openDropdown()'>Select Client(s)</button>" +
                 "<button class='btn btn-small dropdown-toggle' data-ng-click='open=!open;openDropdown()'><span class='caret'></span></button>" +
                 "<ul class='dropdown-menu' aria-labelledby='dropdownMenu'>" +
                     "<li><a data-ng-click='selectAll()'><i class='icon-ok-sign'></i>  Check All</a></li>" +
                     "<li><a data-ng-click='deselectAll();'><i class='icon-remove-sign'></i>  Uncheck All</a></li>" +
                     "<li class='divider'></li>" +
                     "<li data-ng-repeat='option in options'> <a data-ng-click='setSelectedItem()'>{{option.ClientName}}<span data-ng-class='isChecked(option.Id)'></span></a></li>" +
                 "</ul>" +
             "</div>",
        controller: ['$scope',function ($scope) {

            $scope.openDropdown = function () {
                $scope.ObjectId2 = [];
                for (var i = 0; i < $scope.pre_selected.length; i++) {
                    $scope.ObjectId2.push($scope.pre_selected[i].id);
                }

                $scope.ObjectId1 = [];
                for (var i = 0; i < $scope.pre_selected.length; i++) {
                    $scope.ObjectId1.push($scope.pre_selected[i].id);
                }
            };

            $scope.selectAll = function () {
                $scope.model = _.pluck($scope.options, 'Id');
                
                $rootScope.$broadcast('translaorSelectedModel', $scope.model);
            };
            $scope.deselectAll = function () {
                $scope.model = [];
                
                $rootScope.$broadcast('translaorSelectedModel', $scope.model);
            };
            $scope.setSelectedItem = function () {
                var Id = this.option.Id;
                if (_.contains($scope.model, Id)) {
                    $scope.model = _.without($scope.model, Id);
                } else {
                    $scope.model.push(Id);
                }
                
                $rootScope.$broadcast('translaorSelectedModel', $scope.model);
                return false;
            };
            $scope.isChecked = function (Id) {
                if (_.contains($scope.model, Id)) {
                    return 'icon-ok pull-right';
                }
                return false;
            };
        }
    ]}
}]);

/**
* @ngdoc directive
* @name common.directive:userClientDropdown
* @restrict 'E'
* @element select 
* @scope
* @description 
* This is custom directive for multi select dropdown for clients list on users page.
**/
angular.module('common', ['projectIdService', 'ng-breadcrumbs'])
.directive('userClientDropdown', ['$rootScope', function ($rootScope) {
    return {
        restrict: 'E',
        scope: {
            model: '=',
            options: '=',
            pre_selected: '=preSelected'
        },
        template: "<div class='btn-group' data-ng-class='{open: open}'>" +
         "<button class='client_str btn btn-small btn-width ms-dropdown-style' data-ng-mouseover='open=!open;openDropdown()' data-ng-mouseleave='open=!open;openDropdown()'>Select Client(s)</button>" +
                 "<button class='btn btn-small dropdown-toggle' data-ng-mouseover='open=!open;openDropdown()' data-ng-mouseleave='open=!open;openDropdown()'><span class='caret'></span></button>" +
                 "<ul class='dropdown-menu' aria-labelledby='dropdownMenu' data-ng-mouseleave='open=!open;openDropdown()'>" +
                     "<li><a data-ng-click='selectAll()'><i class='icon-ok-sign'></i>  Check All</a></li>" +
                     "<li><a data-ng-click='deselectAll();'><i class='icon-remove-sign'></i>  Uncheck All</a></li>" +
                     "<li class='divider'></li>" +
                     "<li data-ng-repeat='option in options'> <a data-ng-click='setSelectedItem()'>{{option.ClientName}}<span data-ng-class='isChecked(option.ClientId)'></span></a></li>" +
                 "</ul>" +
             "</div>",
        controller: ['$scope', function ($scope) {
            $scope.openDropdown = function () {
                $scope.ObjectId1 = [];
                for (var i = 0; i < $scope.pre_selected.length; i++) {
                    $scope.ObjectId1.push($scope.pre_selected[i]);
                }
              //  $rootScope.$broadcast('selectedModel', $scope.model);
            };

            $scope.selectAll = function () {
         
                $scope.model = _.pluck($scope.options , 'ClientId');
                
                $rootScope.$broadcast('selectedModel', $scope.model);
            };
            $scope.deselectAll = function () {
            
                var warning = confirm("Are you sure you wish to remove this client from this user? If you continue, they will lose all access to this client as well as any older projects that they had previously worked on.");
                if (warning == true) {
                    $scope.model = [];
                    $rootScope.$broadcast('selectedModel', $scope.model);
                } else {
                    
                }
                
                
            };
            $scope.setSelectedItem = function () {
                var optionSelected = this.option.ClientId;

                if (_.contains($scope.model, optionSelected)) {
                    var warning = confirm("Are you sure you wish to remove this client from this user? If you continue, they will lose all access to this client as well as any older projects that they had previously worked on.");
                    if (warning == true) {
                        $scope.model = _.without($scope.model, optionSelected);
                        $rootScope.$broadcast('selectedModel', $scope.model);
                        return false;
                    } else {
                        
                    }
                    
                } else {
                    
                    $scope.model.push(optionSelected);
                }
                
                $rootScope.$broadcast('selectedModel', $scope.model);
                return false;
            };
            
            $scope.isChecked = function (Id) {
                if (_.contains($scope.model, Id)) {
                    return 'icon-ok pull-right';
                }
                return false;
            };

        }
    ]}
}]);

/**
* @ngdoc directive
* @name common.directive:userProjectDropdown
* @restrict 'E'
* @element select 
* @scope
* @description 
* This is custom directive for multi select dropdown for projects list on users page.
**/
angular.module('common', ['projectIdService', 'ng-breadcrumbs'])
.directive('userProjectDropdown', ['$rootScope', function ($rootScope) {
    return {
        restrict: 'E',
        scope: {
            model: '=',
            options: '=',
            disabledstateproject: '=',
            pre_selected: '=preSelected'
        },
        template: "<div class='btn-group' data-ng-class='{open: open}' data-ng-disabled={{'disabledstateproject'}}>" +
         "<button data-ng-disabled={{'disabledstateproject'}} class='project_str btn btn-small btn-width ms-dropdown-style' data-ng-mouseover='open=!open;openDropdown()' data-ng-mouseleave='open=!open;openDropdown()'>Select Project(s)</button>" +
                 "<button data-ng-disabled={{'disabledstateproject'}} class='btn btn-small dropdown-toggle' data-ng-mouseover='open=!open;openDropdown()' data-ng-mouseleave='open=!open;openDropdown()'><span class='caret'></span></button>" +
                 "<ul class='dropdown-menu UserProjectDropdown' aria-labelledby='dropdownMenu' data-ng-mouseleave='open=!open;openDropdown()'>" +
                     "<li><a data-ng-click='selectAll()'><i class='icon-ok-sign'></i>  Check All</a></li>" +
                     "<li><a data-ng-click='deselectAll();'><i class='icon-remove-sign'></i>  Uncheck All</a></li>" +
                     "<li class='divider'></li>" +
                     "<li data-ng-repeat='option in options' class='UserProjectDropdownLi'> <a data-ng-click='setSelectedItem()' title={{option.ClientProjectName}}>{{option.ClientProjectName}}<span data-pid={{option.ProjectId}} data-ng-class='isChecked(option.ProjectId)'></span></a></li>" +
                 "</ul>" +
             "</div>",
        controller: ['$scope',function ($scope) {

            $scope.openDropdown = function () {
                $scope.ObjectId = [];
                for (var i = 0; i < $scope.pre_selected.length; i++) {
                    $scope.ObjectId.push($scope.pre_selected[i]);
                }
                
                $rootScope.$broadcast('projectselectedModel', $scope.model);
            };

            $scope.selectAll = function () {
                $scope.model = _.pluck($scope.options, 'ProjectId');
                
                $rootScope.$broadcast('projectselectedModel', $scope.model);
            };
            $scope.deselectAll = function () {
                $scope.model = [];
                
                $rootScope.$broadcast('projectselectedModel', $scope.model);
            };
            $scope.setSelectedItem = function () {
                var optionSelected = this.option.ProjectId;
                if (_.contains($scope.model, optionSelected)) {
                    $scope.model = _.without($scope.model, optionSelected);
                } else {
                    $scope.model.push(optionSelected);
                }
                
                $rootScope.$broadcast('projectselectedModel', $scope.model);
                return false;
            };
            $scope.isChecked = function (Id) {
                if (_.contains($scope.model, Id)) {
                    return 'icon-ok pull-right';
                }
                return false;
            };
        }
    ]}
}]);