/**
 * @ngdoc service
 * @name Users.UserAuthenticateService 
 * @requires AngularJS.$http 
 * 
 * @description
 * This is service in users module. It contains methods which are used to authenticate user while logging in to system. 
 *  
**/
angular.module('users', ['ngRoute', 'common', 'gmUsersModule', 'angularUtils.directives.dirPagination'])
.service('UserAuthenticateService', ['$http',
function ($http) {

    /**
    * 
    * @ngdoc function
    * @name Users.UserAuthenticateService#getUserAuthenticate
    * @methodOf Users.UserAuthenticateService
    * @description
    *   This method is used to check if user with entered username and pass present in database or not.
    *   Checks if user is authenticated or not.  
    * @param {string} user This is the username entered by user in input field on login page.
    * @param {string} pass This is the password entered by user in input field on login page.
    * @returns {undefined} This method doesn't return.
    */
    this.getUserAuthenticate = function (user, pass, callbackGood, callbackBad) {
       
        $http({
            method: "post",
            url: 'Login/AuthenticateUser/',
            data: {
                UserName: user,
                Password: pass
            }
            
        })
        .success(function (data, status, headers, config) {
            callbackGood(data, status, headers, config);
        })
        .error(function (data, status, headers, config) {
            callbackBad(data, status, headers, config);
            return false;
        })
    },

    /**
    * 
    * @ngdoc function
    * @name Users.UserAuthenticateService#sendForgotPasswordEmail
    * @methodOf Users.UserAuthenticateService
    * @description
    *   This method is used to send email of password reset link to user.
    *   Accepts users email id as input.
    * @param {string} userEmailId This is the email id entered by user in input field on forgot password popup.
    * @returns {undefined} This method doesn't return.
    */
    this.sendForgotPasswordEmail = function(userEmailId, callbackGood, callbackBad){
        $http({
            method: 'POST',
            url: "Users/ForgotPassword",
            data: userEmailId
        }).success(function (data) {
            callbackGood(data);
        })
        .error(function (data) {
            callbackBad(data);
            return false;
        })
    }
}
]);