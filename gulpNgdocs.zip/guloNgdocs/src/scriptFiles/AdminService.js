/**
 * @ngdoc service
 * @name Admin.AdminService
 * @requires AngularJS.$http
 * @requires common.commonService
 * 
 * @description
 * This is service in Admin module. It contains methods which are used for different operations done on admin page.
 *  
**/
gmAdminModule.service('AdminService', ['$http', 'commonService', function ($http, commonService) {

    var ADMINSERVICE = {

          /**
        * @ngdoc function
        * @name Admin.AdminService#getClientsBrandsCategoriesSections
        * @methodOf Admin.AdminService
        * @param {Number} userId This is the userid of current logged in user.
        * @description
        * This service is used to get info on page load.
        * @returns {Object}  This method returns object with all the initial data
        */
        getClientsBrandsCategoriesSections: function (userId, callback) {
            $http({
                method: 'get',
                url: '/Admin/ClientBrandList/' + userId
            })
                .success(function (clientlist) {
                    callback(clientlist);
                })
                .error(function (e) {
                    callback(e);
                });
        },

        //****Client Services start
          /**
        * @ngdoc function
        * @name Admin.AdminService#addClient
        * @methodOf Admin.AdminService
        * @param {Object} addNewClient This is the new added client object with client name as property.
        * @description
        * This service is used to add client
        * @returns {Boolean}  This method returns true/false.If operation is successful then true else false.
        */
        addClient: function (addNewClient, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: 'POST',
                    url: "Admin/AddClient",
                    data: addNewClient,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (data) {
                        callback(data);
                    })
                    .error(function (e) {
                        callback(e);
                    })
            });
        },

         /**
        * @ngdoc function
        * @name Admin.AdminService#editClient
        * @methodOf Admin.AdminService
        * @param {Object} editClientName This is the new added client object with client name as property.
        * @description
        * This service is used to add client
        * @returns {Boolean}  This method returns true/false. If operation is successful then true else false.
        */
        editClient: function (editClientName, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: 'POST',
                    url: "Admin/EditClient",
                    data: editClientName,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (data) {
                        callback(data);
                    })
                    .error(function (e) {
                        callback(e);
                    })
            });

        },
        //****Client Services end

        //****Brands Services start
        //Service to get Brands To Associate
         /**
        * @ngdoc function
        * @name Admin.AdminService#getBrandsToAssociate
        * @methodOf Admin.AdminService
        * @param {Number} clientId This is the selected client id.
        * @description
        * This service is used to list of brands
        * @returns {Array}  This method returns list of all brands.
        */
        getBrandsToAssociate: function (clientId, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "get",
                    url: '/Admin/GetAssociateBrands/' + clientId,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (data) {
                        callback(data);
                    })
                    .error(function (e) {
                        callback(e);
                    })
            });
        },

          /**
        * @ngdoc function
        * @name Admin.AdminService#associateBrand
        * @methodOf Admin.AdminService
        * @param {Object} associateBrandObj This is the object contains selected client id and brand id.
        * @description
        * This service is used to associate brand to client
        * @returns {Boolean}  This method returns true/false. If operation is successful then true else false.
        */
        associateBrand: function (associateBrandObj, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: 'POST',
                    url: "Admin/AssociateBrand",
                    data: associateBrandObj,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                }).
                    success(function (data) {
                        callback(data);
                    }).
                    error(function (e) {
                        callback(e);
                    })
            });
        },

         /**
        * @ngdoc function
        * @name Admin.AdminService#deassociateBrand
        * @methodOf Admin.AdminService
        * @param {Object} associateBrandObj This is the object contains selected client id and brand id.
        * @description
        * This service is used to De-associate brand
        * @returns {Boolean}  This method returns true/false. If operation is successful then true else false.
        */
        deassociateBrand: function (deassociateBrandObj, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: 'POST',
                    url: "Admin/DissociateBrand",
                    data: deassociateBrandObj,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                }).
                    success(function (data) {
                        callback(data);
                    }).
                    error(function (e) {
                        callback(e);
                    })
            });
        },

          /**
        * @ngdoc function
        * @name Admin.AdminService#addBrand
        * @methodOf Admin.AdminService
        * @param {Object} addBrandObj This is the new added brand object with brand name as property.
        * @description
        * This service is used to add brand
        * @returns {Boolean}  This method returns true/false.If operation is successful then true else false.
        */
        addBrand: function (addBrandObj, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: 'POST',
                    url: "Admin/AddBrand",
                    data: addBrandObj,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (data) {
                        callback(data);
                    })
                    .error(function (e) {
                        callback(e);
                    })
            });
        },

          /**
        * @ngdoc function
        * @name Admin.AdminService#editBrand
        * @methodOf Admin.AdminService
        * @param {Object} editBrandObj This is the brand object with brand name as property.
        * @description
        * This service is used to edit brand
        * @returns {Boolean}  This method returns true/false.If operation is successful then true else false.
        */
        editBrand: function (editBrandObj, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: 'POST',
                    url: "Admin/EditBrand",
                    data: editBrandObj,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (data) {
                        callback(data);
                    })
                    .error(function (e) {
                        callback(e);
                    })
            });
        },
        //****Brands Services end

        //****Sections Services start

          /**
        * @ngdoc function
        * @name Admin.AdminService#addSection
        * @methodOf Admin.AdminService
        * @param {Object} addSectionObj This is the new added section object with section name as property.
        * @description
        * This service is used to add section
        * @returns {Boolean}  This method returns true/false.If operation is successful then true else false.
        */
        addSection: function (addSectionObj, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: 'POST',
                    url: "Admin/AddSection",
                    data: addSectionObj,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (data) {
                        callback(data);
                    })
                    .error(function (e) {
                        callback(e);
                    })
            });
        },
       
         /**
        * @ngdoc function
        * @name Admin.AdminService#editSection
        * @methodOf Admin.AdminService
        * @param {Object} editSectionObj This is the section object with section name as property.
        * @description
        * This service is used to edit section
        * @returns {Boolean}  This method returns true/false.If operation is successful then true else false.
        */
        editSection: function (editSectionObj, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: 'POST',
                    url: "Admin/EditSection",
                    data: editSectionObj,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (data) {
                        callback(data);
                    }).
                    error(function (e) {
                        callback(e);
                    })
            });
        },

          /**
        * @ngdoc function
        * @name Admin.AdminService#associateSection
        * @methodOf Admin.AdminService
        * @param {Object} associateSectionObj This is the object contains selected client id and section id.
        * @description
        * This service is used to associate section to client
        * @returns {Boolean}  This method returns true/false. If operation is successful then true else false.
        */
        associateSection: function (associateSectionObj, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: 'POST',
                    url: "Admin/AssociateSection",
                    data: associateSectionObj,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (data) {
                        callback(data);
                    })
                    .error(function (e) {
                        callback(e);
                    })
            });
        },
       
          /**
        * @ngdoc function
        * @name Admin.AdminService#deassociateSection
        * @methodOf Admin.AdminService
        * @param {Object} clientSectionId This is the object contains selected client id and section id.
        * @description
        * This service is used to De-associate section
        * @returns {Boolean}  This method returns true/false. If operation is successful then true else false.
        */
        deassociateSection: function (clientSectionId, callback) {
            $http.get('Admin/DissociateSection/' + clientSectionId)
                .success(function (data) {
                    callback(data);
                })
                .error(function (e) {
                    callback(e);
                })
        },
        //****Sections Services end

        //****Categories Services start.
      /**
        * @ngdoc function
        * @name Admin.AdminService#getGlobalCategories
        * @methodOf Admin.AdminService
        * @description
        * This service is used to list of global categories
        * @returns {Array}  This method returns list of all global categories.
        */
        getGlobalCategories: function (callback) {
            $http({
                method: "get",
                url: "/Admin/GetGlobalCategory/"
            })
                .success(function (globalCategories) {
                    callback(globalCategories);
                })
                .error(function (e) {
                    callback(e);
                })
        },

         /**
        * @ngdoc function
        * @name Admin.AdminService#addNewGlobalCategory
        * @methodOf Admin.AdminService
        * @param {Object} newGlobalCategory This is the new added global category object with category name as property.
        * @description
        * This service is used to add new global catagory
        * @returns {Boolean}  This method returns true/false.If operation is successful then true else false.
        */
        addNewGlobalCategory: function (newGlobalCategory, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "/Admin/AddGlobalCategory",
                    data: {
                        CategoryName: newGlobalCategory
                    },
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }

                })
                    .success(function (status) {
                        callback(status);
                    })
                    .error(function (e) {
                        callback(e);
                    })
            });
        },

      
         /**
        * @ngdoc function
        * @name Admin.AdminService#updateNewGlobalCategory
        * @methodOf Admin.AdminService
        * @param {Object} editedGlobalCategory This is the global category object with category name as property.
        * @description
        * This service is used to edit global catagory
        * @returns {Boolean}  This method returns true/false.If operation is successful then true else false.
        */
        updateNewGlobalCategory: function (editedGlobalCategory, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "/Admin/EditGlobalCategory",
                    data: editedGlobalCategory,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }

                })
                    .success(function (status) {
                        callback(status);
                    })
                    .error(function (e) {
                        callback(e);
                    })
            });
        }
        //****Categories Services end

    }
    return ADMINSERVICE;

}]);