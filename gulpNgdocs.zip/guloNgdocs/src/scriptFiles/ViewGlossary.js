/**
 * @ngdoc object
 * @name ViewGlossary
 * @element html
 * 
 * @requires $routeProvider
 * @requires $locationProvider
 * @requires ngRoute
 * 
 * @description
 * This is view glossary module, which will contain controller for view glossary. 
 *
 */

var ViewGlossary = angular.module('viewGlossary', ['ngRoute', 'ngGrid'])

ViewGlossary.config(['$routeProvider','$locationProvider',function ($routeProvider, $locationProvider) {
   $routeProvider
    .when('/', {
        templateUrl: "/ViewGlossaryController/Content/ngviews/ViewGlossary.html",
        controller: "viewGlossaryController"
    })

}]);