/**
 * @ngdoc object
 * @name Preferences
 * @element html
 * 
 * @requires AngularJS.$routeProvider
 * @requires AngularJS.$locationProvider
 * @requires AngularJS.ngRoute
 * 
 * @description
 * This is preferences module, which will contain controller for my profile page. 
 * 
 */
var Preferences = angular.module('preferences', ['ngRoute', 'common', 'gmPreferencesModule','ui.bootstrap', 'gmProjectsModule']);

Preferences.config(['$routeProvider', '$locationProvider', '$httpProvider', function ($routeProvider, $locationProvider, $httpProvider) {
    $httpProvider.interceptors.push('myInterceptor');
    $routeProvider

  .when('/', {
      templateUrl: "PreferencesController/Content/ngviews/Preferences.html",
      controller: "preferencesController"
  })

 
}])

Preferences.factory('myInterceptor', function () {
    var requestInterceptor = {
        request: function (config) {
            localStorage.setItem('time', new Date());
            return config;
        }
    };

    return requestInterceptor;
});