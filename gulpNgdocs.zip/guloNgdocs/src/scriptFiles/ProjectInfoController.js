/**
 * @ngdoc controller
 * @name Projects.controller:ProjectInfoController
 * @element div
 *
 * @description
 * This Controller is responsible for showing content on project info page.
 *
 * @requires AngularJS.$scope
 * @requires AngularJS.$http
 * @requires AngularJS.$location
 * @requires AngularJS.$route
 * @requires AngularJS.$timeout
 * @requires common
 * @requires common.commonService
 * @requires Projects.LandingPageData
 * 
 * @property {Object} userDetails:Object This is object stores the user details received  from backend when user is logged in. 
 * @property {Object} ProjectInfo:Object This property is object contains all the information of current project, which is to be displayed on project info page.
 * @property {Boolean} IsLocked:Boolean This property is boolean, if project lock status is locked the its true else it is false
 * @property {Boolean} excludeNTL_FD :Boolean This property is boolean, depends on exclude NTL/FD checkbox.
 * @property {String} currentProjectId:String This property is encrypted project id.
 * 
 */
Projects.controller('projectInfoController', ['$scope', '$http', '$location', 'LandingPageData', 'commonService', '$routeParams', 'ProjectIdService', function ($scope, $http, $location, LandingPageData, commonService, $routeParams, ProjectIdService) {
    $scope.showLoader = false;
    var currentProjectId;
    var userDetails = commonService.getLocalData('userDetails');
    $scope.excludeNTL_FD = true;

     /**
     * @ngdoc
     * @name init
     * @methodOf Projects.controller:ProjectInfoController
     * @description
     *This method is called at the beginning  of page load and used for initialisation of variables on page load
     *@return {undefined} This method does not return.
     */
    var init = function () {
        $scope.showLoader = true;
        currentProjectId = commonService.getSessionData('projectIBreadCrumb');
        //client object to string
        $scope.owner_str = '';
        $scope.client_str = '';
        $scope.brand_str = '';

        //Calling service to get the project wise information
        LandingPageData.getPageInfoData(currentProjectId, userDetails.UserId, $scope.excludeNTL_FD, function (projects) {
            $scope.ProjectInfo = projects;
            $scope.showLoader = false;
            $scope.IsLocked = $scope.ProjectInfo.ProjectModel.IsLocked;
            dynamicScreenHeight();

            //brand object to string; client object to string
            for (var i = 0; i < $scope.ProjectInfo.ProjectModel.Owners.length; i++) {
                $scope.owner_str = $scope.owner_str + $scope.ProjectInfo.ProjectModel.Owners[i].OwnerName + ', ';
            }
            $scope.owner_str = $scope.owner_str.slice(0, -2);

            for (var i = 0; i < $scope.ProjectInfo.ProjectModel.Clientlist.length; i++) {
                $scope.client_str = $scope.client_str + $scope.ProjectInfo.ProjectModel.Clientlist[i].ClientName + ', ';
            }
            $scope.client_str = $scope.client_str.slice(0, -2);

            for (var i = 0; i < $scope.ProjectInfo.ProjectModel.ProjectBrands.length; i++) {
                $scope.brand_str = $scope.brand_str + $scope.ProjectInfo.ProjectModel.ProjectBrands[i].BrandName + ', ';
            }
            $scope.brand_str = $scope.brand_str.slice(0, -2);
        });
    };

       /**
     * @ngdoc
     * @name excludeNTL_FD_Count
     * @methodOf Projects.controller:ProjectInfoController
     * @description
     * This method is called to exclude/include NTL/FD count.
     *@return {undefined} This method does not return.
     */
    $scope.excludeNTL_FD_Count = function () {
        if (!$scope.excludeNTL_FD) {
            $scope.excludeNTL_FD = false;
        }
        LandingPageData.getPageInfoData(currentProjectId, userDetails.UserId, $scope.excludeNTL_FD, function (projects) {
            $scope.ProjectInfo = projects;
        });
    };

    /**
     * @ngdoc
     * @name inconsistentTranslation
     * @methodOf Projects.controller:ProjectInfoController
     * @param {Number} languageId This is language id of language 
     * @description
     * This method is called to open inconsistent translation details popup.
     *@return {undefined} This method does not return.
     */
    $scope.inconsistentTranslation = function (languageId) {
        $scope.inconsistentMasterGlossaries = {};
        for (var i = 0; i < $scope.ProjectInfo.ProjectLanguageUser.length; i++) {
            if ($scope.ProjectInfo.ProjectLanguageUser[i].ProjectListItem.LanguageId === languageId) {
                $scope.inconsistentMasterGlossaries = $scope.ProjectInfo.ProjectLanguageUser[i].ProjectListItem.MasterGlossaries;
                $scope.inconsistentLanguage = $scope.ProjectInfo.ProjectLanguageUser[i].ProjectListItem.LanguageName;
            }
        }
        $('#inconsistentTranslation').modal({ backdrop: 'static', keyboard: false });
        $('#inconsistentTranslation').modal('show');
    };

        /**
     * @ngdoc
     * @name changeView
     * @methodOf Projects.controller:ProjectInfoController
     * @param {string} new_path The Name of the view bound with element on which this function is called.

     * @description
     * This function is called to change views and loads respective html page.Below are some views
     * Glossary, Source Setup, Add project, Edit Project,Project Permissions,Project Info
     * @returns {undefined} This method does not return.
     */
    $scope.changeView = function (new_path) {
        var currProjID = $scope.ProjectInfo.ProjectModel.ProjectId;
        switch (new_path) {
            case "editProject":

                $location.path('/projectInfo/editProject');
                break;
            case "addProject":

                $location.path('/projectInfo/addProject');
                break;
            case "glossary":

                if ($scope.ProjectInfo.IsAllSectionInActive === true) {
                    $scope.errorMessage = 'No Glossary Available for the selected project!';
                    $('#errorModal').modal('show');
                    break;
                } else {
                    $location.path('/projectInfo/glossary');
                }
                break;

            case "projectPermissions":

                $location.path('/projectInfo/projectPermissions');
                break;
        }
    };

    init();

}]);
