/**
 * @ngdoc service
 * @name Preferences.PreferencesService
 * @requires AngularJS.$http
 * @requires common.commonService
 * 
 * @description
 * This is service in preferences module. It contains methods which are used for different operations done on my profile page.
 *  
**/
gmPreferencesModule.service('PreferencesService', ['$http', 'commonService', function ($http, commonService) {

    var PREFERENCESERVICE = {

         /**
        * @ngdoc function
        * @name Preferences.PreferencesService#changePassword
        * @methodOf Preferences.PreferencesService
        * @param {Object} password This is password object which contains new and old password.
        * @description
        * This service is used to change password.
        * @returns {String}  This method returns success message.
        */
        changePassword: function (password, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "Users/ChangePassword",
                    data: password,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (success) {
                        callback(success);
                    })
                    .error(function (e) {
                        callback(e);
                    });
            });
        },
        
        /**
        * @ngdoc function
        * @name Preferences.PreferencesService#getUserEmailNotification
        * @methodOf Preferences.PreferencesService
        * @param {Number} userId This is user id of logged in user.
        * @description
        * This service is used to change password.
        * @returns {Array}  This method returns list of notification settings.
        */
        getUserEmailNotification: function (userId, callback) {
            $http.get('Users/GetUserEmailNotification/' + userId)
                .success(function (preferenceList) {
                    callback(preferenceList);
                })
                .error(function (e) {
                    callback(e);
                });
        },
          
        /**
        * @ngdoc function
        * @name Preferences.PreferencesService#updateUserConfirmationForNextTime
        * @methodOf Preferences.PreferencesService
        * @param {Object} data This is object contains all the details entered in my profile page.
        * @description
        * This service is used to update user information.
        * @returns {Boolean}  This method returns true if operation is successful
        */
        updateUserConfirmationForNextTime: function (data, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: 'POST',
                    url: "Users/UpdateUserConfirmationForNextTime",
                    data: data,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (data) {
                        callback(data);
                    })
                    .error(function (e) {
                        callback(e);
                    });
            });
        },

       /**
        * @ngdoc function
        * @name Preferences.PreferencesService#saveEmailNotification
        * @methodOf Preferences.PreferencesService
        * @param {Object} data This is object contains information about selected notifications.
        * @description
        * This service is used to save notification settings on my profile page.
        * @returns {Boolean}  This method returns true if operation is successful
        */
        saveEmailNotification: function (data, callback) {
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: 'POST',
                    url: "Users/SaveEmailNotification",
                    data: data,
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                    .success(function (preferenceList) {
                        callback(preferenceList);
                    })
                    .error(function (e) {
                        callback(e);
                    });
            });
        }
    };
    return PREFERENCESERVICE;
}]);