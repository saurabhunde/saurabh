/**
* @ngdoc directive
* @name Projects.directive:permission
* @restrict 'E'
* @element input
* @requires Projects.ProjectPermissionsService
* @requires AngularJS.$route
* @scope
* @description 
* This is custom directive created for assigning projects permissions to users.
**/

Projects.directive("permission", ['$routeParams', 'ProjectPermissionsService', 'ProjectIdService', '$route', function ($routeParams, ProjectPermissionsService, ProjectIdService, $route) {
    return {
        scope: {
            rule: '=',
            permission: '=',
            index: '@',
            cellnumber: '@',
            projectid:'@',
            callbackFn: '&',
            loaderFn:'&',
            userdetails: '=',
            projectinfo: '='
        },
        restrict: 'E',
        transclude: true,
        templateUrl: '/ProjectsController/Content/Directives/ProjectPermissionsTemplate.html',
        link: function (scope, el, attr) {
            scope.$watch('projectinfo', function (newVal) {
                if (newVal) {  
            //declaring the variables
            scope.data = [];
            scope.data.push(scope.permission.ProjectUserNameList);
            scope.selectedUserList = [];
            scope.selectUser = [];
            scope.unselectUser = [];
            scope.userList = [];
            scope.addSelectedUser = [];
            scope.updateUserDetails = {
                ProjectId: null,
                LanguageId: null,
                UserIds: [],
                UserRole: null
            };
            //GLMGR-169
            scope.userDetailsNew = [];
            scope.userDetailsNew.push(scope.userdetails.UserRoles[0].UserRoleName);
            scope.ProjectInfoNew = [];
            if (scope.projectinfo != undefined) {
                scope.ProjectInfoNew.push(scope.projectinfo.UserPermissionList);
            }
            //GLMGR-169 end

            //function used to push Role Wise user information in a commonly used array.
            var pushSelectedUserInfo = function (selectedUserList) {
                for (var j = 0; j < selectedUserList.length; j++) {
                    scope.addSelectedUser.push(selectedUserList[j].UserName);
                    scope.selectUser.push(selectedUserList[j]);
                }
                
            };

            //To populate the user list in the popup on load of the page
            scope.populateListOnLoad = function myfunction(role) {
                switch(role){
                    case 'Translator':
                        pushSelectedUserInfo(scope.data[0].ProjectTranslatorName);
                        break;

                    case 'Read Only Translator':
                        pushSelectedUserInfo(scope.data[0].ProjectReadOnlyTranslatorName);
                        break;

                    case 'Super Access Translator':
                        pushSelectedUserInfo(scope.data[0].ProjectSuperAccessTranslatorName);
                        break;

                    case 'Super Access Approver':
                        pushSelectedUserInfo(scope.data[0].ProjectSuperAccessApproverName);
                        break;
                    case 'Approver As Translator':
                        pushSelectedUserInfo(scope.data[0].ProjectApproverTranslatorName);
                        break;

                    case 'Approver':
                        pushSelectedUserInfo(scope.data[0].ProjectApproverName);
                        break;
                    case 'Read Only Approver':
                        pushSelectedUserInfo(scope.data[0].ProjectReadOnlyApproverName);
                        break;
                    case 'Translator As Approver':
                        pushSelectedUserInfo(scope.data[0].ProjectTranslatorApproverName);
                        break;
                }
            };

            //function on click of the input box when the modal popup opens
            scope.populateUserListInPopup = function (role) {
                //re-initialising variables on click of the input box

                scope.userList = [];
                scope.groupList = [];
                scope.LanguageUserName = [];
                //According to the role assign the users
                switch (role) {
                    case 'Translator':
                        angular.copy(scope.data[0].LanguageTranslatorName, scope.userList);
                        angular.copy(scope.data[0].LanguageTranslatorGroupNames, scope.groupList);
                        break;

                    case 'Read Only Translator':
                        angular.copy(scope.data[0].LanguageReadOnlyTranslatorName, scope.userList);
                        angular.copy(scope.data[0].LanguageReadOnlyTranslatorGroupNames, scope.groupList);
                        break;

                    case 'Super Access Translator':
                        angular.copy(scope.data[0].LanguageSuperAccessTranslatorName, scope.userList);
                        angular.copy(scope.data[0].LanguageSuperAccessTranslatorGroupNames, scope.groupList);
                        break;

                    case 'Super Access Approver':
                        angular.copy(scope.data[0].LanguageSuperAccessApproverName, scope.userList);
                        angular.copy(scope.data[0].LanguageSuperAccessApproverGroupNames, scope.groupList);
                        break;

                    case 'Approver As Translator':
                        angular.copy(scope.data[0].LanguageApproverTranslatorName, scope.userList);
                        angular.copy(scope.data[0].LanguageApproverTranslatorGroupNames, scope.groupList);
                        break;

                    case 'Approver':
                        angular.copy(scope.data[0].LanguageApproverName, scope.userList);
                        angular.copy(scope.data[0].LanguageApproverGroupNames, scope.groupList);
                        break;
                    case 'Read Only Approver':
                        angular.copy(scope.data[0].LanguageReadOnlyApproverName, scope.userList);
                        angular.copy(scope.data[0].LanguageReadOnlyApproverGroupNames, scope.groupList);
                        break;
                        
                    case 'Translator As Approver':
                        angular.copy(scope.data[0].LanguageTranslatorApproverName, scope.userList);
                        angular.copy(scope.data[0].LanguageTranslatorApproverGroupName, scope.groupList);
                    break;
                }

            };

            scope.showGroupUsers = function () {
                if (scope.selectedGroup) {
                    scope.userList = [];
                    angular.copy(scope.selectedGroup.Users, scope.userList);

                    for (var i = 0; i < scope.selectUser.length; i++) {
                        for (var j = 0; j < scope.userList.length; j++) {
                            if (scope.userList[j].UserId === scope.selectUser[i].UserId) {
                                scope.userList.splice(j, 1);
                                break;
                            }
                        }
                    }
                }
              
            };
            scope.showAllUsers = function () {
                scope.populateUserListInPopup(scope.rule.UserName);

                for (var i = 0; i < scope.selectUser.length; i++) {
                    for (var j = 0; j < scope.userList.length; j++) {
                        if (scope.userList[j].UserId === scope.selectUser[i].UserId) {
                            scope.userList.splice(j, 1);
                            break;
                        }
                    }
                }
            };

            //Add the selected permissions from the popup to the table
            scope.saveSelectedPermissions = function (rule) {
                scope.addSelectedUser = [];
                //add selected users from left side of the list to the right side of the user list
                for (var i = 0; i < scope.selectUser.length; i++) {
                    scope.addSelectedUser.push(scope.selectUser[i].UserName);
                }
                scope.updateUserDetails.ProjectId = scope.projectid;
                scope.updateUserDetails.LanguageId = scope.permission.LanguageId;
                
                var adminUser = JSON.parse(localStorage.getItem('adminUser'));

                if (adminUser) {
                    scope.updateUserDetails['OriginalUserId'] = adminUser.UserId;
                } else {
                     scope.updateUserDetails['OriginalUserId'] = null;
                }

                //add unselected users from right side of the list to the left side of the user list
                for (var i = 0; i < scope.selectUser.length; i++) {
                    scope.updateUserDetails.UserIds.push(scope.selectUser[i].UserId);
                }
                scope.updateUserDetails.UserRole = rule.UserId;
                //call the function to save the list to the db
                scope.saveUsersList(scope.updateUserDetails);
                $('.user-permission-textbox').prop('disabled', true);
                $('.modal-backdrop.fade.in').css('display', 'none');
            };

            //Function to save the user list to db
            scope.saveUsersList = function (updateUserDetails) {
                scope.loaderFn();
                //calling the service to save user list to db
                ProjectPermissionsService.savePermissionsUserList(updateUserDetails, function (status) {
                    if (status) {
                        scope.callbackFn();
                        init();
                    }
                    else {
                        scope.loaderFn();
                    }
                });
            };

            //Add Selected Users From Left List to Right List
            scope.addSelectedUsers = function (selectedUsers) {
                var index;
                for (var i = 0; i < selectedUsers.length; i++) {
                    scope.selectUser.push(selectedUsers[i]);
                    for (var j = 0; j < scope.userList.length; j++) {
                        if (scope.userList[j].UserId == scope.selectedUsers[i].UserId) {
                            scope.userList.splice(j, 1);
                        }
                    }
                }
            }

            //Remove the selected users from right list to left list
            scope.removeSelectedUsers = function (removedUsers) {
                for (var i = 0; i < removedUsers.length; i++) {
                    scope.unselectUser.push(removedUsers[i]);
                    scope.userList.push(removedUsers[i]);
                    for (var j = 0; j < scope.selectUser.length; j++) {
                        if (removedUsers[i].UserId == scope.selectUser[j].UserId) {
                                scope.selectUser.splice(j, 1); 
                        }
                    }
                }
            }

            //function to cancel the selection
            scope.cancelSelection = function () {
                init();
            }

            //load user list and pits permissions assigned on page load 
            var init = function () {
                //initialising the variables
                scope.data = [];
                scope.data.push(scope.permission.ProjectUserNameList);
                scope.selectedUserList = [];
                scope.selectUser = [];
                scope.unselectUser = [];
                scope.userList = [];
                scope.addSelectedUser = [];
                scope.updateUserDetails = {
                    ProjectId: null,
                    LanguageId: null,
                    UserIds: [],
                    UserRole: null
                };
                scope.populateListOnLoad(scope.rule.UserName);
            }
            init();

        }
    }, true);
        }
    };
}]);