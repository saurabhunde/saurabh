/**
 * @ngdoc service
 * @name Users.UserAuthorizationService 
 * @requires AngularJS.$http
 * @requires common.commonService
 * 
 * @description
 * This is service in users module. It contains methods which are used to authenticate user while logging in to system.
 * This service is called after UserAuthentication service.
 *  
**/

angular.module('users', ['ngRoute', 'common', 'gmUsersModule', 'angularUtils.directives.dirPagination'])
.service('UserAuthorizationService', ['$http','commonService',

   function ($http, commonService) {
       var _userdetails = {};

  /**
    * 
    * @ngdoc function
    * @name Users.UserAuthorizationService#getUserAuthorization
    * @methodOf Users.UserAuthorizationService
    * @description
    *   This method is used to get all the details of user after logging in of user.
    * @param {string} user This is the username entered by user in input field on login page.
    * @returns {object} This method returns object with all user details as properties in it eg. user role (Admin,super Admin).
    */
       this.getUserAuthorization = function (user, callbackGood, callbackBad) {
            $http({
                method: "post",
                url: "Login/GetUserDetails",
                data: {
                    UserName: user
                }
                      
            }).success(function (data, status, headers, config) {
                _userdetails = data;
                callbackGood(data, status, headers, config);
            })
            .error(function (data, status, headers, config) {
                callbackBad(data, status, headers, config)
            })
       },

    /**
    * 
    * @ngdoc function
    * @name Users.UserAuthorizationService#updateUserTermAccepted
    * @methodOf Users.UserAuthorizationService
    * @description
    *   This method is used to set terms accepted flag in database.
    * @param {int} userId This is the userid of user.
    * @returns {boolean} This method returns true/false depending on user action, If user accepts terms and conditions returns true else returns false. 
    */
        this.updateUserTermAccepted = function (userId, callbackGood, callbackBad) {
           
                $http({
                    method: "post",
                    url: "Login/UpdateUserTermAccepted",
                    data: {
                        UserId: userId
                    }
                }).success(function (data, status, headers, config) {
                    _userdetails.IsTermAccepted = data;
                    callbackGood(data, status, headers, config);
                })
               .error(function (data, status, headers, config) {
                   callbackBad(data, status, headers, config)
               })
        },

       this.userDetails = _userdetails;

   }
]);
