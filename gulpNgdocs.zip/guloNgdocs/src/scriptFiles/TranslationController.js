/**
 * @ngdoc controller
 * @name Projects.controller:TranslationController
 * @element div
 *
 * @description
 * This Controller is responsible for showing content on project glossary translation page.
 *
 * @requires AngularJS.$scope
 * @requires AngularJS.$rootScope
 * @requires AngularJS.$http
 * @requires AngularJS.$location
 * @requires AngularJS.$route
 * @requires AngularJS.$timeout
 * @requires common.commonService
 * @requires Projects.Glossary
 * 
 * @property {Object} userDetails:Object This is object stores the user details received from backend when user is logged in. 
 * @property {Object} glossaryData:Object This is object stores all glossary data.
 * @property {Object} gridOptions:Object This is object store ng grid configuration
 * @property {Array} facdata:Array This is array of objects contains data property of gridOptions 
 * @property {Array} defdata:Array This is array of objects column definitions for ng grid column set as columnDefs property in gridOptions
 * @property {Boolean} hideAddInfoCols:Boolean This property stores the boolean value of hide additional info column checkbox.
 * @property {Boolean} hideEmptyAddInfoCols:Boolean This property stores the boolean value of hide empty additional info column checkbox.
 * @property {Boolean} isTranslationSourceRequired:Boolean This property stores the boolean value of hide translation source column checkbox.
 * @property {Boolean} isStarred:Boolean This property stores the boolean value of hide starred column checkbox
 * @property {String} hc_nopin_source:String This property is header template for Translation Source column.
 * @property {String} hc_nopin:String This property is header template for categories
 * @property {String} hc_nopin_language:String This property is header template for Languages(left to right)
 * @property {String} hc_nopin_language_rtl:String This property is header template for Languages(right to left)
 * @property {String} hc_nopin_master_rtl:String This property is header template for master-language(source term)(right to left)
 * @property {String} celltemp:String This property is cell template of glossary table cells
 * @property {String} editCellTempForEngDescript:String This property is editable English Description cell template -- used when user double clicks on cell in ng-grid and it becomes editable . Here it is disabled and only used to copy text 
 * @property {String} editCellTempForCat:String This property is editable other category cell template -- used when user double clicks on cell in ng-grid and it becomes editable . Here it is disabled and only used to copy text 
 *
 * 
 */
Projects.controller('translationController', ['$scope', '$rootScope', '$http', '$route', '$location', 'Glossary', 'commonService', '$routeParams', 'ProjectIdService', 'saveBlob', 'LandingPageData', function ($scope, $rootScope, $http, $route, $location, Glossary, commonService, $routeParams, ProjectIdService, saveBlob, LandingPageData) {
    $scope.cmntbtn = false; // add comment button enable disable variable
    $rootScope.headerId = "";
    var isVisible = false;
    sessionStorage.setItem('isVisible', false);
    $scope.searchmode = true;
    $scope.TransPage = true; // GLMGR-916
    var count = 0;
    $scope.glossaryEditMode = true;
    var transSourceRequired = false;
    $scope.isValidField = false;
    $scope.searchResultStatus = false;
    $scope.exoprtTabToggle = false;
    $scope.isValidExport = false;
    $scope.filter = false;
    $scope.noData = false;
    $scope.defaultGlossarySectionType = true;
    $scope.ntlGlossarySectionType = false;
    $scope.allexportlanguages = {};
    $scope.allexportlanguages.status = false;
    $scope.allSferaLangSelected = {};
    $scope.allSferaLangSelected.status = false;
    $scope.sferaEnglishOnly = false;
    $scope.exportGlossary = true;
    $scope.sendGlossarybtn = false;
    $scope.ValidationMsgSfera = "";
    $scope.isValidSferaExport = false;
    $scope.sfersExport = false;
    $scope.includeAll = {};
    $scope.includeAll.status = false
    $scope.approveOnly = {};
    $scope.approveOnly.status = false
    $scope.sferaExportPass = {};
    $scope.sferaExportPass.pass = "";
    $scope.englishOnlyChecked = false;
    $scope.allExportxslsSectioncheck = {};
    $scope.allExportxslsSectioncheck.status = false;
    $scope.allExportxslslanguagecheck = {};
    $scope.allExportxslslanguagecheck.status = false;
    $scope.allexportsection = {};
    $scope.allexportsection.status = false;
    $scope.allCategories = {};
    $scope.allCategories.status = false;
    $scope.allLanguages = {};
    $scope.allLanguages.status = false;
    $scope.validationMsgSaveAsExcel = 'At least one category and one Language need to be selected';
    $scope.submitshow = true;
    var winWidth = window.innerWidth;
    var emailRegex = new RegExp("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$");
    $rootScope.languageSelected = "";
    $scope.facdata = [];
    $scope.defdata = [];
    var Catsequence = [];
    $scope.exportSend = {};
    $scope.totalServerItems = 0;
    $scope.glossaryPageOnly = false;
    $scope.editcmnt = true;
    $scope.glossaryValuesUL = true;
    var GlossaryCheck = {};
    $scope.hideGotoSourceSetup = true;
    var updateUserLockData = {};
    updateUserLockData.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
    updateUserLockData.PageId = JSON.parse(sessionStorage.getItem('resourcePageId'));
    updateUserLockData.ResourceId = sessionStorage.getItem('ResourceId');
    updateUserLockData.SessionId = null;
    var isFrontEndFunctionCalled = {
        'isCheckColorsCalled': false,
        'isHideStarredTermsCalled': false
    };
    $scope.autoApproveReview = false; //GLMGR-206
    $scope.onlyForTranslationTab = true; //GLMGR-1226
    $scope.onlyforApprover = false;
    //GLMGR-1239
    var hideCatCols = true;
    $scope.isCheckedEmptyInfoCols = false;
    $scope.hideEmptyAddInfoCOls = false;

    //GLMGR-1261
    $scope.addTermNote = false;
    var inconsistentFlagForEmptyTranslation = false;

    //GLMGR-1448
    var masterGlossaryId;
    var languageName;
    var projectLangId;
    $scope.allEmail = false;
    $scope.selfEmail = false;
    $scope.approverEmail = false;
    $scope.translatorEmail = false;
    $scope.projectOwnerEmail = false;
    $scope.checkboxValid = false;
    $scope.checkboxValidEdit = false;
    $scope.hideAddCmtbtn = false;
    var EditallEmail = false;
    var EditselfEmail = false;
    var EditapproverEmail = false;
    var EditTranslatorEmail = false;
    var EditprojectOwnerEmail = false;
    $scope.isEditCmt = false;
    var IsAllCategories, IsAllLanguages;
    var masterGlossaries = [];
    var isHavingBlankTranslation = false;
    //ng-grid options for initialization of ng-grid
    $scope.gridOptions = {
        data: 'facdata',
        columnDefs: 'defdata',
        showColumnMenu: true,
        enableCellEdit: true,
        enableColumnResize: true,
        enableColumnReordering: false,
        enablePinning: true,
        enablePaging: true,
        enableSorting: true,
        noKeyboardNavigation: false,
        showFilter: true,
        showGroupPanel: false,
        groupable: false,
        rowHeight: 110,
        multiSelect: false,
        keepLastSelected: false,
        showFooter: false,
        totalServerItems: "totalServerItems"
    };
    $scope.exportPass = ''; //GLMGR-203
    $scope.disableCompleteBtn = false;

     //GLMGR-1597 
    var exportKNP = false;
    var IsTranslationNotes = false;

    //GLMGR-1598 
    $scope.isTranslationSourceRequired = false;
    $scope.transSourceDisabled = true;

    /**
     * @ngdoc
     * @name isStarredChecked
     * @methodOf Projects.controller:TranslationController
     * @description
     * This function is called on yes option on hide starred column popup.This is used to hide/show starred column
     * @returns {undefined} This method does not return.
     */
    $scope.isStarredChecked = function () {

        if ($scope.isStarred) {
            sessionStorage.setItem('hideStarredCol', $scope.isStarred);
            $scope.hideStarredCol = false;
            if ($scope.filter == true) {
                $scope.filterOptions();
            } else {
                $scope.facdata = [];
                $scope.defdata = [];
                GlossaryNgGrid($scope.glossaryData, $scope.headingsDropdown);
            }

        } else {
            sessionStorage.setItem('hideStarredCol', $scope.isStarred);
            $scope.hideStarredCol = true;
            if ($scope.filter == true) {
                $scope.filterOptions();
            } else {
                $scope.facdata = [];
                $scope.defdata = [];
                GlossaryNgGrid($scope.glossaryData, $scope.headingsDropdown);
            }
        }
    };

       /**
     * @ngdoc
     * @name hideTransSourceColumn
     * @methodOf Projects.controller:TranslationController
     * @description
     * This function is called on hide translation source column checkbox.This is used to hide/show translation source column
     * @returns {undefined} This method does not return.
     */
    $scope.hideTransSourceColumn = function () {
        if ($scope.filter == true) {
            $scope.filterOptions();
        } else {
            $scope.facdata = [];
            $scope.defdata = [];
            GlossaryNgGrid($scope.glossaryData, $scope.headingsDropdown);
        }
    };

     /**
     * @ngdoc
     * @name hideStarredColumn
     * @methodOf Projects.controller:TranslationController
     * @description
     * This function is called on hide starred column checkbox.This is used to hide/show starred column
     * @returns {undefined} This method does not return.
     */
    $scope.hideStarredColumn = function () {
        if ($scope.isStarred && $scope.isHavingStarredTerm) {
            $('#hideStrredColModal').modal('show');
        }
        else {
            $scope.isStarredChecked();
        }
    };
    
    //GLMGR -1239
     /**
     * @ngdoc
     * @name hideAddInfoColumns
     * @methodOf Projects.controller:TranslationController
     * @description
     * This function is called on hide add info column checkbox.This is used to hide/show additional info columns
     * @returns {undefined} This method does not return.
     */
    $scope.hideAddInfoColumns = function () {
        hideCatCols = false;
        $scope.isCheckedEmptyInfoCols = true;
        $scope.hideEmptyAddInfoCOls = true;
        sessionStorage.setItem('hideAddInfoCols', $scope.hideAddInfoCOls);

        if ($scope.filter == true) {
            $scope.filterOptions();
        } else {
            $scope.facdata = [];
            $scope.defdata = [];
            GlossaryNgGrid($scope.glossaryData, $scope.headingsDropdown);
        }


    };

    /**
     * @ngdoc
     * @name hideEmptyColumns
     * @methodOf Projects.controller:TranslationController
     * @description
     * This function is called on hide empty add info column checkbox.This is used to hide/show empty additional info columns
     * @returns {undefined} This method does not return.
     */
    $scope.hideEmptyColumns = function () {
        if ($scope.filter == true) {
            $scope.filterOptions();
        } else {
            $scope.facdata = [];
            $scope.defdata = [];
            GlossaryNgGrid($scope.glossaryData, $scope.headingsDropdown);
        }

    };

      /**
     * @ngdoc
     * @name defaultGlossarySection
     * @methodOf Projects.controller:TranslationController
     * @description
     * This function is called on click of default section tab.This is used to switch to default section.
     * @returns {undefined} This method does not return.
     */
    $scope.defaultGlossarySection = function () {
        //GLMGR-1239 reset hide add info cols when switching ntl<>default
        $scope.hideAddInfoCOls = false;
        $scope.isCheckedAddInfoCols = false;
        sessionStorage.setItem('hideAddInfoCols', $scope.hideAddInfoCOls);
        $scope.AdditionInfoCat = true;

        $scope.defaultGlossarySectionType = true;
        $scope.ntlGlossarySectionType = false;
        var temp = 'default';
        $scope.filter = false;
        $scope.headingsDropdown = undefined;
        sessionStorage.setItem('glossaryTab', JSON.stringify(temp));
        sessionStorage.setItem("filterStatus", "undefined");
        sessionStorage.setItem("filterImage", "undefined");
        sessionStorage.setItem("pendingTranslationsFilter", "0");
        sessionStorage.setItem("pendingApprovalsFilter", "0");
        sessionStorage.setItem("approvedFilter", "0");
        sessionStorage.setItem("rejectedFilter", "0");
        sessionStorage.setItem("pendingSuggFilter", "0");
        sessionStorage.setItem("filterOnStatus", "0");

        $('#filterOptionsButton').css("border-style", "none");
        $('#filterOptionsButton').css("border-color", "none");
        $('#filterOptionsButton').css("background-image", "url('../../../Content/Common/Assets/Images/export_n.png')");
        $('#filterOptionsButton').css("color", "white");
        Glossary.getTranslationInitialData($scope.projectId, commonService.getLocalData('userDetails').UserId, 1, glossaryInitialData);
    };

     /**
     * @ngdoc
     * @name ntlGlossarySection
     * @methodOf Projects.controller:TranslationController
     * @description
     * This function is called on click of NTL section tab.This is used to switch to NTL section.
     * @returns {undefined} This method does not return.
     */
    $scope.ntlGlossarySection = function () {
        //GLMGR-1239 reset hide add info cols when switching ntl<>default
        $scope.hideAddInfoCOls = false;
        $scope.isCheckedAddInfoCols = false;
        sessionStorage.setItem('hideAddInfoCols', $scope.hideAddInfoCOls);
        $scope.AdditionInfoCat = true;

        $scope.defaultGlossarySectionType = false;
        $scope.ntlGlossarySectionType = true;
        var temp = 'ntl';
        $scope.filter = false;
        $scope.headingsDropdown = undefined;
        sessionStorage.setItem('glossaryTab', JSON.stringify(temp));
        sessionStorage.setItem("filterStatus", "undefined");
        sessionStorage.setItem("filterImage", "undefined");
        sessionStorage.setItem("pendingTranslationsFilter", "0");
        sessionStorage.setItem("pendingApprovalsFilter", "0");
        sessionStorage.setItem("approvedFilter", "0");
        sessionStorage.setItem("rejectedFilter", "0");
        sessionStorage.setItem("pendingSuggFilter", "0");
        sessionStorage.setItem("filterOnStatus", "0");

        $('#filterOptionsButton').css("border-style", "none");
        $('#filterOptionsButton').css("border-color", "none");
        $('#filterOptionsButton').css("background-image", "url('../../../Content/Common/Assets/Images/export_n.png')");
        $('#filterOptionsButton').css("color", "white");
        Glossary.getTranslationInitialData($scope.projectId, commonService.getLocalData('userDetails').UserId, 2, glossaryInitialData);
    };

     /**
     * @ngdoc
     * @name editCmnt
     * @methodOf Projects.controller:TranslationController
     * @param {Object} cmnt This is comment object containing comment  details .
     * @param {String} showtext This is comment should be appear in text area.
     * @description
     * This function is called on double click of comment in comment popup.This is used to show textarea of comment to be edited.Text area is used for editing the comment in comment popup
     * @returns {undefined} This method does not return.
     */
    $scope.editCmnt = function (cmnt, showtext) {
        $scope.hideAddCmtbtn = true;
        if (cmnt.UserId == commonService.getLocalData('userDetails').UserId) {
            if ($scope.editcmnt == true) {

                $scope[showtext] = true;
                $scope.showtext = showtext;
                $scope.cmnt = cmnt;
                $scope.CommentId = $scope.cmnt.CommentId;
                $scope.editcmnt = false;
                $scope.textcmnt = $scope.cmnt.CommentText;
                $scope.isEditCmt = true;
                EditallEmail = false;
                EditselfEmail = false;
                EditapproverEmail = false;
                EditTranslatorEmail = false;
                EditprojectOwnerEmail = false;
                $scope.previouscomment = $scope.cmnt.CommentText;
                $scope.previouscommentId = $scope.cmnt.CommentId;
                $('#commntCheckboxEdit').find('input:checkbox').prop('checked', false);
            } else {
                alert("Please save previous comment");
            }
        }

    };

    /**
     * @ngdoc
     * @name saveEditedCmnt
     * @methodOf Projects.controller:TranslationController
     * @param {Object} cmnt This is comment object containing comment  details .
     * @param {String} textcmnt This is edited comment
     * @description
     * This function is called on save and send button on edit comment.This function is used for saving edited  comment in comment popup.
     * @returns {undefined} This method does not return.
     */
    $scope.saveEditedCmnt = function (textcmnt, cmnt, showtext) {
            $scope.checkboxValidEdit = false;
            var data = {};
            data.UserId = $scope.cmnt.UserId;
            data.CommentId = $scope.CommentId;
            data.CommentText = textcmnt;
            data.Email = null;
            data.InsertedDate = null;

            if ($scope.adminUser) {
                data['OriginalUserId'] = $scope.adminUser.UserId;
            } else {
                data['OriginalUserId'] = null;
            }

            data['EncryptedProjectId'] = $scope.projectId;
            data['ProjectId'] = $scope.unEncryptedProjectId;
            data['UserName'] = commonService.getLocalData('userDetails').FirstName + " " + commonService.getLocalData('userDetails').LastName;
            data['MasterGlossaryId'] = masterGlossaryId;
            data['LanguageName'] = languageName;
            data['ProjectLanguageId'] = projectLangId;
            data['UserEmailId'] = commonService.getLocalData('userDetails').UserName;

            var checkboxes = $('#commntCheckboxEdit li input[type=checkbox]:checked');
            for (var i = 0; i < checkboxes.length; i++) {
                switch (checkboxes[i].value) {
                    case "self":
                        EditselfEmail = true;
                        break;
                    case "approver":
                        EditapproverEmail = true;
                        break;
                    case "translator":
                        EditTranslatorEmail = true;
                        break;
                    case "projectowner":
                        EditprojectOwnerEmail = true;
                        break;
                }
            }
            data['IsSelf'] = EditselfEmail;
            data['IsSendToApprover'] = EditapproverEmail;
            data['IsSendToTranslator'] = EditTranslatorEmail;
            data['IsSendToProjectOwner'] = EditprojectOwnerEmail;
            console.log("data",data);
            Glossary.saveEditedCmnt(data, function (data) {
                $scope.hideAddCmtbtn = false;
                $scope.showTextArea = false;
                $scope[showtext] = false;
                $scope.editcmnt = true;
                $scope.isEditCmt = false;
            });
        
       
    };

    /**
     * @ngdoc
     * @name cancelComment
     * @methodOf Projects.controller:TranslationController
     * @description
     * This function is called on cancel button on comment popup.This function is used to cancel comment popup
     * @returns {undefined} This method does not return.
     */
    $scope.cancelComment = function () {
        $scope.editcmnt = true;
        $scope[$scope.showtext] = false;
        $scope.textcmnt = "";
        $scope.modal.comments = "";
    };

    /**
     * @ngdoc
     * @name cancelEditCmt
     * @methodOf Projects.controller:TranslationController
     * @description
     * This function is called on cancel button on edit comment.This function is used to cancel edit comment.
     * @returns {undefined} This method does not return.
     */
    $scope.cancelEditCmt = function (showtext) {
        $('#' + $scope.previouscommentId).text($scope.previouscomment);
        $scope.hideAddCmtbtn = false;
        $scope.showTextArea = false;
        $scope[showtext] = false;
        $scope.editcmnt = true;
        $scope.isEditCmt = false;
    };

    //View language info
    $scope.langInfo = function (col) {
        $scope.langInfoId = 0;
        $scope.langInfoDetails = {};
        $scope.attachedFilesList = [];
        $scope.publisher = null;
        $scope.languageComments = null;
        for (var i = 0; i < $scope.GlossaryInitialTerms.ProjectLanguages.length; i++) {
            if (col.displayName == $scope.GlossaryInitialTerms.ProjectLanguages[i].LanguageName) {
                $scope.languageId = $scope.GlossaryInitialTerms.ProjectLanguages[i].LanguageId;
                $scope.langInfoId = $scope.GlossaryInitialTerms.ProjectLanguages[i].ProjectLanguageInfoId;
                $scope.projectlangId = $scope.GlossaryInitialTerms.ProjectLanguages[i].ProjectLanguageId;
            }
        }
        if ($scope.langInfoId != 0) {
            Glossary.getLangInfo($scope.langInfoId, function (langInfoDetails) {
                $scope.langInfoDetails = langInfoDetails;
                $scope.publisher = $scope.langInfoDetails.PublisherName;
                $scope.languageComments = $scope.langInfoDetails.Comments;
            });
        } else {
            callUpdateUserLockService(updateUserLockData);
        }
        $scope.langInfoTitle = col.displayName;
        $('#languageInfo').modal('show');

        //Show Attachments
        LandingPageData.ShowAttachmentToInfo($scope.projectId, $scope.projectlangId, $scope.languageId, function (attachedFilesList) {
            $('#upload_prev').hide();
            $('#no_upload_prev').hide();
            $scope.attachedFilesList = attachedFilesList;


            if ($scope.attachedFilesList.length >= 1) {
                $('#upload_prev').show();
                $('#no_upload_prev').hide();
            } else {
                $('#upload_prev').hide();
                $('#no_upload_prev').show();
            }
        });
    };

    //Save language info
    $scope.saveLangInfo = function () {
        var saveLangModel = {};
        saveLangModel['ProjectLanguageId'] = $scope.projectlangId;
        saveLangModel['ProjectLanguageInfoId'] = $scope.langInfoId;
        saveLangModel['Comments'] = $scope.languageComments;
        saveLangModel['PublisherName'] = $scope.publisher;
        saveLangModel['CurrentUserId'] = commonService.getLocalData('userDetails').UserId;
        Glossary.saveLangInfo(saveLangModel, function (data) {
            $scope.langInfoDetails = {};
            $scope.publisher = null;
            $scope.languageComments = null;
            $scope.langInfoId = 0;
            $('#languageInfo').modal('hide');
            location.reload();
        });

    };

   /**
     * @ngdoc
     * @name searchInGlossaryTerm
     * @methodOf Projects.controller:TranslationController
     * @param {String} glossarySearchCategory This selected search criteria.
     * @description
     * This function is called on Search button on search popup.This is used to search term in glossary by selected criteria.
     * @returns {undefined} This method does not return.
     */
    $scope.searchInGlossaryTerm = function (glossarySearchCategory) {
        $scope.glossaryValuesUL = false;
        $('filter - checkboxes').each(function () {
            $(this).prop("checked", false);
            $(this).prop("disabled", false);
        });
        $scope.FilterLang = '';
        $scope.filterStatus = '';
        $scope.filter = false;
        $scope.searchmode = false;
        var pattern = /[0-9]/g;
        if (!$scope.glossarySearchText) {
            $scope.isValidField = true;
            $scope.errorMsg = 'Please enter the Search Text';
            return false;
        }
        if (!$scope.glossarySearchCategory) {
            $scope.isValidField = true;
            $scope.errorMsg = 'Please select the Search Category';
            return false;
        } else {
            if (glossarySearchCategory === "English Unique Id") {

                if (!pattern.test($scope.glossarySearchText)) {
                    $scope.isValidField = true;
                    $scope.errorMsg = 'Please enter a number as a unique id';
                    return false;
                }
            }
            $scope.isValidField = false;
            $scope.errorMsg = '';
            var ProjectGlossarySearchModel = {};
            ProjectGlossarySearchModel['ProjectId'] = $scope.projectId;
            ProjectGlossarySearchModel['userId'] = commonService.getLocalData('userDetails').UserId;
            ProjectGlossarySearchModel['headerId'] = 0;
            ProjectGlossarySearchModel['SearchCategory'] = $scope.glossarySearchCategory;
            ProjectGlossarySearchModel['SearchText'] = $scope.glossarySearchText;
            $('#searchPopup').modal('hide');
            $scope.showLoader = true;
            Glossary.searchTermInGlossary(ProjectGlossarySearchModel, function (searchList) {
                $scope.searchList = searchList;
                $scope.searchResult = true;
                $scope.resultTable = false;
                $scope.sectionListdrop = true;
                $scope.submitshow = false;
                $scope.showLoader = false;
            });
        }
    };

    //clear search mode
    $scope.clearSearch = function () {
        $scope.submitshow = true;
        location.reload();
    };

    $scope.backToSearch = function () {
        $scope.searchResult = true;
        $scope.resultTable = false;
        $scope.submitshow = false;
    };

    /**
     * @ngdoc
     * @name exportGlossaryToggle
     * @methodOf Projects.controller:TranslationController
     * @param {String} headingName This selected tab name.
     * @description
     * This function is called on tabs in export glossary popup  popup.This is used to toggle between 'send glossary' and 'export excel' tabs in export glossary modal popup
     * @returns {undefined} This method does not return.
     */
    $scope.exportGlossaryToggle = function (headingName) {
        switch (headingName) {
            case 'Xlxs':
                $scope.exportGlossary = true;
                $scope.sendGlossarybtn = false;
                $scope.sfersExport = false;
                break;
            case 'Send':
                $scope.exportGlossary = false;
                $scope.sendGlossarybtn = false;
                $scope.sfersExport = false;
                break;
            case 'Sfera':
                $scope.exportGlossary = false;
                $scope.sendGlossarybtn = false;
                $scope.sfersExport = true;
                break;

        }
    };

    /**
     * @ngdoc
     * @name sendGlossary
     * @methodOf Projects.controller:TranslationController
     * @description
     * This function is called on send glossary button on export glossary popup.This is used to send glossary to particular user  
     * @returns {undefined} This method does not return.
     */
    $scope.sendGlossary = function () {
        var data = {};
        data.ProjectId = $scope.projectId;
        data.ProjectName = $scope.GlossaryInitialTerms.ProjectTitle;

        var categories = [];
        $('.exportCategories:checked').each(function (id, value) {
            categories.push(this.value);

        });
        data.Sections = categories.join();

        var languages = [];
        $('.exportLanguages:checked').each(function (id, value) {
            languages.push(this.value);
        });
        data.Languages = languages.join();

        data.FirstName = $scope.exportSend.firstName;
        data.LastName = $scope.exportSend.lastName;
        data.EmailId = $scope.exportSend.email;
        data.ExpirationDateTime = $scope.exportSend.date;

        if ($scope.adminUser) {
            data['OriginalUserId'] = $scope.adminUser.UserId;
        } else {
            data['OriginalUserId'] = null;
        }

        if (!mandatoryValidation(data)) {
            return false;
        }

        Glossary.sendGlossaryService(data, function (statusData) {
            $scope.exportSend = {};
            $scope.validationMsg = "";
            $scope.isValidField = false;
            $scope.allexportsection.status = false;
            $scope.allexportlanguages.status = false;
            $('input:checkbox').each(function () {
                $(this).prop("checked", false);
                $(this).prop("disabled", false);
            });
            $('#exportSettings').modal('hide');
        });

    };

    //GLMGR-1597
    
  /**
     * @ngdoc
     * @name exportKNPClicked
     * @methodOf Projects.controller:TranslationController
     * @description
     * This function is called on Export in KNP checkbox on export glossary popup.This is used to uncheck all other checkboxes on popup
     * @returns {undefined} This method does not return.
     */
    $scope.exportKNPClicked = function () {
        if ($('#IsExportKNP').prop('checked')) {
            $('.Defchkbox').each(function () {
                $(this).prop("checked", false);
                $(this).prop("disabled", true);
            });
            $('#IsTranslationNotes').prop('checked', true);
        } else {
            $('.Defchkbox').each(function () {
                $(this).prop("checked", true);
                $(this).prop("disabled", false);
            });
            $('#IsTranslationNotes').prop('checked', false);
        }
    };

     /**
     * @ngdoc
     * @name exportModalShow
     * @methodOf Projects.controller:TranslationController
     * @description
     * This function is called on export glossary button on Translation page.This is used to show export glossary popup.
     * @returns {undefined} This method does not return.
     */
    $scope.exportModalShow = function () {
        $('#IsExportKNP').prop('checked', false);
        $('#IsTranslationNotes').prop('checked', false);
        $('#exportSettings').modal({ backdrop: 'static', keyboard: false });
        $('.Defchkbox').each(function () {
            $(this).prop("checked", true);
            $(this).prop("disabled", false);
        });
        $('#exportSettings').modal('show');
    };

     /**
     * @ngdoc
     * @name mandatoryValidation
     * @methodOf Projects.controller:TranslationController
     * @param {Object} data This is object containing all data entered in export glossary popup.
     * @description
     * This function is used for validation on export glossary fields.
     * @returns {undefined} This method does not return.
     */
    var mandatoryValidation = function (data) {
        //Check for all mandatory fields
        if (!data.Sections && !data.EmailId && !data.Languages && !data.ExpirationDateTime) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please enter the mandatory fields!";
            return false;
        }
        if (!data.Sections && !data.EmailId) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please enter the mandatory fields!";
            return false;
        }
        if (!data.Languages && !data.EmailId ) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please enter the mandatory fields!";
            return false;
        }
        if (!data.Sections && !data.Languages) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please enter the mandatory fields!";
            return false;
        }
        if (!data.ExpirationDateTime && !data.Sections) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please enter the mandatory fields!";
            return false;
        }
        if (!data.ExpirationDateTime && !data.Languages) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please enter the mandatory fields!";
            return false;
        }
        if (!data.ExpirationDateTime && !data.EmailId) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please enter the mandatory fields!";
            return false;
        }
        //check for section
        if (!data.Sections) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please select atleast 1 section from the list below.";
            return false;
        }
        if (!data.Languages) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please select atleast 1 language from the list below.";
            return false;
        }
        if (!data.EmailId) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please enter the email id";
            return false;
        }
        if (!data.FirstName) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please enter the first name";
            return false;
        }
        if (!data.LastName) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please enter the last name";
            return false;
        }
        if (!data.ExpirationDateTime) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please enter expiry date and time";
            return false;
        }
        if (!data.EmailId) {
            if (!emailRegex.test(data.EmailId)) {
                $scope.isValidField = true;
                $scope.validationMsg = "Please enter a valid email address";
                return false;
            }
        }

        if (data.ExpirationDateTime) {
            var dte = new Date($scope.exportSend.date);

            if (new Date() > dte) {
                $scope.isValidField = true;
                $scope.validationMsg = "Please select date greater than the current date";
                return false;
            } else {
                $scope.isValidField = false;
                $scope.validationMsg = "";
                return true;
            }
        } else {
            $scope.isValidField = false;
            $scope.validationMsg = "";
            return true;
        }
    };

    /* Starts -- Functions for tabs in export glossary function . This is for clicking of checkboxes of languages and sections along with all buttons in language and section dropdown */
    $scope.allSferalanguages = function () {
        if ($scope.allSferaLangSelected.status == true) {
            $('.exportSferaLanguages:not(:checked)').each(function (id, value) {
                $(this).prop('checked', true);
            });
        } else {
            $('.exportSferaLanguages:checked').each(function (id, value) {
                $(this).prop('checked', false);
            });
        }

        if ($('.exportSferaLanguages:checked').length > 0) {
            $scope.OtherLangsClicked = true;
            $scope.sferaEnglishOnly = false;
            $scope.englishOnlyChecked = false;
            $('.englishOnly').prop('checked', false);
        } else {
            $scope.OtherLangsClicked = false;
        }
    };

    $scope.checkSferaLanguageStatus = function () {
        var count = 0;
        $('.exportSferaLanguages:not(:checked)').each(function (id, value) {
            count++;

        });

        if (count > 0) {
            $scope.allSferaLangSelected.status = false;
        } else {
            $scope.allSferaLangSelected.status = true;
        }

        if ($('.exportSferaLanguages:checked').length > 0) {
            $scope.OtherLangsClicked = true;
            $scope.sferaEnglishOnly = false;
            $scope.englishOnlyChecked = false;
            $('.englishOnly').prop('checked', false);
        } else {
            $scope.OtherLangsClicked = false;
            $scope.englishOnlyChecked = false;
        }
    };

    $scope.sferaEnglishOnlyCheck = function (sferaEnglishOnly) {
        $scope.sferaEnglishOnly = sferaEnglishOnly;
        if (sferaEnglishOnly) {
            $scope.allSferaLangSelected.status = false;
            $scope.englishOnlyChecked = true;
            $scope.includeAll.status = false
            $scope.approveOnly.status = false;
            $('.includeAll .approveOnly').prop('checked', false);
            $('.exportSferaLanguages:checked').each(function (id, value) {
                $(this).prop('checked', false);
            });

        } else {
            $scope.englishOnlyChecked = false;
        }
    };

    $scope.trasnlationCheck = function (check) {
        if (check == 'includeAll') {
            if (!$scope.includeAll || $scope.includeAll.status) {
                $scope.includeAll.status = true;
            } else {
                $scope.includeAll.status = false;
            }
            $scope.approveOnly.status = false;
        } else {
            if (!$scope.approveOnly || $scope.approveOnly.status) {
                $scope.approveOnly.status = true;
            } else {
                $scope.approveOnly.status = false;
            }
            $scope.includeAll.status = false;
        }
    };

    $scope.allsendlanguages = function () {
        if ($scope.allexportlanguages.status == true) {
            $('.exportLanguages:not(:checked)').each(function (id, value) {
                $(this).prop('checked', true);
            });

        } else {
            $('.exportLanguages:checked').each(function (id, value) {
                $(this).prop('checked', false);
            });
        }
    };

    $scope.checkLanguageStatus = function () {
        var count = 0;
        $('.exportLanguages:not(:checked)').each(function (id, value) {
            count++;
        });

        if (count > 0) {
            $scope.allexportlanguages.status = false;
        } else {
            $scope.allexportlanguages.status = true;
        }
    };

    $scope.allsendsection = function () {
        if ($scope.allexportsection.status == true) {
            $('.exportCategories:not(:checked)').each(function (id, value) {
                $(this).prop('checked', true);
            });

        } else {
            $('.exportCategories:checked').each(function (id, value) {
                $(this).prop('checked', false);
            });
        }
    };

    $scope.checSectionStatus = function () {
        var count = 0;
        $('.exportCategories:not(:checked)').each(function (id, value) {
            count++;
        });

        if (count > 0) {
            $scope.allexportsection.status = false;
        } else {
            $scope.allexportsection.status = true;
        }
    };

    $scope.allExportxlslanguages = function () {
        if ($scope.allExportxslslanguagecheck.status == true) {
            $('.languages:not(:checked)').each(function (id, value) {
                $(this).prop('checked', true);
            });

        } else {
            $('.languages:checked').each(function (id, value) {
                $(this).prop('checked', false);
            });
        }
    };

    $scope.checExportLanguagesStatus = function () {
        var count = 0;
        $('.languages:not(:checked)').each(function (id, value) {
            count++;

        });

        if (count > 0) {
            $scope.allExportxslslanguagecheck.status = false;
        } else {
            $scope.allExportxslslanguagecheck.status = true;
        }
    };

    $scope.allExportxlsSection = function () {
        if ($scope.allExportxslsSectioncheck.status == true) {
            $('.categories:not(:checked)').each(function (id, value) {
                $(this).prop('checked', true);
            });
        } else {
            $('.categories:checked').each(function (id, value) {
                $(this).prop('checked', false);
            });
        }
    };

    $scope.checExportSectionStatus = function () {
        var count = 0;
        $('.categories:not(:checked)').each(function (id, value) {
            count++;
        });

        if (count > 0) {
            $scope.allExportxslsSectioncheck.status = false;
        } else {
            $scope.allExportxslsSectioncheck.status = true;
        }
    };

    /* Ends -- Functions for tabs in export glossary function . This is for clicking of checkboxes of languages and sections along with all buttons in language and section dropdown */

    /**
     * @ngdoc
     * @name cancelExport
     * @methodOf Projects.controller:TranslationController
     * @description
     * This function is used to cancel export and close popup
     * @returns {undefined} This method does not return.
     */
    $scope.cancelExport = function () {
        $scope.exportSend = {};
        $scope.validationMsg = "";
        $scope.isValidField = false;
        $scope.allexportsection.status = false;
        $scope.allexportlanguages.status = false;
        $scope.isValidExport = false;
        $scope.allCategories.status = false;
        $scope.allLanguages.status = false;
        $('input:checkbox').each(function () {
            $(this).prop("checked", false);
            $(this).prop("disabled", false);
        });
        $('#exportSettings').modal('hide');
        $scope.exportPass = '';
        $(".exp-password").attr("type", "password");
        $(".exp-Sferapassword").attr("type", "password");
        $('#showHide').prop('checked', false);
        $('#showHideSfera').prop('checked', false);
    };

    //show-hide password GLMGR-203
    $("#showHide").click(function () {
        if ($(".exp-password").attr("type") == "password") {
            $(".exp-password").attr("type", "text");

        } else {
            $(".exp-password").attr("type", "password");
        }
    });

    //show hide password Sfera
    $scope.showPasswordSfera = function () {
        if ($(".exp-Sferapassword").attr("type") == "password") {
            $(".exp-Sferapassword").attr("type", "text");

        } else {
            $(".exp-Sferapassword").attr("type", "password");
        }
    };

     /**
     * @ngdoc
     * @name sFeraValidation
     * @methodOf Projects.controller:TranslationController
     * @description
     * This function is used to validate sFera knp form.
     * @returns {undefined} This method does not return.
     */
    var sFeraValidation = function () {
        if ($('.allLanguage:checked').length === 0 && $('.englishOnly:checked').length === 0 && $('.exportSferaLanguages:checked').length === 0) {
            $scope.ValidationMsgSfera = "At least one Language need to be selected";
            $scope.isValidSferaExport = true;
            return false;
        } else if (!$scope.sferaEnglishOnly && !($scope.includeAll.status || $scope.approveOnly.status)) {
            $scope.ValidationMsgSfera = "Translations is required field";
            $scope.isValidSferaExport = true;
            return false
        } else if (!$scope.sferaExportPass.pass) {
            $scope.ValidationMsgSfera = "Password cannot be empty";
            $scope.isValidSferaExport = true;
            return false;
        } else {
            return true;
        }
    };

       /**
     * @ngdoc
     * @name sferaExport
     * @methodOf Projects.controller:TranslationController
     * @description
     * This function is called on export button in sFera KNP section on export glossary popup.This is used to export glossary with selected options.
     * @returns {undefined} This method does not return.
     */
    $scope.sferaExport = function () {
        if (sFeraValidation()) {
            $scope.showLoader = true;
            var status = {};
            var languages = [];
            $('.exportSferaLanguages:checked').each(function (id, value) {
                languages.push(this.value);
            });
            status['ProjectLanguageId'] = languages;
            status['ProjectId'] = $scope.projectId;
            status['UserId'] = commonService.getLocalData('userDetails').UserId;
            status['IsAllLanguages'] = $scope.allSferaLangSelected.status;
            if ($scope.allSferaLangSelected.status)
                status['IsOnlyEnglish'] = false;
            else
                status['IsOnlyEnglish'] = $scope.sferaEnglishOnly;

            status['password'] = $scope.sferaExportPass.pass;
            status['TranslationIncludeAll'] = $scope.includeAll.status;
            status['TranslationApprovedOnly'] = $scope.approveOnly.status;
            status['UserRoleName'] = commonService.getLocalData('userDetails').UserRoles[0].UserRoleName;

            console.log("status--", status);
            Glossary.exportSFeraKNP(status, function (data) {
                $scope.isValidSferaExport = false;
                $scope.ValidationMsgSfera = "";
                $('input:checkbox').each(function () {
                    $(this).prop("checked", false);
                    $(this).prop("disabled", false);
                });
                $scope.showLoader = false;
                $scope.sferaExportPass.pass = '';
                $(".exp-Sferapassword").attr("type", "password");
                $('#showHideSfera').prop('checked', false);
            });
            $('#exportSettings').modal('hide');
        }
    };

    /**
     * @ngdoc
     * @name exportData
     * @methodOf Projects.controller:TranslationController
     * @description
     * This function is called on export button on export glossary popup.This is used to export glossary with selected options.
     * @returns {undefined} This method does not return.
     */
    $scope.exportData = function () {
        $scope.showLoader = true;
        var status = {};
        $('.status:checked').each(function (id) {
            status[this.id] = true;
        });
        $('.status:not(:checked)').each(function (id, value) {
            status[this.id] = false;
        });

        var categories = [];
        $('.categories:checked').each(function (id, value) {
            categories.push(this.value);
        });
        var languages = [];
        $('.languages:checked').each(function (id, value) {
            languages.push(this.value);
        });
        status['ProjectCategoryId'] = categories;
        status['ProjectLanguageId'] = languages;
        status['ProjectId'] = $scope.projectId;
        status['UserId'] = commonService.getLocalData('userDetails').UserId;
        status['Password'] = $scope.exportPass;
        
        if ($('#IsExportKNP:checkbox:checked').length > 0) {
            exportKNP = true;
        } else {
            exportKNP = false;
        }
        if ($('#IsTranslationNotes:checkbox:checked').length > 0) {
            IsTranslationNotes = true;
        } else {
            IsTranslationNotes = false;
        }
        status['IsExoprtKNP'] = exportKNP;
        status['IsNotes'] = IsTranslationNotes;

        if ($scope.adminUser) {
            status['OriginalUserId'] = $scope.adminUser.UserId;
        } else {
            status['OriginalUserId'] = null;
        }
        //Mandatory validation
        if (IsAllCategories === false  || (IsAllLanguages === false || status.ProjectLanguageId.length == 0)) {
            $scope.isValidExport = true;
            $scope.showLoader = false;
            $scope.validationMsgSaveAsExcel = 'At least one Language need to be selected';
            return true;
        } else if (!$scope.exportPass || $scope.exportPass.length == 0) { //Export to excel password validation GLMGR-203
            $scope.isValidExport = true;
            $scope.showLoader = false;
            $scope.validationMsgSaveAsExcel = 'Password cannot be empty';
            return false;
        } else if ($scope.exportPass.length > 15 || $scope.exportPass.length < 3 || $scope.exportPass.indexOf(' ') >= 0) {
            $scope.isValidExport = true;
            $scope.showLoader = false;
            $scope.validationMsgSaveAsExcel = 'Password length should be minimum 3 and maximum 15 characters, no blank space allowed.';
            return false;
        } else {
            $scope.isValidExport = false;
            $scope.showLoader = true;
        }

        Glossary.postExportSettings(status, function (status) {
            $scope.isValidExport = false;
            $scope.allCategories.status = false;
            $scope.allLanguages.status = false;
            $('input:checkbox').each(function () {
                $(this).prop("checked", false);
                $(this).prop("disabled", false);
            });
            $scope.showLoader = false;
            $scope.exportPass = '';
            $(".exp-password").attr("type", "password");
            $('#showHide').prop('checked', false);
        });
        $('#exportSettings').modal('hide');
    };

    //function call on load of page
      /**
     * @ngdoc
     * @name glossaryInitialData
     * @methodOf Projects.controller:TranslationController
     * @param {Object} glossaryInitialTerms This is object containing all glossary terms on page load
     * @description
     * This function is called on page load to get all glossary data. Here many variables are set to local storage and also values retrieved from local storage
     * @returns {undefined} This method does not return.
     */
    var glossaryInitialData = function (glossaryInitialTerms) {
        $scope.noData = false;
        $scope.showLoader = true;
        //GLMGR-169
        if (glossaryInitialTerms.UserPermissionList == null && $scope.userRole === 'Admin') {
            $scope.enableCellEditFlag = true;
        } else {
            if (glossaryInitialTerms.UserPermissionList.AddEditTranslation === false && $scope.userRole === 'Admin') {
                $scope.enableCellEditFlag = false;
            } else {
                $scope.enableCellEditFlag = true;
            }
        }
        if (glossaryInitialTerms == 'error') {
            $('#serverError').modal('show');
            $scope.showLoader = false;
        }
        $scope.HasTranslationPrivilege = glossaryInitialTerms.HasTranslationPrivilege;

        //Date Time Picker for Send Glossary
        $('#datepicker1').datetimepicker();
        $('#datepicker1').datetimepicker('setEndDate', null);
        $("#exportSettings").scroll(function () {
            $('#datepicker1').datetimepicker('hide');
            $('#datepicker1').blur();
        });

        //hide Export Glossary button for Translator and Approver
        if ($scope.userDetails.UserRoles[0].UserRoleName === 'Translator' || $scope.userDetails.UserRoles[0].UserRoleName === 'Approver') {
            $scope.hideForTranslatorApprover = true;
        } else {
            $scope.hideForTranslatorApprover = false;
        }

        $scope.GlossaryInitialTerms = glossaryInitialTerms;
        //GLMGR 656
        if ($scope.userDetails.UserRoles[0].UserRoleName === 'Translator' || $scope.userDetails.UserRoles[0].UserRoleName === 'Approver' || $scope.userDetails.UserRoles[0].UserRoleName === 'Client User' || ($scope.userDetails.UserRoles[0].UserRoleName === 'Admin' && $scope.GlossaryInitialTerms.UserPermissionList.AddEditSourceSetup == false)) {
            $scope.hideGotoSourceSetup = true;
        } else {
            $scope.hideGotoSourceSetup = false;
        }

        sessionStorage.setItem("PageId", $scope.GlossaryInitialTerms.PageId);

        $scope.exportSections = [];
        angular.copy($scope.GlossaryInitialTerms.ProjectHeaders, $scope.exportSections);
        for (var i = 0; i < $scope.exportSections.length; i++) {
            if ($scope.exportSections[i].IsSecret == true) {
                $scope.exportSections.splice(i, 1);
                i--;
            }
        }

        var secretStaus;

        for (var i = 0; i < $scope.GlossaryInitialTerms.ProjectLanguages.length; i++) {
            if ($scope.translationProjectLanguageId == $scope.GlossaryInitialTerms.ProjectLanguages[i].ProjectLanguageId) {
                secretStaus = $scope.GlossaryInitialTerms.ProjectLanguages[i].SuperAccessPrivilege;
            }

        }
        if (secretStaus == false) {
            for (var j = 0; j < $scope.GlossaryInitialTerms.ProjectHeaders.length; j++) {
                if ($scope.GlossaryInitialTerms.ProjectHeaders[j].IsSecret == true) {
                    $scope.GlossaryInitialTerms.ProjectHeaders.splice(j, 1);
                    j--;
                }
            }
        }


        if ($scope.GlossaryInitialTerms.ProjectHeaders.length > 0) {
            $scope.noData = false;
            $scope.facdata = [];
            $scope.defdata = [];
            if (commonService.getSessionData('GlossarySection')) {
                $scope.headingsDropdown = commonService.getSessionData('GlossarySection');
                $scope.sectionId = $scope.headingsDropdown.Id;
                var flag = false;
                for (var k = 0; k < $scope.GlossaryInitialTerms.ProjectHeaders.length; k++) {
                    if ($scope.GlossaryInitialTerms.ProjectHeaders[k].Id == $scope.sectionId) {
                        flag = true;
                        break;
                    }
                }
                if (flag === false) {
                    $scope.headingsDropdown = $scope.GlossaryInitialTerms.ProjectHeaders[0];
                    $scope.sectionId = $scope.GlossaryInitialTerms.ProjectHeaders[0].Id;
                    sessionStorage.setItem('GlossarySection', JSON.stringify($scope.GlossaryInitialTerms.ProjectHeaders[0]));
                }

            } else {
                $scope.headingsDropdown = $scope.GlossaryInitialTerms.ProjectHeaders[0];

                sessionStorage.setItem('GlossarySection', JSON.stringify($scope.GlossaryInitialTerms.ProjectHeaders[0]));
            }

            /* Populating various scope varaibles for different tabs in glossary page ex- translation tab , approver tab according to permissions and user type*/

            $scope.addTranslationlanguages = [];
            $scope.addApprovelanguages = [];
            $scope.FilterLanglist = [];
            for (var h = 0; h < $scope.GlossaryInitialTerms.ProjectLanguages.length; h++) {
                if ($scope.GlossaryInitialTerms.ProjectLanguages[h].ProjectLanguageId == $scope.translationProjectLanguageId) {
                    $scope.FilterLanglist.push($scope.GlossaryInitialTerms.ProjectLanguages[h]);
                    $scope.FilterLang = $scope.GlossaryInitialTerms.ProjectLanguages[h];
                    break;
                }
            }
            for (var j = 0; j < $scope.GlossaryInitialTerms.ProjectLanguages.length; j++) {
                if (commonService.getLocalData('userDetails').UserRoles[0].UserRoleName == 'Approver') {
                    if ($scope.GlossaryInitialTerms.ProjectLanguages[j].WritePrivilege == true &&
                        $scope.GlossaryInitialTerms.ProjectLanguages[j].HasTranslationPrivilege == true) {
                        $scope.addTranslationlanguages.push($scope.GlossaryInitialTerms.ProjectLanguages[j]);
                    }
                    if ($scope.GlossaryInitialTerms.ProjectLanguages[j].HasApproveRejectPrivilege == true) {
                        $scope.addApprovelanguages.push($scope.GlossaryInitialTerms.ProjectLanguages[j]);
                    }
                } else if (commonService.getLocalData('userDetails').UserRoles[0].UserRoleName == 'Translator') {
                    if ($scope.GlossaryInitialTerms.ProjectLanguages[j].WritePrivilege == true &&
                                        $scope.GlossaryInitialTerms.ProjectLanguages[j].HasTranslationPrivilege == true) {
                        $scope.addTranslationlanguages.push($scope.GlossaryInitialTerms.ProjectLanguages[j]);
                    }
                    if ($scope.GlossaryInitialTerms.ProjectLanguages[j].HasApproveRejectPrivilege == true) {
                        $scope.addApprovelanguages.push($scope.GlossaryInitialTerms.ProjectLanguages[j]);
                    }
                } else {
                    $scope.addApprovelanguages.push($scope.GlossaryInitialTerms.ProjectLanguages[j]);
                    if ($scope.GlossaryInitialTerms.ProjectLanguages[j].WritePrivilege == true) {
                        $scope.addTranslationlanguages.push($scope.GlossaryInitialTerms.ProjectLanguages[j]);
                    }
                }

            }

            if ($scope.addApprovelanguages.length < 1) {
                $scope.NoApproveRejectLanguage = true;
            }
            if (commonService.getLocalData('userDetails').UserRoles[0].UserRoleName == 'Client User') {
                $scope.HasTranslationPrivilege = true;
            } else {
                $scope.HasTranslationPrivilege = glossaryInitialTerms.HasTranslationPrivilege;
            }

            Glossary.getTranslationData($scope.projectId, $scope.headingsDropdown.Id, commonService.getLocalData('userDetails').UserId, $scope.translationProjectLanguageId, glossarySectionData);
            $rootScope.headerId = $scope.headingsDropdown.Id;
        } else {
            $scope.noData = true;
            $scope.showLoader = false;
            $('#noHeader').modal('show');
            $scope.facdata = [];
            $scope.defdata = [];
        }
        $scope.ObjectId1 = [];
        $scope.ClientName_str = '';
        for (var i = 0; i < $scope.GlossaryInitialTerms.ProjectClients.length; i++) {
            $scope.ObjectId1.push($scope.GlossaryInitialTerms.ProjectClients[i].ClientName);
            $scope.ClientName_str = $scope.ClientName_str + $scope.GlossaryInitialTerms.ProjectClients[i].ClientName + ', ';
        }
        $scope.ClientName_str = $scope.ClientName_str.slice(0, -2);


    };

    $scope.revertTranslationPopup = function (listMasterGlossary, row, selectedLanguage) {
        //object new
        $scope.revertTranslation = {};
        $scope.revertTranslation.LanguageTerm = row.TranslatedTerm;
        $scope.revertTranslation.TranslatorUserId = $scope.userId;;
        $scope.revertTranslation.MasterGlossaryId = listMasterGlossary.MasterGlossaryId;
        $scope.revertTranslation.ProjectLanguageId = selectedLanguage.ProjectLanguageId;
        $scope.revertTranslation.RowVersion = listMasterGlossary.ProjectLanguages[0].RowVersion;
        $scope.revertTranslation.IsRevertedText = true;
        $scope.revertTranslation.GlossaryTranslationId = row.GlossaryTranslationId;
        $scope.revertTranslation.IsTranslationTermUpdate = true;
        if ($scope.adminUser) {
            $scope.revertTranslation.OriginalUserId = $scope.adminUser.UserId;
        } else {
            $scope.revertTranslation.OriginalUserId = null;
        }

        $('#confirmRevertTranslation').modal({ backdrop: 'static', keyboard: false });
        $('#confirmRevertTranslation').modal('show');
    };

    $scope.updateTranslation = function () {
        Glossary.saveRevertedTranslation($scope.revertTranslation, function (status) {
        });
    };

     /**
     * @ngdoc
     * @name glossarySectionData
     * @methodOf Projects.controller:TranslationController
     * @param {Object} glossaryData This is object containing all glossary terms for section
     * @description
     * This function is call back function of getGlossaryData , used only in glossaryInitialData function
     * @returns {undefined} This method does not return.
     */
    var glossarySectionData = function (glossaryData) {
        if (glossaryData == 'error') {
            $('#serverError').modal('show');
            $scope.showLoader = false;
        }

        $scope.glossaryData = glossaryData;

        

        $scope.showLoader = false;
        Catsequence = glossaryData.ProjectCategorySequence;

        $('section.container').css('height', window.innerHeight);
        $('.wide-screen-wrapper .ngViewport').css('height', window.innerHeight - 650);
        $('.wide-screen-wrapper .gridStyle').css('height', window.innerHeight - 640);
        $scope.sectionHeader = $scope.glossaryData.HeaderText;


        //GLMGR-1239 if section having atleast one empty column then only check the hideEmptyCol checkbox
        for (var i = 0; i < $scope.glossaryData.SectionCategories.length; i++) {
            if ($scope.glossaryData.SectionCategories[i].IsCategoryEmpty === true) {
                $scope.isCheckedEmptyInfoCols = true;
                $scope.hideEmptyAddInfoCOls = true;
            }
        }

        //GLMGR-1239 check if section has atleast one starred term
        $scope.isHavingStarredTerm = false;
        for (var i = 0; i < glossaryData.MasterGlossaries.length; i++) {
            if (glossaryData.MasterGlossaries[i].IsStarred == true) {
                $scope.isHavingStarredTerm = true;
            }
        }
        if (!$scope.isHavingStarredTerm) {
            $scope.isStarred = true;
            $scope.hideStarredCol = false;
        }
        else {
            $scope.isStarred = false;
            $scope.hideStarredCol = true;
        }

        //GLMGR-622 start

        $scope.pendingTranslationsFilterValue = sessionStorage.getItem("pendingTranslationsFilter");
        $scope.pendingApprovalsFilterValue = sessionStorage.getItem("pendingApprovalsFilter");
        $scope.filterStatusValue = sessionStorage.getItem("filterStatus");
        $scope.approvedFilterValue = sessionStorage.getItem("approvedFilter");
        $scope.rejectedFilterValue = sessionStorage.getItem("rejectedFilter");
        $scope.pendingSuggFilterValue = sessionStorage.getItem("pendingSuggFilter");

        if (sessionStorage.getItem("filterOnStatus") === "1") {
            $scope.FilterLang = commonService.getSessionData('glossaryFilterLang');
            $scope.translationProjectLanguageId = $scope.FilterLang.ProjectLanguageId;
            if ($scope.filterStatusValue !== 'undefined') {
                $scope.filterStatus = $scope.filterStatusValue;
            }
            if (sessionStorage.getItem("filterImage") !== 'undefined') {
                $scope.filterImage = sessionStorage.getItem("filterImage");
            }
            ($scope.pendingTranslationsFilterValue > 0) ? ($('#pendingTranslationsFilter').attr('checked', 'checked')) : ($('#pendingTranslationsFilter').attr('checked', false));
            ($scope.pendingApprovalsFilterValue > 0) ? ($('#pendingApprovalsFilter').attr('checked', 'checked')) : ($('#pendingApprovalsFilter').attr('checked', false));
            ($scope.approvedFilterValue > 0) ? ($('#approvedFilter').attr('checked', 'checked')) : ($('#approvedFilter').attr('checked', false));
            ($scope.rejectedFilterValue > 0) ? ($('#rejectedFilter').attr('checked', 'checked')) : ($('#rejectedFilter').attr('checked', false));
            ($scope.pendingSuggFilterValue > 0) ? ($('#pendingSuggFilter').attr('checked', 'checked')) : ($('#pendingSuggFilter').attr('checked', false));
            $scope.filterOptions();

        } else {
            GlossaryNgGrid(glossaryData);
        }
        //GLMGR-622 end
    };

    // to show star icon in 'S' column in the ng-grid
    $scope.checkIsStarred = function (row) {
        if (row.starred) {
            return true;
        } else {
            return false;
        }
    };

    /* Starts -- Starred term pop functionality , logic*/
      /**
     * @ngdoc
     * @name listStarredTerms
     * @methodOf Projects.controller:TranslationController
     * @param {Object} row This is object row details
     * @description
     * This function is used to open starred term list detail popup 
     * @returns {undefined} This method does not return.
     */
    $scope.listStarredTerms = function (row, completeRow) {
        if (commonService.getLocalData('userDetails').UserRoles[0].UserRoleName === 'Editorial Staff') {
            return false;
        }
        if (!$scope.isStarred) {
            $scope.LanguageTermTranslationDetails = [];
            $scope.initialEnglishTerm = row.MasterText;
            $scope.termBrands = '';
            if (row.starred) {
                Glossary.getStarredItemsTranslationApproval(row.GlossaryTranslationId, commonService.getLocalData('userDetails').UserId, row.MasterGlossaryId, function (starredTerms) {
                    $scope.StarredTerms = starredTerms.StarredNonStarredTermDetailsList[0]; // lang list
                    //set current lang as selected
                    if (!$scope.FilterLang) {
                        $scope.StarredTermsByLangObject = $scope.StarredTerms.ProjectTranslationTermDetailsByLanguage[0].projectTranslationTermDetails;
                        $scope.lang = $scope.StarredTerms.AssignedLanguages[0];
                    } else {
                        for (var i = 0; i < $scope.StarredTerms.ProjectTranslationTermDetailsByLanguage.length; i++) {
                            if ($scope.FilterLang.LanguageId === $scope.StarredTerms.ProjectTranslationTermDetailsByLanguage[i].LanguageId) {
                                $scope.StarredTermsByLangObject = $scope.StarredTerms.ProjectTranslationTermDetailsByLanguage[i].projectTranslationTermDetails;
                                $scope.lang = $scope.StarredTerms.AssignedLanguages[i];
                            }
                        }
                    }

                    //Convert status to Approved, Rejected or Pending GLMGR-1127
                    for (var j = 0; j < $scope.StarredTermsByLangObject.length; j++) {
                        for (var i = 0; i < $scope.StarredTermsByLangObject[j].LanguageTermTranslationDetails.length; i++) {
                            if ($scope.StarredTermsByLangObject[j].LanguageTermTranslationDetails[i].TermStatus.includes("APPROVED")) {
                                $scope.StarredTermsByLangObject[j].LanguageTermTranslationDetails[i].TermStatus = 'Approved';
                            } else if ($scope.StarredTermsByLangObject[j].LanguageTermTranslationDetails[i].TermStatus.includes("REJECTED")) {
                                $scope.StarredTermsByLangObject[j].LanguageTermTranslationDetails[i].TermStatus = 'Rejected';
                            } else {
                                $scope.StarredTermsByLangObject[j].LanguageTermTranslationDetails[i].TermStatus = 'Pending';
                            }
                        }
                    }

                    //There is no translation available for this Starred Term
                    $scope.StarredTermIsDataAvailable = true;
                    for (var i = 0; i < $scope.StarredTermsByLangObject.length; i++) {
                        if ($scope.StarredTermsByLangObject[i].LanguageTermTranslationDetails.length > 0) {
                            $scope.StarredTermIsDataAvailable = false;
                        }
                    }

                    //get brands
                    $scope.StarredTermsBrands = starredTerms.StarredNonStarredTermDetailsList[0].CommonBrands;
                    for (var i = 0; i < $scope.StarredTermsBrands.length; i++) {
                        $scope.termBrands = $scope.termBrands + $scope.StarredTermsBrands[i].BrandName + ', ';
                    }
                    $scope.termBrands = $scope.termBrands.slice(0, -2);
                });
                $('#starredPopup').modal({ backdrop: 'static', keyboard: false });
                $('#starredPopup').modal('show');
            } else {
                return false;
            }
        }

        //InsertAutoTranslation GLMGR-1127
        $scope.insertTranslation = function (termlist) {
            var autoTrans = {};
            var str = $scope.languageTransField;
            autoTrans = completeRow.entity[str];
            autoTrans['LanguageTerm'] = termlist.TranslatedTerm;
            autoTrans['TranslatedTerm'] = termlist.TranslatedTerm;
            autoTrans['ProjectId'] = $scope.projectId;
            autoTrans['RoleName'] = commonService.getLocalData('userDetails').UserRoles[0].UserRoleName;
            autoTrans['ProjectLanguageId'] = $scope.translationProjectLanguageId;
            autoTrans['TranslatorUserId'] = commonService.getLocalData('userDetails').UserId;

            if ($scope.adminUser) {
                autoTrans['OriginalUserId'] = $scope.adminUser.UserId;
            } else {
                autoTrans['OriginalUserId'] = null;
            }

            Glossary.InsertAutoTranslation(autoTrans, function (data) {
                var str = $scope.languageTransField;
                completeRow.entity[str].term = termlist.TranslatedTerm;
            })
            $('#starredPopup').modal('hide');
        };
    };

    /*Starred term by language selection GLMGR-1101*/
     /**
     * @ngdoc
     * @name starredTermLanguage
     * @methodOf Projects.controller:TranslationController
     * @param {Object} index This is object contains language details of selected language.
     * @description
     * This function is called on language dropdown on starred term list detail popup.Used to select language to show starred term list in popup 
     * @returns {undefined} This method does not return.
     */
    $scope.starredTermLanguage = function (index) {
        //change language
        for (var i = 0; i < $scope.StarredTerms.ProjectTranslationTermDetailsByLanguage.length; i++) {
            if (index.Id === $scope.StarredTerms.ProjectTranslationTermDetailsByLanguage[i].LanguageId) {
                $scope.StarredTermsByLangObject = $scope.StarredTerms.ProjectTranslationTermDetailsByLanguage[i].projectTranslationTermDetails;
                $scope.lang = $scope.StarredTerms.AssignedLanguages[i];
            }
        }

        //Convert status to Approved, Rejected or Pending GLMGR-1127
        for (var j = 0; j < $scope.StarredTermsByLangObject.length; j++) {
            for (var i = 0; i < $scope.StarredTermsByLangObject[j].LanguageTermTranslationDetails.length; i++) {
                if ($scope.StarredTermsByLangObject[j].LanguageTermTranslationDetails[i].TermStatus.includes("APPROVED")) {
                    $scope.StarredTermsByLangObject[j].LanguageTermTranslationDetails[i].TermStatus = 'Approved';
                } else if ($scope.StarredTermsByLangObject[j].LanguageTermTranslationDetails[i].TermStatus.includes("REJECTED")) {
                    $scope.StarredTermsByLangObject[j].LanguageTermTranslationDetails[i].TermStatus = 'Rejected';
                } else {
                    $scope.StarredTermsByLangObject[j].LanguageTermTranslationDetails[i].TermStatus = 'Pending';
                }
            }
        }

        //There is no translation available for this Starred Term
        $scope.StarredTermIsDataAvailable = true;
        for (var i = 0; i < $scope.StarredTermsByLangObject.length; i++) {
            if ($scope.StarredTermsByLangObject[i].LanguageTermTranslationDetails.length > 0) {
                $scope.StarredTermIsDataAvailable = false;
            }
        }
    };

    /* Ends -- Starred term pop functionality , logic*/

     /**
     * @ngdoc
     * @name getTermSuggestions
     * @methodOf Projects.controller:TranslationController
     * @param {Object} row This is object of row details
     * @description
     * This function is called on suggestion icon on glossary table.Used to get master term suggestion history GLMGR-1153
     * @returns {undefined} This method does not return.
     */
    $scope.getTermSuggestions = function (row) {
        $scope.OriginalTerm = row.MasterText;
        Glossary.getTermSuggestions($scope.projectId, row.MasterGlossaryId, $rootScope.headerId, commonService.getLocalData('userDetails').UserId, function (status) {
            $scope.suggestionsHistoryFilter = _.groupBy(status, 'IsApproveReject');
            $scope.suggestionsHistoryTrue = $scope.suggestionsHistoryFilter.true;
            $scope.suggestionsHistoryFalse = $scope.suggestionsHistoryFilter.false;
            $scope.ApproveRejectComment = '';
            $('#TermSuggestionsPopup').modal({ backdrop: 'static', keyboard: false });
            $('#TermSuggestionsPopup').modal('show');
            $scope.IsAccepted = true;
        });
    };

    $scope.showHideHistoryToggle = function (showHideHistory) {
        if (showHideHistory) {
            $scope.showHideHistory = false;
        } else {
            $scope.showHideHistory = true;
        }
    };

    //View and add comment popup functionality
    /**
     * @ngdoc
     * @name addComment
     * @methodOf Projects.controller:TranslationController
     * @param {Object} row This is object of row details
     * @description
     * This function is called on comment icon on glossary table. Used to open comment popup
     * @returns {undefined} This method does not return.
     */
    $scope.addComment = function (row) {
        $scope.allEmail = false;
        $scope.selfEmail = false;
        $scope.approverEmail = false;
        $scope.translatorEmail = false;
        $scope.projectOwnerEmail = false;
        $scope.checkboxValid = false;
        $scope.checkboxValidEdit = false;
        EditallEmail = false;
        $scope.EditselfEmail = false;
        $scope.EditapproverEmail = false;
        $scope.EditTranslatorEmail = false;
        $scope.EditprojectOwnerEmail = false;
        masterGlossaryId = row.MasterGlossaryId;
        languageName = row.LanguageName;
        projectLangId = row.ProjectLanguageId;
        if (row.GlossaryTranslationId == 0) {
            $scope.CommentErrorPopupMessage = 'In order to add a comment please add a translation first. If you are not ready to add a translation but you still want to add a comment then click in the blank cell as if you were about to translate,leave it blank and then click away from that cell. You should be able to add a comment after this is done.';
            $('#CommentErrorPopup').modal('show');
        } else {
            $scope.commentGlossaryTransalationId = row.GlossaryTranslationId;
            Glossary.addcmnt(row.GlossaryTranslationId, function (data) {
                $scope.commentData = data;
                $('#CommentPopup').modal('show');
            });

        }

        //chech for checkbox on comment popup
        $scope.isAtleastOneCheckboxChecked = function () {
            if ($('#commntCheckbox li input[type=checkbox]:checked').length > 0) {
                $scope.checkboxValid = false;
            }
            else{
                $scope.checkboxValid = true;
            }
        };
          //chech for checkbox on comment popup
    $scope.isAtleastOneCheckboxCheckedEdit = function () {
        if ($('#commntCheckboxEdit li input[type=checkbox]:checked').length > 0) {
            $scope.checkboxValidEdit = false;
        }
        else {
            $scope.checkboxValidEdit = true;
        }
    };

    /**
     * @ngdoc
     * @name SaveComment
     * @methodOf Projects.controller:TranslationController
     * @description
     * This function is called on save and send button on comment poup.This is used to save comment.
     * @returns {undefined} This method does not return.
     */
        $scope.SaveComment = function () {
            var commentTerm = {};
            if (!$scope.modal || !$scope.modal.comments) {
                alert("empty comments not allowed");
                $('#CommentPopup').modal('show');
                $scope.cmntbtn = false;
            } else {
                    $scope.cmntbtn = true;
                    $scope.checkboxValid = false;
                    commentTerm['glossaryTranslationId'] = $scope.commentGlossaryTransalationId;
                    commentTerm['CurrentUserId'] = commonService.getLocalData('userDetails').UserId;
                    commentTerm['Comment'] = $scope.modal.comments;

                    if ($scope.adminUser) {
                        commentTerm['OriginalUserId'] = $scope.adminUser.UserId;
                    } else {
                        commentTerm['OriginalUserId'] = null;
                    }

                    commentTerm['EncryptedProjectId'] = $scope.projectId;
                    commentTerm['ProjectId'] = $scope.unEncryptedProjectId;
                    commentTerm['UserName'] = commonService.getLocalData('userDetails').FirstName + " " + commonService.getLocalData('userDetails').LastName;
                    commentTerm['MasterGlossaryId'] = masterGlossaryId;
                    commentTerm['LanguageName'] = languageName;
                    commentTerm['ProjectLanguageId'] = projectLangId;
                    commentTerm['UserEmailId'] = commonService.getLocalData('userDetails').UserName;
                    if ($scope.allEmail) {
                        commentTerm['IsSelf'] = true;
                        commentTerm['IsSendToApprover'] = true;
                        commentTerm['IsSendToTranslator'] = true;
                        commentTerm['IsSendToProjectOwner'] = true;
                    } else {
                        commentTerm['IsSelf'] = $scope.selfEmail;
                        commentTerm['IsSendToApprover'] = $scope.approverEmail;
                        commentTerm['IsSendToTranslator'] = $scope.translatorEmail;
                        commentTerm['IsSendToProjectOwner'] = $scope.projectOwnerEmail;
                    }
                    Glossary.saveComment(commentTerm, function (data) {
                        row.cmntcolor = true;
                        $scope.modal.comments = null;
                        $scope.cmntbtn = false;
                        $('#CommentPopup').modal('hide');
                    });
            }
        };

    };

      /**
     * @ngdoc
     * @name addTranslationSource
     * @methodOf Projects.controller:TranslationController
     * @param {Object} row This is object of row details
     * @description
     * This function is called on translation source icon on glossary table. Used to View and add Translation Source popup: GLMGR-1030
     * @returns {undefined} This method does not return.
     */
    $scope.addTranslationSource = function (row) {
        $scope.MasterGlossaryIdtemp = row.MasterGlossaryId;
        $scope.onlyForTranslationTab = true;
        if (row.GlossaryTranslationId == 0) {
            $scope.CommentErrorPopupMessage = 'In order to add a Translation Source please add a translation first. If you are not ready to add a translation but you still want to add a Translation Source then click in the blank cell as if you were about to translate, leave it blank and then click away from that cell. You should be able to add a Translation Source after this is done.';
            $('#CommentErrorPopup').modal('show');
        } else {
            Glossary.GetTranslationSource($scope.projectId, row.MasterGlossaryId, $scope.translationProjectLanguageId, commonService.getLocalData('userDetails').UserId, function (data) {
                $scope.TranslationSourceData = data;

                //create list objects for Translation Source Option
                $scope.TranslationSourceList = [
                  { "value": 0, "option": "--Select Source--" },
                  { "value": 1, "option": "The original book" },
                  { "value": 2, "option": "Client provided script" },
                  { "value": 3, "option": "Client provided website" },
                  { "value": 4, "option": "Public website" },
                  { "value": 5, "option": "Other" },
                  { "value": 6, "option": "I translated this myself" }
                ];

                //new entry or has history
                if ($scope.TranslationSourceData.GlossaryTranslationSource == null) {
                    $scope.TranslationSourceOption = $scope.TranslationSourceList[5];
                    $scope.SourceComment = '';
                } else {
                    $scope.currentTranslationSourceOption = $scope.TranslationSourceList[$scope.TranslationSourceData.GlossaryTranslationSource.TranslationSourceId];
                    $scope.currentSourceComment = $scope.TranslationSourceData.GlossaryTranslationSource.SourceComment;
                    $scope.TranslationSourceOption = $scope.currentTranslationSourceOption;
                    $scope.SourceComment = $scope.currentSourceComment;
                }


                $('#TranslationSourcePopup').modal({ backdrop: 'static', keyboard: false });
                $('#TranslationSourcePopup').modal('show');

                //Save Translation Source
                $scope.SaveTranslationSource = function (TranslationSourceOption, SourceComment) {
                    //no changes done
                    if ($scope.currentTranslationSourceOption) {
                        if (TranslationSourceOption.value === $scope.currentTranslationSourceOption.value && SourceComment.trim().toLowerCase() === $scope.currentSourceComment.toLowerCase()) {
                            alert('There is no change in the Translation Source Option or Comment. Please change either and click "Save" or click "Cancel"');
                            return false;
                        }
                    }

                    var GlossaryTranslationSource = {};
                    GlossaryTranslationSource['MasterGlossaryId'] = $scope.MasterGlossaryIdtemp;
                    GlossaryTranslationSource['ProjectLanguageId'] = $scope.translationProjectLanguageId;
                    GlossaryTranslationSource['TranslationSourceId'] = TranslationSourceOption.value;
                    GlossaryTranslationSource['TranslationSource'] = TranslationSourceOption.option;
                    GlossaryTranslationSource['SourceComment'] = SourceComment;
                    if ($scope.adminUser) {
                        OriginalUserId = $scope.adminUser.UserId;
                    } else {
                        OriginalUserId = null;
                    }

                    Glossary.saveTranslationSource(GlossaryTranslationSource, $scope.projectId, commonService.getLocalData('userDetails').UserId, OriginalUserId, function (data) {
                        $('#TranslationSourcePopup').modal('hide');
                        if (TranslationSourceOption.value === 0) {
                            row.IsTranslationSourceAdded = false;
                        } else {
                            row.IsTranslationSourceAdded = true;
                        }
                    });
                }
            });
        }
    };

     /**
     * @ngdoc
     * @name ClearTranslationSource
     * @methodOf Projects.controller:TranslationController
     * @description
     * This function is called on clear button on translation source popup. Used to clear translation source.
     * @returns {undefined} This method does not return.
     */
    $scope.ClearTranslationSource = function () {
        $scope.TranslationSourceOption = $scope.TranslationSourceList[0];
        $scope.SourceComment = '';
    };

    /**
     * @ngdoc
     * @name addBulkTranslationSource
     * @methodOf Projects.controller:TranslationController
     * @param {Object} col This is object of translation source column details
     * @description
     * This function is called on translation source icon on Translation source column. Used to show popup to add Translation source for all terms in bulk.
     * @returns {undefined} This method does not return.
     */
    $scope.addBulkTranslationSource = function (col) {

        //create list objects for Translation Source Option
        $scope.TranslationSourceList = [
          { "value": 0, "option": "--Select Source--" },
          { "value": 1, "option": "The original book" },
          { "value": 2, "option": "Client provided script" },
          { "value": 3, "option": "Client provided website" },
          { "value": 4, "option": "Public website" },
          { "value": 5, "option": "Other" },
          { "value": 6, "option": "I translated this myself" }
        ];

        $scope.BulkTranslationSourceOption = $scope.TranslationSourceList[5];
        $scope.SourceComment = '';
        $scope.IsForAll = true;

        $('#BulkTranslationSourcePopup').modal({ backdrop: 'static', keyboard: false });
        $('#BulkTranslationSourcePopup').modal('show');

    };

      /**
     * @ngdoc
     * @name SaveBulkTranslationSource
     * @methodOf Projects.controller:TranslationController
     * @param {Object} col This is object of translation source column details
     * @description
     * This function is called on translation source icon on Translation source column. Used to save Translation source for all terms in bulk.
     * @returns {undefined} This method does not return.
     */
    $scope.SaveBulkTranslationSource = function (BulkTranslationSourceOption, SourceComment, IsForAll) {
        var GlossaryBulkTranslationSource = {};
        GlossaryBulkTranslationSource['ProjectLanguageId'] = $scope.FilterLang.ProjectLanguageId;
        GlossaryBulkTranslationSource['TranslationSourceId'] = BulkTranslationSourceOption.value;
        GlossaryBulkTranslationSource['TranslationSource'] = BulkTranslationSourceOption.option;
        GlossaryBulkTranslationSource['SourceComment'] = SourceComment;
        GlossaryBulkTranslationSource['SectionId'] = $scope.headingsDropdown.SectionId;
        GlossaryBulkTranslationSource['GlossaryData'] = $scope.glossaryData;

        if ($scope.adminUser) {
            OriginalUser = $scope.adminUser.UserId;
        } else {
            OriginalUser = null;
        }

        Glossary.saveBulkTranslationSource(GlossaryBulkTranslationSource, $scope.projectId, commonService.getLocalData('userDetails').UserId, $scope.IsForAll, OriginalUser, function (data) {
            $('#BulkTranslationSourcePopup').modal('hide');
            location.reload();
        });
    };

        /**
     * @ngdoc
     * @name autoTranslationPopup
     * @methodOf Projects.controller:TranslationController
     * @param {Object} col This is object of starred column details
     * @param {Object} row This is object of row details
     * @description
     * This function is called on auto translation icon on starred column. Used to show auto translation confirmation popup.
     * @returns {undefined} This method does not return.
     */
    $scope.autoTranslationPopup = function (col, row) {
        $scope.MasterGlossaryIdtemp = row.MasterGlossaryId;
        $scope.AutoTranslationConfirmed = true;
        $scope.RememberAutoTranslation = true;
        if (!$scope.glossaryData.IsRememberUserNextTime) {
            $('#confirmAutoTranslation').modal({ backdrop: 'static', keyboard: false });
            $('#confirmAutoTranslation').modal('show');
            var str = $scope.languageTransField;
            $scope.autoTranslation = function (AutoTranslationConfirmed, RememberAutoTranslation) {
                var autoTrans = {};
                autoTrans = row.entity[str];
                autoTrans['ProjectId'] = $scope.projectId;
                autoTrans['RoleName'] = commonService.getLocalData('userDetails').UserRoles[0].UserRoleName;
                autoTrans['ProjectLanguageId'] = $scope.translationProjectLanguageId;
                autoTrans['TranslatorUserId'] = commonService.getLocalData('userDetails').UserId;
                autoTrans.IsRememberNextTime = RememberAutoTranslation;

                if ($scope.adminUser) {
                    autoTrans['OriginalUserId'] = $scope.adminUser.UserId;
                } else {
                    autoTrans['OriginalUserId'] = null;
                }

                $scope.showLoader = true;
                if (AutoTranslationConfirmed === true) {
                    Glossary.SaveAutoTranslation(autoTrans, function (data) {
                        var str = $scope.languageTransField;
                        row.entity[str].term = data.TranslatedTerm;
                        col.HasConsistanceApprovedTranslation = false;
                        $scope.showLoader = false;
                        if (autoTrans.IsRememberNextTime === true) {
                            location.reload();
                        }
                    })
                }
                $('#BulkTranslationSourcePopup').modal('hide');
            }
        } else {
            var str = $scope.languageTransField;
            var autoTrans = {};
            autoTrans = row.entity[str];
            autoTrans['ProjectId'] = $scope.projectId;
            autoTrans['RoleName'] = commonService.getLocalData('userDetails').UserRoles[0].UserRoleName;
            autoTrans['ProjectLanguageId'] = $scope.translationProjectLanguageId;
            autoTrans['TranslatorUserId'] = commonService.getLocalData('userDetails').UserId;
            autoTrans.IsRememberNextTime = true;
            $scope.showLoader = true;
            Glossary.SaveAutoTranslation(autoTrans, function (data) {
                var str = $scope.languageTransField;
                row.entity[str].term = data.TranslatedTerm;
                col.HasConsistanceApprovedTranslation = false;
                $scope.showLoader = false;
            })
            $('#BulkTranslationSourcePopup').modal('hide');
        }
    };

    //Download attachment
    $scope.downloadAttachment = function (AttachmentId, Name, Type) {
        Glossary.getDownloadAttachment($scope.projectId, $scope.projectlangId, AttachmentId, function (data) {
        });
    };

    //Download All attachments
    $scope.downloadAttachmentAll = function (LanguageId, AttachmentId, Name, Type) {
        window.URL = window.URL || window.webkitURL;
        Glossary.getDownloadAttachmentAll($scope.projectId, LanguageId, AttachmentId, function (data) {
            $scope.attachment = data;
        });
    };

    /**
     * @ngdoc
     * @name AllSection
     * @methodOf Projects.controller:TranslationController
     * @description
     * This function is called on click of All option in sections popup.This is used to set filter and redirect to All Glossary section.
     * @returns {undefined} This method does not return.
     */
    var AllSection = function () {
        //GLMGR-622 start
        sessionStorage.setItem("filterStatus", $scope.filterStatus);
        sessionStorage.setItem("filterImage", $scope.filterImage);
        sessionStorage.setItem("pendingTranslationsFilter", $('#pendingTranslationsFilter:checkbox:checked').length);
        sessionStorage.setItem("pendingApprovalsFilter", $('#pendingApprovalsFilter:checkbox:checked').length);
        sessionStorage.setItem("approvedFilter", $('#approvedFilter:checkbox:checked').length);
        sessionStorage.setItem("rejectedFilter", $('#rejectedFilter:checkbox:checked').length);
        sessionStorage.setItem("pendingSuggFilter", $('#pendingSuggFilter:checkbox:checked').length);
        //GLMGR-622 end

        var languages = [];
        languages.push($scope.translationProjectLanguageId);
        sessionStorage.setItem('AllglossaryLangList', JSON.stringify(languages));
        $scope.changeView('GlossaryAllsection');

    };


    //shift + tab -- change in line functionality in language cell text area
    $scope.onTextChange = function ($event) {
        var key = $event.keyCode;

        if (key == 9 && $event.shiftKey) {
            var value = $(".txtArea").val();
            $(".txtArea").val(value + "\n");
            return true;
        } else {
            return true;
        }
    };

      /**
     * @ngdoc
     * @name defObjForCat
     * @methodOf Projects.controller:TranslationController
     * @param {String} str This is string concatenated projectId string
     * @param {Number} catWidth This is column width for category columns
     * @param {Number} index This is index of category in category array
     * @param {Boolean} pin This is boolean used to decide is column need to be pinned
     * @param {String} celltemp This is cell template
     * @param {String} editTemp This is this is edit template contains text area to edit fields
     * @description
     * This function is called on internally in GlossaryNgGrid function.Used to create column definition object for categories(addl. info) columns in ng-grid
     * @returns {Object} This method return column definition object for category column.
     */
    var defObjForCat = function (str, catWidth, index, pin, celltemp, editTemp) {
        var staticName = 'cat';
        if ($scope.hideAddInfoCOls) {
            return {
                field: staticName.concat(str),
                displayName: $scope.catList[index].CategoryName,
                width: catWidth,
                pinned: false,
                cellTemplate: celltemp,
                editableCellTemplate: editTemp,
                visible: false
            };
        } else {
            return {
                field: staticName.concat(str),
                displayName: $scope.catList[index].CategoryName,
                width: catWidth,
                pinned: false,
                cellTemplate: celltemp,
                editableCellTemplate: editTemp,
                visible: true
            };
        }
    };


       /**
     * @ngdoc
     * @name GlossaryNgGrid
     * @methodOf Projects.controller:TranslationController
     * @param {Object} glossaryData This is object contains  whole glossary data.
     * @param {Object} headerValue This is object contains  selected sections details.
     * @description
     * This function is called on page load.Used to create grid structure to show glossary data
     * @returns {undefined} This method does not return.
     */
    var GlossaryNgGrid = function (glossaryData) {
        var uuid = 'a';
        $scope.catList = $scope.GlossaryInitialTerms.ProjectCategories;
        //console.log("glossaryData---", glossaryData);

        //GLMGR-486
        masterGlossaries = glossaryData.MasterGlossaries;

        if (glossaryData.SectionCategories != null) {
            $scope.catList = glossaryData.SectionCategories; //[{ "CategoryId": 1, "ProjectId": null, "DbProjectId": 0, "ProjectCategoryId": 1677, "GlossaryCategoryId": 0, "MasterGlossaryId": 0, "CategoryName": "Annotations", "CategoryText": null, "UserId": 0, "GlossaryCategoryRowVersion": null, "SectionType": 1, "IsActive": true, "SectionCategoryActiveStatus": false, "IsSectionEmpty": false }, { "CategoryId": 2, "ProjectId": null, "DbProjectId": 0, "ProjectCategoryId": 1678, "GlossaryCategoryId": 0, "MasterGlossaryId": 0, "CategoryName": "Book / Chapter", "CategoryText": null, "UserId": 0, "GlossaryCategoryRowVersion": null, "SectionType": 1, "IsActive": true, "SectionCategoryActiveStatus": false, "IsSectionEmpty": true }, { "CategoryId": 268, "ProjectId": null, "DbProjectId": 0, "ProjectCategoryId": 1679, "GlossaryCategoryId": 0, "MasterGlossaryId": 0, "CategoryName": "11", "CategoryText": null, "UserId": 0, "GlossaryCategoryRowVersion": null, "SectionType": 1, "IsActive": true, "SectionCategoryActiveStatus": false, "IsSectionEmpty": false }];
        }

        /*Starts -- creating grid templates*/

        // header template for categories
        var hc_nopin = "<div class=\"ngHeaderSortColumn {{col.headerClass}}\" ng-style=\"{'cursor': col.cursor}\" ng-class=\"{ 'ngSorted': !col.noSortVisible() }\">\r" +
            "\n" +
            " <div ng-click=\"col.sort($event)\" ng-class=\"'colt' + col.index\" class=\"ngHeaderText\">{{col.displayName}}</div>\r" +
            "\n" +
            " <div class=\"ngSortButtonDown\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonDown()\"></div>\r" +
            "\n" +
            " <div class=\"ngSortButtonUp\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonUp()\"></div>\r" +
            "\n" +
            " <div class=\"ngSortPriority\">{{col.sortPriority}}</div>\r" +
            "\n" +
            "</div>\r" +
            "\n" +
            "<div ng-show=\"col.resizable\" class=\"ngHeaderGrip\" ng-click=\"col.gripClick($event)\" ng-mousedown=\"col.gripOnMouseDown($event)\"></div>\r" +
            "\n";

        // header template for Languages(left to right)
        var hc_nopin_language = "<div class=\"ngHeaderSortColumn {{col.headerClass}}\" ng-style=\"{'cursor': col.cursor}\" ng-class=\"{ 'ngSorted': !col.noSortVisible() }\">\r" +
            "\n" +
            " <div ng-click=\"col.sort($event)\" ng-class=\"'colt' + col.index\" class=\"ngHeaderText\">{{col.displayName}}</div>\r" +
            "\n" +
            " <div class=\"ngSortButtonDown\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonDown()\"></div>\r" +
            "\n" +
            " <div class=\"ngSortButtonUp\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonUp()\"></div>\r" +
            "\n" +
            " <div class=\"ngSortPriority\">{{col.sortPriority}}</div>\r" +
            "\n" +
            '<div class="lang-info-icon" ng-click="langInfo(col)" ></div>' +
            '</div>\r' +
            "</div>\r" +
            "\n" +
            "<div ng-show=\"col.resizable\" class=\"ngHeaderGrip\" ng-click=\"col.gripClick($event)\" ng-mousedown=\"col.gripOnMouseDown($event)\"></div>\r" +
            "\n";
        // header template for Languages(right to left)
        var hc_nopin_language_rtl = "<div class=\"ngHeaderSortColumn {{col.headerClass}}\" ng-style=\"{'cursor': col.cursor}\" ng-class=\"{ 'ngSorted': !col.noSortVisible() }\">\r" +
            "\n" +
            " <div ng-click=\"col.sort($event)\" ng-class=\"'colt' + col.index\" class=\"ngHeaderText-rtl\">{{col.displayName}}</div>\r" +
            "\n" +
            " <div class=\"ngSortButtonDown\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonDown()\"></div>\r" +
            "\n" +
            " <div class=\"ngSortButtonUp\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonUp()\"></div>\r" +
            "\n" +
            " <div class=\"ngSortPriority\">{{col.sortPriority}}</div>\r" +
            "\n" +
            '<div class="lang-info-icon-rtl" ng-click="langInfo(col)" ></div>' +
            '</div>\r' +
            "</div>\r" +
            "\n" +
            "<div ng-show=\"col.resizable\" class=\"ngHeaderGrip\" ng-click=\"col.gripClick($event)\" ng-mousedown=\"col.gripOnMouseDown($event)\"></div>\r" +
            "\n";


        // header template for master-language(source term)(right to left)
        var hc_nopin_master_rtl = "<div class=\"ngHeaderSortColumn {{col.headerClass}}\" ng-style=\"{'cursor': col.cursor}\" ng-class=\"{ 'ngSorted': !col.noSortVisible() }\">\r" +
            "\n" +
            " <div ng-click=\"col.sort($event)\" ng-class=\"'colt' + col.index\" class=\"ngHeaderText-rtl\">{{col.displayName}}</div>\r" +
            "\n" +
            " <div class=\"ngSortButtonDown\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonDown()\"></div>\r" +
            "\n" +
            " <div class=\"ngSortButtonUp\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonUp()\"></div>\r" +
            "\n" +
            " <div class=\"ngSortPriority\">{{col.sortPriority}}</div>\r" +
            "\n" +
            " <div ng-class=\"{ ngPinnedIcon: col.pinned, ngUnPinnedIcon: !col.pinned }\" ng-click=\"togglePin(col)\" ng-show=\"col.pinnable\"></div>\r" +
            "\n" +
            "</div>\r" +
            "\n" +
            "<div ng-show=\"col.resizable\" class=\"ngHeaderGrip\" ng-click=\"col.gripClick($event)\" ng-mousedown=\"col.gripOnMouseDown($event)\"></div>\r" +
            "\n";

        // header template for Translation Source GLMGR-1030
        var hc_nopin_source =
            "<div class=\"ngHeaderSortColumn {{col.headerClass}}\" ng-style=\"{'cursor': col.cursor}\" ng-class=\"{ 'ngSorted': !col.noSortVisible() }\">\r" +
            "\n" +
            " <div ng-click=\"col.sort($event)\" ng-class=\"'colt' + col.index\" class=\"ngHeaderText\">{{col.displayName}}</div>\r" +
            "\n" +
            " <div class=\"ngSortButtonDown\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonDown()\"></div>\r" +
            "\n" +
            " <div class=\"ngSortButtonUp\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonUp()\"></div>\r" +
            "\n" +
            " <div class=\"ngSortPriority\">{{col.sortPriority}}</div>\r" +
            "\n" +
            '<div class="lang-info-icon source-bulk-icon" ng-click="addBulkTranslationSource(col)" ></div>' +
            "\n" +
            "</div>\r" +
            "\n" +
            "<div ng-show=\"col.resizable\" class=\"ngHeaderGrip\" ng-click=\"col.gripClick($event)\" ng-mousedown=\"col.gripOnMouseDown($event)\"></div>\r" +
            "\n";

        // cell template
        var celltemp = '<div class="ngCellText" tooltip={{row.getProperty(col.field).term}}  tooltip-placement="top" ng-cell-text>{{row.getProperty(col.field).term}}</div>';

        // editable English Description cell template -- used when user double clicks on cell in ng-grid and it becomes editable . Here it is disabled and only used to copy text 
        var editCellTempForEngDescript = '<textarea readonly ng-class="\'colt\' + col.index" style="min-width:400px; resize: none; height:110px;"  ng-model="row.getProperty(col.field).term" ng-input="row.getProperty(col.field).term" class="txtArea"/>';

        // editable other category cell template -- used when user double clicks on cell in ng-grid and it becomes editable . Here it is disabled and only used to copy text 
        var editCellTempForCat = '<textarea readonly ng-class="\'colt\' + col.index" style="min-width:150px; resize: none; height:110px;"  ng-model="row.getProperty(col.field).term" ng-input="row.getProperty(col.field).term" class="txtArea"/>';

        /*Ends -- creating grid templates*/

        var staticName = 'cat';
        //column defn for categories.
        var countCat = 0;
        $scope.preSettings = commonService.getSessionData('gridContextInstance');

        //column defn for categories.
        if (Catsequence) {

            for (var j = 0; j < Catsequence.length; j++) {
                for (var i = 0; i < $scope.catList.length; i++) {

                    if (Catsequence[j] == $scope.catList[i].ProjectCategoryId) {
                        //check if hide empty add info checkbox is checked
                        if ($scope.hideEmptyAddInfoCOls) {
                            if ($scope.catList[i].IsCategoryEmpty) {
                                continue;
                            }
                        }
                        var str = $scope.catList[i].ProjectCategoryId.toString();
                        countCat = countCat + 1;

                        //Checking condition so that  first 5 categories pinning can be set true.
                        if (countCat < 5) {

                            /*checking whether category(Addl Info) column is 'English Description' or not . If it then set its width to 400 . 
                            Other categories are set to 150 only.
                            Also 'English Description' column is set to 400 only when it is one of the first 5 categories in category sequence otherwise set to normal 150 */

                            if ($scope.catList[i].CategoryName == 'English Description') {
                                if (commonService.getSessionData('gridContextInstance') != null) {
                                    if (commonService.getSessionData('gridContextSaved') == true && commonService.getSessionData('gridContextInstance').length > 0 && hideCatCols) {
                                        var catflag = false;
                                        for (var f = 0; f < $scope.preSettings.length; f++) {
                                            if ($scope.preSettings[f].field == staticName.concat(str)) {
                                                $scope.defdata.push($scope.preSettings[f]);
                                                catflag = true;
                                                break;
                                            }
                                        }

                                        if (catflag == false) {
                                            $scope.defdata.push(defObjForCat(str, 400, i, true, celltemp, editCellTempForEngDescript));
                                        }

                                    } else {
                                        $scope.defdata.push(defObjForCat(str, 400, i, true, celltemp, editCellTempForEngDescript));
                                    }
                                } else {
                                    $scope.defdata.push(defObjForCat(str, 400, i, true, celltemp, editCellTempForEngDescript));
                                }
                            } else {
                                if (commonService.getSessionData('gridContextInstance') != null) {
                                    if (commonService.getSessionData('gridContextSaved') == true && commonService.getSessionData('gridContextInstance').length > 0 && hideCatCols) {
                                        var catflag = false;
                                        for (var f = 0; f < $scope.preSettings.length; f++) {
                                            if ($scope.preSettings[f].field == staticName.concat(str)) {
                                                $scope.defdata.push($scope.preSettings[f]);
                                                catflag = true;
                                                break;
                                            }
                                        }

                                        if (catflag == false) {
                                            $scope.defdata.push(defObjForCat(str, 150, i, true, celltemp, editCellTempForCat));

                                        }
                                    } else {
                                        $scope.defdata.push(defObjForCat(str, 150, i, true, celltemp, editCellTempForCat));

                                    }
                                } else {
                                    $scope.defdata.push(defObjForCat(str, 150, i, true, celltemp, editCellTempForCat));
                                }
                            }
                        } else {
                            if (commonService.getSessionData('gridContextInstance') != null) {
                                if (commonService.getSessionData('gridContextSaved') == true && commonService.getSessionData('gridContextInstance').length > 0 && hideCatCols) {
                                    var catflag = false;
                                    for (var f = 0; f < $scope.preSettings.length; f++) {
                                        if ($scope.preSettings[f].field == staticName.concat(str)) {
                                            $scope.defdata.push($scope.preSettings[f]);
                                            catflag = true;
                                            break;
                                        }
                                    }
                                    if (catflag == false) {
                                        $scope.defdata.push(defObjForCat(str, 150, i, false, celltemp, editCellTempForCat));
                                    }
                                } else {
                                    $scope.defdata.push(defObjForCat(str, 150, i, false, celltemp, editCellTempForCat));
                                }
                            } else {
                                $scope.defdata.push(defObjForCat(str, 150, i, false, celltemp, editCellTempForCat));
                            }


                        }
                    }

                }
            }
        }
        var masterLangfield = $scope.GlossaryInitialTerms.MasterLanguage.MasterLanguageName;
        masterLangfield = masterLangfield.replace(/ +/g, "");
        masterLangfield = masterLangfield.replace(/\//g, '');

        // master-lang column definition according to conditions (RTL or not)
        if ($scope.GlossaryInitialTerms.MasterLanguage.IsRLT === true) {
            $scope.defdata.push({
                field: masterLangfield,
                displayName: $scope.GlossaryInitialTerms.MasterLanguage.MasterLanguageName,
                width: 300,
                pinned: false,
                enableCellEdit: true,
                headerCellTemplate: hc_nopin_master_rtl,
                cellTemplate: '<div class="ngCellText pull-left width100per"> <div class="pull-left termImgDiv" ng-hide="row.getProperty(col.field).MasterImageUrl == null || isTermImageOn"> <img src="{{row.getProperty(col.field).MasterImageUrl}}" class="termImg"/> </div> <div class="pull-right ngCellText ngCellTextMasterTerm" tooltip={{row.getProperty(col.field).term}}  tooltip-placement="top" ng-cell-text>{{row.getProperty(col.field).term}}<br><br><span style="color:lime;" title="{{row.getProperty(col.field).brandlist}}">{{row.getProperty(col.field).brandcount}}</span></div></div>',
                cellClass: 'cellToolTip',
                editableCellTemplate: '<textarea readonly ng-class="\'colt\' + col.index" style="min-width:200px; resize: none; height:110px;"  ng-model="row.getProperty(col.field)term" ng-input="row.getProperty(col.field).term" class="txtArea"/>',
                cellClass: 'langg'
            });

        } else {
            $scope.defdata.push({
                field: masterLangfield,
                displayName: $scope.GlossaryInitialTerms.MasterLanguage.MasterLanguageName,
                width: 300,
                pinned: false,
                enableCellEdit: true,
                cellTemplate: '<div class="ngCellText pull-left width100per"><div class="pull-left ngCellText ngCellTextMasterTerm" tooltip={{row.getProperty(col.field).term}}  tooltip-placement="top" ng-cell-text>{{row.getProperty(col.field).term}}<br><br><span style="color:lime;" title="{{row.getProperty(col.field).brandlist}}">{{row.getProperty(col.field).brandcount}}</span></div><div class="pull-right termImgDiv" ng-hide="row.getProperty(col.field).MasterImageUrl == null || isTermImageOn"><img src="{{row.getProperty(col.field).MasterImageUrl}}" class="termImg"/> </div></div>',//ng-if="row.getProperty(col.field).MasterImageUrl == null"
                cellClass: 'cellToolTip',
                editableCellTemplate: '<textarea readonly ng-class="\'colt\' + col.index" style="min-width:200px; resize: none; height:110px;"  ng-model="row.getProperty(col.field).term" ng-input="row.getProperty(col.field).term" class="txtArea"/>'
            });
        }

        // Brand column definition 
        $scope.defdata.push({
            field: "brand",
            displayName: 'Brand',
            width: 150,
            pinned: false,
            enableCellEdit: true,
            visible: false,
            cellTemplate: celltemp,
            cellClass: 'cellToolTip',
            editableCellTemplate: '<textarea readonly ng-class="\'colt\' + col.index" style="min-width:200px; resize: none; height:110px;"  ng-model="row.getProperty(col.field).term" ng-input="row.getProperty(col.field).term" class="txtArea"/>'
        });

        // English Id column definition 
        $scope.defdata.push({
            field: uuid,
            displayName: 'Unique Id',
            width: 150,
            pinned: false,
            enableCellEdit: true,
            cellTemplate: '<div class="ngCellText" tooltip={{row.getProperty(col.field).term}}  tooltip-placement="top" ng-cell-text>{{row.getProperty(col.field).term}}<span ng-click="getTermSuggestions(row.getProperty(col.field))" ng-class="{\'suggestion-on\':row.getProperty(col.field).IsSuggestionExist, \'suggestion-off\': !row.getProperty(col.field).IsSuggestionExist, \'suggestion-null\':row.getProperty(col.field).IsSuggestionExist === null}"></span></div>',
            cellClass: 'cellToolTip',
            editableCellTemplate: '<textarea readonly ng-class="\'colt\' + col.index" style="min-width:200px; resize: none; height:110px;"  ng-model="row.getProperty(col.field).term" ng-input="row.getProperty(col.field).term" class="txtArea"/>'
        });

        // Starred column definition 
        $scope.defdata.push({
            field: 'Starred',
            displayName: 'Starred',
            width: 60,
            headerCellTemplate: hc_nopin,
            enableCellEdit: false,
            //cellTemplate: '<div class="ngCellText" ng-click="listStarredTerms(row.getProperty(col.field))" ng-class="{\'ngCellText\' : isStarred, \'starred-icon ngCellText\': !isStarred && checkIsStarred(row.getProperty(col.field))}"  ng-cell-text></div>'
            //cellTemplate: '<div class="ngCellText" ng-cell-text> <br/> <span ng-click="listStarredTerms(row.getProperty(col.field),row)" ng-class="{\'ngCellText\' : isStarred, \'starred-icon ngCellText\': !isStarred && checkIsStarred(row.getProperty(col.field))}"></span> <br/> <span class="ngCellText" ng-click="autoTranslationPopup(row)" ng-class="{\'auto-translation-on\' : row.getProperty(col.field).HasConsistanceApprovedTranslation == true, \'auto-translation-off\' : row.getProperty(col.field).HasConsistanceApprovedTranslation == false}"></span></div> '
            cellTemplate: '<div class="ngCellText" ng-cell-text> <br/> <span ng-click="listStarredTerms(row.getProperty(col.field),row)" ng-class="{ \'is-consistance-translation-true ngCellText\' : row.getProperty(col.field).IsConsistanceTranslation === true && checkIsStarred(row.getProperty(col.field)), \'is-consistance-translation-false ngCellText\' : row.getProperty(col.field).IsConsistanceTranslation === false && checkIsStarred(row.getProperty(col.field)) , \'is-consistance-translation-null ngCellText\' : row.getProperty(col.field).IsConsistanceTranslation === null && checkIsStarred(row.getProperty(col.field)) }"></span> <br/> <span ng-click="autoTranslationPopup(row.getProperty(col.field),row)" ng-class="{\'auto-translation-on\' : row.getProperty(col.field).HasConsistanceApprovedTranslation == true, \'auto-translation-off\' : row.getProperty(col.field).HasConsistanceApprovedTranslation == false}"></span></div> ',
            visible: $scope.hideStarredCol
        });

        var langList = $scope.GlossaryInitialTerms.ProjectLanguages;
        if ($scope.filter == true) {
            langList = [];
            langList.push($scope.FilterLang);
        }
        for (var i = 0; i < langList.length; i++) {
            if ($scope.translationProjectLanguageId === langList[i].ProjectLanguageId) {
                var str2 = langList[i].ProjectLanguageId.toString();
                var staticLang = 'lang';
                // column definition for langauge(translation , version , comment ) columns in ng-grid

                //GLMGR-1030 Translation source template
                if (langList[i].IsTranslationSourceRequired === true) {
                    $scope.transSourceDisabled = false;
                    transSourceRequired = true;
                    $scope.defdata.push({
                        field: 'source' + staticLang.concat(str2),
                        displayName: 'Trans Source',
                        width: 140,
                        pinned: false,
                        disableColumnMenu: true,
                        enableCellEdit: false,
                        sortable: false,
                        headerCellTemplate: hc_nopin_source,
                        cellTemplate: '<div class="ngCellText" ng-click="addTranslationSource(row.getProperty(col.field))" ng-class="{\'source-icon-on\' : row.getProperty(col.field).IsTranslationSourceAdded == true, \'source-icon\' : row.getProperty(col.field).IsTranslationSourceAdded == false}" ng-cell-text></div>',
                        visible: !$scope.isTranslationSourceRequired
                    });
                }

                if (langList[i].IsRightToLeft == true) {
                    $scope.defdata.push({
                        field: staticLang.concat(str2),
                        displayName: langList[i].LanguageName,
                        width: 400,
                        headerCellTemplate: hc_nopin_language_rtl,
                        enableCellEdit: $scope.enableCellEditFlag,
                        cellEditableCondition: 'row.getProperty(col.field).edit == true',
                        cellTemplate: '<div  class="ngCellText"  ng-cell-text>{{row.getProperty(col.field).term}}</div>',
                        editableCellTemplate: '<textarea ng-class="\'colt\' + col.index" style="min-width:400px; resize: none; height:110px;"  ng-model="row.getProperty(col.field).term" ng-input="row.getProperty(col.field).term" class="txtArea" ng-keyup="onTextChange($event)"/>',
                        cellClass: 'langg'
                    });
                    $scope.defdata.push({
                        field: 'Phonetic' + staticLang.concat(str2),
                        displayName: 'Phonetic',
                        width: 100,
                        disableColumnMenu: true,
                        headerCellTemplate: hc_nopin,
                        enableCellEdit: $scope.enableCellEditFlag,
                        sortable: false,
                        cellEditableCondition: 'row.getProperty(col.field).edit == true',
                        cellTemplate: '<div  class="ngCellText"  ng-cell-text>{{row.getProperty(col.field).PhoneticTerm}}</div>',
                        editableCellTemplate: '<textarea ng-class="\'colt\' + col.index" style="min-width:100px; resize: none; height:110px;"  ng-model="row.getProperty(col.field).PhoneticTerm" ng-input="row.getProperty(col.field).PhoneticTerm" class="txtArea" ng-keyup="onTextChange($event)"/>',
                        cellClass: 'langg'
                    });
                    $scope.defdata.push({
                        field: 'Plural' + staticLang.concat(str2),
                        displayName: 'Plural',
                        width: 100,
                        disableColumnMenu: true,
                        headerCellTemplate: hc_nopin,
                        enableCellEdit: $scope.enableCellEditFlag,
                        sortable: false,
                        cellEditableCondition: 'row.getProperty(col.field).edit == true',
                        cellTemplate: '<div  class="ngCellText"  ng-cell-text>{{row.getProperty(col.field).PluralTerm}}</div>',
                        editableCellTemplate: '<textarea ng-class="\'colt\' + col.index" style="min-width:100px; resize: none; height:110px;"  ng-model="row.getProperty(col.field).PluralTerm" ng-input="row.getProperty(col.field).PluralTerm" class="txtArea" ng-keyup="onTextChange($event)"/>',
                        cellClass: 'langg'
                    });

                } else {
                    $scope.defdata.push({
                        field: staticLang.concat(str2),
                        displayName: langList[i].LanguageName,
                        width: 400,
                        headerCellTemplate: hc_nopin_language,
                        enableCellEdit: $scope.enableCellEditFlag,
                        cellEditableCondition: 'row.getProperty(col.field).edit == true',
                        cellTemplate: '<div  class="ngCellText"  ng-cell-text>{{row.getProperty(col.field).term}}</div>',
                        editableCellTemplate: '<textarea ng-class="\'colt\' + col.index" style="min-width:400px; resize: none; height:110px;"  ng-model="row.getProperty(col.field).term" ng-input="row.getProperty(col.field).term" class="txtArea" ng-keyup="onTextChange($event)"/>'
                    });
                    $scope.defdata.push({
                        field: 'Phonetic' + staticLang.concat(str2),
                        displayName: 'Phonetic',
                        width: 100,
                        disableColumnMenu: true,
                        headerCellTemplate: hc_nopin,
                        enableCellEdit: $scope.enableCellEditFlag,
                        sortable: false,
                        cellEditableCondition: 'row.getProperty(col.field).edit == true',
                        cellTemplate: '<div  class="ngCellText"  ng-cell-text>{{row.getProperty(col.field).PhoneticTerm}}</div>',
                        editableCellTemplate: '<textarea ng-class="\'colt\' + col.index" style="min-width:100px; resize: none; height:110px;"  ng-model="row.getProperty(col.field).PhoneticTerm" ng-input="row.getProperty(col.field).PhoneticTerm" class="txtArea" ng-keyup="onTextChange($event)"/>'
                    });
                    $scope.defdata.push({
                        field: 'Plural' + staticLang.concat(str2),
                        displayName: 'Plural',
                        width: 100,
                        disableColumnMenu: true,
                        headerCellTemplate: hc_nopin,
                        enableCellEdit: $scope.enableCellEditFlag,
                        sortable: false,
                        cellEditableCondition: 'row.getProperty(col.field).edit == true',
                        cellTemplate: '<div  class="ngCellText"  ng-cell-text>{{row.getProperty(col.field).PluralTerm}}</div>',
                        editableCellTemplate: '<textarea ng-class="\'colt\' + col.index" style="min-width:100px; resize: none; height:110px;"  ng-model="row.getProperty(col.field).PluralTerm" ng-input="row.getProperty(col.field).PluralTerm" class="txtArea" ng-keyup="onTextChange($event)"/>'
                    });

                }

                $scope.defdata.push({
                    field: 'Ver' + staticLang.concat(str2),
                    displayName: 'V',
                    width: 40,
                    enableCellEdit: false,
                    sortable: false,
                    headerCellTemplate: hc_nopin,
                    cellTemplate: '<div ng-class="{ CLIENT_APPROVED : row.getProperty(col.field).TermStatus == \'CLIENT_APPROVED\'&&!hideColors, APPROVER_APPROVED : row.getProperty(col.field).TermStatus == \'APPROVER_APPROVED\'&&!hideColors, TRANSLATION_COMPLETED : row.getProperty(col.field).TermStatus == \'TRANSLATION_COMPLETED\'&&!hideColors, CLIENT_REJECTED : row.getProperty(col.field).TermStatus == \'CLIENT_REJECTED\'&&!hideColors , APPROVER_REJECTED : row.getProperty(col.field).TermStatus == \'APPROVER_REJECTED\'&&!hideColors }"><div class="ngCellText" ng-hide="row.getProperty(col.field).IsVersionToHide">{{row.getProperty(col.field).Ver}}</div></div>'
                });
                $scope.defdata.push({
                    field: 'Status' + staticLang.concat(str2),
                    displayName: 'Approval Status',
                    width: 120,
                    disableColumnMenu: true,
                    enableCellEdit: false,
                    headerCellTemplate: hc_nopin,
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field).Status}}</div>'
                });
                $scope.defdata.push({
                    field: 'comment' + staticLang.concat(str2),
                    displayName: 'C',
                    width: 25,
                    pinned: false,
                    headerCellTemplate: hc_nopin,
                    enableCellEdit: false,
                    sortable: false,
                    cellTemplate: '<div class="ngCellText"  style=" padding-left:0px; width:25px; height:70px;" ng-click="addComment(row.getProperty(col.field))" ng-class="{\'bgcolor\' : row.getProperty(col.field).cmntcolor == true, \'comment-icon\' : row.getProperty(col.field).cmntcolor == false}" ng-cell-text></div>',
                    cellClass: 'cellToolTip'
                });

            }

        }


        /*Below logic -- data for columns according to colmn def. Here additional data might be stored inside the column which not shown on ng-grid .This is done to implement certain functionalities and also differntiate different rows 
         For example GlossaryTranslationId will be stored in coment column so that when comment icon is clicked we have the id to send it to backened for further communication*/

        for (var k = 0; k < glossaryData.MasterGlossaries.length; k++) {
            var gridRowDataObj = {};

            //data for Category columns according to colmn def. 
            for (var l = 0; l < glossaryData.MasterGlossaries[k].ProjectCategories.length; l++) {
                var catDataObj = {};
                catDataObj['term'] = glossaryData.MasterGlossaries[k].ProjectCategories[l].CategoryText;
                catDataObj['languageTranslation'] = false;
                var str3 = glossaryData.MasterGlossaries[k].ProjectCategories[l].ProjectCategoryId.toString();
                gridRowDataObj[staticName.concat(str3)] = catDataObj;
            }


            var masterobj = {};
            var uuidobj = {};
            var brandobj = {};
            //data for Master-lang column according to colmn def. 
            masterobj['term'] = glossaryData.MasterGlossaries[k].MasterText;
            masterobj['languageTranslation'] = false;
            masterobj['MasterImageUrl'] = glossaryData.MasterGlossaries[k].MasterImageUrl;
            if (glossaryData.MasterGlossaries[k].BrandCount > 1) {
                masterobj['brandcount'] = glossaryData.MasterGlossaries[k].BrandCount.toString() + " brands";
            }

            var brandArray = [];
            var brandListV = 'This term is associated to these brands: \n ';
            if (glossaryData.MasterGlossaries[k].BrandCount > 0) {
                for (var i = 0; i < glossaryData.MasterGlossaries[k].GlossaryAddedBrands.length; i++) {
                    brandArray.push(glossaryData.MasterGlossaries[k].GlossaryAddedBrands[i].BrandName);
                    brandListV = brandListV + (glossaryData.MasterGlossaries[k].GlossaryAddedBrands[i].BrandName) + ' \n ';
                }
            }
            //data for brand column according to colmn def. 
            brandobj['term'] = brandArray.join();
            gridRowDataObj['brand'] = brandobj;

            masterobj['brandlist'] = brandListV;
            gridRowDataObj[masterLangfield] = masterobj;

            //data for English Id column according to colmn def. 
            uuidobj['term'] = glossaryData.MasterGlossaries[k].MasterGlossaryId;
            uuidobj['languageTranslation'] = false;
            uuidobj['IsSuggestionExist'] = glossaryData.MasterGlossaries[k].IsSuggestionExist;
            uuidobj['MasterGlossaryId'] = glossaryData.MasterGlossaries[k].MasterGlossaryId;
            uuidobj['MasterText'] = glossaryData.MasterGlossaries[k].MasterText;
            gridRowDataObj[uuid] = uuidobj;

            //data for language columns
            for (var m = 0; m < glossaryData.MasterGlossaries[k].ProjectLanguages.length; m++) {
                if ($scope.translationProjectLanguageId == glossaryData.MasterGlossaries[k].ProjectLanguages[m].ProjectLanguageId) {
                    var str4 = glossaryData.MasterGlossaries[k].ProjectLanguages[m].ProjectLanguageId.toString();
                    var staticlangString = 'lang';
                    $scope.languageTransField = staticlangString.concat(str4);
                    var langTransDataObj = {};
                    var langVerDataObj = {};
                    var langCmntDataObj = {};
                    var langStatusDataObj = {};
                    var langPhoneticDataObj = {};
                    var langPluralDataObj = {};
                    var langTrnSourceDataObj = {};
                    var starredDataObj = {};
                    //var langAutoTranslationObj = {};

                    //data for language translation column
                    langTransDataObj['term'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].TranslatedTerm;
                    langTransDataObj['OriginalText'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].TranslatedTerm;
                    langTransDataObj['MasterTerm'] = glossaryData.MasterGlossaries[k].MasterText;
                    if (!glossaryData.MasterGlossaries[k].ProjectLanguages[m].RowVersion) {
                        langTransDataObj['RowVersion'] = null;
                    } else {
                        langTransDataObj['RowVersion'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].RowVersion;
                    }

                    langTransDataObj['IsVersionToHide'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].IsVersionToHide;
                    langTransDataObj['TermStatus'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus;
                    langTransDataObj['ProjectLanguageId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].ProjectLanguageId;
                    langTransDataObj['MasterGlossaryId'] = glossaryData.MasterGlossaries[k].MasterGlossaryId;
                    langTransDataObj['GlossaryTranslationId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].GlossaryTranslationId;
                    $scope.GlossaryTransId = glossaryData.MasterGlossaries[k].ProjectLanguages[m].GlossaryTranslationId;
                    langTransDataObj['Version'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].Version;
                    langTransDataObj['ClientUserId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].ClientUserId;
                    langTransDataObj['ApproverUserId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].ApproverUserId;
                    langTransDataObj['PhoneticTerm'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].PhoneticTerm;
                    langTransDataObj['PluralTerm'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].PluralTerm;
                    langTransDataObj['languageTranslation'] = true;
                    langTransDataObj['IsTranslationTermUpdate'] = true;
                    langTransDataObj['IsPhoneticTermUpdate'] = false;
                    langTransDataObj['IsPluralizedTermUpdate'] = false;
                    if (glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus == null) {
                        langTransDataObj['edit'] = true;
                    } else {
                        langTransDataObj['edit'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].IsEditable;
                    }
                    gridRowDataObj[staticlangString.concat(str4)] = langTransDataObj;

                    //data for language phonetic column
                    langPhoneticDataObj['PhoneticTerm'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].PhoneticTerm;
                    langPhoneticDataObj['OriginalText'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].PhoneticTerm;
                    langPhoneticDataObj['MasterTerm'] = glossaryData.MasterGlossaries[k].MasterText;
                    langPhoneticDataObj['LanguageTerm'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].TranslatedTerm;
                    langPhoneticDataObj['TermStatus'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus;
                    langPhoneticDataObj['ProjectLanguageId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].ProjectLanguageId;
                    langPhoneticDataObj['MasterGlossaryId'] = glossaryData.MasterGlossaries[k].MasterGlossaryId;
                    langPhoneticDataObj['GlossaryTranslationId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].GlossaryTranslationId;
                    langPhoneticDataObj['RowVersion'] = langTransDataObj['RowVersion'];
                    langPhoneticDataObj['Version'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].Version;
                    langPhoneticDataObj['ClientUserId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].ClientUserId;
                    langPhoneticDataObj['ApproverUserId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].ApproverUserId;
                    langPhoneticDataObj['languageTranslation'] = true;
                    langPhoneticDataObj['IsTranslationTermUpdate'] = false;
                    langPhoneticDataObj['IsPhoneticTermUpdate'] = true;
                    langPhoneticDataObj['IsPluralizedTermUpdate'] = false;
                    langPhoneticDataObj['PluralTerm'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].PluralTerm;
                    langPhoneticDataObj['edit'] = true;
                    gridRowDataObj['Phonetic' + staticlangString.concat(str4)] = langPhoneticDataObj;

                    //data for language plural column
                    langPluralDataObj['PluralTerm'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].PluralTerm;
                    langPluralDataObj['OriginalText'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].PluralTerm;
                    langPluralDataObj['MasterTerm'] = glossaryData.MasterGlossaries[k].MasterText
                    langPluralDataObj['LanguageTerm'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].TranslatedTerm;
                    langPluralDataObj['TermStatus'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus;
                    langPluralDataObj['ProjectLanguageId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].ProjectLanguageId;
                    langPluralDataObj['MasterGlossaryId'] = glossaryData.MasterGlossaries[k].MasterGlossaryId;
                    langPluralDataObj['GlossaryTranslationId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].GlossaryTranslationId;
                    langPluralDataObj['RowVersion'] = langTransDataObj['RowVersion'];
                    langPluralDataObj['Version'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].Version;
                    langPluralDataObj['ClientUserId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].ClientUserId;
                    langPluralDataObj['ApproverUserId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].ApproverUserId;
                    langPluralDataObj['languageTranslation'] = true;
                    langPluralDataObj['IsTranslationTermUpdate'] = false;
                    langPluralDataObj['IsPhoneticTermUpdate'] = false;
                    langPluralDataObj['IsPluralizedTermUpdate'] = true;
                    langPluralDataObj['PhoneticTerm'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].PhoneticTerm;
                    langPluralDataObj['edit'] = true;
                    gridRowDataObj['Plural' + staticlangString.concat(str4)] = langPluralDataObj;

                    langVerDataObj['TermStatus'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus;
                    langVerDataObj['IsVersionToHide'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].IsVersionToHide;
                    langVerDataObj['Ver'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].Version;

                    gridRowDataObj['Ver' + staticlangString.concat(str4)] = langVerDataObj;
                    if (glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'NOT_STARTED') {
                        langStatusDataObj['Status'] = 'N/A';
                        langStatusDataObj['term'] = 'N/A';
                    } else if (glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'APPROVER_APPROVED' || glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'CLIENT_APPROVED') {
                        langStatusDataObj['Status'] = 'Approved';
                        langStatusDataObj['term'] = 'Approved';
                    } else if (glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'APPROVER_REJECTED' || glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'CLIENT_REJECTED') {
                        langStatusDataObj['Status'] = 'Rejected';
                        langStatusDataObj['term'] = 'Rejected';
                    } else if (glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'TRANSLATION_COMPLETED') {
                        langStatusDataObj['Status'] = 'Pending';
                        langStatusDataObj['term'] = 'Pending';
                    } else if (glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'APPROVER_APPROVED_IN_PROGRESS' || glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'APPROVER_REJECTED_IN_PROGRESS' || glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'CLIENT_APPROVER_IN_PROGRESS' || glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'CLIENT_REJECTED_IN_PROGRESS') {
                        langStatusDataObj['Status'] = 'In Progress';
                        langStatusDataObj['term'] = 'In Progress';
                    }
                    gridRowDataObj['Status' + staticlangString.concat(str4)] = langStatusDataObj;
                    langCmntDataObj['GlossaryTranslationId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].GlossaryTranslationId;
                    langCmntDataObj['MasterGlossaryId'] = glossaryData.MasterGlossaries[k].MasterGlossaryId;
                     langCmntDataObj['LanguageName'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].LanguageName;
                    langCmntDataObj['ProjectLanguageId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].ProjectLanguageId;
                    langCmntDataObj['cmntcolor'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].IsCommented;
                    gridRowDataObj['comment' + staticlangString.concat(str4)] = langCmntDataObj;
                    //Translation Source GLMGR-1030
                    langTrnSourceDataObj['MasterGlossaryId'] = glossaryData.MasterGlossaries[k].MasterGlossaryId;
                    langTrnSourceDataObj['IsTranslationSourceAdded'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].IsTranslationSourceAdded;
                    langTrnSourceDataObj['GlossaryTranslationId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].GlossaryTranslationId;
                    gridRowDataObj['source' + staticlangString.concat(str4)] = langTrnSourceDataObj;

                    //data for Starred column according to colmn def. 
                    starredDataObj['MasterText'] = glossaryData.MasterGlossaries[k].MasterText;
                    starredDataObj['MasterGlossaryId'] = glossaryData.MasterGlossaries[k].MasterGlossaryId;
                    starredDataObj['GlossaryTranslationId'] = $scope.GlossaryTransId;
                    starredDataObj['starred'] = glossaryData.MasterGlossaries[k].IsStarred;
                    starredDataObj['TranslatedTerm'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].TranslatedTerm;

                    starredDataObj['HasConsistanceApprovedTranslation'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].HasConsistanceApprovedTranslation; //Auto Translation GLMGR-1125
                    starredDataObj['IsConsistanceTranslation'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].IsConsistanceTranslation; //Auto Translation GLMGR-1126

                    gridRowDataObj['Starred'] = starredDataObj;

                }
            }
            $scope.facdata.push(gridRowDataObj);

        }

        //ng-grid height adjustment on selection of section

        if (isVisible == false) {

            $('.wide-screen-wrapper .ngViewport').css('height', window.innerHeight - 590);
            $('.wide-screen-wrapper .gridStyle').css('height', window.innerHeight - 550);
        } else {

            $('.wide-screen-wrapper .ngViewport').css('height', window.innerHeight - 270);
            $('.wide-screen-wrapper .gridStyle').css('height', window.innerHeight - 230);
        }
    };

    /* Status filter starts */
    //GLMGR-1227 Select all checkbox
    $scope.selectAllLangFilters = function () {
        if ($('#selectAll:checkbox:checked').length > 0) {
            $('#pendingTranslationsFilter').prop('checked', true);
            $('#pendingApprovalsFilter').prop('checked', true);
            $('#approvedFilter').prop('checked', true);
            $('#rejectedFilter').prop('checked', true);
        } else {
            $('#pendingTranslationsFilter').prop('checked', false);
            $('#pendingApprovalsFilter').prop('checked', false);
            $('#approvedFilter').prop('checked', false);
            $('#rejectedFilter').prop('checked', false);
        }
    };

     /**
     * @ngdoc
     * @name filterOptions
     * @methodOf Projects.controller:TranslationController
     * @description
     * This function is called on Save filter settings button on filters popup.This is used to set filters on glossary data.
     * @returns {undefined} This method does not return.
     */
    $scope.filterOptions = function () {
        $('#filterOption').modal('hide');
        $scope.showLoader = true;
        //GLMGR-622 
        sessionStorage.setItem("filterOnStatus", "1");
        sessionStorage.setItem("filterglossaryLang", "1");
        // Calling backened to get the latest data for the grid as this page is editable and statuses may change when data is modified.
        Glossary.getTranslationData($scope.projectId, commonService.getSessionData('GlossarySection').Id, commonService.getLocalData('userDetails').UserId, $scope.translationProjectLanguageId, function (glossaryData) {
            $scope.glossaryData = glossaryData;
            $scope.glossaryCopy = {};
            var count = 0;

            //empty language model to be pushed inside in case of pending translation
            var langModel = {
                GlossaryTranslationId: 0,
                IsEditable: true,
                LanguageId: 0,
                LanguageName: "",
                ProjectId: 0,
                ProjectLanguageId: 0,
                TermStatus: "",
                PhoneticTerm: "",
                PluralTerm: "",
                TranslatedTerm: "Translation Pending",
                Version: ""
            };
            //Making copy of glossay i.e. glossaryCopy
            angular.copy($scope.glossaryData, $scope.glossaryCopy);

            //emtying the language data from glossaryCopy
            for (var i = 0; i < $scope.glossaryCopy.MasterGlossaries.length; i++) {
                $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages = [];
            }

            //Calculating for no of filter checkboxes checked
            $('.filter-checkboxes:checked').each(function (id, value) {
                count++;

            });

            /*checking whether language is selected or not . If-block contains language selected logic else-block throws an error message . 
              Not required here as such because User cannot select language as only one langauge is displayed on the page*/
            if ($scope.FilterLang) {

                // if  filter checkboxes are checked 
                if (count > 0) {
                    $('#filterOptionsButton').css("border-style", "ridge");
                    $('#filterOptionsButton').css("border-color", "red");
                    $('#filterOptionsButton').css("background-image", "url('../../../Content/Common/Assets/Images/export_s.png')");
                    $('#filterOptionsButton').css("color", "red");

                    var islangStatusSet = false;
                    /*checking whether pending Translations checkbox is checked or not. If checked then applying the filter logic for that
                    Backened Jason contain no language data for translations which are not started hence we push langModel for those terms
                    but when there is no translation in the whole glossary section then they send language data with null values then we have push the language data sent by backened*/

                    if ($('#pendingTranslationsFilter:checkbox:checked').length > 0) {
                        var islangStatusSet = true;
                        for (var i = 0; i < $scope.glossaryData.MasterGlossaries.length; i++) {
                            var flag = false;
                            for (var k = 0; k < $scope.glossaryData.MasterGlossaries[i].ProjectLanguages.length; k++) {
                                if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].ProjectLanguageId == $scope.FilterLang.ProjectLanguageId) {
                                    if ($('#pendingSuggFilter:checkbox:checked').length > 0) {
                                        if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TranslatedTerm == null && $scope.glossaryData.MasterGlossaries[i].IsSuggestionExist === false) {
                                            // null values in language data
                                            flag = true;
                                            $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages.push($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k]);
                                            break;
                                        } else {
                                            //translation present hence skip it
                                            flag = true;
                                            break;
                                        }
                                    }
                                    else {
                                        if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TranslatedTerm != null) {
                                            //translation present hence skip it
                                            flag = true;
                                            break;
                                        } else {
                                            // null values in language data
                                            flag = true;
                                            $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages.push($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k]);
                                            break;
                                        }
                                    }
                                }
                            }
                            if (flag == false) {
                                // no langauge data in backened jason
                                $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages.push(langModel);
                            }
                        }
                        $scope.filter = true;
                    }

                    /*checking whether approved Translations checkbox is checked or not. If checked then applying the filter logic for that*/
                    if ($('#approvedFilter:checkbox:checked').length > 0) {
                        var islangStatusSet = true;
                        for (var i = 0; i < $scope.glossaryData.MasterGlossaries.length; i++) {
                            var flag = false;
                            for (var k = 0; k < $scope.glossaryData.MasterGlossaries[i].ProjectLanguages.length; k++) {
                                if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].ProjectLanguageId == $scope.FilterLang.ProjectLanguageId) {
                                    if ($('#pendingSuggFilter:checkbox:checked').length > 0) {
                                        if (($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'APPROVER_APPROVED' || $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'CLIENT_APPROVED') && $scope.glossaryData.MasterGlossaries[i].IsSuggestionExist === false) {
                                            $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages.push($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k]);
                                        }
                                    } else {
                                        if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'APPROVER_APPROVED' || $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'CLIENT_APPROVED') {
                                            $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages.push($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k]);
                                        }
                                    }
                                }
                            }
                        }
                        $scope.filter = true;
                    }

                    /*checking whether rejected Translations checkbox is checked or not. If checked then applying the filter logic for that*/
                    if ($('#rejectedFilter:checkbox:checked').length > 0) {
                        var islangStatusSet = true;
                        for (var i = 0; i < $scope.glossaryData.MasterGlossaries.length; i++) {
                            var flag = false;
                            for (var k = 0; k < $scope.glossaryData.MasterGlossaries[i].ProjectLanguages.length; k++) {
                                if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].ProjectLanguageId == $scope.FilterLang.ProjectLanguageId) {
                                    if ($('#pendingSuggFilter:checkbox:checked').length > 0) {
                                        if (($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'APPROVER_REJECTED' || $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'CLIENT_REJECTED') && $scope.glossaryData.MasterGlossaries[i].IsSuggestionExist === false) {
                                            $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages.push($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k]);
                                        }
                                    } else {
                                        if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'APPROVER_REJECTED' || $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'CLIENT_REJECTED') {
                                            $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages.push($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k]);
                                        }
                                    }
                                }
                            }
                        }
                        $scope.filter = true;
                    }

                    /*checking whether pending Approvals checkbox is checked or not. If checked then applying the filter logic for that*/
                    if ($('#pendingApprovalsFilter:checkbox:checked').length > 0) {
                        var islangStatusSet = true;
                        for (var i = 0; i < $scope.glossaryData.MasterGlossaries.length; i++) {
                            var flag = false;
                            for (var k = 0; k < $scope.glossaryData.MasterGlossaries[i].ProjectLanguages.length; k++) {
                                if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].ProjectLanguageId == $scope.FilterLang.ProjectLanguageId) {
                                    if ($('#pendingSuggFilter:checkbox:checked').length > 0) {
                                        if (($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'TRANSLATION_COMPLETED' || $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'APPROVER_APPROVED_IN_PROGRESS' || $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'APPROVER_REJECTED_IN_PROGRESS' || $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'CLIENT_APPROVER_IN_PROGRESS' || $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'CLIENT_REJECTED_IN_PROGRESS') && $scope.glossaryData.MasterGlossaries[i].IsSuggestionExist === false) {
                                            $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages.push($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k]);
                                        }
                                    } else {
                                        if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'TRANSLATION_COMPLETED' || $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'APPROVER_APPROVED_IN_PROGRESS' || $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'APPROVER_REJECTED_IN_PROGRESS' || $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'CLIENT_APPROVER_IN_PROGRESS' || $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'CLIENT_REJECTED_IN_PROGRESS') {
                                            $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages.push($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k]);
                                        }
                                    }
                                }
                            }
                        }
                        $scope.filter = true;
                    }

                    /*checking whether pending Suggestion checkbox is checked or not. If checked then applying the filter logic for that*/
                    if (!islangStatusSet) {
                        if ($('#pendingSuggFilter:checkbox:checked').length > 0) {
                            for (var i = 0; i < $scope.glossaryData.MasterGlossaries.length; i++) {
                                var flag = false;
                                for (var k = 0; k < $scope.glossaryData.MasterGlossaries[i].ProjectLanguages.length; k++) {
                                    if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].ProjectLanguageId == $scope.FilterLang.ProjectLanguageId) {
                                        if ($scope.glossaryData.MasterGlossaries[i].IsSuggestionExist === false) {
                                            $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages.push($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k]);
                                        }
                                    }
                                }
                            }
                            $scope.filter = true;
                        }
                    }

                    /*deleting terms in glossaryCopy where no langauge data is present after applying filter*/
                    for (var k = 0; k < $scope.glossaryCopy.MasterGlossaries.length; k++) {
                        if ($scope.glossaryCopy.MasterGlossaries[k].ProjectLanguages.length < 1) {
                            $scope.glossaryCopy.MasterGlossaries.splice(k, 1);
                            k--;
                        }
                    }
                    /*Comment filter '1' for commented terms '2' for un-commented terms . Here filter is applied on glossaryCopy after other filters is applied*/
                    if ($scope.filterStatus == '1') {
                        for (var k = 0; k < $scope.glossaryCopy.MasterGlossaries.length; k++) {
                            if ($scope.glossaryCopy.MasterGlossaries[k].ProjectLanguages[0].IsCommented == false) {
                                $scope.glossaryCopy.MasterGlossaries.splice(k, 1);
                                k--;
                            }
                        }
                    }
                    if ($scope.filterStatus == '2') {
                        for (var k = 0; k < $scope.glossaryCopy.MasterGlossaries.length; k++) {
                            if ($scope.glossaryCopy.MasterGlossaries[k].ProjectLanguages[0].IsCommented == true) {
                                $scope.glossaryCopy.MasterGlossaries.splice(k, 1);
                                k--;
                            }
                        }
                    }
                    /*Image filter 'withImage' for  terms with image 'withoutImage' for terms without terms . Here filter is applied on glossaryCopy after other filters is applied*/
                    if ($scope.filterImage == 'withImage') {
                        for (var k = 0; k < $scope.glossaryCopy.MasterGlossaries.length; k++) {
                            if ($scope.glossaryCopy.MasterGlossaries[k].MasterImageUrl == null) {
                                $scope.glossaryCopy.MasterGlossaries.splice(k, 1);
                                k--;
                            }
                        }
                    }
                    if ($scope.filterImage == 'withoutImage') {
                        for (var k = 0; k < $scope.glossaryCopy.MasterGlossaries.length; k++) {
                            if ($scope.glossaryCopy.MasterGlossaries[k].MasterImageUrl != null) {
                                $scope.glossaryCopy.MasterGlossaries.splice(k, 1);
                                k--;
                            }
                        }
                    }
                    sessionStorage.setItem('glossaryFilterLang', JSON.stringify($scope.FilterLang));
                    sessionStorage.setItem("filterStatus", $scope.filterStatus);
                    sessionStorage.setItem("filterImage", $scope.filterImage);
                    sessionStorage.setItem("pendingTranslationsFilter", $('#pendingTranslationsFilter:checkbox:checked').length);
                    sessionStorage.setItem("pendingApprovalsFilter", $('#pendingApprovalsFilter:checkbox:checked').length);
                    sessionStorage.setItem("approvedFilter", $('#approvedFilter:checkbox:checked').length);
                    sessionStorage.setItem("rejectedFilter", $('#rejectedFilter:checkbox:checked').length);
                    sessionStorage.setItem("pendingSuggFilter", $('#pendingSuggFilter:checkbox:checked').length);
                    sessionStorage.setItem("filterOnStatus", "1");
                    $scope.showLoader = false;
                    $scope.facdata = [];
                    $scope.defdata = [];
                    GlossaryNgGrid($scope.glossaryCopy, commonService.getSessionData('GlossarySection'));
                    $(window).resize();
                }
                    // if no filter checkboxes are checked 
                else {
                    if ($scope.filterStatus || $scope.filterImage) {
                        $('#filterOptionsButton').css("border-style", "ridge");
                        $('#filterOptionsButton').css("border-color", "red");
                        $('#filterOptionsButton').css("background-image", "url('../../../Content/Common/Assets/Images/export_s.png')");
                        $('#filterOptionsButton').css("color", "red");

                        $scope.filter = true;
                        for (var i = 0; i < $scope.glossaryData.MasterGlossaries.length; i++) {
                            for (var k = 0; k < $scope.glossaryData.MasterGlossaries[i].ProjectLanguages.length; k++) {
                                if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].ProjectLanguageId == $scope.FilterLang.ProjectLanguageId) {

                                    $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages.push($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k]);

                                    break;
                                }
                            }
                        }


                        if ($scope.filterStatus == '1') {
                            for (var k = 0; k < $scope.glossaryCopy.MasterGlossaries.length; k++) {
                                if ($scope.glossaryCopy.MasterGlossaries[k].ProjectLanguages[0].IsCommented == false) {
                                    $scope.glossaryCopy.MasterGlossaries.splice(k, 1);
                                    k--;
                                }
                            }
                        }
                        if ($scope.filterStatus == '2') {
                            for (var k = 0; k < $scope.glossaryCopy.MasterGlossaries.length; k++) {
                                if ($scope.glossaryCopy.MasterGlossaries[k].ProjectLanguages[0].IsCommented == true) {
                                    $scope.glossaryCopy.MasterGlossaries.splice(k, 1);
                                    k--;
                                }
                            }
                        }
                        /*Image filter 'withImage' for  terms with image 'withoutImage' for terms without terms . Here filter is applied on glossaryCopy after other filters is applied*/
                        if ($scope.filterImage == 'withImage') {
                            for (var k = 0; k < $scope.glossaryCopy.MasterGlossaries.length; k++) {
                                if ($scope.glossaryCopy.MasterGlossaries[k].MasterImageUrl == null) {
                                    $scope.glossaryCopy.MasterGlossaries.splice(k, 1);
                                    k--;
                                }
                            }
                        }
                        if ($scope.filterImage == 'withoutImage') {
                            for (var k = 0; k < $scope.glossaryCopy.MasterGlossaries.length; k++) {
                                if ($scope.glossaryCopy.MasterGlossaries[k].MasterImageUrl != null) {
                                    $scope.glossaryCopy.MasterGlossaries.splice(k, 1);
                                    k--;
                                }
                            }
                        }
                        $('#filterOption').modal('hide');
                        sessionStorage.setItem('glossaryFilterLang', JSON.stringify($scope.FilterLang));
                        sessionStorage.setItem("filterStatus", $scope.filterStatus);
                        sessionStorage.setItem("filterImage", $scope.filterImage);
                        sessionStorage.setItem("pendingTranslationsFilter", $('#pendingTranslationsFilter:checkbox:checked').length);
                        sessionStorage.setItem("pendingApprovalsFilter", $('#pendingApprovalsFilter:checkbox:checked').length);
                        sessionStorage.setItem("approvedFilter", $('#approvedFilter:checkbox:checked').length);
                        sessionStorage.setItem("pendingSuggFilter", $('#pendingSuggFilter:checkbox:checked').length);
                        sessionStorage.setItem("rejectedFilter", $('#rejectedFilter:checkbox:checked').length);
                        sessionStorage.setItem("filterOnStatus", "1");
                        $scope.facdata = [];
                        $scope.defdata = [];
                        GlossaryNgGrid($scope.glossaryCopy, commonService.getSessionData('GlossarySection'));
                        $scope.showLoader = false;
                        $(window).resize();
                    } else {
                        $('#filterOptionsButton').css("border-style", "none");
                        $('#filterOptionsButton').css("border-color", "none");
                        $('#filterOptionsButton').css("background-image", "url('../../../Content/Common/Assets/Images/export_n.png')");
                        $('#filterOptionsButton').css("color", "white");

                        $('#filterOption').modal('hide');
                        $scope.filter = false;
                        sessionStorage.setItem("filterStatus", "undefined");
                        sessionStorage.setItem("filterImage", "undefined");
                        sessionStorage.setItem("pendingTranslationsFilter", "0");
                        sessionStorage.setItem("pendingApprovalsFilter", "0");
                        sessionStorage.setItem("approvedFilter", "0");
                        sessionStorage.setItem("rejectedFilter", "0");
                        sessionStorage.setItem("pendingSuggFilter", "0");
                        sessionStorage.setItem("filterOnStatus", "0");
                        alert('No filter Selected');
                        $scope.facdata = [];
                        $scope.defdata = [];
                        GlossaryNgGrid($scope.glossaryData, commonService.getSessionData('GlossarySection'));
                        $scope.showLoader = false;
                        $(window).resize();
                    }

                }
                //GLMGR-622 start

                //GLMGR-622 end
            }
            //else {
            //    $scope.showLoader = false;
            //    alert('Please Select Language');
            //}
        });
    };

    $scope.showFilter = function () {
        $('#filterOption').modal({
            backdrop: 'static',
            keyboard: false
        })
        $('#filterOption').modal('show');
    };

    /**
     * @ngdoc
     * @name clearFilterOptions
     * @methodOf Projects.controller:TranslationController
     * @description
     * This function is called on clear filter button on filters poup.This is used to clear all filters.
     * @returns {undefined} This method does not return.
     */
    $scope.clearFilterOptions = function () {
        //GLMGR-622 start
        sessionStorage.setItem("filterStatus", "undefined");
        sessionStorage.setItem("filterImage", "undefined");
        sessionStorage.setItem("pendingTranslationsFilter", "0");
        sessionStorage.setItem("pendingApprovalsFilter", "0");
        sessionStorage.setItem("approvedFilter", "0");
        sessionStorage.setItem("rejectedFilter", "0");
        sessionStorage.setItem("pendingSuggFilter", "0");
        sessionStorage.setItem("filterOnStatus", "0");

        $('#filterOptionsButton').css("border-style", "none");
        $('#filterOptionsButton').css("border-color", "none");
        $('#filterOptionsButton').css("background-image", "url('../../../Content/Common/Assets/Images/export_n.png')");
        $('#filterOptionsButton').css("color", "white");
        //GLMGR-622 end
        location.reload();
    };
    /* Status filter ends */

     /**
     * @ngdoc
     * @name viewSectionResult
     * @methodOf Projects.controller:TranslationController
     * @param {Object} sectionSelected This selected section.
     * @description
     * This function is called on click of search result. This is used to show clicked section data in grid
     * @returns {undefined} This method does not return.
     */
    $scope.viewSectionResult = function (sectionSelected, index) {
        $scope.showLoader = true;
        $scope.searchmode = false;
        var d = document.getElementById(index);
        d.setAttribute('class', 'aTagClicked');
        $scope.facdata = [];
        $scope.defdata = [];
        var data = {};
        data.projectId = $scope.projectId;
        data.headerId = sectionSelected.ProjectHeaderId;
        data.userId = commonService.getLocalData('userDetails').UserId;
        data.roleName = commonService.getLocalData('userDetails').UserRoles[0].UserRoleName;
        data.projectLanguageId = $scope.translationProjectLanguageId;
        data.pageId = 2;
        data.term = $scope.glossarySearchText;
        data.searchedCategory = $scope.glossarySearchCategory;


        Glossary.getSectionData(data, function (glossaryData) {

            if (glossaryData == 'error') {
                $('#serverError').modal('show');
                $scope.showLoader = false;
            }


            $scope.glossaryData = glossaryData;
            for (var i = 0; i < $scope.GlossaryInitialTerms.ProjectHeaders.length; i++) {
                if ($scope.GlossaryInitialTerms.ProjectHeaders[i].Id == sectionSelected.ProjectHeaderId) {
                    $scope.sectionId = $scope.GlossaryInitialTerms.ProjectHeaders[i].Id;

                    sessionStorage.setItem('GlossarySection', JSON.stringify($scope.GlossaryInitialTerms.ProjectHeaders[i]));
                    break;
                }
            }
            Catsequence = glossaryData.ProjectCategorySequence;

            $scope.facdata = [];
            $scope.defdata = [];
            $scope.searchResultStatus = true;

            GlossaryNgGrid(glossaryData);

            $scope.showLoader = false;
            $scope.searchResult = false;
            $scope.resultTable = true;
            $scope.submitshow = true;


            $(window).resize();

        });

    };

    // Language History feature start
      /**
     * @ngdoc
     * @name getLanguageNamePopup
     * @methodOf Projects.controller:TranslationController
     * @description
     * This function is called on Language history button on glossary page.This is used to show popup to select language 
     * @returns {undefined} This method does not return.
     */
    $scope.getLanguageNamePopup = function () {
        $scope.languageHistory = [];
        $scope.categories = [];
        $scope.ProjectLanguages = [];
        getSectionList();
        $scope.historyLogFlag = true;

        if (sessionStorage.getItem("filterOnStatus") === "1") {
            $scope.selectedLanguageId = $scope.FilterLang.ProjectLanguageId;
            $scope.selectedLanguage = $scope.FilterLang;
            $scope.getLanguageHistory($scope.selectedLanguage, commonService.getSessionData('headerId'));
        } else {
            $scope.selectedLanguageId = JSON.parse(sessionStorage.getItem('glossaryNewLang')).ProjectLanguageId;
            $scope.selectedLanguage = JSON.parse(sessionStorage.getItem('glossaryNewLang'));
            $scope.getLanguageHistory($scope.selectedLanguage, commonService.getSessionData('headerId'));
        }
    };

    /**
     * @ngdoc
     * @name getLanguageName
     * @methodOf Projects.controller:TranslationController
     * @param {Object} language This selected language.
     * @description
     * This function is called on change of language dropdown on select language popup.This is used to show language history for selected language 
     * @returns {undefined} This method does not return.
     */
    $scope.getLanguageName = function (language) {
        $('#languageHistory').modal('hide');
        $('.modal-backdrop').css('display', 'none');
        $scope.selectedLanguageId = language.ProjectLanguageId;
        $scope.selectedLanguage = language.LanguageName;
        $scope.getLanguageHistory($scope.selectedLanguage, commonService.getSessionData('headerId'));
    };

     /**
     * @ngdoc
     * @name getLanguageHistory
     * @methodOf Projects.controller:TranslationController
     * @param {Object} selectedLaguageObj This is selected language.
     * @param {Number} sectionSelectedObjId This is selected section id.
     * @description
     * This function is called on change of section dropdown on select language history popup.This is used to get the Language History Information according to the selected language and section
     * @returns {undefined} This method does not return.
     */
    $scope.getLanguageHistory = function (selectedLaguageObj, sectionSelectedObjId) {
        $scope.selectedLanguageId = selectedLaguageObj.ProjectLanguageId;
        $scope.headerId = sectionSelectedObjId;
        $scope.showLoader = true;
        $scope.historyLogFlag = true;


        //Call Service for getting Project History Information
        Glossary.getProjectHistory($scope.projectId, $scope.headerId, $scope.userId, $scope.userRole, $scope.selectedLanguageId, function (languageHistory) {

            //set revert rights for ApproverAsTranslator having different assigned languages
            $scope.revertTranslationApproverAsTranslator = false;
            for (var i = 0; i < $scope.addTranslationlanguages.length; i++) {
                if ($scope.addTranslationlanguages[i].ProjectLanguageId === $scope.selectedLanguageId) {
                    $scope.revertTranslationApproverAsTranslator = true;
                    break;
                }
            }

            $scope.languageHistory = languageHistory;
            var catEmpty = {
                CategoryId: "",
                CategoryName: "",
                CategoryText: "",
                DbProjectId: 0,
                GlossaryCategoryId: 0,
                MasterGlossaryId: 0,
                ProjectCategoryId: 0,
                ProjectId: null
            };
            $scope.categories = $scope.languageHistory.Categories;
            for (var i = 0; i < $scope.languageHistory.MasterGlossaries.length; i++) {
                if ($scope.languageHistory.MasterGlossaries[i].ProjectCategories.length < $scope.categories.length) {

                    for (var j = 0; j < $scope.categories.length; j++) {
                        var flag = 0;
                        for (var k = 0; k < $scope.languageHistory.MasterGlossaries[i].ProjectCategories.length; k++) {
                            if ($scope.languageHistory.MasterGlossaries[i].ProjectCategories[k].CategoryName == $scope.categories[j].CategoryName) {
                                flag = 1;
                                break;
                            }
                        }
                        if (flag == 0) {
                            if (j < $scope.languageHistory.MasterGlossaries[i].ProjectCategories.length) {
                                $scope.languageHistory.MasterGlossaries[i].ProjectCategories.splice(j, 0, catEmpty);
                            }
                            else {
                                $scope.languageHistory.MasterGlossaries[i].ProjectCategories.push(catEmpty);
                            }
                        }

                    }

                }

            }

            //open popup
            $('#languageHistoryPopup').modal({ backdrop: 'static', keyboard: false });
            $('#languageHistoryPopup').modal('show');

            $scope.showLoader = false;
        });
    };

    /**
     * @ngdoc
     * @name toggleHistoryLogForTerm
     * @methodOf Projects.controller:TranslationController
     * @param {Number} termIndex This is index of term in language history table
     * @description
     * This function is called on toggle button in language history poup.
     * @returns {undefined} This method does not return.
     */
    $scope.toggleHistoryLogForTerm = function (termIndex) {
        //var elem = $(this).next('.td1')
        $('.term' + termIndex).toggle('fast');
        //$scope.historyLogFlag = $scope.historyLogFlag === false ? true : false;
    };

    var getSectionList = function () {
        var sectionType = 1;
        if (commonService.getSessionData('glossaryTab') && commonService.getSessionData('glossaryTab') === 'default') {
            sectionType = 1;
        } else if (commonService.getSessionData('glossaryTab') && commonService.getSessionData('glossaryTab') === 'ntl') {
            sectionType = 2;
        }
        Glossary.getGlossaryInitialData($scope.projectId, commonService.getLocalData('userDetails').UserId, sectionType, function (data) {
            $scope.SectionList = data;
            $scope.sectionId = commonService.getSessionData('headerId');
            for (var i = 0; i < data.ProjectHeaders.length; i++) {
                if (commonService.getSessionData('headerId') == data.ProjectHeaders[i].Id) {
                    $scope.sectionSelected = data.ProjectHeaders[i];
                    $scope.headerId = data.ProjectHeaders[i].Id;
                }
            }
            $scope.ObjectId1 = [];
            $scope.ClientName_str = '';
            for (var i = 0; i < data.ProjectClients.length; i++) {
                $scope.ObjectId1.push(data.ProjectClients[i].ClientName);
                $scope.ClientName_str = $scope.ClientName_str + data.ProjectClients[i].ClientName + ', ';
            }
            $scope.ClientName_str = $scope.ClientName_str.slice(0, -2);
        });
    };
    // Language History feature end

        /**
     * @ngdoc
     * @name finalSubmit
     * @methodOf Projects.controller:TranslationController
     * @description
     * This function is called on complete translations button.This function is used to show confirmation poup
     * @returns {undefined} This method does not return.
     */
    $scope.finalSubmit = function () {
        var Statuslang = 'Statuslang' + $scope.translationProjectLanguageId;
        //GLMGR-206
        $scope.IsTermRejected = false;
        $scope.autoApproveReview = false;
        for (var i = 0; i < $scope.facdata.length; i++) {
            if ($scope.facdata[i][Statuslang].Status == 'Rejected') {
                $scope.IsTermRejected = true;
            }
        }

        //language permission check for ApproverAsTransltor to approve the terms for that language
        $scope.IsApproverAsTranslatorUIFlag = false;

        for (var i = 0; i < $scope.addApprovelanguages.length; i++) {
            if ($scope.addApprovelanguages[i].ProjectLanguageId === $scope.translationProjectLanguageId) {
                $scope.IsApproverAsTranslatorUIFlag = true;
                break;
            } else {
                $scope.IsApproverAsTranslatorUIFlag = false;
            }
        }

        //GLMGR-486 check for is having blank translation
        var boolArray = [];
        isHavingBlankTranslation = false;
        for (var i = 0; i < masterGlossaries.length; i++) {
            for (var j = 0; j < masterGlossaries[i].ProjectLanguages.length; j++) {
                if (masterGlossaries[i].ProjectLanguages[j].LanguageId === JSON.parse(sessionStorage.getItem('glossaryNewLang')).LanguageId) {
                    if (masterGlossaries[i].ProjectLanguages[j].TranslatedTerm === null || masterGlossaries[i].ProjectLanguages[j].TranslatedTerm === "") {
                        boolArray.push(true);
                    } else {
                        boolArray.push(false);
                    }
                }
            }
        }

        //iterate boolArray
        for (var i = 0; i < boolArray.length; i++) {
            if (boolArray[i] === true) {
                isHavingBlankTranslation = true;
            }
        }

        if ($scope.IsApproverAsTranslatorUIFlag == true && $scope.facdata.length > 0 && $scope.userRole == 'Approver') {
            $scope.autoApprove = false;
            $scope.autoApproveRejected = 'approveAll';
            $('#autoApprove').modal('show');
        } else {
            if ($scope.facdata.length === 0) {
                $('#termsubmission').modal('show');
            } else {
                //GLMGR-486 
                if (isHavingBlankTranslation) {
                    $scope.submissionMessage = "Not all terms in this section contain a translation. Are you sure you wish to submit this section as complete?";
                    $scope.submissionMessage1 = "You can always return at another point to add in the additional translations.";
                    $('#confirmSubmission').modal('show');
                } else {
                    $scope.finalTranslationSubmit();
                }
                
            }
        }
    };

        /**
     * @ngdoc
     * @name finalTranslationSubmit
     * @methodOf Projects.controller:TranslationController
     * @description
     * This function is called on ok button on confirmation popup.This function is used submit translations
     * @returns {undefined} This method does not return.
     */
    $scope.finalTranslationSubmit = function () {
        var finalSubmit = {};
        finalSubmit['ProjectId'] = commonService.getSessionData('projectIBreadCrumb');
        finalSubmit['ProjectLanguageId'] = $scope.translationProjectLanguageId;
        finalSubmit['UserId'] = commonService.getLocalData('userDetails').UserId;
        finalSubmit['RoleName'] = commonService.getLocalData('userDetails').UserRoles[0].UserRoleName;
        finalSubmit['headerId'] = $rootScope.headerId;
        finalSubmit['headerName'] = $scope.glossaryData.HeaderText;

        if ($scope.adminUser) {
            finalSubmit['OriginalUserId'] = $scope.adminUser.UserId;
        } else {
            finalSubmit['OriginalUserId'] = null;
        }

        //GLMGR-206
        if ($scope.IsApproverAsTranslatorUIFlag && $scope.userRole == 'Approver') {
            finalSubmit['IsApproverAsTranslator'] = $scope.IsApproverAsTranslatorUIFlag;
            finalSubmit['ApproveYes'] = $scope.autoApprove;
            if ($scope.autoApproveRejected == 'approveAll') {
                finalSubmit['ApproveAll'] = true;
                finalSubmit['ApproveOnlyNonRejected'] = false;
            } else {
                finalSubmit['ApproveAll'] = false;
                finalSubmit['ApproveOnlyNonRejected'] = true;
            }
        }
        var UpdateGlossaries = [];
        var FilteredUpdateGlossaries = [];
        finalSubmit['IsFilterView'] = false;
        for (var i = 0; i < $scope.glossaryData.MasterGlossaries.length; i++) {
            for (var k = 0; k < $scope.glossaryData.MasterGlossaries[i].ProjectLanguages.length; k++) {
                if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].ProjectLanguageId == $scope.translationProjectLanguageId) {
                    var temp = {};
                    temp.GlossaryTranslationId = $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].GlossaryTranslationId;
                    temp.MasterText = $scope.glossaryData.MasterGlossaries[i].MasterText;
                    temp.RowVersion = $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].RowVersion;
                    temp.MasterGlossaryId = $scope.glossaryData.MasterGlossaries[i].MasterGlossaryId;
                    UpdateGlossaries.push(temp);
                    break;

                }
            }
        }
        finalSubmit['UpdatedGlossaryTranslations'] = UpdateGlossaries;

        if ($scope.filter === true) {
            finalSubmit['IsFilterView'] = true;
            for (var i = 0; i < $scope.glossaryCopy.MasterGlossaries.length; i++) {
                for (var k = 0; k < $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages.length; k++) {
                    if ($scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages[k].ProjectLanguageId == $scope.translationProjectLanguageId) {
                        var temp = {};
                        temp.GlossaryTranslationId = $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages[k].GlossaryTranslationId;
                        temp.MasterText = $scope.glossaryCopy.MasterGlossaries[i].MasterText;
                        temp.RowVersion = $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages[k].RowVersion;
                        temp.MasterGlossaryId = $scope.glossaryCopy.MasterGlossaries[i].MasterGlossaryId;
                        FilteredUpdateGlossaries.push(temp);
                        break;
                    }
                }
            }
            finalSubmit['UpdatedGlossaryTranslationsApplyFilter'] = FilteredUpdateGlossaries;
        } 

        $scope.showLoader = true;
        if (transSourceRequired === true) {
            //GLMGR-1030 to check if translated term are having Translation source added
            Glossary.ValidateGlossaryTranslationForTranslationSource(finalSubmit, function (validate) {
                Glossary.finaltranslationSubmit(finalSubmit, function (statusData) {// check if source term suggestion is pending    
                    $scope.isConsistanceForEmailList = statusData[0].IsConsistanceForEmailList;
                    $scope.objMasterGlossaryViewModelWithIdList = statusData[0].ObjMasterGlossaryViewModelWithIdList;
                    if (statusData == '') {
                        $scope.showLoader = false;
                        return false;
                    }
                    var concurrencyFlag = false;
                    for (var i = 0; i < statusData.length; i++) {
                        if (statusData[i].ConcurrentUpdateFailure == true) {
                            concurrencyFlag = true;
                            break;
                        }
                    }
                    if (validate.Result === false) {
                        $scope.CommentErrorPopupMessage = 'Note - you have attempted to submit without adding your translation source. Please add the source for your translation before proceeding';
                        $('#CommentErrorPopup').modal({
                            backdrop: 'static',
                            keyboard: false
                        })
                        $('#CommentErrorPopup').modal('show');
                        $scope.showLoader = false;
                        return false;
                    }

                    if (concurrencyFlag == true) {
                        $scope.showLoader = false;
                        $('#concurrencyMsg3').modal('show');
                        return;
                    }

                    if (statusData[0].PendingSuggestionTerms != null && !concurrencyFlag) {
                        if (statusData[0].IsConsistanceTranslation === true) {
                            $scope.showInconsistentMessage = true;
                        }
                        if (statusData[0].PendingSuggestionTerms.length > 0) {
                            $scope.showPendingSuggestionMessage = true;
                        }
                        if (statusData[0].PendingSuggestionTerms.length > 0 || statusData[0].IsConsistanceTranslation === true) {
                            if (statusData[0].IsNewApprovedTermExist === true) {
                                $scope.addTermNote = true;
                            } else {
                                $scope.addTermNote = false;
                            }
                            //GLMGR-1261 new logic to show newly added terms seperate
                            $scope.newTermApprovedSugg = [];
                            $scope.pendingSuggTerms = [];
                            for (var i = 0; i < statusData[0].PendingSuggestionTerms.length; i++) {
                                for (var j = 0; j < $scope.glossaryData.MasterGlossaries.length; j++) {
                                    if (statusData[0].PendingSuggestionTerms[i].Id == $scope.glossaryData.MasterGlossaries[j].MasterGlossaryId) {
                                        $scope.pendingSuggTerms.push(statusData[0].PendingSuggestionTerms[i]);
                                    }
                                }
                            }
                            $scope.newTermApprovedSugg = _.difference(statusData[0].PendingSuggestionTerms, $scope.pendingSuggTerms);

                            //$scope.PendingSuggTerms = statusData[0].PendingSuggestionTerms;
                            $scope.PendingSuggTerms = $scope.pendingSuggTerms;

                            $('#sourceTermsModifiedAndTranslationSource').modal({
                                backdrop: 'static',
                                keyboard: false
                            })
                            $('#sourceTermsModifiedAndTranslationSource').modal('show');
                            $scope.showLoader = false;
                            return;
                        } else if (validate.Result === true) {
                            Glossary.finaltranslationSubmit(finalSubmit, function (fsubmit) {// check concurrency
                                var concurrencyFlag = false;
                                for (var i = 0; i < fsubmit.length; i++) {
                                    if (fsubmit[i].ConcurrentUpdateFailure == true) {
                                        concurrencyFlag = true;
                                        break;
                                    }
                                }

                                if (concurrencyFlag == true) {
                                    $scope.showLoader = false;
                                    $('#concurrencyMsg3').modal('show');
                                    return;
                                } else {
                                    $scope.sendEmail();
                                }
                                $scope.showLoader = false;
                            });
                        }
                    } else if (statusData[0].IsConsistanceTranslation === true) {
                        $scope.showInconsistentMessage = true;
                        $('#sourceTermsModifiedAndTranslationSource').modal({
                            backdrop: 'static',
                            keyboard: false
                        })
                        $('#sourceTermsModifiedAndTranslationSource').modal('show');
                        $scope.showLoader = false;
                        return;
                    } else if (validate.Result === true) {
                        Glossary.finaltranslationSubmit(finalSubmit, function (fsubmit) {// check concurrency
                            var concurrencyFlag = false;
                            for (var i = 0; i < fsubmit.length; i++) {
                                if (fsubmit[i].ConcurrentUpdateFailure == true) {
                                    concurrencyFlag = true;
                                    break;
                                }
                            }

                            if (concurrencyFlag == true) {
                                $scope.showLoader = false;
                                $('#concurrencyMsg3').modal('show');
                                return;
                            } else {
                                $scope.sendEmail();
                            }
                            $scope.showLoader = false;
                        });
                    }
                });

            });

        } else {
            Glossary.finaltranslationSubmit(finalSubmit, function (fsubmit) {
                $scope.isConsistanceForEmailList = fsubmit[0].IsConsistanceForEmailList;
                $scope.objMasterGlossaryViewModelWithIdList = fsubmit[0].ObjMasterGlossaryViewModelWithIdList;
                if (fsubmit == '') {
                    $scope.showLoader = false;
                    return false;
                }
                var concurrencyFlag = false;
                for (var i = 0; i < fsubmit.length; i++) {
                    if (fsubmit[i].ConcurrentUpdateFailure == true) {
                        concurrencyFlag = true;
                        break;
                    }
                }
                if (fsubmit[0].IsConsistanceTranslation === true) {
                    $scope.showInconsistentMessage = true;
                }

                if (concurrencyFlag == true) {
                    $scope.showLoader = false;
                    $('#concurrencyMsg3').modal('show');
                    return;
                } else if (fsubmit[0].PendingSuggestionTerms != null) { //pending suggestion
                    if (fsubmit[0].IsConsistanceTranslation === true) {
                        $scope.showInconsistentMessage = true;
                    }
                    if (fsubmit[0].PendingSuggestionTerms.length > 0) {
                        $scope.showPendingSuggestionMessage = true;
                    }
                    if (fsubmit[0].PendingSuggestionTerms.length > 0 || fsubmit[0].IsConsistanceTranslation === true) {
                        if (fsubmit[0].IsNewApprovedTermExist === true) {
                            $scope.addTermNote = true;
                        } else {
                            $scope.addTermNote = false;
                        }

                        //GLMGR-1261 new logic to show newly added terms seperate
                        $scope.newTermApprovedSugg = [];
                        $scope.pendingSuggTerms = [];
                        for (var i = 0; i < fsubmit[0].PendingSuggestionTerms.length; i++) {
                            for (var j = 0; j < $scope.glossaryData.MasterGlossaries.length; j++) {
                                if (fsubmit[0].PendingSuggestionTerms[i].Id == $scope.glossaryData.MasterGlossaries[j].MasterGlossaryId) {
                                    $scope.pendingSuggTerms.push(fsubmit[0].PendingSuggestionTerms[i]);
                                }
                            }
                        }
                        $scope.newTermApprovedSugg = _.difference(fsubmit[0].PendingSuggestionTerms, $scope.pendingSuggTerms);

                        //$scope.PendingSuggTerms = fsubmit[0].PendingSuggestionTerms;
                        $scope.PendingSuggTerms = $scope.pendingSuggTerms;
                        $('#sourceTermsModifiedAndTranslationSource').modal({
                            backdrop: 'static',
                            keyboard: false
                        })
                        $('#sourceTermsModifiedAndTranslationSource').modal('show');
                        $scope.showLoader = false;
                        return;
                    } else {
                        $scope.sendEmail();
                        $scope.showLoader = false;
                    }
                } else if (fsubmit[0].IsConsistanceTranslation === true) {
                    $scope.showInconsistentMessage = true;
                    $('#sourceTermsModifiedAndTranslationSource').modal({
                        backdrop: 'static',
                        keyboard: false
                    })
                    $('#sourceTermsModifiedAndTranslationSource').modal('show');
                    $scope.showLoader = false;
                    return;
                } else {
                    $scope.sendEmail();
                    $scope.showLoader = false;
                }
            });
        }
        $scope.showLoader = false;
    };

    //ApproverAsTranslator finalSubmitReview GLMGR-206
    $scope.finalSubmitReview = function (value) {
        if (value === 'review') {
            $scope.autoApproveReview = true;
        } else {
            $scope.autoApproveReview = false;
        }
    };

     /**
     * @ngdoc
     * @name init
     * @methodOf Projects.controller:TranslationController
     * 
     * @description
     * This function is used for initialisation of the variables on page load
     * @return {undefined} This method does not return.
     */
    var init = function () {
        //GLMGR-1239 Retain hide Add info column checkbox on refresh 
        $scope.isCheckedAddInfoCols = JSON.parse(sessionStorage.getItem('hideAddInfoCols'));
        $scope.hideAddInfoCOls = JSON.parse(sessionStorage.getItem('hideAddInfoCols'));
        if (!$scope.hideAddInfoCOls) {
            hideCatCols = false;
        } else {
            hideCatCols = true;
        }
        //GLMGR-1239 Retain hide starred column checkbox on refresh 
        $scope.isStarred = JSON.parse(sessionStorage.getItem('hideStarredCol'));
        if ($scope.isStarred) {
            $scope.hideStarredCol = false;
        }


        $scope.showGlossaryPage = true;
        $scope.projectId = commonService.getSessionData('projectIBreadCrumb');
        $scope.unEncryptedProjectId=commonService.getSessionData('unEncriptedProjectId');
        $scope.userId = commonService.getLocalData('userDetails').UserId;
        $scope.translationProjectLanguageId = commonService.getSessionData('translationProjectLanguageId');
        $scope.approveProjectLanguageId = commonService.getSessionData('approveProjectLanguageId');
        $scope.userRole = commonService.getLocalData('userDetails').UserRoles[0].UserRoleName;
        $scope.HasWritePrivilege = commonService.getSessionData('HasWritePrivilege');
        $scope.glossaryView = false;
        var searchTableApproverPage = false;

        sessionStorage.setItem('searchTableApproverPage', JSON.stringify(searchTableApproverPage));
        var resorceIdx = 2;
        sessionStorage.setItem('resourcePageId', JSON.stringify(resorceIdx));

        $scope.showLoader = true;
        if (commonService.getSessionData('glossaryTab') && commonService.getSessionData('glossaryTab') === 'default') {
            $scope.defaultGlossarySectionType = true;
            $scope.ntlGlossarySectionType = false;
            Glossary.getTranslationInitialData($scope.projectId, commonService.getLocalData('userDetails').UserId, 1, glossaryInitialData);
        } else if (commonService.getSessionData('glossaryTab') && commonService.getSessionData('glossaryTab') === 'ntl') {
            $scope.defaultGlossarySectionType = false;
            $scope.ntlGlossarySectionType = true;
            Glossary.getTranslationInitialData($scope.projectId, commonService.getLocalData('userDetails').UserId, 2, glossaryInitialData);
        } else {
            Glossary.getTranslationInitialData($scope.projectId, commonService.getLocalData('userDetails').UserId, 1, glossaryInitialData);
        }

        $scope.pageName = "Translations";
        $scope.showSaveButton = true;

        //watch for change in headerdropdown
        $scope.$watch('headingsDropdown', function (new_value, old_value) {
            if (old_value !== undefined && new_value !== undefined) {

                $scope.showLoader = true;
                if (new_value == null) {
                    AllSection();
                } else {
                    Glossary.getTranslationData($scope.projectId, new_value.Id, commonService.getLocalData('userDetails').UserId, $scope.translationProjectLanguageId, function (glossaryData) {

                        if (glossaryData == 'error') {
                            $('#serverError').modal('show');
                            $scope.showLoader = false;
                        }
                        $scope.glossaryData = glossaryData;
                        Catsequence = glossaryData.ProjectCategorySequence;

                        $rootScope.headerId = new_value.Id;

                        sessionStorage.setItem('GlossarySection', JSON.stringify(new_value));
                        hideCatCols = true;

                        //GLMGR-1239 if section having atleast one empty column then only check the hideEmptyCol checkbox
                        $scope.isCheckedEmptyInfoCols = false;
                        $scope.hideEmptyAddInfoCOls = false;
                        for (var i = 0; i < $scope.glossaryData.SectionCategories.length; i++) {
                            if ($scope.glossaryData.SectionCategories[i].IsCategoryEmpty === true) {
                                $scope.isCheckedEmptyInfoCols = true;
                                $scope.hideEmptyAddInfoCOls = true;
                            }
                        }


                        //GLMGR-1239 check if section has atleast one starred term
                        $scope.isHavingStarredTerm = false;
                        for (var i = 0; i < glossaryData.MasterGlossaries.length; i++) {
                            if (glossaryData.MasterGlossaries[i].IsStarred == true) {
                                $scope.isHavingStarredTerm = true;
                            }
                        }
                        if (!$scope.isHavingStarredTerm) {
                            $scope.isStarred = true;
                            $scope.hideStarredCol = false;
                        }
                        else {
                            $scope.isStarred = false;
                            $scope.hideStarredCol = true;
                        }
                        sessionStorage.setItem('headerId', JSON.stringify(new_value.Id));
                        $scope.headingsDropdown.Id = new_value.Id;
                        $scope.sectionId = $scope.headingsDropdown.Id;

                        $scope.showLoader = false;

                        $scope.facdata = [];
                        $scope.defdata = [];

                        if ($scope.filter == true) {
                            $scope.filterOptions();
                        } else {
                            GlossaryNgGrid(glossaryData, new_value);
                        }
                    });
                }
            }
        });


        // Function to get attachments list on user Id
        Glossary.getAttachmentList($scope.projectId, commonService.getLocalData('userDetails').UserId, function (AttachmentList) {
            $scope.attachmentList = AttachmentList;
        });

        //open attachment popup if attachment is present.
        $scope.downloadAttachmentPopup = function () {
            if ($scope.attachmentList.AttachementInfo.length === 0) {
                $scope.errorMessage = 'No attachment available for this project.';
                $scope.errorTitle = 'No Attachment';
                $('#errorModal').modal('show');
                return true;
            } else {
                $('#downloadAttachment').modal('show');
            }
        };
    };

     /**
     * @ngdoc
     * @name sendEmail
     * @methodOf Projects.controller:TranslationController
     * 
     * @description
     * This function is used for sending email on translation complete button clicked
     * @return {undefined} This method does not return.
     */
    $scope.sendEmail = function () {
        var emailData = {};
        emailData['ProjectId'] = commonService.getSessionData('projectIBreadCrumb');
        emailData['ProjectTitle'] = $scope.GlossaryInitialTerms.ProjectTitle;
        emailData['ProjectLanguageId'] = $scope.translationProjectLanguageId;
        for (var i = 0; i < $scope.glossaryData.MasterGlossaries[0].ProjectLanguages.length; i++) {
            if ($scope.glossaryData.MasterGlossaries[0].ProjectLanguages[i].ProjectLanguageId === $scope.translationProjectLanguageId) {
                emailData['LanguageId'] = $scope.glossaryData.MasterGlossaries[0].ProjectLanguages[i].LanguageId;
                emailData['LanguageName'] = $scope.glossaryData.MasterGlossaries[0].ProjectLanguages[i].LanguageName;
                break;
            }
        }
        emailData['UserId'] = commonService.getLocalData('userDetails').UserId;
        emailData['UserName'] = commonService.getLocalData('userDetails').UserName;
        emailData['RoleName'] = commonService.getLocalData('userDetails').UserRoles[0].UserRoleName;
        emailData['headerId'] = $rootScope.headerId;
        emailData['Group'] = $scope.glossaryData.HeaderText;
        emailData['IsConsistanceForEmailList'] = $scope.isConsistanceForEmailList;
        emailData['ObjMasterGlossaryViewModelWithIdList'] = $scope.objMasterGlossaryViewModelWithIdList;

        //GLMGR-206
        if ($scope.IsApproverAsTranslatorUIFlag && $scope.autoApprove && $scope.userRole == 'Approver') {
            emailData['IsSendMailForApprove'] = true;
        }


        Glossary.emailSendConfirmation(emailData, function (emailreturn) {
            location.reload();
        });
        $('.modal-backdrop').css('display', 'none');
    };

    $scope.loadOnSubmit = function () {
        //GLMGR-1228
        $('#sourceTermsModifiedAndTranslationSource').modal('hide');
        $('#filterConfirmation').modal('show');
    };

    //GLMGR-1228 Apply filters pending approvals and source term pending suggestion automatically after pressing submit later
    $scope.applyFilter = function () {
        $('#pendingSuggFilter').prop('checked', true);
        $('#pendingApprovalsFilter').prop('checked', true);
        $scope.filterOptions();
    };

    /**
     * @ngdoc
     * @name changeView
     * @methodOf Projects.controller:TranslationController
     * @param {string} new_path The Name of the view bound with element on which this function is called.

     * @description
     * This function is called to change views and loads respective html page.Below are some views
     * translation, Source Setup, approve translation, Glossary All sections,
     * @returns {undefined} This method does not return.
     */
    $scope.changeView = function (new_path) {
        //GLMGR-1239 uncheck hide add info col on view change
        sessionStorage.setItem('hideAddInfoCols', false);
        switch (new_path) {
            case "translation":
                $location.search('projectlanguageid', $scope.translationProjectLanguageId);
                $location.path('/glossary/translation');
                break;

            case "approve":
                $location.search('projectlanguageid', $scope.approveProjectLanguageId);
                $location.path('/glossary/approve');
                break;

            case "glossary":
                $location.path('/glossary');
                break;

            case "GlossaryAllsection":
                $location.path('/glossary/translation/glossaryAllSection');
                break;

                //GLMGR-656
            case "sourceSetup":
                sessionStorage.setItem('SourceSetupActiveSection', '');
                sessionStorage.setItem('isShowRemovedTermsFlag', '0');
                $location.path('/glossary/sourceSetup');
                break;
        }
    };

    init();
    $scope.z = 0;

    //function call for auto save of translation
    $scope.$on('ngGridEventEndCellEdit', function (event) {
        var originalText = event.targetScope.row.entity[event.targetScope.col.field].OriginalText;

        if (!event.targetScope.row.entity[event.targetScope.col.field].languageTranslation || event.targetScope.row.entity[event.targetScope.col.field].languageTranslation == false || !event.targetScope.row.entity[event.targetScope.col.field]) {

        } else {
            $('#emptydiv').modal({
                backdrop: 'static',
                keyboard: false
            })
            $('#emptydiv').modal('show');
            var str = $scope.languageTransField;
            var flag = true;
            var termtrans = event.targetScope.row.entity[event.targetScope.col.field];
            termtrans['TranslatorUserId'] = commonService.getLocalData('userDetails').UserId;
            termtrans['RoleName'] = commonService.getLocalData('userDetails').UserRoles[0].UserRoleName;

            if ($scope.adminUser) {
                termtrans['OriginalUserId'] = $scope.adminUser.UserId;
            } else {
                termtrans['OriginalUserId'] = null;
            }

            //$('#pageload').modal({ backdrop: 'static', keyboard: false })
            $scope.showLoader = true;
            if (termtrans.IsTranslationTermUpdate === true) {
                if (termtrans.term && termtrans.term != 'N/A' && termtrans.term != 'n/a' &&
                    termtrans.PhoneticTerm && termtrans.PhoneticTerm != 'N/A' && termtrans.PhoneticTerm != 'n/a' && 
                    termtrans.PhoneticTerm.toLowerCase().trim() === termtrans.term.toLowerCase().trim()) {
                        flag = false;
                }
                if (termtrans.term && termtrans.term != 'N/A' && termtrans.term != 'n/a' && 
                    termtrans.PluralTerm &&termtrans.PluralTerm != 'N/A' && termtrans.PluralTerm != 'n/a' && 
                    termtrans.PluralTerm.toLowerCase().trim() === termtrans.term.toLowerCase().trim()) {
                    flag = false;
                }
            } else if (termtrans.IsPhoneticTermUpdate === true) {
                if (termtrans.PluralTerm && termtrans.PhoneticTerm &&
                    termtrans.PluralTerm != 'N/A' && termtrans.PluralTerm != 'n/a' &&
                    termtrans.PhoneticTerm != 'N/A' && termtrans.PhoneticTerm != 'n/a' && 
                    termtrans.PhoneticTerm.toLowerCase().trim() === termtrans.PluralTerm.toLowerCase().trim()) {
                    flag = false;
                }
                if (termtrans.LanguageTerm && termtrans.LanguageTerm != 'N/A' && termtrans.LanguageTerm != 'n/a' &&
                    termtrans.PhoneticTerm && termtrans.PhoneticTerm != 'N/A' && termtrans.PhoneticTerm != 'n/a' &&
                    termtrans.PhoneticTerm.toLowerCase().trim() === termtrans.LanguageTerm.toLowerCase().trim()) {
                    flag = false;
                }
            } else {
                if (termtrans.LanguageTerm && termtrans.LanguageTerm != 'N/A' && termtrans.LanguageTerm != 'n/a' && 
                    termtrans.PluralTerm  && termtrans.PluralTerm != 'N/A' && termtrans.PluralTerm != 'n/a' &&
                     termtrans.PluralTerm.toLowerCase().trim() === termtrans.LanguageTerm.toLowerCase().trim()) {
                    flag = false;
                }
                if (termtrans.PluralTerm && termtrans.PhoneticTerm &&
                termtrans.PluralTerm != 'N/A' && termtrans.PluralTerm != 'n/a'  && 
                termtrans.PhoneticTerm != 'N/A' && termtrans.PhoneticTerm != 'n/a' && 
                termtrans.PhoneticTerm.toLowerCase().trim() === termtrans.PluralTerm.toLowerCase().trim()) {
                    flag = false;
                }
            }


            if (flag === true) {
                for (var i = 0; i < $scope.glossaryData.MasterGlossaries.length; i++) {
                    for (var k = 0; k < $scope.glossaryData.MasterGlossaries[i].ProjectLanguages.length; k++) {
                        if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].ProjectLanguageId == $scope.translationProjectLanguageId) {
                            if (termtrans.IsTranslationTermUpdate === true) {
                                if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TranslatedTerm &&
                                    termtrans.term && termtrans.term != 'N/A' && termtrans.term != 'n/a' && 
                                    $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TranslatedTerm.toLowerCase().trim() === termtrans.term.toLowerCase().trim()) {
                                    if ($scope.glossaryData.MasterGlossaries[i].MasterText.toLowerCase().trim() != termtrans.MasterTerm.toLowerCase().trim()) {
                                        flag = false;
                                        break;
                                    }
                                }
                                if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].PhoneticTerm  && 
                                termtrans.term && termtrans.term != 'N/A' && termtrans.term != 'n/a' && 
                                $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].PhoneticTerm.toLowerCase().trim() === termtrans.term.toLowerCase().trim()) {
                                    flag = false;
                                    break;
                                }
                                if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].PluralTerm  && 
                                termtrans.term && termtrans.term != 'N/A' && termtrans.term != 'n/a' && 
                                $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].PluralTerm.toLowerCase().trim() === termtrans.term.toLowerCase().trim()) {
                                    flag = false;
                                    break;
                                }
                            }
                            else if (termtrans.IsPhoneticTermUpdate === true) {
                                if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TranslatedTerm && termtrans.PhoneticTerm && 
                                termtrans.PhoneticTerm != 'N/A' && termtrans.PhoneticTerm != 'n/a' && 
                                $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TranslatedTerm.toLowerCase().trim() === termtrans.PhoneticTerm.toLowerCase().trim()) {
                                    flag = false;
                                    break;
                                }
                                if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].PhoneticTerm && termtrans.PhoneticTerm  && 
                                termtrans.PhoneticTerm != 'N/A' && termtrans.PhoneticTerm != 'n/a' && 
                                $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].PhoneticTerm.toLowerCase().trim() === termtrans.PhoneticTerm.toLowerCase().trim()) {
                                    if ($scope.glossaryData.MasterGlossaries[i].MasterText.toLowerCase().trim() != termtrans.MasterTerm.toLowerCase().trim()) {
                                        flag = false;
                                        break;
                                    }
                                }
                                if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].PluralTerm  && termtrans.PhoneticTerm && 
                                termtrans.PhoneticTerm != 'N/A' && termtrans.PhoneticTerm != 'n/a' && 
                                $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].PluralTerm.toLowerCase().trim() === termtrans.PhoneticTerm.toLowerCase().trim()) {
                                    flag = false;
                                    break;
                                }
                            }
                            else {
                                if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TranslatedTerm && 
                                termtrans.PluralTerm && termtrans.PluralTerm != 'N/A' && termtrans.PluralTerm != 'n/a' && 
                                $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TranslatedTerm.toLowerCase().trim() === termtrans.PluralTerm.toLowerCase().trim()) {
                                    flag = false;
                                    break;
                                }
                                if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].PhoneticTerm && termtrans.PluralTerm && 
                                termtrans.PluralTerm != 'N/A' && termtrans.PluralTerm != 'n/a' && 
                                $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].PhoneticTerm.toLowerCase().trim() === termtrans.PluralTerm.toLowerCase().trim()) {
                                    flag = false;
                                    break;
                                }
                                if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].PluralTerm  && termtrans.PluralTerm && 
                                termtrans.PluralTerm != 'N/A' && termtrans.PluralTerm != 'n/a' && 
                                $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].PluralTerm.toLowerCase().trim() === termtrans.PluralTerm.toLowerCase().trim()) {
                                    if ($scope.glossaryData.MasterGlossaries[i].MasterText.toLowerCase().trim() != termtrans.MasterTerm.toLowerCase().trim()) {
                                        flag = false;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    if (flag === false) {
                        break;
                    }
                }
            }

            if (flag == true) {
                if (termtrans.IsTranslationTermUpdate === true) {
                    if (originalText !== null) {
                        if (originalText.length > 0 && termtrans.term.length === 0) {
                            $('#confirmRemoveTranslation').modal({ backdrop: 'static', keyboard: false });
                            inconsistentFlagForEmptyTranslation = true;
                            $scope.showLoader = false;
                            $('#confirmRemoveTranslation').modal('show');
                        } else {
                            termtrans['LanguageTerm'] = termtrans.term;
                            inconsistentFlagForEmptyTranslation = false;
                        }
                    } else {
                        inconsistentFlagForEmptyTranslation = false;
                        termtrans['LanguageTerm'] = termtrans.term;
                    }

                }
                Glossary.translationAutoSave(termtrans, function (data) {
                    if (data == 'error') {
                        $('#emptydiv').modal('hide');
                        $('#serverError').modal('show');
                        $scope.showLoader = false;
                    } else if (data.ConcurrentUpdateFailure) {
                        $('#emptydiv').modal('hide');
                        $("#concurrencyMsg2").modal('show');
                        $scope.submissionMessage = "Changes have been made to the record recently, Please press OK to refresh";


                    } else {

                        // updating the Front-end objects after successful submission of translation (ex -- ng-grid objects , filter objects , etc)
                        event.targetScope.row.entity['Phonetic' + str].PhoneticTerm = data.PhoneticTerm;
                        event.targetScope.row.entity['Phonetic' + str].OriginalText = data.PhoneticTerm;
                        event.targetScope.row.entity['Phonetic' + str].LanguageTerm = data.TranslatedTerm;
                        event.targetScope.row.entity['Phonetic' + str].PluralTerm = data.PluralTerm;
                        event.targetScope.row.entity['Phonetic' + str].RowVersion = data.RowVersion;
                        event.targetScope.row.entity['Phonetic' + str].GlossaryTranslationId = data.UpdatedGlossaryTranslationId;
                        event.targetScope.row.entity['Plural' + str].PhoneticTerm = data.PhoneticTerm;
                        event.targetScope.row.entity['Plural' + str].LanguageTerm = data.TranslatedTerm;
                        event.targetScope.row.entity['Plural' + str].PluralTerm = data.PluralTerm;
                        event.targetScope.row.entity['Plural' + str].OriginalText = data.PluralTerm;
                        event.targetScope.row.entity['Plural' + str].RowVersion = data.RowVersion;
                        event.targetScope.row.entity['Plural' + str].GlossaryTranslationId = data.UpdatedGlossaryTranslationId;
                        event.targetScope.row.entity[str].PhoneticTerm = data.PhoneticTerm;
                        event.targetScope.row.entity[str].term = data.TranslatedTerm;
                        event.targetScope.row.entity[str].OriginalText = data.TranslatedTerm;
                        event.targetScope.row.entity[str].PluralTerm = data.PluralTerm;
                        event.targetScope.row.entity[str].RowVersion = data.RowVersion;
                        event.targetScope.row.entity[str].GlossaryTranslationId = data.UpdatedGlossaryTranslationId;
                        event.targetScope.row.entity['comment' + str].GlossaryTranslationId = data.UpdatedGlossaryTranslationId;
                        event.targetScope.row.entity['Ver' + str].TermStatus = data.GlossaryTranslation.Status;
                        event.targetScope.row.entity['Ver' + str].Ver = data.GlossaryTranslation.Version;
                        event.targetScope.row.entity['Ver' + str].IsVersionToHide = data.GlossaryTranslation.IsVersionToHide;
                        if (data.GlossaryTranslation.Status === "TRANSLATION_COMPLETED") {
                            event.targetScope.row.entity['Status' + str].Status = 'Pending';
                            event.targetScope.row.entity['Status' + str].term = 'Pending';
                        }

                        event.targetScope.row.entity['source' + str].GlossaryTranslationId = data.UpdatedGlossaryTranslationId; //GLMGR-1030
                        event.targetScope.row.entity[event.targetScope.col.field].RowVersion = data.RowVersion;
                        event.targetScope.row.entity[event.targetScope.col.field].GlossaryTranslationId = data.UpdatedGlossaryTranslationId;
                        for (var i = 0; i < $scope.glossaryData.MasterGlossaries.length; i++) {
                            if (termtrans.MasterGlossaryId == $scope.glossaryData.MasterGlossaries[i].MasterGlossaryId) {
                                for (var k = 0; k < $scope.glossaryData.MasterGlossaries[i].ProjectLanguages.length; k++) {
                                    if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].ProjectLanguageId == $scope.translationProjectLanguageId) {
                                        $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].GlossaryTranslationId = data.UpdatedGlossaryTranslationId;
                                        $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].RowVersion = data.RowVersion;
                                        $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TranslatedTerm = data.TranslatedTerm;
                                        $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].PhoneticTerm = data.PhoneticTerm;
                                        $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].PluralTerm = data.PluralTerm;
                                        $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus = data.GlossaryTranslation.Status;
                                        $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].Version = data.GlossaryTranslation.Version;
                                        break;
                                    }
                                }
                                break;
                            }

                        }
                        if ($scope.filter == true) {

                            for (var i = 0; i < $scope.glossaryCopy.MasterGlossaries.length; i++) {

                                if (termtrans.MasterGlossaryId == $scope.glossaryCopy.MasterGlossaries[i].MasterGlossaryId) {
                                    for (var k = 0; k < $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages.length; k++) {
                                        if ($scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages[k].ProjectLanguageId == $scope.translationProjectLanguageId) {
                                            $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages[k].GlossaryTranslationId = data.UpdatedGlossaryTranslationId;
                                            $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages[k].RowVersion = data.RowVersion;
                                            $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages[k].TranslatedTerm = data.TranslatedTerm;
                                            $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages[k].PhoneticTerm = data.PhoneticTerm;
                                            $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages[k].PluralTerm = data.PluralTerm;
                                            $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages[k].TermStatus = data.GlossaryTranslation.Status;
                                            $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages[k].Version = data.GlossaryTranslation.Version;
                                            break;
                                        }
                                    }
                                    break;
                                }
                            }

                            $('#emptydiv').modal('hide');
                            $scope.showLoader = false;
                        } else {
                            $('#emptydiv').modal('hide');
                            $scope.showLoader = false;
                        }

                        // is translation inconsistent
                        if (data.IsConsistanceTranslation === false && !inconsistentFlagForEmptyTranslation) {
                            $('#inconsistentTranslation').modal('show');
                        }
                    }



                });
            } else {
                $('#emptydiv').modal('hide');
                $('#duplicateTransError').modal({
                    backdrop: 'static',
                    keyboard: false
                })
                $('#duplicateTransError').modal('show');
            }
        }
        $scope.proceedWithTrans = function (key) {
            $('#emptydiv').modal({
                backdrop: 'static',
                keyboard: false
            })
            $('#emptydiv').modal('show');
            if (termtrans.IsTranslationTermUpdate === true) {
                if (key == 'duplicate') {
                    termtrans['LanguageTerm'] = termtrans.term;
                    $scope.isTransremoved = false;
                }
                else if (key == 'remove') {
                    termtrans['LanguageTerm'] = '';
                    $scope.isTransremoved = true;
                }
                else {
                    termtrans['LanguageTerm'] = termtrans.term;
                }

            }

            if ($scope.adminUser) {
                termtrans['OriginalUserId'] = $scope.adminUser.UserId;
            } else {
                termtrans['OriginalUserId'] = null;
            }

            Glossary.translationAutoSave(termtrans, function (data) {
                if (data == 'error') {
                    $('#emptydiv').modal('hide');
                    $('#serverError').modal('show');
                    $scope.showLoader = false;
                } else if (data.ConcurrentUpdateFailure) {
                    $('#emptydiv').modal('hide');
                    $("#concurrencyMsg2").modal('show');
                    $scope.submissionMessage = "Changes have been made to the record recently, Please press OK to refresh";

                } else {

                    // updating the Front-end objects after successful submission of translation (ex -- ng-grid objects , filter objects , etc)
                    event.targetScope.row.entity['Phonetic' + str].PhoneticTerm = data.PhoneticTerm;
                    event.targetScope.row.entity['Phonetic' + str].OriginalText = data.PhoneticTerm;
                    event.targetScope.row.entity['Phonetic' + str].LanguageTerm = data.TranslatedTerm;
                    event.targetScope.row.entity['Phonetic' + str].PluralTerm = data.PluralTerm;
                    event.targetScope.row.entity['Phonetic' + str].RowVersion = data.RowVersion;
                    event.targetScope.row.entity['Phonetic' + str].GlossaryTranslationId = data.UpdatedGlossaryTranslationId;
                    event.targetScope.row.entity['Plural' + str].PhoneticTerm = data.PhoneticTerm;
                    event.targetScope.row.entity['Plural' + str].LanguageTerm = data.TranslatedTerm;
                    event.targetScope.row.entity['Plural' + str].PluralTerm = data.PluralTerm;
                    event.targetScope.row.entity['Plural' + str].OriginalText = data.PluralTerm;
                    event.targetScope.row.entity['Plural' + str].RowVersion = data.RowVersion;
                    event.targetScope.row.entity['Plural' + str].GlossaryTranslationId = data.UpdatedGlossaryTranslationId;
                    event.targetScope.row.entity[str].PhoneticTerm = data.PhoneticTerm;
                    event.targetScope.row.entity[str].term = data.TranslatedTerm;
                    event.targetScope.row.entity[str].OriginalText = data.TranslatedTerm;
                    event.targetScope.row.entity[str].PluralTerm = data.PluralTerm;
                    event.targetScope.row.entity[str].RowVersion = data.RowVersion;
                    event.targetScope.row.entity[str].GlossaryTranslationId = data.UpdatedGlossaryTranslationId;
                    event.targetScope.row.entity['comment' + str].GlossaryTranslationId = data.UpdatedGlossaryTranslationId;
                    event.targetScope.row.entity['Ver' + str].TermStatus = data.GlossaryTranslation.Status;
                    event.targetScope.row.entity['Ver' + str].Ver = data.GlossaryTranslation.Version;
                    event.targetScope.row.entity['Ver' + str].IsVersionToHide = data.GlossaryTranslation.IsVersionToHide;
                    if (data.GlossaryTranslation.Status === "TRANSLATION_COMPLETED") {
                        event.targetScope.row.entity['Status' + str].Status = 'Pending';
                        //if translation removed status text pending  removed
                        if ($scope.isTransremoved) {
                            event.targetScope.row.entity['Status' + str].term = '';
                        } else {
                            event.targetScope.row.entity['Status' + str].term = 'Pending';
                        }

                    }
                    if (data.GlossaryTranslation.Status === "TRANSLATION_IN_PROGRESS") {
                        if ($scope.isTransremoved) {
                            event.targetScope.row.entity['Status' + str].Status = '';
                        }
                    }

                    event.targetScope.row.entity['source' + str].GlossaryTranslationId = data.UpdatedGlossaryTranslationId; //GLMGR-1030
                    event.targetScope.row.entity[event.targetScope.col.field].RowVersion = data.RowVersion;
                    event.targetScope.row.entity[event.targetScope.col.field].GlossaryTranslationId = data.UpdatedGlossaryTranslationId;
                    for (var i = 0; i < $scope.glossaryData.MasterGlossaries.length; i++) {
                        if (termtrans.MasterGlossaryId == $scope.glossaryData.MasterGlossaries[i].MasterGlossaryId) {
                            for (var k = 0; k < $scope.glossaryData.MasterGlossaries[i].ProjectLanguages.length; k++) {
                                if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].ProjectLanguageId == $scope.translationProjectLanguageId) {
                                    $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].GlossaryTranslationId = data.UpdatedGlossaryTranslationId;
                                    $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].RowVersion = data.RowVersion;
                                    $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TranslatedTerm = data.TranslatedTerm;
                                    $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].PhoneticTerm = data.PhoneticTerm;
                                    $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].PluralTerm = data.PluralTerm;
                                    $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus = data.GlossaryTranslation.Status;
                                    $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].Version = data.GlossaryTranslation.Version;
                                    break;
                                }
                            }
                            break;
                        }

                    }
                    if ($scope.filter == true) {

                        for (var i = 0; i < $scope.glossaryCopy.MasterGlossaries.length; i++) {

                            if (termtrans.MasterGlossaryId == $scope.glossaryCopy.MasterGlossaries[i].MasterGlossaryId) {
                                for (var k = 0; k < $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages.length; k++) {
                                    if ($scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages[k].ProjectLanguageId == $scope.translationProjectLanguageId) {
                                        $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages[k].GlossaryTranslationId = data.UpdatedGlossaryTranslationId;
                                        $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages[k].RowVersion = data.RowVersion;
                                        $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages[k].TranslatedTerm = data.TranslatedTerm;
                                        $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages[k].PhoneticTerm = data.PhoneticTerm;
                                        $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages[k].PluralTerm = data.PluralTerm;
                                        $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages[k].TermStatus = data.GlossaryTranslation.Status;
                                        $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages[k].Version = data.GlossaryTranslation.Version;
                                        break;
                                    }
                                }
                                break;
                            }
                        }

                        $('#emptydiv').modal('hide');
                        $scope.showLoader = false;
                    } else {
                        $('#emptydiv').modal('hide');
                        $scope.showLoader = false;
                    }
                }
                if (data.IsConsistanceTranslation === false && !inconsistentFlagForEmptyTranslation) {
                    $('#inconsistentTranslation').modal('show');
                }

            });
        };

        $scope.cancelEmptyTranslation = function () {
            inconsistentFlagForEmptyTranslation = false;
            $('#confirmRemoveTranslation').modal('hide');
        };

        $scope.revertTrans = function () {
            if (termtrans.IsTranslationTermUpdate === true) {
                event.targetScope.row.entity[event.targetScope.col.field].term = termtrans.OriginalText;
            }
            else if (termtrans.IsPhoneticTermUpdate === true) {
                event.targetScope.row.entity[event.targetScope.col.field].PhoneticTerm = termtrans.OriginalText;
            }
            else {
                event.targetScope.row.entity[event.targetScope.col.field].PluralTerm = termtrans.OriginalText;
            }
            $('#emptydiv').modal('hide');
            $scope.showLoader = false;
        }
    });

    $scope.loadagain = function () {
        $('.modal-backdrop').css('display', 'none');
        location.reload();
    }

    $scope.addGlossaryTranslation = function () {
        $('#addTranslation').modal('show');
    };

     /**
     * @ngdoc
     * @name translateTerms
     * @methodOf Projects.controller:TranslationController
     * @param {string} language The selected language to show translation page.

     * @description
     * This function is called on ok button on add translation popup.This is used to show translation page for only selected language
     * @returns {undefined} This method does not return.
     */
    $scope.translateTerms = function (language) {
        $scope.newLang = language;
        sessionStorage.setItem('glossaryNewLang', JSON.stringify(language));
        GlossaryCheck.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
        GlossaryCheck.ResourceId = language.ProjectLanguageId.toString();
        GlossaryCheck.PageId = $scope.GlossaryInitialTerms.PageId;
        sessionStorage.setItem('ResourceId', JSON.stringify(language.ProjectLanguageId));
        commonService.checkSourceSetup(GlossaryCheck, function (status) {
            if (status == "error") {
                $('#serverError').modal('show');
            } else if (status.IsLocked === true) {
                $('#addTranslation').modal('hide');
                $scope.projectTransLanguageid = language.ProjectLanguageId;
                $('#translationLanguageWarning').modal('show');
            } else {
                $('#filterOptionsButton').css("border-style", "none");
                $('#filterOptionsButton').css("border-color", "none");
                $('#filterOptionsButton').css("background-image", "url('../../../Content/Common/Assets/Images/export_n.png')");
                $('#filterOptionsButton').css("color", "white");
                $scope.filter = false;
                sessionStorage.setItem("filterStatus", "undefined");
                sessionStorage.setItem("filterImage", "undefined");
                sessionStorage.setItem("pendingTranslationsFilter", "0");
                sessionStorage.setItem("pendingApprovalsFilter", "0");
                sessionStorage.setItem("approvedFilter", "0");
                sessionStorage.setItem("rejectedFilter", "0");
                sessionStorage.setItem("pendingSuggFilter", "0");
                sessionStorage.setItem("filterOnStatus", "0");
                $scope.projectTransLanguageid = language.ProjectLanguageId;
                sessionStorage.setItem('translationProjectLanguageId', JSON.stringify(language.ProjectLanguageId));
                $scope.translationProjectLanguageId = commonService.getSessionData('translationProjectLanguageId');
                $('#addTranslation').modal('hide');
                $('.modal-backdrop').css('display', 'none');
                $scope.changeView('translation');
            }
        });
    };


    $scope.continueToTranslationPage = function () {
        sessionStorage.setItem('translationProjectLanguageId', JSON.stringify($scope.projectTransLanguageid));
        $scope.translationProjectLanguageId = commonService.getSessionData('translationProjectLanguageId');
        $('#translationLanguageWarning').modal('hide');
        $('.modal-backdrop').css('display', 'none');
        $('#filterOptionsButton').css("border-style", "none");
        $('#filterOptionsButton').css("border-color", "none");
        $('#filterOptionsButton').css("background-image", "url('../../../Content/Common/Assets/Images/export_n.png')");
        $('#filterOptionsButton').css("color", "white");
        $scope.filter = false;
        sessionStorage.setItem("filterStatus", "undefined");
        sessionStorage.setItem("filterImage", "undefined");
        sessionStorage.setItem("pendingTranslationsFilter", "0");
        sessionStorage.setItem("pendingApprovalsFilter", "0");
        sessionStorage.setItem("approvedFilter", "0");
        sessionStorage.setItem("rejectedFilter", "0");
        sessionStorage.setItem("pendingSuggFilter", "0");
        sessionStorage.setItem("filterOnStatus", "0");
        $scope.changeView('translation');
    };

    $scope.addGlossaryApproveTranslation = function () {
        if (sessionStorage.getItem("filterOnStatus") === "1") {
            sessionStorage.setItem('glossaryFilterLang', JSON.stringify($scope.FilterLang));
            $scope.ApproveTerms($scope.FilterLang);
        } else {
            $('#ApproveTranslation').modal('show');
        }
    };

    //change of view to approve translation 
    $scope.ApproveTerms = function (language) {
        $scope.newLang = language;
        sessionStorage.setItem('glossaryNewLang', JSON.stringify(language));
        GlossaryCheck.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
        GlossaryCheck.ResourceId = language.ProjectLanguageId.toString();
        GlossaryCheck.PageId = 3;
        sessionStorage.setItem('ResourceId', JSON.stringify(language.ProjectLanguageId));

        commonService.checkSourceSetup(GlossaryCheck, function (status) {
            if (status == "error") {
                $('#serverError').modal('show');
            } else if (status.IsLocked === true) {
                $('#ApproveTranslation').modal('hide');
                $scope.projectApproveLanguageid = language.ProjectLanguageId;
                $('#approveLanguageWarning').modal('show');
            } else {
                $scope.projectApproveLanguageid = language.ProjectLanguageId;
                sessionStorage.setItem('approveProjectLanguageId', JSON.stringify(language.ProjectLanguageId));
                $scope.approveProjectLanguageId = commonService.getSessionData('approveProjectLanguageId');
                $('.modal-backdrop').css('display', 'none');
                $scope.changeView('approve');
            }
        });

    };


    $scope.continueToApprovePage = function () {
        sessionStorage.setItem('approveProjectLanguageId', JSON.stringify($scope.projectApproveLanguageid));
        $scope.approveProjectLanguageId = commonService.getSessionData('approveProjectLanguageId');
        $('.modal-backdrop').css('display', 'none');
        $scope.changeView('approve');
    };

       /**
     * @ngdoc
     * @name bannerToggle
     * @methodOf Projects.controller:TranslationController
     * @description
     * This function is called on expand icon on glossary page.Used to expand grid size.
     * @returns {undefined} This method does not return.
     */
    $scope.bannerToggle = function () {
        if (isVisible == true) {
            $('.container-header, .navbar-default, .glossary-header-wrapper, footer').show();
            $('section.container').css('height', window.innerHeight - 216);
            $('.wide-screen-wrapper .ngViewport').css('height', window.innerHeight - 620);
            $('.wide-screen-wrapper .gridStyle').css('height', window.innerHeight - 570);
            isVisible = false;
            sessionStorage.setItem('isVisible', false);
        } else {
            $('.container-header, .navbar-default, .glossary-header-wrapper, footer').hide();
            $('section.container').css('height', window.innerHeight);
            $('.wide-screen-wrapper .ngViewport').css('height', window.innerHeight - 290);
            $('.wide-screen-wrapper .gridStyle').css('height', window.innerHeight - 250);
            isVisible = true;
            sessionStorage.setItem('isVisible', true);
        }
    };

    //event on any change in ng-grid table
    $scope.$on('ngGridEventColumns', function (event, newColumns) {

        if (newColumns.length > 0) {
            sessionStorage.setItem('gridContextInstance', JSON.stringify(newColumns));
        }

        sessionStorage.setItem('gridContextSaved', JSON.stringify(true));
    });
    //backend call for updating the locking time of the user in the current page
    var callUpdateUserLockService = function (data) {
        commonService.setTimeInSourceSetupCall(data, function (status) {
        });
        return true;
    };

    //To gradually reduce the size of the image upto a limit on column resize
    $scope.$watch('gridOptions.$gridScope.isColumnResizing', function (newValue, oldValue) {
        if (newValue === false && oldValue === true) {
            //on stop resizing
            var max_size = 110;
            $(".width100per").each(function (i) {
                x = $(this).width();
                $(".ngCellTextMasterTerm").each(function (i) {
                    var h = max_size;
                    var w = Math.ceil(x - 120);
                    $(this).css({ height: h + 'px', width: w + 'px' });
                });

            });
        }
    }, true);
    
    $scope.$watchCollection('facdata', function (new_value, old_value) {
        if (new_value.length > 0) {
            $scope.disableCompleteBtn = false;
        } else {
            $scope.disableCompleteBtn = true;
        }
    });
}]);