'use strict';

/**
  * @ngdoc servicesdfasdf
  * @name foo
  * @description Malformed docblock
**/
angular.module('foo', [])
.factory('foo', function() {
  return {};
});