NG_DOCS={
  "sections": {
    "api": "Glossary Manager Docs"
  },
  "pages": [
    {
      "section": "api",
      "id": "Admin",
      "shortName": "Admin",
      "type": "object",
      "moduleName": "Admin",
      "shortDescription": "This is admin module, which contains adminController which is responsible for all the operations done on the admin page.",
      "keywords": "$httpprovider $routeprovider admin admincontroller angularjs api common html module ngroute object operations responsible"
    },
    {
      "section": "api",
      "id": "Admin.AdminService",
      "shortName": "Admin.AdminService",
      "type": "service",
      "moduleName": "Admin",
      "shortDescription": "This is service in Admin module. It contains methods which are used for different operations done on admin page.",
      "keywords": "$http add addbrand addbrandobj addclient addnewclient addnewglobalcategory addsection addsectionobj admin adminservice angularjs api associate associatebrand associatebrandobj associatesection associatesectionobj brand brands catagory categories category client clientid clientsectionid common commonservice current data de-associate deassociatebrand deassociatesection edit editbrand editbrandobj editclient editclientname editedglobalcategory editsection editsectionobj false function getbrandstoassociate getclientsbrandscategoriessections getglobalcategories global info initial list load logged method methods module newglobalcategory object operation operations property returns selected service successful true updatenewglobalcategory user userid"
    },
    {
      "section": "api",
      "id": "Admin.controller:AdminController",
      "shortName": "AdminController",
      "type": "controller",
      "moduleName": "Admin",
      "shortDescription": "This Controller is responsible for all the operations done on the admin page",
      "keywords": "$http $route $scope $timeout add addbrand addcategory addclient addsection admin admin-controller-admincontroller-page admin-controller-page admincontroller adminservice angularjs api application array associate associatebrand associated associatesection boolean box brand brandlist brands button called categories category categorylist change check checkmaxlen class click client clientlist clients clientsel common commonservice controller data de-associate deassociate deassociatebrand deassociatesection details div edit editbrand editclient editsection entered exist fields function getbrandstoassociate getsectionstoassociate global globalcategories init initial initially input isexistingbrand isexistingcategory isexistingclient isexistingsection left length list loaded logged max method number object operations populatebrand popup property responsible return sectionlist sections select selected selectedtab tab tabid tabs update updatecategory user userid"
    },
    {
      "section": "api",
      "id": "AngularJS",
      "shortName": "AngularJS",
      "type": "object",
      "moduleName": "AngularJS",
      "shortDescription": "This section contains all inbuilt in functionalities of angualr js.",
      "keywords": "angualr angularjs api click details functionalities https inbuilt js link object org reference respective sections"
    },
    {
      "section": "api",
      "id": "AngularJS.$http",
      "shortName": "AngularJS.$http",
      "type": "service",
      "moduleName": "AngularJS",
      "shortDescription": "This built in AngularJS API (service) .",
      "keywords": "$http angularjs api built click details https link org service"
    },
    {
      "section": "api",
      "id": "AngularJS.$httpProvider",
      "shortName": "AngularJS.$httpProvider",
      "type": "service",
      "moduleName": "AngularJS",
      "shortDescription": "This AngularJS in built module which is used to change the default behavior of the $http service.",
      "keywords": "$http $httpprovider angularjs api behavior built change click default details https link module org service"
    },
    {
      "section": "api",
      "id": "AngularJS.$interval",
      "shortName": "AngularJS.$interval",
      "type": "service",
      "moduleName": "AngularJS",
      "shortDescription": "This built in AngularJS API (service) ",
      "keywords": "$interval angularjs api built click details https link org service"
    },
    {
      "section": "api",
      "id": "AngularJS.$location",
      "shortName": "AngularJS.$location",
      "type": "service",
      "moduleName": "AngularJS",
      "shortDescription": "This built in AngularJS API (service) .",
      "keywords": "$location angularjs api built click details https link org service"
    },
    {
      "section": "api",
      "id": "AngularJS.$locationProvider",
      "shortName": "AngularJS.$locationProvider",
      "type": "service",
      "moduleName": "AngularJS",
      "shortDescription": "This AngularJS routing provider module.",
      "keywords": "$locationprovider angularjs api click details https link module org provider routing service"
    },
    {
      "section": "api",
      "id": "AngularJS.$rootScope",
      "shortName": "AngularJS.$rootScope",
      "type": "service",
      "moduleName": "AngularJS",
      "shortDescription": "This built in AngularJS API (service).",
      "keywords": "$rootscope angularjs api built click details https link org service"
    },
    {
      "section": "api",
      "id": "AngularJS.$route",
      "shortName": "AngularJS.$route",
      "type": "service",
      "moduleName": "AngularJS",
      "shortDescription": "This AngularJS routing provider module.",
      "keywords": "$route angularjs api click details https link module org provider routing service"
    },
    {
      "section": "api",
      "id": "AngularJS.$routeProvider",
      "shortName": "AngularJS.$routeProvider",
      "type": "service",
      "moduleName": "AngularJS",
      "shortDescription": "This built in AngularJS API (service) ",
      "keywords": "$routeprovider angularjs api built click details https link org service"
    },
    {
      "section": "api",
      "id": "AngularJS.$scope",
      "shortName": "AngularJS.$scope",
      "type": "service",
      "moduleName": "AngularJS",
      "shortDescription": "This built in AngularJS API (service) .",
      "keywords": "$scope angularjs api built click details https link org service"
    },
    {
      "section": "api",
      "id": "AngularJS.$timeout",
      "shortName": "AngularJS.$timeout",
      "type": "service",
      "moduleName": "AngularJS",
      "shortDescription": "This built in AngularJS API (service) ",
      "keywords": "$timeout angularjs api built click details https link org service"
    },
    {
      "section": "api",
      "id": "AngularJS.ng-breadcrumbs",
      "shortName": "AngularJS.ng-breadcrumbs",
      "type": "service",
      "moduleName": "AngularJS",
      "shortDescription": "",
      "keywords": "angularjs api better breadcrumb-style help ian js kennington navigation ng-breadcrumb ng-breadcrumbs service v0 views walter"
    },
    {
      "section": "api",
      "id": "AngularJS.ngRoute",
      "shortName": "AngularJS.ngRoute",
      "type": "service",
      "moduleName": "AngularJS",
      "shortDescription": "This AngularJS in built module which is used for routing.",
      "keywords": "angularjs api built click details https link module ngroute org routing service"
    },
    {
      "section": "api",
      "id": "AuditTrail",
      "shortName": "AuditTrail",
      "type": "object",
      "moduleName": "AuditTrail",
      "shortDescription": "This is Audit Trail module, which will contain controller for Audit Trail page. ",
      "keywords": "$locationprovider $routeprovider angularjs api audit audittrail common controller html module ngroute object trail"
    },
    {
      "section": "api",
      "id": "AuditTrail.AuditTrailService",
      "shortName": "AuditTrail.AuditTrailService",
      "type": "service",
      "moduleName": "AuditTrail",
      "shortDescription": "This is service in Audit trail module. It contains methods which are used for different operations done on audit trail page.",
      "keywords": "$http angularjs api applied array audit audittrail audittrailservice basis clienidlist client common commonservice data details displayed excel exportauditinfo exported filter filtercriteriaforlogs filters function getauditinfo getclientspecificprojects getfilterdataforaudit info list logged method methods module object operations password projectid projects returns role saveblob selected service sheet table trail user userid userrolename xexportlogdisplayresult"
    },
    {
      "section": "api",
      "id": "AuditTrail.controller:AuditTrailController",
      "shortName": "AuditTrailController",
      "type": "controller",
      "moduleName": "AuditTrail",
      "shortDescription": "This Controller is responsible for showing and exporting log on audit trail page.",
      "keywords": "$http $location $scope angularjs api applied audit audittrail audittrail-controller-audittrailcontroller-page audittrail-controller-page audittrailcontroller audittrailservice backend basis boolean button called change checkexportpassword class client column common commonservice controller data details disable div dropdown empty encrypted enddate export exportauditlogs exporting file filtercriteriaforlogs filters function getclientspecificprojects getfilterdata init initialisation initially inside keyname list load loaded log logged logs message method object password popup project projectid projects received responsible return selected selectedclient selectedpage selectedprojectid set setexportpassword showauditlogs showaudittable showemptytablemsg showexportlogsbtn showing sort sorted start startdate stores string table trail user userdetails users validate values variables"
    },
    {
      "section": "api",
      "id": "common",
      "shortName": "common",
      "type": "object",
      "moduleName": "common",
      "shortDescription": "This is common module for all modules.",
      "keywords": "angularjs api common html module modules ng-breadcrumbs object"
    },
    {
      "section": "api",
      "id": "common.commonService",
      "shortName": "common.commonService",
      "type": "service",
      "moduleName": "common",
      "shortDescription": "This is a common service used by all controllers in application.This service contains all the common functions eg.gerUserGuide method is used to download help document. ",
      "keywords": "$http admin adminuserobj angularjs antiforgery api application check checking checksourcesetup common commonservice controllers cookie data db deleting details document download exist expiration extendsessiontiming function functions geruserguide getexpirationtime gettoken getuserguide getuserrecorddeleted help huides impersonated impersonatelogout impersonateuser input lock locking locks logged logout method object objects pageid projectid provided record records resourceid resources returns service session settimeinsourcesetupcall status time timeout token true uerid updating user userguide userid userimpersonateinfo username"
    },
    {
      "section": "api",
      "id": "common.directive:attachFiles",
      "shortName": "attachFiles",
      "type": "directive",
      "moduleName": "common",
      "shortDescription": "This is custom directive used on file upload. This is used to get file data(name,size,type)",
      "keywords": "api attachfiles common custom data directive file input size type upload"
    },
    {
      "section": "api",
      "id": "common.directive:attachImages",
      "shortName": "attachImages",
      "type": "directive",
      "moduleName": "common",
      "shortDescription": "This is custom directive used on image file upload on source setup page. This is used to get file data(name,size,type)",
      "keywords": "api attachimages common custom data directive file image input setup size source type upload"
    },
    {
      "section": "api",
      "id": "common.directive:brandDropdown",
      "shortName": "brandDropdown",
      "type": "directive",
      "moduleName": "common",
      "shortDescription": "This is custom directive used for multi select dropdown for brands.",
      "keywords": "api branddropdown brands common custom directive dropdown multi select"
    },
    {
      "section": "api",
      "id": "common.directive:distributionlistClientDropdown",
      "shortName": "distributionlistClientDropdown",
      "type": "directive",
      "moduleName": "common",
      "shortDescription": "This is custom directive used on distribution list page for multiselect dropdown for clients.",
      "keywords": "api clients common custom directive distribution distributionlistclientdropdown dropdown list multiselect"
    },
    {
      "section": "api",
      "id": "common.directive:dropdownMultiselect",
      "shortName": "dropdownMultiselect",
      "type": "directive",
      "moduleName": "common",
      "shortDescription": "This is custom directive used on add project page for multiselect dropdown for clients.",
      "keywords": "add api clients common custom directive dropdown dropdownmultiselect multiselect project"
    },
    {
      "section": "api",
      "id": "common.directive:multiSelectDragLeftRight",
      "shortName": "multiSelectDragLeftRight",
      "type": "directive",
      "moduleName": "common",
      "shortDescription": "This is custom directive for multi select drag left to right and vice versa.",
      "keywords": "api common custom directive drag left multi multiselectdragleftright select versa vice"
    },
    {
      "section": "api",
      "id": "common.directive:multiSelectDragLeftRightProjectEdit",
      "shortName": "multiSelectDragLeftRightProjectEdit",
      "type": "directive",
      "moduleName": "common",
      "shortDescription": "This is custom directive for multi select drag left to right and vice versa on project Edit page.",
      "keywords": "api common custom directive drag edit left multi multiselectdragleftrightprojectedit project select versa vice"
    },
    {
      "section": "api",
      "id": "common.directive:multiSelectDragLeftRightSourceSetup",
      "shortName": "multiSelectDragLeftRightSourceSetup",
      "type": "directive",
      "moduleName": "common",
      "shortDescription": "This is custom directive for multi select drag left to right and vice versa on source setup page.",
      "keywords": "api common custom directive drag left multi multiselectdragleftrightsourcesetup select setup source versa vice"
    },
    {
      "section": "api",
      "id": "common.directive:ownerDropdown",
      "shortName": "ownerDropdown",
      "type": "directive",
      "moduleName": "common",
      "shortDescription": "This is custom directive for multi select dropdown for project owners on add/edit project.",
      "keywords": "add api common custom directive dropdown multi ownerdropdown owners project select"
    },
    {
      "section": "api",
      "id": "common.directive:searchDropDown",
      "shortName": "searchDropDown",
      "type": "directive",
      "moduleName": "common",
      "shortDescription": "This is custom directive for multi select dropdowns on search page.",
      "keywords": "api common custom directive dropdowns multi search searchdropdown select"
    },
    {
      "section": "api",
      "id": "common.directive:translatorClientDropdown",
      "shortName": "translatorClientDropdown",
      "type": "directive",
      "moduleName": "common",
      "shortDescription": "This is custom directive for multi select dropdown for clients list on translation page.",
      "keywords": "api clients common custom directive dropdown list multi select translation translatorclientdropdown"
    },
    {
      "section": "api",
      "id": "common.directive:userClientDropdown",
      "shortName": "userClientDropdown",
      "type": "directive",
      "moduleName": "common",
      "shortDescription": "This is custom directive for multi select dropdown for clients list on users page.",
      "keywords": "api clients common custom directive dropdown list multi select userclientdropdown users"
    },
    {
      "section": "api",
      "id": "common.directive:userProjectDropdown",
      "shortName": "userProjectDropdown",
      "type": "directive",
      "moduleName": "common",
      "shortDescription": "This is custom directive for multi select dropdown for projects list on users page.",
      "keywords": "api common custom directive dropdown list multi projects select userprojectdropdown users"
    },
    {
      "section": "api",
      "id": "DistributionList",
      "shortName": "DistributionList",
      "type": "object",
      "moduleName": "DistributionList",
      "shortDescription": "This is DistributionList module, which contains distributionListController for distribution list menu to show all distribution lists in the application",
      "keywords": "$httpprovider $locationprovider $routeprovider angularjs api application common distribution distributionlist distributionlistcontroller html list lists menu module ngroute object"
    },
    {
      "section": "api",
      "id": "DistributionList.controller:DistributionListController",
      "shortName": "DistributionListController",
      "type": "controller",
      "moduleName": "DistributionList",
      "shortDescription": "This Controller is responsible for showing distribution lists on distribution list page and all the operations done on distribution list page.",
      "keywords": "$location $route $scope $timeout activate activated active add adddlform admin admins allclientllist angularjs api approver array box button called change changedlstatus changedlstatusactiv checkbox class click client clients column common commonservice confirmation confirmdeletedlbutton controller createnewdlpopup data delete deleted deselecting details distribution distributionlist distributionlist-controller-distributionlistcontroller-page distributionlist-controller-page distributionlistcontroller distributionlistname distributionlistservice distrubutionliststatus div dl dllist dls dlstatus dropdown duplicatevalidation edit editdistributionlist editdl editdlform field fields filter form function getusersforapprovertranslator group icon inactive init initialisation initially inputs isactivefilter isinactivefilter keyname knowledge langcheked language languages left list lists load loaded method model move newdl object open operations popup property pushing reset resetdata responsible return role rolename roles savedistributionlist savenewadaminandsuperadmindl savenewapproverandtranslatordl savenewclientadminandclientuserdl select selected selectedclients selectedlang selectedrolename selectedusers selecting selectlangclick selectroleonpopup selectuserclick showallfilter showing showrolewisedistributionist showstatuswiseditributionlist side sort sorted status store string super table translator translators type unique unselectedlang unselecteduser unselectlangclick unselectuserclick update updateadaminandsuperadmindl updateapproverandtranslatordl updateclientadminandclientuserdl updated user users validate validated validatedldataonchange validation variables wise"
    },
    {
      "section": "api",
      "id": "DistributionList.DistributionListService",
      "shortName": "DistributionList.DistributionListService",
      "type": "service",
      "moduleName": "DistributionList",
      "shortDescription": "This is service in Users module. It contains methods which are used for different operations done on users page.",
      "keywords": "$http accoriding adddistributionlist angularjs api applied called changedistributionliststatus click common commonservice current data details displayed distribution distributionlist distributionlistfilterdata distributionlistid distributionlistinfo distributionlistservice dl dls edit editdistributionlist edited existing filters function getdistributionlist getdldetails icon list lists logged method methods module newly object operations popup retrieveusersbyclientsandlanguages returns save selected service status table uesed update user userid users"
    },
    {
      "section": "api",
      "id": "Help",
      "shortName": "Help",
      "type": "object",
      "moduleName": "Help",
      "shortDescription": "This is Help module, which will contain controller for help page. ",
      "keywords": "$locationprovider $routeprovider angularjs api common controller help html module ngroute object"
    },
    {
      "section": "api",
      "id": "Help.controller:HelpController",
      "shortName": "HelpController",
      "type": "controller",
      "moduleName": "Help",
      "shortDescription": "This Controller is responsible for download the user guides from help page.",
      "keywords": "$http $location $scope angularjs api backend called class common commonservice controller details div download file function getuserguides guide guides help help-controller-helpcontroller-page help-controller-page helpcontroller init initialisation initially load loaded logged method object path received responsible return stores user userdeatails userdetails variables"
    },
    {
      "section": "api",
      "id": "Login",
      "shortName": "Login",
      "type": "object",
      "moduleName": "Login",
      "shortDescription": "This is login module, which will contain controller for login page. ",
      "keywords": "$locationprovider $routeprovider angularjs api controller html login module ngroute object users"
    },
    {
      "section": "api",
      "id": "Login.controller:LoginController",
      "shortName": "LoginController",
      "type": "controller",
      "moduleName": "Login",
      "shortDescription": "This Controller is responsible for showing Login page and handling requests made on Login page ",
      "keywords": "$http $location $scope accept acceptdeclinehandler accepted angularjs api authenticateuser backend button called change checks class clicked clicks condition conditions controller database decline details div don email empty entered entries error false field forgetpasswordemail form function getuserdetails handling hash link logged login login-controller-logincontroller-page login-controller-page logincontroller loginerrormessage match message method ng-show object onhashchange pass password property received requests reset response responsible send session showing status storage stores string terms tracks url user userauthenticateservice userauthorizationservice userdetails username users valid weather"
    },
    {
      "section": "api",
      "id": "Login.controller:ResetPasswordController",
      "shortName": "ResetPasswordController",
      "type": "controller",
      "moduleName": "Login",
      "shortDescription": "This Controller is responsible for showing Login page and handling requests made on Login page ",
      "keywords": "$http $location $scope angularjs api authenticate authenticateuser boolean called check class controller data details div email encrypted enterded expiration expired handling init link linkexpired load login login-controller-page login-controller-resetpasswordcontroller-page message messageheader method object pass password requests reset reseting resetpassword resetpasswordcontroller responsible return returns showing stores string success url urldateencripted user userauthenticateservice userauthorizationservice users variable"
    },
    {
      "section": "api",
      "id": "Preferences",
      "shortName": "Preferences",
      "type": "object",
      "moduleName": "Preferences",
      "shortDescription": "This is preferences module, which will contain controller for my profile page. ",
      "keywords": "$locationprovider $routeprovider angularjs api controller html module ngroute object preferences profile"
    },
    {
      "section": "api",
      "id": "Preferences.controller:PreferencesController",
      "shortName": "PreferencesController",
      "type": "controller",
      "moduleName": "Preferences",
      "shortDescription": "This Controller is responsible for all the operations done on the My profile page",
      "keywords": "$http $scope $timeout angularjs api array assigned auto blur button called cancel cancelsettings change changepassword checkbox checkvalidations class click common commonservice complete controller details div fields function info init initialisation initially input isrememberusernexttime issectioncompletereminder landingpagedata languages list load loaded logged message method notification notifications object operations otherlang pass password popup preferencelist preferences preferences-controller-page preferences-controller-preferencescontroller-page preferencescontroller profile projects property remember rememberautotranslation reminder responsible return returns role save savesettings settings string submit success tab tabs toggle translation user userinfo userrolename validation variables"
    },
    {
      "section": "api",
      "id": "Preferences.PreferencesService",
      "shortName": "Preferences.PreferencesService",
      "type": "service",
      "moduleName": "Preferences",
      "shortDescription": "This is service in preferences module. It contains methods which are used for different operations done on my profile page.",
      "keywords": "$http angularjs api change changepassword common commonservice data details entered function getuseremailnotification list logged message method methods module notification notifications object operation operations password preferences preferencesservice profile returns save saveemailnotification selected service settings success successful true update updateuserconfirmationfornexttime user userid"
    },
    {
      "section": "api",
      "id": "Projects",
      "shortName": "Projects",
      "type": "object",
      "moduleName": "Projects",
      "shortDescription": "This is Projects module, which will contains controller for project page. ",
      "keywords": "$httpprovider $locationprovider $routeprovider angularjs api common controller html module ngroute object project projects"
    },
    {
      "section": "api",
      "id": "Projects.controller:ApprovalController",
      "shortName": "ApprovalController",
      "type": "controller",
      "moduleName": "Projects",
      "shortDescription": "This Controller is responsible for showing content on project glossary Approval page.",
      "keywords": "$http $location $rootscope $route $scope $timeout accept add addcomment additional addtranslationsource allapprovestatus allrejectstatus allsection angularjs api appear appears approval approvalcontroller approve approved approvestatus approveterms area array backend bannertoggle boolean bound box button call called cancel cancelcomment canceleditcmt cancelexport categories category catwidth cell cells celltemp change changeview check checkbox checkboxes class clear clearfilteroptions click clicked clicks close cmnt column columndefs columns comment common commonservice complete concatinated configuration confirmation content controller copy create criteria data decide default defaultglossarysection defdata definition definitions defobjforcat description detail details disabled div double dropdown edit editable editcelltempforcat editcelltempforengdescript editcmnt edited editing edittemp element email empty english entered excel expand export exportdata exportglossarytoggle exportknpclicked exportmodalshow facdata fields filter filteroptions filters finaltranslationsubmit form function getglossarydata getlanguagehistory getlanguagename getlanguagenamepopup gettermsuggestions glmgr-1030 glmgr-1153 glossary glossarydata glossaryinitialdata glossaryinitialterms glossarynggrid glossarysearchcategory glossarysectiondata grid gridoptions hc_nopin hc_nopin_language hc_nopin_language_rtl hc_nopin_master_rtl hc_nopin_source header headervalue headingname hide hideaddinfocols hideaddinfocolumns hideemptyaddinfocols hideemptycolumns hidestarredcolumn hidetranssourcecolumn history html icon info init initialisation internally isstarred isstarredchecked istranslationsourcerequired knp language languages left list liststarredterms load loads local logged mandatoryvalidation master master-language method modal new_path ng ng-grid ntl ntlglossarysection object objects open option options pending pendingsuggestiontermlist pin pinned popup project projectid projects projects-controller-approvalcontroller-page projects-controller-page property received redirect reject rejected rejectstatus respective responsible result retrieved return row save savecomment saveeditedcmnt saving search searchinglossaryterm sections sectionselected sectionselectedobjid select selected selectedlaguageobj send sendemail sendglossary sending set settings setup sfera sferaexport sferavalidation showing showtext size source starred starredtermlanguage storage store stores str string structure submit suggestion suggestions switch tab table tabs template term termindex terms text textcmnt toggle togglehistorylogforterm translation uncheck user userdetails validate validation values variables view views viewsectionresult width"
    },
    {
      "section": "api",
      "id": "Projects.controller:GlossaryAllSectionController",
      "shortName": "GlossaryAllSectionController",
      "type": "controller",
      "moduleName": "Projects",
      "shortDescription": "This Controller is responsible for showing content on project all glossary page.",
      "keywords": "$http $location $rootscope $route $scope $timeout add additional allglossary allglossaryredirect alllanguagesglossary allsection angularjs api approve array backend boolean bound box button call called change changeview check checkbox checkboxes checkcolors checkimage checkphonetics checkphoneticsclick checkstatus class clear clearfilteroptions clearsearch click color colors column columndefs columns common commonservice configuration content controller data defdata definitions depending details div dropdown element empty entered facdata filter filterbysectiontype filteroptions filters filtervalue function generate glossary glossaryallsectioncontroller glossarydata glossaryterms glossaryuigrid grid gridoptions gridoptions1 headerlist hide hideaddinfocols hideaddinfocolumns hidecolors hideemptyaddinfocols hideemptycolumns hideimage hidephoneticpluralcols hidestatus history html image info init initialisation inside landingpagedata language languages list load loads logged method new_path object objects open option options pending pendingsuggfilterongrid phonetics popup poup processor project projects projects-controller-glossaryallsectioncontroller-page projects-controller-page property received render renderablerows respective responsible return row rows save search sections sectiontype select selectalllangfilters selected session set settings showfilter showing singlefilter source sourcetermpendingsugg status store stores string suggestions table term terms text translation type ui user userdetails variable variables view views"
    },
    {
      "section": "api",
      "id": "Projects.controller:GlossaryController",
      "shortName": "GlossaryController",
      "type": "controller",
      "moduleName": "Projects",
      "shortDescription": "This Controller is responsible for showing content on project glossary page.",
      "keywords": "$http $location $rootscope $route $scope $timeout add addglossaryapprovetranslation addglossarytranslation additional allsection angularjs api approve approver approveterms area array attachment backend boolean bound button call called cancel cancelexport categories category catwidth cell cells celltemp change changeview checkbox checkboxes class clear clearfilteroptions click clicked clicks close column columndefs columns comment common commonservice conatains concatenated configuration content controller copy create criteria data decide default defaultglossarysection defdata definition definitions defobjforcat defobjforlang description detail details disabled div double download downloadattachmentpopup dropdown edit editable editcelltempforcat editcelltempforengdescript edittemp element empty english entered excel export exportdata exportglossarytoggle exportknpclicked exportmodalshow facdata fields filter filteroptions filters form function getglossarydata getlanguagehistory getlanguagename getlanguagenamepopup gettermsuggestions glmgr-1153 glmgr-1598 gloassary glossary glossarycontroller glossarydata glossaryinitialdata glossaryinitialterms glossarynggrid glossarysearchcategory glossarysectiondata grid gridoptions hc_nopin hc_nopin_language hc_nopin_language_rtl hc_nopin_master_rtl hc_nopin_source header headervalue headingname hide hideaddinfocols hideaddinfocolumns hideemptyaddinfocols hideemptycolumns hidestarredcolumn hidetranssourcecolumn history html icon info init initialisation internally isstarred isstarredchecked istranslationsourcerequired knp language languages left list liststarredterms load loads local logged mandatoryvalidation master master-language method modal new_path ng ng-grid ntl ntlglossarysection object objects og open option options pin pinned popup project projectid projects projects-controller-glossarycontroller-page projects-controller-page property received redirect respective responsible result retrived return row save search searchinglossaryterm sections sectionselected sectionselectedobjid select selected selectedlaguageobj send sendglossary set settings setup sfera sferaexport sferavalidation showfilter showing showtranslationsource source starred starredtermlanguage storage store stores str string structure suggestion switch tab table tabs template term termindex terms text toggle togglehistorylogforterm translateterms translation uncheck user userdetails validate validation values variables version view views viewsectionresult width"
    },
    {
      "section": "api",
      "id": "Projects.controller:ProjectAddController",
      "shortName": "ProjectAddController",
      "type": "controller",
      "moduleName": "Projects",
      "shortDescription": "This Controller is responsible for adding new project.",
      "keywords": "$http $location $route $scope $timeout add adding additional angularjs api applied array assigned assigneduserlist backend blur brands button called categories change check checkprojectnameblurdup class clear clearcat clearlang cleartranssourcelang click client clients columns common commonservice controller create data depending details dir direction div dropdown duplicate fields filed form function getprojectadddata group groups groupuserlist includes info init initialisation input items landingpagedata langaugeselected language languages left list load logged mandatoryvalidation mandatoryvalidationonchange master masterlanguageid masterlanguageselected method model move movedownclick moveowner movesourceselectedlang movesourceunselectedsections moveupclick mydatabrands mydataclients mydataowners number object objects owner ownergrouppopup owners parameter passed populate popup pre project projectaddcontroller projectname projects projects-controller-page projects-controller-projectaddcontroller-page property received required respective responsible return returns save saveproject secure securetitle select selectcat selected selectedlangsourcelist selectlang sequence set showcommmonbrands showvaluesonownerdropdown side source stores string title translation translationsourcepopup true user userdetails users validate validation values variables"
    },
    {
      "section": "api",
      "id": "Projects.controller:ProjectEditController",
      "shortName": "ProjectEditController",
      "type": "controller",
      "moduleName": "Projects",
      "shortDescription": "This Controller is responsible for editing the existing project.",
      "keywords": "$http $location $route $scope $timeout add additional addnewcategorybuttonclick addnewcategoryclick angularjs api array assigned assigneduserlist attached attachedfiles attachment attachmentlanguageid attachments backend blur bound brands button called categories category categoryremoveok change changeview check checkprojectnameblur checkprojectnameblurdup class clear cleartranssourcelang click clients columns common commonservice controller create data delete deletefile deletelocalcategory depending details dir direction div doed dropdown duplication edit editcategory editcategoryclick edited editing element encrypted entire existing fields file files form fuction function getfilelist getprojecteditdata glossary group groups groupuserlist html info init initial initialisation items landing landingpagedata language languageremoveok languages left list load loads logged mandatoryvalidation mandatoryvalidationonchange master masterlanguageid method move movedownclick moveowner movesourceselectedlang movesourceunselectedsections moveupclick mydatabrands mydataclients mydataowners navigate navsorcesetup new_path newcategory newly number object objects opens owner ownergrouppopup owners permissions popup project projecteditcontroller projectid projects projects-controller-page projects-controller-projecteditcontroller-page property received redirect redirecturl remove removed required respective responsible return returns save saveproject secure securetitle select selectcat selected selectedlangsourcelist selection selectlang sends sequence setup showcommmonbrands showeditcategorypopup showvaluesonownerdropdown source stores string title translation translationsourcepopup true unselectedcat unselectedlang updated upload uploadattachments url user userdetails users validate validation values variables view views"
    },
    {
      "section": "api",
      "id": "Projects.controller:ProjectInfoController",
      "shortName": "ProjectInfoController",
      "type": "controller",
      "moduleName": "Projects",
      "shortDescription": "This Controller is responsible for showing content on project info page.",
      "keywords": "$http $location $route $scope $timeout add angularjs api backend boolean bound called change changeview checkbox class common commonservice content controller count current currentprojectid depends details displayed div edit element encrypted exclude excludentl_fd excludentl_fd_count false function glossary html inconsistent inconsistenttranslation info init initialisation islocked landingpagedata language languageid load loads lock locked logged method new_path ntl object open permissions popup project projectinfo projectinfocontroller projects projects-controller-page projects-controller-projectinfocontroller-page property received respective responsible return setup showing source status stores string translation true user userdetails variables view views"
    },
    {
      "section": "api",
      "id": "Projects.controller:ProjectMasterController",
      "shortName": "ProjectMasterController",
      "type": "controller",
      "moduleName": "Projects",
      "shortDescription": "This Controller is responsible for showing content on project source setup page.",
      "keywords": "$http $interval $location $route $scope $timeout accept add addbrandidfromradiobtn addbulksection adding additional addnewgroup addnewrow addnewrowstodb addsectionscategories allow allowduplicatemastertextinfoimport angularjs api apply applybulksuggestions applybulksuggestionspopup applysuggestionsbutton approve approvesuggestion area argument array assign assigned attached auto autosaveaftersequencechanged autosavetermimage backend backfrompreview basic blur boolean bound box brand brands bulk bulkaddeditpopup button buttonlabel buttons call called callsectioncomplete cancel cancelbulksection cancelmigration cancels cancelscriptupload cancelsection cancelsuggestions categories category change changed changes changesectiontype changestarredstate changeview check checkbox checkboxes checkduplicatebulksection checkduplicatesection checked checking checkmaxlen checksectionstatus class clear cleared clearsourcesetupfilters click close closes closing column columns comment commit commitscript common commonservice complete completing conatins confirmation content controller copy creating crop current data db default defaultsection delete deletebulksection deleted deletefile deleterow deletesection deleting depends details disable displayed displayingselectedgroup distribution div doed don dropdown duplicate duplicates edit edited editleft editsectionname element enable encrypted entered event false file fileid filter filters flag focus function funtion future generates getallsectionscategory getassignedwatcherbygroup getgroupid getheaderlistandcategorylist getissecretonchange getprojectbasicinfoonload getrowwisebrands getsectiontobemovedonchange getsourcesetupfilters gettermsuggestions getunassignedwatcherbygroup glossary glossarygroupid gotouploadscript group groupid header headers headerstomigrate headertext hide hideinfocolumns hideinfocolumnscolumn hidestarred hidestarredcolumn hidetermuniqueid hidetermuniqueidcolumn history html icon image imagedelete imagepreview images import importsourcefile info init initial initialisation inserttableinui internal isaddedimagedetails isaddrowbuttondisabled isowner isrestoredflag issecret issecretchanged issequencechanged label landingpagedata left length link list load loads lockntlsectionprefixcall logged lost marking master masterglossaries masterglossaryid max message method migrate migrated migration mode modetype monitor monitorelementchange mothod move moveselectedsections moveselectedwatcher movetermtoothersection moveunselectedsections moveunselectedwatcher moving mydata myimagedata names navigate new_path newcancelsection newly nosecavalablemsg ntl ntlsection number object od onclick open openmovetermtopopup options owner parent parentindex passed pending permissions populate popup poup preeview prefix preview previous proceed proceedtoglossary proceedtotabchange project projectheaderid projectid projectinfo projectmaster projectmastercontroller projects projects-controller-page projects-controller-projectmastercontroller-page property radio received redirect reject rejectsuggestion reloadsectionafterpopup remind reminder remove removebrandidfromradiobtn removed removedbulksections removedwatcher removesectionscategories removesuggestion respective responsible restore return review reviewmodecommenttext reviewmodedelete reviewmoderestore reviewmodesuggtext reviewpanel reviewpanelcheckbox reviewsuggestion row row-wise rowdata rowid rowindex save saveallsectionsbrands savebulksection savecategoryinfo savecropimage saveeditbulksection savemastertextinfo savemigration saventlsectiontype saverowwisebrand saves savesectionscategories savewatcherlist saving script seclected secname secret sectioncomplete sectioncompleteconfirmation sectioncompletereminderinfotoggle sectioncompleteremindersettings sectioncompleteremindersettingsservice sectionindex sectionlist sections sectionsubmit sectionsubtype sectiontype select selectbulksection selected selectedbulksections selecteddlgroup selectedgroup selectedgroupcopy selectedsectionslist selectedwatchers sequence session set sets settings setup showdeletesectionpopup showhidehistorytoggle showing showselectedgroups showvalidation side source star starred starreddetailspopup starredstatepopup status storage store stores string submit submitsuggestions submitted suggestion suggestions switch switchmode system tab table tabledata tableid tableindex term term-wise text texteditbulksection time title true type unassigned unique unlock unlocksectionpopup unselecteddlgroup unselectedsectionslist update updated updateheadertext updating upload uploadattachments uploaded user userdetails validation validationmsg values variables view views watcher watcherlist watchers wise wizard"
    },
    {
      "section": "api",
      "id": "Projects.controller:ProjectsController",
      "shortName": "ProjectsController",
      "type": "controller",
      "moduleName": "Projects",
      "shortDescription": "This Controller is responsible for showing project landing page and showing all the project deatils on particular projects page.",
      "keywords": "$http $interval $location $route $scope 39 access add additional admin admins angularjs api approval array assigned assinged backend backfrompreview boolean bottom bound box brandfilter browser button call callallglossarypage called calls cancel cancelscriptupload carousal carousel carouselimageclick change changelockstatusclick changes changestatusclick changeview check checkbox checked checks class click client clientfilter column columnmapping comma commitscript common commonservice controller corousaldata count current currentprojectid currentuserid currentuserrolename deatils delete deletefile deselectedadmins details display div doed drop dropdown dropdowns edit element encrypted excel exclude export exportuseraccessreport false feature file filter final fuction function functionality getbacktofileupload getbacktohomepage glossaries glossary html ids image import info init initialisation isalreadyselected isvalidforpreview item knp labels landing landingpagedata languages left limit limitaccesforselectedadmins limitaccess list load loads lock logged mapping master method move moveuserstoleft moveuserstoright navigate navsorcesetup netflix new_path ntl number object objects onclick open opens option options opup owner ownerfilter parameter passed permissions popup preeview prepared preview project projectactivefilter projectdetails projectid projectlanglist projectlistvertical projects projects-controller-page projects-controller-projectscontroller-page projectscontroller prop property received redirect remove report reset resetbuttonlabels respective responsible return returns role save search select selectallclicked selected selectedadmins selects separated service session sets setup showing skip source sourcepreview status storage stores string submit super textfiltersearch ticked toggle toggleprojectlistclick translation true unencripted unencrypted upload uploadattachments uploadfilewizard user useraccessreport userdetails users validation variables view views wise wizard"
    },
    {
      "section": "api",
      "id": "Projects.controller:ProjectsPermissions",
      "shortName": "ProjectsPermissions",
      "type": "controller",
      "moduleName": "Projects",
      "shortDescription": "This Controller is responsible for assigning permissions to user.",
      "keywords": "$http $location $route $scope add addselectededitorialusers angularjs api array assigned assigning backend basic box called change changeview class client clients clientusername clientusernamestr comma common commonservice controller currprojid details directive displayed div editorial encrypted format generic getallpermissionsonload geteditorialstaffinfo getprojectbasicinfoonload info init input landingpagedata left list load loaded loader logged method new_path number object opened operation path permission permissions permissionuserroles popup project projectid projectinfo projectpermissions projectpermissionsservice projects projects-controller-page projects-controller-projectspermissions-page projectspermissions property received redirection remove removed removedusers removeselectededitorialusers respect responsible return returns role roles save saveeditorialstaffs secure selected selectededitorialstaffs selectededitorialstaffslist selectedusers separated showloaderindirective staff staffs stores string successful title true unselected unselectededitorialstaffs update user userdetails username usernames users view"
    },
    {
      "section": "api",
      "id": "Projects.controller:TranslationController",
      "shortName": "TranslationController",
      "type": "controller",
      "moduleName": "Projects",
      "shortDescription": "This Controller is responsible for showing content on project glossary translation page.",
      "keywords": "$http $location $rootscope $route $scope $timeout add addbulktranslationsource addcomment additional addtranslationsource allsection angularjs api appear approve area array auto autotranslationpopup backend bannertoggle boolean bound bulk button call called cancel cancelcomment canceleditcmt cancelexport categories category catwidth cell cells celltemp change changeview checkbox checkboxes class clear clearfilteroptions cleartranslationsource click clicked clicks close cmnt col column columndefs columns comment common commonservice complete concatenated configuration confirmation content controller copy create criteria data decide default defaultglossarysection defdata definition definitions defobjforcat description detail details disabled div double dropdown edit editable editcelltempforcat editcelltempforengdescript editcmnt edited editing edittemp element email empty english entered excel expand export exportdata exportglossarytoggle exportknpclicked exportmodalshow facdata fields filter filteroptions filters finalsubmit finaltranslationsubmit form function getglossarydata getlanguagehistory getlanguagename getlanguagenamepopup gettermsuggestions glmgr-1030 glmgr-1153 glossary glossarydata glossaryinitialdata glossaryinitialterms glossarynggrid glossarysearchcategory glossarysectiondata grid gridoptions hc_nopin hc_nopin_language hc_nopin_language_rtl hc_nopin_master_rtl hc_nopin_source header headervalue headingname hide hideaddinfocols hideaddinfocolumns hideemptyaddinfocols hideemptycolumns hidestarredcolumn hidetranssourcecolumn history html icon info init initialisation internally isstarred isstarredchecked istranslationsourcerequired knp language languages left list liststarredterms load loads local logged mandatoryvalidation master master-language method modal new_path ng ng-grid ntl ntlglossarysection object objects open option options pin pinned popup poup project projectid projects projects-controller-page projects-controller-translationcontroller-page property received redirect respective responsible result retrieved return row save savebulktranslationsource savecomment saveeditedcmnt saving search searchinglossaryterm sections sectionselected sectionselectedobjid select selected selectedlaguageobj send sendemail sendglossary sending set settings setup sfera sferaexport sferavalidation showing showtext size source starred starredtermlanguage storage store stores str string structure submit suggestion switch tab table tabs template term termindex terms text textarea textcmnt toggle togglehistorylogforterm translateterms translation translationcontroller translations uncheck user userdetails validate validation values variables view views viewsectionresult width"
    },
    {
      "section": "api",
      "id": "Projects.directive:optionsClass",
      "shortName": "optionsClass",
      "type": "directive",
      "moduleName": "Projects",
      "shortDescription": "This is custom directive created for highlighting the secret section in dropdown of all sections on source setup page.",
      "keywords": "api created custom directive dropdown highlighting optionsclass projects secret sections select setup source"
    },
    {
      "section": "api",
      "id": "Projects.directive:optionsClassLangOrder",
      "shortName": "optionsClassLangOrder",
      "type": "directive",
      "moduleName": "Projects",
      "shortDescription": "This is custom directive created for putting selected languages in an alphabetical order.",
      "keywords": "add alphabetical api box created custom directive language languages option optionsclasslangorder order project projects putting select selected"
    },
    {
      "section": "api",
      "id": "Projects.directive:optionsClassOrder",
      "shortName": "optionsClassOrder",
      "type": "directive",
      "moduleName": "Projects",
      "shortDescription": "This is custom directive created for putting addtional info options in an alphabetical order.",
      "keywords": "add addtional alphabetical api box created custom directive info option options optionsclassorder order project projects putting select"
    },
    {
      "section": "api",
      "id": "Projects.directive:optionsClassSections",
      "shortName": "optionsClassSections",
      "type": "directive",
      "moduleName": "Projects",
      "shortDescription": "This is custom directive created for coloring the selected secret section in dropdown of all sections on source setup page.",
      "keywords": "api coloring created custom directive dropdown option optionsclasssections projects secret sections selected setup source"
    },
    {
      "section": "api",
      "id": "Projects.directive:permission",
      "shortName": "permission",
      "type": "directive",
      "moduleName": "Projects",
      "shortDescription": "This is custom directive created for assigning projects permissions to users.",
      "keywords": "$route angularjs api assigning created custom directive input permission permissions projectpermissionsservice projects users"
    },
    {
      "section": "api",
      "id": "Projects.Glossary",
      "shortName": "Projects.Glossary",
      "type": "service",
      "moduleName": "Projects",
      "shortDescription": "This is service in projects module. It contains methods which are used for different operations done on project glossary pages.",
      "keywords": "$http accept add addcmnt allsave angularjs api applied approval approveallcheckautosave approvecheckautosave approved approvefinalsubmit approverpage attached attachment attachmentid attachments auto autotrans box catagories changed check checkbox columns comment comments commentterm common commonservice current data default details download edited editedcmnt email emaildata emailsendconfirmation emailsendconfirmationapproval encrypted entered excel export exported exportsferaknp file filters finalsubmit finaltranslationsubmit form format function functionality getapprovalglossaryinitialdata getapprovedata getattachmentlist getdownloadattachment getdownloadattachmentall getglossarydata getglossaryinitialdata getlanginfo getpendingsuggestiontermlist getprojecthistory getsectiondata getstarreditems getstarreditemstranslationapproval gettermsuggestions gettranslationdata gettranslationinitialdata gettranslationsource gloosary glosaary glossary glossarybulktranslationsource glossarygroupid glossarytranslationid glossarytranslationsource grids headerid history impersonated inconsistency info init insert insertautotranslation intial knp lang langid langinfoid language languageid languages list load logged main master masterglossaryid method methods module ntl object operations originaluserid parameter passed popup postexportsettings project projectglossarysearchmodel projectid projectlanguageid projects returns role row save saveautotranslation saveblob savebulktranslationsource savecomment saveeditedcmnt savelanginfo savelangmodel savetranslationsource search searchterminglossary sectiontype selected send senddata sendglossaryservice service sfera single source starred status strred submit suggestion term terms termtrans translated translation translationautosave translations true type user userid userrole userrolename users validateglossarytranslationfortranslationsource wise"
    },
    {
      "section": "api",
      "id": "Projects.LandingPageData",
      "shortName": "Projects.LandingPageData",
      "type": "service",
      "moduleName": "Projects",
      "shortDescription": "This is service in projects module. It contains methods which are used for different operations done on project landing page.",
      "keywords": "$http acces accessuserreport active add addnewcategory admin admins angularjs ant api application applied array assigned assignedadminlist attached attachment attachmentid boolan box brand brandid brandidfilter brands button called cancelled carosalprojectlist carosalprojectlistfilter carousel categories category change changeprojectlockstatus changeprojectstatus check checked click client clientid clientidfilter clientids clients column columnmppingobj common commonservice creating creator current data db delete deleted deletedlocalcategory deleteexistingfileonserver deletelocalcategory deletion depending details displayed document download dropdown duplicates edit edited editedlocalcategory encrypted entered entire excel excludentlfd exportreportinputs false file files filter filters forgery form function getattachedfilelist getattachedfilelistentireproject getclientlist getcorousaldata getlimitaccessalladmin getnewprojectdata getpagedata getpageeditdata getpageinfodata getprojectlist glossary ids impersonated import importnetflixdatacommit importnetflixknpfiledatacommit inactive info inputtextfilter isownerofprojectfilter knp landing landingpagedata language languageid languages limited list load local logged mapping mappings master method methods module myprojects netflix newcat number object objects operation operations original originaluserid owner owners parameter pass passed password popup postdeleteattachment prepopulated preview project project-wise projectid projectlanguageid projectownerlist projects projectstatefilteractive projecttitle properties reports required return returns role save saveeditedproject savelimitaccessadminusers search selected server service showattachmenttoinfo specific status successful table text thr title token true update updated updatelocalcategory upload uploadfile uploadscriptdb user userid userrole users view wizard"
    },
    {
      "section": "api",
      "id": "Projects.ProjectMaster",
      "shortName": "Projects.ProjectMaster",
      "type": "service",
      "moduleName": "Projects",
      "shortDescription": "This is service in projects module. It contains methods which are used for different operations done on project source setup page.",
      "keywords": "$http adding angularjs api applied appliedsuggestion apply applybulksuggestions applysuggestionhistoryforbulkmodel applysuggestionpermasterglossary applytermsuggestions area array assigned attached auto autosavecategoryinfo autosaveglossarybrands autosavemastertermmodel autosaverowsequence autosavetermimage boolean brand brandidlist brands bulk categories category categoryaddedids categoryremovedids change changed changerowsequence changestarredstate changestarredstatusmodel check checksectioncategories checksectionstatus checkstarredterm clientids clients comment comments commenttextautosave commit commitscriptdb commitscriptdbntl common commonservice compare complete convertdefaultsectiontontlsection current data db default delbulksection delete deleted deletedimagelist deletedrowslist deleterecordsfromheader deletesection deletetermimage delsecdata destination details distibution distribution distributionlistid duplicate editdata encrypted existing false file filename files filesize flag focus function getassigneddistibutionlistusers getbulksectiondata getcategoriesandheaderlist getdistibutionlistusers getpreviewtermimage getprojectheaderid getsavedheadersfromdb getsectionsbrandslist getstarredterminfo gettermsuggestions getwatcherlistdata glmgr-758 glossary glossaryaddedbrands glossarygroupid glossaryremovedbrands glossarysequenceformoveterm group header headerid headers headertext ids image images imageuploadmastertermmodel impersonated individual initial insert insertedbyuserid insertrowtonewsection isaccepted issecret issectioncomplete issectionunlock isstarred list lock logged lost mark marked master masterglossarybrandsmodel masterglossarycategorymodel masterglossaryid masterglossaryidstr masterid masterterm mastertext method methods migrate mode modetype module movetermtoothersection moving newaddedrowslist newsecdata ntl object objects objsectionstatus operations origin originaluser originaluserid originsectionid parameter passed preview process project projectcategorydata projectid projectmaster projects properties records reminder remove removed removesuggestions required retore returns review reviewmodedelete reviewmoderestore role row rows save saved saveeditedbulksection saveentiresections saveheaderdatatodb savenewbulksection savesectionsbrandslist savesectionscategorylist script secret sectionbrandstobesaved sectioncomplete sectionid sectionlist sections sectionsubtype sectiontype sectionviewmodel selected selectedsectionids sending sequence sequencing service set setup setwatchers source sourcesetupsequence star starred status submittermsuggestions subtype successful suggestedtext suggestedtextautosave suggestion suggestions suggestiontype table target targetsectionid term terms text true type unlock unlocksection update updated updatedbyuserid updatedrowslist updateglossarygroupheader updateheaderrecords upload uploadfile uploadscriptdb user userid users validation wachersuserid watcher watchers"
    },
    {
      "section": "api",
      "id": "Projects.ProjectPermissionsService",
      "shortName": "Projects.ProjectPermissionsService",
      "type": "service",
      "moduleName": "Projects",
      "shortDescription": "This is service in projects module. It is responsible for assigning project permissions to user.",
      "keywords": "$http angularjs api array assigning basic boolean common commonservice current db details editorial editorialstaffprojectpermissioninputmodel encrypted function geteditorialstaffinfo getprojectbasicinfo getprojectpermissions info input landingpagedata language list load logged master masterlanguageid method model module object operation parameter passed permissions permissionslist project projectid projectpermissionsservice projects property responsible returns save savepermissionsuserlist selected service staff successful user userid users"
    },
    {
      "section": "api",
      "id": "Projects.saveBlob",
      "shortName": "Projects.saveBlob",
      "type": "service",
      "moduleName": "Projects",
      "shortDescription": "This is service in projects module. This service is used to download all browser supported files from application.",
      "keywords": "api application browser download files module projects saveblob service supported"
    },
    {
      "section": "api",
      "id": "Search",
      "shortName": "Search",
      "type": "object",
      "moduleName": "Search",
      "shortDescription": "This is Search module, which will contain controller for search page. ",
      "keywords": "$httpprovider $locationprovider $routeprovider angularjs api common controller html module ngroute object search"
    },
    {
      "section": "api",
      "id": "Search.controller:SearchController",
      "shortName": "SearchController",
      "type": "controller",
      "moduleName": "Search",
      "shortDescription": "This Controller is responsible for search term with different criteria.",
      "keywords": "$http $location $route $scope 39 admin angularjs api applied applying approval array assigned backend boolean brand brands brnadlable button called class click clicked client clientlable coldata column common commonservice controller criteria current currentuserid currentuserrolename data db deatails details display displayastitle div dropdown false field fields filter filters function grid gridresultclick gridviewresult heading hideapproverstatus info init initialisation initially inputsearchclientdata islistview issearchvalid label langdroplist language languagelable languages list listviewheading listviewresult load loaded logged method number object onchange onselectbrands onselectclient onselectlangauge operation perform performing populate project projectlable projectresultclick projects property received redirect redirected reset resetbuttonlabel resetonchange responsible result return role row rowdata search search-controller-page search-controller-searchcontroller-page searchcontroller searchtermbranddata searchtermprojectdata searchtermservice searchtypelist searchvalidobj select selected set showbackbutton status statuslable stores string super table term title toggle togglesearchview translation translationstatuslist true type user userdetails validated validation variables view"
    },
    {
      "section": "api",
      "id": "Search.SearchTermService",
      "shortName": "Search.SearchTermService",
      "type": "service",
      "moduleName": "Search",
      "shortDescription": "This is service in Search module. It contains methods which are used for different operations done on search page.",
      "keywords": "$http angularjs api application applied array assigned brands client clients common commonservice current data details dropdown dropdowns filters function getsearchtermprepopulateddata grid initial inputsearchclientdata languages list load logged method methods module object operations project projects returns role saveblob search searchbrandsprojectlanguagepopulateddata searchbuttonmethod searchdetailsonprojectclick searched searchinputinfodetails searchprojectslanguagepopulateddata searchtermservice searchtranslationstatuspopulateddata searchtypepopulateddata selected service status term type types user userid userrolename values view"
    },
    {
      "section": "api",
      "id": "Translators",
      "shortName": "Translators",
      "type": "object",
      "moduleName": "Translators",
      "shortDescription": "This is Translators module, which contains TranslatorsController for translators menu to show all translator users in the application. ",
      "keywords": "$httpprovider $locationprovider $routeprovider angularjs api application common html menu module ngroute object translator translators translatorscontroller users"
    },
    {
      "section": "api",
      "id": "Translators.controller:TranslatorsController",
      "shortName": "TranslatorsController",
      "type": "controller",
      "moduleName": "Translators",
      "shortDescription": "This Controller is responsible for showing users on users page and all the operations done on users page.",
      "keywords": "$location $route $scope $timeout activatetranslator active add addeditnewexperiencerow addedittraslatortab addnewexperiencerow addnewtranslator angularjs api appropriate array assigned availableusernames boolean box btn button called change character check checked checkforduplicateusername checkisnativelanguage checkisnativelanguageforedit checkmaxlen class clicking clientroles clients common commonservice comparison confirmation confirmdeleteuserbutton controller copy create createnewtranslatoruser current currentemailid currentuserid default delete deleted deletenewexperiencerow deletenewexperiencerowforedit deletetranslator deselecting details div dropdown duplicate edit editformisrequired editing edittranslatorinfo email emailcopiedforcomparison emaild enabled enablednotificationnames existing experience false field filter form fornativelang function getuserdetails icon ids impersonate impersonation inactive init initialisation initially input inside isactive isinactive isrequired knp language languages left length list load loaded local loggin mandatoryvalidation max maximum method mydataclients names native newtranslator newusername notification notifications notificationtab number object oldfirstnamelastname oldvalue open operations popup preview property pushing responsible return row select selected selecteditlangclick selectedlang selectedlanguageid selecting selection selectlang selectlangclick set settings showaddusertab showing shownotificationtab showstatuslanguagewisetranslatorlist showstatuswisetranslatorlist side sort status storage stores string tab textbox textboxes toggle trans translator translatordata translatordetails translatoreditinfo translatorimpersonateinfo translators translators-controller-page translators-controller-translatorscontroller-page translatorscontroller true unselecteditlangclick unselectedlang unselectlang unselectlangclick user userlanguages username users userstatus validate validation values variables view viewtranslatorinfo wise"
    },
    {
      "section": "api",
      "id": "Translators.TranslatorData",
      "shortName": "Translators.TranslatorData",
      "type": "service",
      "moduleName": "Translators",
      "shortDescription": "This is service in Translators module. It contains methods which are used for different operations done on translators page.",
      "keywords": "$http activate activatetranslatorinformation angularjs api authenticate boolean common commonservice currentuserid db delete deleted deletetranslatorinformation details displayed email emailid experience false function getadduseremialnotificationinfo gettranslatordata gettranslatorexperiencedata getuserauthenticateimpersonate impersonated impersonatetranslator impersonation info list logged method methods module newly notification notifications object operation operations performed returns role roleid save savetranslatorinformation selected seleted service settings successful table translator translatordata translatordetails translatoreditinfo translatorimpersonateinfo translators true updated updatetranslatorinformation user userid userlist username users"
    },
    {
      "section": "api",
      "id": "Users",
      "shortName": "Users",
      "type": "object",
      "moduleName": "Users",
      "shortDescription": "This is Users module, which contains usersController for users menu to show all users in the application",
      "keywords": "$httpprovider $locationprovider $routeprovider angularjs api application common html menu module ngroute object users userscontroller"
    },
    {
      "section": "api",
      "id": "Users.controller:UsersController",
      "shortName": "UsersController",
      "type": "controller",
      "moduleName": "Users",
      "shortDescription": "This Controller is responsible for showing users on users page and all the operations done on users page.",
      "keywords": "$location $route $scope $timeout activateuser active add addeditusertab admin angularjs api appropriate approver array assigned availableusernames boolean box button called change changeotherlanguagesaspernativelanguage changeuserrole character check checkforduplicateusername checkisnativelanguage checkisnativelanguageforedit checkmaxlen class clicking client clientroles clients column common commonservice comparison confirmation confirmdeleteuserbutton controller copy create createnewuser current currentuseremailid currentuserid default delete deleteuser deselecting details disable disablesavebtn disableupdatebtn div dropdown duplicate edit editformisrequired editing editorial edituser email emailcopiedforcomparison enabled enablednotificationadmin enablednotificationapprover enablednotificationclientadmin enablednotificationclientuser enablednotificationeditorial enablednotificationsuperadmin existing false field fields filter form fornativelang function functionality getuserdetails icon ids impersonate impersonation inactive init initialisation initially input inside isactive isinactive isrequired keyname knp language languages left length list listofprojects load loaded local logged mandatoryvalidation mandatoryvalidationforedituser mandatoryvalidationonchange max maximum method model mydata mydataclients mydataprojects native newly newusername notification notifications notificationtab number object oldfirstnamelastname oldvalue open operations options passed popup preview projects property pushing respective responsible return role rolename roles save savenewadminandclientadmin savenewapproverclientuser select selected selecteditlangclick selectedlang selectedlanguageid selectedroleid selecting selection selectlang selectlangclick set settings showaddusertab showcommmonprojects showing shownotificationtab showrolewiseuserlist showstatuslanguagewiseuserlist showstatuswiseuserlist side sort sorted staff status storage stores string super tab textbox textboxes toggle true unselecteditlangclick unselectedlang unselectlang unselectlangclick update updateadminandclientadmininfo updateapproverclientuserinfo user usereditinfo userimpersonateinfo userlanguages userlist username users users-controller-page users-controller-userscontroller-page userscontroller userstatus usertype validate validation values variables wise"
    },
    {
      "section": "api",
      "id": "Users.UserAuthenticateService",
      "shortName": "Users.UserAuthenticateService",
      "type": "service",
      "moduleName": "Users",
      "shortDescription": "This is service in users module. It contains methods which are used to authenticate user while logging in to system. ",
      "keywords": "$http accepts angularjs api authenticate authenticated check checks database doesn email entered field forgot function getuserauthenticate input link logging login method methods module pass password popup reset return send sendforgotpasswordemail service system user userauthenticateservice useremailid username users"
    },
    {
      "section": "api",
      "id": "Users.UserAuthorizationService",
      "shortName": "Users.UserAuthorizationService",
      "type": "service",
      "moduleName": "Users",
      "shortDescription": "This is service in users module. It contains methods which are used to authenticate user while logging in to system.",
      "keywords": "$http accepted accepts action admin angularjs api authenticate called common commonservice conditions database depending details entered false field flag function getuserauthorization input logging login method methods module object properties returns role service set super system terms true updateusertermaccepted user userauthentication userauthorizationservice userid username users"
    },
    {
      "section": "api",
      "id": "Users.UserList",
      "shortName": "Users.UserList",
      "type": "service",
      "moduleName": "Users",
      "shortDescription": "This is service in Users module. It contains methods which are used for different operations done on users page.",
      "keywords": "$http access accessallclients activate activateuserinformation admin angularjs api array assigned authenticate boolean client clientidlist clients common commonservice create current currentuserid data delete deleted deleteuserinformation details displayed edit edited edituserid email false function getadduseremialnotificationinfo getclientprojectstring getuserauthenticateimpersonate getusereditinfo getuserlist ids impersonated impersonateuser impersonation info infomartion initial isreadonly list logged method methods module newly notification notifications object operation operations project projectidlist projects read respective returns role roleid rolename save saveclientadmininformation saveclientuserinformation saveuserinformation selected seleted service set settings showcommonprojects successful table true update updateclientadmininformation updateclientuserinformation updated updateuserinformation user userdetails usereditinfo userid userimpersonateinfo userlist username userrolename users"
    },
    {
      "section": "api",
      "id": "ViewGlossary",
      "shortName": "ViewGlossary",
      "type": "object",
      "moduleName": "ViewGlossary",
      "shortDescription": "This is view glossary module, which will contain controller for view glossary. ",
      "keywords": "$locationprovider $routeprovider api controller glossary html module ngroute object view viewglossary"
    },
    {
      "section": "api",
      "id": "ViewGlossary.controller:ViewGlossaryController",
      "shortName": "ViewGlossaryController",
      "type": "controller",
      "moduleName": "ViewGlossary",
      "shortDescription": "This Controller is responsible for showing content on sent glossary page.",
      "keywords": "$http $location $rootscope $route $scope angularjs api array boolean called categories catsequence check class column columndefs configuration content controller create data defdata definitions details div email expiration expired facdata fails function glossary glossarydata glossarylocked glossarynggrid grid gridoptions hc_nopin hc_nopin_language hc_nopin_language_rtl hc_nopin_master_rtl hc_nopin_source header headervalue init initialisation languages left link list load locked master-language message method ng object objects paginate pagination property responsible return sections selected send sendfortoken set showing source store stores string structure template term time token tokenexpired translation user validate validation variables verify verifytoken viewglossary viewglossary-controller-page viewglossary-controller-viewglossarycontroller-page viewglossarycontroller viewlogin viewlogincred viewlogincredfail"
    }
  ],
  "apis": {
    "api": true
  },
  "__file": "_FAKE_DEST_/js/docs-setup.js",
  "__options": {
    "startPage": "/api",
    "scripts": [
      "js/angular.min.js",
      "js/angular-animate.min.js",
      "js/marked.js",
      "app.min.js"
    ],
    "styles": [],
    "title": "Glossary Manager Docs",
    "html5Mode": true,
    "editExample": true,
    "navTemplate": false,
    "navContent": "",
    "navTemplateData": {},
    "image": "img/home.png",
    "imageLink": "/",
    "titleLink": "/",
    "loadDefaults": {
      "angular": true,
      "angularAnimate": true,
      "marked": true
    }
  },
  "html5Mode": true,
  "editExample": true,
  "startPage": "/api",
  "scripts": [
    "js/angular.min.js",
    "js/angular-animate.min.js",
    "js/marked.js",
    "app.min.js"
  ]
};