var gulp = require('gulp')
var gulpDocs = require('gulp-ngdocs');
var connect = require('gulp-connect');
gulp.task('ngdocs', [], function () {
 
  var options = {
    scripts: ['../app.min.js'],
    html5Mode: true,
    startPage: '/api',
    title: "Glossary Manager Docs",
    image: "images/home.png",
    imageLink: "/",
    titleLink: "/"
  }
  connect.server({
    root: 'docs',
    livereload: false,
    fallback: 'docs/index.html',
    port: 8083
  });
  return gulp.src('src/scriptFiles/*.js')
    .pipe(gulpDocs.process(options))
    .pipe(gulp.dest('docs'));
});