export interface Tournament {
    tid:number;
    tname:String;
}