import { Component, OnInit } from '@angular/core';
import {Tournament} from './tournament.modal';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  tournamentList:Array<Tournament>;
  constructor() { }

  ngOnInit() {
    this.tournamentList = [
      {
        tid:1,
        tname:'T1'
      }
    ]
  }

}
