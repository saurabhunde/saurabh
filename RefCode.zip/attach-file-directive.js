/**
* @ngdoc directive
* @name common.directive:attachFiles
* @restrict 'A'
* @element input
* @scope
* @description 
* This is custom directive used on file upload. This is used to get dile data(name,size,type)
**/
Common.directive('attachFiles', ['$rootScope', function ($rootScope) {
    return {
        scope: {
            fileid: '='
        },
        link: function (scope, element, attrs) {
            element.on("click", function () {
                this.value = null;
            });
            

            element.on('change', function (evt) {
                   var fileData = '';
                   scope.audioDetailsObj = [];
                   var reader = new FileReader();
                   reader.readAsDataURL(evt.target.files[0]);
                   
                   reader.onload = function () {
                       fileData = reader.result;
                       scope.audioDetailsObj[0] = {
                           filename: evt.target.files[0].name,
                           filesize: evt.target.files[0].size,
                           filetype: evt.target.files[0].type,
                           filedata: fileData.split(',')[1]
                       };
                       $rootScope.$broadcast('addedFileDetails', scope.audioDetailsObj, scope.fileid);
                   }; 
            });
        }
    }
}]);