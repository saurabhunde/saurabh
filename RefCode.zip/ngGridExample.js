Projects.controller('glossaryController', ['$scope', '$rootScope', '$http', '$location', 'Glossary', 'commonService', '$routeParams', 'ProjectIdService', 'saveBlob', '$compile', '$parse', 'LandingPageData', '$timeout', function ($scope, $rootScope, $http, $location, Glossary, commonService, $routeParams, ProjectIdService, saveBlob, $compile, $parse, LandingPageData, $timeout) {
    var hideCatCols = true;
    $scope.searchmode = true;
    $scope.cmntbtn = false; // add comment button enable disable variable
    $scope.isValidField = false;
    $scope.isValidExport = false;
    var filter = false;
    $scope.filterErrorMessage = 'Please Select Language';
    $scope.noData = false;
    $scope.glossaryEditMode = false;
    //To show - hide textarea
    $scope.NoApproveRejectLanguage = false;
    $scope.showTextArea = false;
    $scope.exoprtTabToggle = false;
    $scope.resultTable = false;
    $scope.defaultGlossarySectionType = true;
    $scope.ntlGlossarySectionType = false;
    $scope.searchResult = false;
    $scope.sectionListdrop = false;
    $scope.allexportlanguages = {};
    $scope.allexportlanguages.status = false;
    $scope.allSferaLangSelected = {};
    $scope.allSferaLangSelected.status = false;
    $scope.sferaEnglishOnly = false;
    $scope.exportGlossary = true;
    $scope.sendGlossarybtn = false;
    $scope.ValidationMsgSfera = "";
    $scope.isValidSferaExport = false;
    $scope.sfersExport = false;
    $scope.includeAll = {};
    $scope.includeAll.status = false
    $scope.approveOnly = {};
    $scope.approveOnly.status = false
    $scope.sferaExportPass = {};
    $scope.sferaExportPass.pass="";
    $scope.allExportxslsSectioncheck = {};
    $scope.allExportxslsSectioncheck.status = false;
    $scope.allExportxslslanguagecheck = {};
    $scope.allExportxslslanguagecheck.status = false;
    $scope.allexportsection = {};
    $scope.allexportsection.status = false;
    $scope.allCategories = {};
    $scope.allCategories.status = false;
    $scope.allLanguages = {};
    $scope.allLanguages.status = false;
    $scope.allglossaryLanguages = {};
    $scope.allglossaryLanguages.status = false;
    var isVisible = false;
    sessionStorage.setItem('isVisible', false);
    $scope.editcmnt = true;
    var emailRegex = new RegExp("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$");
    $rootScope.headerId = "";
    $rootScope.languageSelected = "";
    $scope.validationMsgSaveAsExcel = 'At least one category and one Language need to be selected';
    $scope.facdata = [];
    $scope.defdata = [];
    var Catsequence = [];
    $scope.searchResult = false;
    $scope.glossaryValuesUL = true;
    $scope.exportSend = {};
    $scope.glossaryPageOnly = true;
    var GlossaryCheck = {};
    $scope.hideGotoSourceSetup = true;
    $scope.exportPass = ''; //GLMGR-203
    $scope.onlyForTranslationTab = false; //GLMGR-1226
    //GLMGR-1239
    $scope.isCheckedEmptyInfoCols = false;
    $scope.hideEmptyAddInfoCOls = false;
    $scope.totalServerItems = 0;
    //GLMGR-1448
    var masterGlossaryId;
    var languageName;
    var projectLangId;
    $scope.allEmail = false;
    $scope.selfEmail = false;
    $scope.approverEmail = false;
    $scope.translatorEmail = false;
    $scope.projectOwnerEmail = false;
    $scope.checkboxValid = false;
    $scope.checkboxValidEdit = false;
    $scope.hideAddCmtbtn = false;
    $scope.englishOnlyChecked = false;
    var EditallEmail = false;
    var EditselfEmail = false;
    var EditapproverEmail = false;
    var EditTranslatorEmail = false;
    var EditprojectOwnerEmail = false;
    var previouscomment="";
    $scope.isEditCmt = true;
    var IsAllCategories, IsAllLanguages;

    //GLMGR-1597 
    var exportKNP = false;
    var IsTranslationNotes = false;

    //GLMGR-1598 
    $scope.isTranslationSourceRequired = false;
    $scope.transSourceDisabled = true;


    // header template for Translation Source GLMGR-1030
    var hc_nopin_source =
        "<div class=\"ngHeaderSortColumn {{col.headerClass}}\" ng-style=\"{'cursor': col.cursor}\" ng-class=\"{ 'ngSorted': !col.noSortVisible() }\">\r" +
        "\n" +
        " <div ng-click=\"col.sort($event)\" ng-class=\"'colt' + col.index\" class=\"ngHeaderText\">{{col.displayName}}</div>\r" +
        "\n" +
        " <div class=\"ngSortButtonDown\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonDown()\"></div>\r" +
        "\n" +
        " <div class=\"ngSortButtonUp\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonUp()\"></div>\r" +
        "\n" +
        " <div class=\"ngSortPriority\">{{col.sortPriority}}</div>\r" +
        "\n" +
        '<div class="lang-info-icon source-bulk-icon" ng-click="addBulkTranslationSource(col)" ></div>' +
        "\n" +
        "</div>\r" +
        "\n" +
        "<div ng-show=\"col.resizable\" class=\"ngHeaderGrip\" ng-click=\"col.gripClick($event)\" ng-mousedown=\"col.gripOnMouseDown($event)\"></div>\r" +
        "\n";

    //set hashURL for GLMGR-1189
    sessionStorage.setItem('hashURL', null);

    //ng-grid config-block
    $scope.gridOptions = {
        data: 'facdata',
        columnDefs: 'defdata',
        showColumnMenu: true,
        enableCellEdit: true,
        enableColumnResize: true,
        enableColumnReordering: false,
        enablePinning: true,
        enablePaging: true,
        enableSorting: true,
        noKeyboardNavigation: false,
        showFilter: true,
        showGroupPanel: false,
        groupable: false,
        rowHeight: 110,
        showFooter: false,
        multiSelect: false,
        keepLastSelected: false,
        totalServerItems: "totalServerItems"
    };
    //hide starred column
    $scope.isStarredChecked = function () {
        if ($scope.isStarred) {
            sessionStorage.setItem('hideStarredCol', $scope.isStarred);
            $scope.hideStarredCol = false;
            if (filter == true) {
                $scope.filterOptions();
            } else {
                $scope.facdata = [];
                $scope.defdata = [];
                GlossaryNgGrid($scope.glossaryData, $scope.headingsDropdown);
            }

        } else {
            sessionStorage.setItem('hideStarredCol', $scope.isStarred);
            $scope.hideStarredCol = true;
            if (filter == true) {
                $scope.filterOptions();
            } else {
                $scope.facdata = [];
                $scope.defdata = [];
                GlossaryNgGrid($scope.glossaryData, $scope.headingsDropdown);
            }
        }
    };

    //GLMGR-1598 hide translation source column
    $scope.hideTransSourceColumn = function () {
        if (filter == true) {
            $scope.filterOptions();
        } else {
            $scope.facdata = [];
            $scope.defdata = [];
            GlossaryNgGrid($scope.glossaryData, $scope.headingsDropdown);
        }
    };

    //popup of hide starred term
    $scope.hideStarredColumn = function () {
        if ($scope.isStarred && $scope.isHavingStarredTerm) {
            $('#hideStrredColModal').modal('show');
        }
        else {
            $scope.isStarredChecked();
        }
    };

    //GLMGR -1239
    //Hide Add info columns on checkbox
    $scope.hideAddInfoColumns = function () {
        hideCatCols = false;
        $scope.isCheckedEmptyInfoCols = true;
        $scope.hideEmptyAddInfoCOls = true;
        sessionStorage.setItem('hideAddInfoCols', $scope.hideAddInfoCOls);

        if (filter == true) {
            $scope.filterOptions();
        } else {
            $scope.facdata = [];
            $scope.defdata = [];
            GlossaryNgGrid($scope.glossaryData, $scope.headingsDropdown);
        }


    };

    //hide empty additional info columns
    $scope.hideEmptyColumns = function () {
        if (filter == true) {
            $scope.filterOptions();
        } else {
            $scope.facdata = [];
            $scope.defdata = [];
            GlossaryNgGrid($scope.glossaryData, $scope.headingsDropdown);
        }

    };

    $scope.defaultGlossarySection = function () {
        if ($scope.defaultGlossarySectionType === false) {
            //GLMGR-1239 reset hide add info cols when switching ntl<>default
            $scope.hideAddInfoCOls = false;
            $scope.isCheckedAddInfoCols = false;
            sessionStorage.setItem('hideAddInfoCols', $scope.hideAddInfoCOls);

            $scope.defaultGlossarySectionType = true;
            $scope.ntlGlossarySectionType = false;
            var temp = 'default';
            filter = false;
            sessionStorage.setItem('glossaryTab', JSON.stringify(temp));
            sessionStorage.setItem("filterStatus", "undefined");
            sessionStorage.setItem("filterImage", "undefined");
            sessionStorage.setItem("pendingTranslationsFilter", "0");
            sessionStorage.setItem("pendingApprovalsFilter", "0");
            sessionStorage.setItem("approvedFilter", "0");
            sessionStorage.setItem("rejectedFilter", "0");
            sessionStorage.setItem("pendingSuggFilter", "0");
            sessionStorage.setItem("filterOnStatus", "0");

            $('.filter-checkboxes').prop('checked', false);

            $('#filterOptionsButton').css("border-style", "none");
            $('#filterOptionsButton').css("border-color", "none");
            $('#filterOptionsButton').css("background-image", "url('../../../Content/Common/Assets/Images/export_n.png')");
            $('#filterOptionsButton').css("color", "white");
            $scope.headingsDropdown = undefined;
            sessionStorage.setItem('glossaryTab', JSON.stringify(temp));
            Glossary.getGlossaryInitialData($scope.projectId, commonService.getLocalData('userDetails').UserId, 1, glossaryInitialData);
        }

    };

    $scope.ntlGlossarySection = function () {
        if ($scope.ntlGlossarySectionType === false) {
            //GLMGR-1239 reset hide add info cols when switching ntl<>default
            $scope.hideAddInfoCOls = false;
            $scope.isCheckedAddInfoCols = false;
            sessionStorage.setItem('hideAddInfoCols', $scope.hideAddInfoCOls);


            $scope.defaultGlossarySectionType = false;
            $scope.ntlGlossarySectionType = true;
            var temp = 'ntl';
            filter = false;
            sessionStorage.setItem('glossaryTab', JSON.stringify(temp));
            sessionStorage.setItem("filterStatus", "undefined");
            sessionStorage.setItem("filterImage", "undefined");
            sessionStorage.setItem("pendingTranslationsFilter", "0");
            sessionStorage.setItem("pendingApprovalsFilter", "0");
            sessionStorage.setItem("approvedFilter", "0");
            sessionStorage.setItem("rejectedFilter", "0");
            sessionStorage.setItem("pendingSuggFilter", "0");
            sessionStorage.setItem("filterOnStatus", "0");

            $('.filter-checkboxes').prop('checked', false);

            $('#filterOptionsButton').css("border-style", "none");
            $('#filterOptionsButton').css("border-color", "none");
            $('#filterOptionsButton').css("background-image", "url('../../../Content/Common/Assets/Images/export_n.png')");
            $('#filterOptionsButton').css("color", "white");
            $scope.headingsDropdown = undefined;
            sessionStorage.setItem('glossaryTab', JSON.stringify(temp));
            Glossary.getGlossaryInitialData($scope.projectId, commonService.getLocalData('userDetails').UserId, 2, glossaryInitialData);
        }
    };

    //Saving new commnet functionality
    $scope.SaveComment = function () {
        $scope.cmntbtn = true;
        var commentTerm = {};
        if (!$scope.modal || !$scope.modal.comments) {
            alert("empty comments not allowed");
            $('#CommentPopup').modal('show');
            $scope.cmntbtn = false;
        } else {
            commentTerm['glossaryTranslationId'] = $scope.commentGlossaryTransalationId;
            commentTerm['CurrentUserId'] = commonService.getLocalData('userDetails').UserId;
            commentTerm['Comment'] = $scope.modal.comments;

            if ($scope.adminUser) {
                commentTerm['OriginalUserId'] = $scope.adminUser.UserId;
            } else {
                commentTerm['OriginalUserId'] = null;
            }

            Glossary.saveComment(commentTerm, function (data) {
                alert(data);
                $scope.editcmnt = true;
                $scope.modal.comments = null;
                $scope.cmntbtn = false;
                $('#CommentPopup').modal('hide');
            });

        }

    };

    //View and add comment popup functionality
    $scope.addComment = function (row) {
        $scope.allEmail = false;
        $scope.selfEmail = false;
        $scope.approverEmail = false;
        $scope.translatorEmail = false;
        $scope.projectOwnerEmail = false;

        EditallEmail = false;
        EditselfEmail = false;
        EditapproverEmail = false;
        EditTranslatorEmail = false;
        EditprojectOwnerEmail = false;

        $scope.checkboxValid = false;
        $scope.checkboxValidEdit = false;
        masterGlossaryId = row.MasterGlossaryId;
        languageName = row.LanguageName;
        projectLangId = row.ProjectLanguageId;
        if (row.GlossaryTranslationId == 0) {
            alert("Translation not yet started");
        } else {
            $scope.commentGlossaryTransalationId = row.GlossaryTranslationId;
            Glossary.addcmnt(row.GlossaryTranslationId, function (data) {
                $scope.commentData = data;
                $('#CommentPopup').modal('show');
            });

        }

    };

    //Download Attachment
    $scope.downloadAttachment = function (AttachmentId, Name, Type) {
        Glossary.getDownloadAttachment($scope.projectId, $scope.projectlangId, AttachmentId, function (data) { });
    };

    //Download All attachments
    $scope.downloadAttachmentAll = function (LanguageId, AttachmentId, Name, Type) {
        window.URL = window.URL || window.webkitURL;
        Glossary.getDownloadAttachmentAll($scope.projectId, LanguageId, AttachmentId, function (data) {
            $scope.attachment = data;
        });
    };

    /*  all glosaary logic start */
    //all glossary page popup
    var AllSection = function () {
        if (sessionStorage.getItem("filterOnStatus") === "1") {
            $scope.allglossaryRedirect();
        } else {
            if ($scope.GlossaryInitialTerms.ProjectLanguages.length > 1) {
                $('#allGlossary').modal('show');
            } else {
                var languages = [];
                for (var i = 0; i < $scope.GlossaryInitialTerms.ProjectLanguages.length; i++) {
                    languages.push($scope.GlossaryInitialTerms.ProjectLanguages[i].ProjectLanguageId);
                }
                sessionStorage.setItem('AllglossaryLangList', JSON.stringify(languages));
                $('.modal-backdrop.fade.in').css('display', 'none');
                $('#allGlossary').modal('hide');
                $scope.changeView('GlossaryAllsection');
            }
        }
    };

    $scope.allglossaryRedirect = function () {
        var languages = [];
        if (sessionStorage.getItem("filterOnStatus") !== "1") {
            $('.allglossaryLanguage:checked').each(function (id, value) {
                languages.push(this.value);
            });
        } else {
            languages.push($scope.FilterLang.ProjectLanguageId);
        }
        sessionStorage.setItem('AllglossaryLangList', JSON.stringify(languages));
        $('.modal-backdrop.fade.in').css('display', 'none');
        $('#allGlossary').modal('hide');
        $scope.changeView('GlossaryAllsection');
    };

    $scope.checkAllglossaryLanguageStatus = function () {
        var count = 0;
        $('.allglossaryLanguage:not(:checked)').each(function (id, value) {
            count++;

        });

        if (count > 0) {
            $scope.allglossaryLanguages.status = false;
        } else {
            $scope.allglossaryLanguages.status = true;
        }
    };

    $scope.allLanguagesglossary = function () {
        if ($scope.allglossaryLanguages.status == true) {
            $('.allglossaryLanguage:not(:checked)').each(function (id, value) {
                $(this).prop('checked', true);
            });
        } else {
            $('.allglossaryLanguage:checked').each(function (id, value) {
                $(this).prop('checked', false);
            });
        }
    };

    $scope.allglossaryCancel = function () {
        location.reload();
    };
    /* all glosaary logic end */

    //View language info
    $scope.langInfo = function (col) {
        $scope.langInfoId = 0;
        $scope.langInfoDetails = {};
        $scope.attachedFilesList = [];
        $scope.publisher = null;
        $scope.languageComments = null;
        for (var i = 0; i < $scope.GlossaryInitialTerms.ProjectLanguages.length; i++) {
            if (col.displayName == $scope.GlossaryInitialTerms.ProjectLanguages[i].LanguageName) {
                $scope.langInfoId = $scope.GlossaryInitialTerms.ProjectLanguages[i].ProjectLanguageInfoId;
                $scope.projectlangId = $scope.GlossaryInitialTerms.ProjectLanguages[i].ProjectLanguageId;
                $scope.langInfoLangId = $scope.GlossaryInitialTerms.ProjectLanguages[i].LanguageId;
            }
        }
        if ($scope.langInfoId != 0) {
            Glossary.getLangInfo($scope.langInfoId, function (langInfoDetails) {

                $scope.langInfoDetails = langInfoDetails;
                $scope.publisher = $scope.langInfoDetails.PublisherName;
                $scope.languageComments = $scope.langInfoDetails.Comments;

            });
        }
        $scope.langInfoTitle = col.displayName;
        $('#languageInfo').modal('show');

        //Show Attachments List of assigned languages of User Id
        LandingPageData.ShowAttachmentToInfo($scope.projectId, $scope.projectlangId, $scope.langInfoLangId, function (attachedFilesList) {
            $('#upload_prev').hide();
            $('#no_upload_prev').hide();
            $scope.attachedFilesList = attachedFilesList;
            if ($scope.attachedFilesList.length >= 1) {
                $('#upload_prev').show();
                $('#no_upload_prev').hide();
            } else {
                $('#upload_prev').hide();
                $('#no_upload_prev').show();
            }
        });

    };

    //Save language info
    $scope.saveLangInfo = function () {
        var saveLangModel = {};
        saveLangModel['ProjectLanguageId'] = $scope.projectlangId;
        saveLangModel['ProjectLanguageInfoId'] = $scope.langInfoId;
        saveLangModel['Comments'] = $scope.languageComments;
        saveLangModel['PublisherName'] = $scope.publisher;
        saveLangModel['CurrentUserId'] = commonService.getLocalData('userDetails').UserId;

        Glossary.saveLangInfo(saveLangModel, function (data) {
            $scope.langInfoDetails = {};
            $scope.publisher = null;
            $scope.languageComments = null;
            $scope.langInfoId = 0;
            $('#languageInfo').modal('hide');
            location.reload();
        });

    };

    $scope.searchInGlossaryTerm = function (glossarySearchCategory) {
        $scope.glossaryValuesUL = false;
        $('filter - checkboxes').each(function () {
            $(this).prop("checked", false);
            $(this).prop("disabled", false);
        });
        $scope.FilterLang = '';
        $scope.filterStatus = '';
        filter = false;
        $scope.searchmode = false;
        var pattern = /[0-9]/g;
        if (!$scope.glossarySearchText) {
            $scope.isValidField = true;
            $scope.errorMsg = 'Please enter the Search Text';
            return false;
        }
        if (!$scope.glossarySearchCategory) {
            $scope.isValidField = true;
            $scope.errorMsg = 'Please select the Search Category';
            return false;
        } else {
            if (glossarySearchCategory === "English Unique Id") {

                if (!pattern.test($scope.glossarySearchText)) {
                    $scope.isValidField = true;
                    $scope.errorMsg = 'Please enter a number as a unique id';
                    return false;
                }
            }
            $scope.isValidField = false;
            $scope.errorMsg = '';
            var ProjectGlossarySearchModel = {};
            ProjectGlossarySearchModel['ProjectId'] = $scope.projectId;
            ProjectGlossarySearchModel['userId'] = commonService.getLocalData('userDetails').UserId;
            ProjectGlossarySearchModel['headerId'] = 0;
            ProjectGlossarySearchModel['SearchCategory'] = $scope.glossarySearchCategory;
            ProjectGlossarySearchModel['SearchText'] = $scope.glossarySearchText;

            $('#searchPopup').modal('hide');
            $scope.showLoader = true;
            Glossary.searchTermInGlossary(ProjectGlossarySearchModel, function (searchList) {
                $scope.searchList = searchList;
                $scope.searchResult = true;
                $scope.resultTable = false;
                $scope.sectionListdrop = true;
                $scope.showLoader = false;
            });
        }
    };

    $(".glossary-search-input").keyup(function (e) {
        if (e.keyCode == 13) {
            $scope.searchInGlossaryTerm();
        }
    });

    $scope.clearSearch = function () {
        location.reload();
    };

    $scope.backToSearch = function () {
        $scope.searchmode = false;
        $scope.searchResult = true;
        $scope.resultTable = false;
    };

    // to toggle between 'send glossary' and 'export xsls' tabs in export gloassary modal popup
    $scope.exportGlossaryToggle = function (headingName) {
        switch (headingName) {
            case 'Xlxs':
                $scope.exportGlossary = true;
                $scope.sendGlossarybtn = false;
                $scope.sfersExport = false;
                    break;
            case 'Send':
                $scope.exportGlossary = false;
                $scope.sendGlossarybtn = true;
                $scope.sfersExport = false;
                break;
            case 'Sfera':
                $scope.exportGlossary = false;
                $scope.sendGlossarybtn = false;
                $scope.sfersExport = true;
                break;
        }
    };

    // send glossary functionality
    $scope.sendGlossary = function () {
        var data = {};
        data.ProjectId = $scope.projectId;
        data.ProjectName = $scope.GlossaryInitialTerms.ProjectTitle;

        var categories = [];
        $('.exportCategories:checked').each(function (id, value) {
            categories.push(this.value);

        });
        data.Sections = categories.join();

        var languages = [];
        $('.exportLanguages:checked').each(function (id, value) {
            languages.push(this.value);
        });

        data.Languages = languages.join();

        data.FirstName = $scope.exportSend.firstName;
        data.LastName = $scope.exportSend.lastName;
        data.GlossarySentBy = commonService.getLocalData('userDetails').UserId;
        data.EmailId = $scope.exportSend.email;
        data.ExpirationDateTime = $scope.exportSend.date;

        if ($scope.adminUser) {
            data['OriginalUserId'] = $scope.adminUser.UserId;
        } else {
            data['OriginalUserId'] = null;
        }

        if (!mandatoryValidation(data)) {
            return false;
        }
        Glossary.sendGlossaryService(data, function (statusData) {
            $scope.exportSend = {};
            $scope.validationMsg = "";
            $scope.isValidField = false;
            $scope.allexportsection.status = false;
            $scope.allexportlanguages.status = false;
            $('input:checkbox').each(function () {
                $(this).prop("checked", false);
                $(this).prop("disabled", false);
            });
            $('#exportSettings').modal('hide');
        });

    };

    $scope.exportKNPClicked = function () {
        if ($('#IsExportKNP').prop('checked')) {
            $('.Defchkbox').each(function () {
                $(this).prop("checked", false);
                $(this).prop("disabled", true);
            });
            $('#IsTranslationNotes').prop('checked', true);
        }else {
            $('.Defchkbox').each(function () {
                $(this).prop("checked", true);
                $(this).prop("disabled", false);
            });
            $('#IsTranslationNotes').prop('checked', false);
        }
    };

    $scope.exportModalShow = function () {
        $('#IsExportKNP').prop('checked', false);
        $('#IsTranslationNotes').prop('checked', false);
        $('#exportSettings').modal({ backdrop: 'static', keyboard: false });
        $('.Defchkbox').each(function () {
            $(this).prop("checked", true);
            $(this).prop("disabled", false);
        });
        $('#exportSettings').modal('show');
    };

    //Mandatory Validation
    var mandatoryValidation = function (data) {
        //Check for all mandatory fields
        if (!data.Sections && !data.EmailId && !data.Languages && !data.ExpirationDateTime) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please enter the mandatory fields!";
            return false;
        }
        if (!data.Sections && !data.EmailId) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please enter the mandatory fields!";
            return false;
        }
        if (!data.Languages && !data.EmailId) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please enter the mandatory fields!";
            return false;
        }
        if (data.Sections && !data.Languages) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please enter the mandatory fields!";
            return false;
        }
        if (!data.ExpirationDateTime && !data.Sections) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please enter the mandatory fields!";
            return false;
        }
        if (!data.ExpirationDateTime && !data.Languages) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please enter the mandatory fields!";
            return false;
        }
        if (!data.ExpirationDateTime && !data.EmailId) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please enter the mandatory fields!";
            return false;
        }
        //check for section
        if (!data.Sections) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please select atleast 1 section from the list below.";
            return false;
        }
        if (!data.Languages) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please select atleast 1 language from the list below.";
            return false;
        }
        if (!data.EmailId) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please enter the email id";
            return false;
        }
        if (!data.FirstName) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please enter the first name";
            return false;
        }
        if (!data.LastName) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please enter the last name";
            return false;
        }
        if (!data.ExpirationDateTime) {
            $scope.isValidField = true;
            $scope.validationMsg = "Please enter expiry date and time";
            return false;
        }
        if (data.EmailId) {
            if (!emailRegex.test(data.EmailId)) {
                $scope.isValidField = true;
                $scope.validationMsg = "Please enter a valid email address";
                return false;
            }

        }

        if (data.ExpirationDateTime) {
            var dte = new Date($scope.exportSend.date);
            if (new Date() > dte) {
                $scope.isValidField = true;
                $scope.validationMsg = "Please select date greater than the current date";
                return false;
            } else {
                $scope.isValidField = false;
                $scope.validationMsg = "";
                return true;
            }
        } else {
            $scope.isValidField = false;
            $scope.validationMsg = "";
            return true;
        }

    };

    /* Starts -- Functions for tabs in export glossary function . This is for clicking of checkboxes of languages and sections along with all buttons in language and section dropdown */
    $scope.allSferalanguages = function () {
        if ($scope.allSferaLangSelected.status == true) {
            $('.exportSferaLanguages:not(:checked)').each(function (id, value) {
                $(this).prop('checked', true);
            });
        } else {
            $('.exportSferaLanguages:checked').each(function (id, value) {
                $(this).prop('checked', false);
            });
        }

        if ($('.exportSferaLanguages:checked').length > 0) {
            $scope.OtherLangsClicked = true;
            $scope.sferaEnglishOnly = false;
            $scope.englishOnlyChecked = false;
            $('.englishOnly').prop('checked', false);
        } else {
            $scope.OtherLangsClicked = false;
        }
    };

    $scope.checkSferaLanguageStatus = function () {
        var count = 0;
        $('.exportSferaLanguages:not(:checked)').each(function (id, value) {
            count++;

        });

        if (count > 0) {
            $scope.allSferaLangSelected.status = false;
        } else {
            $scope.allSferaLangSelected.status = true;
        }

        if ($('.exportSferaLanguages:checked').length>0) {
            $scope.OtherLangsClicked = true;
            $scope.sferaEnglishOnly = false;
            $scope.englishOnlyChecked = false;
            $('.englishOnly').prop('checked',false);
        } else {
            $scope.OtherLangsClicked = false;
            $scope.englishOnlyChecked = false;
        }
    };

    $scope.sferaEnglishOnlyCheck = function (sferaEnglishOnly) {
        $scope.sferaEnglishOnly = sferaEnglishOnly;
        if (sferaEnglishOnly) {
            $scope.allSferaLangSelected.status = false;
            $scope.englishOnlyChecked = true;
            $scope.includeAll.status = false
            $scope.approveOnly.status = false;
            $('.includeAll .approveOnly').prop('checked', false);
            $('.exportSferaLanguages:checked').each(function (id, value) {
                $(this).prop('checked', false);
            });

        } else {
            $scope.englishOnlyChecked = false;
        }
    };

    $scope.trasnlationCheck = function (check) {
        if (check == 'includeAll') {
            if (!$scope.includeAll || $scope.includeAll.status) {
                $scope.includeAll.status = true;
            } else {
                $scope.includeAll.status = false;
            }
            $scope.approveOnly.status = false;
        } else {
            if (!$scope.approveOnly || $scope.approveOnly.status) {
                $scope.approveOnly.status = true;
            } else {
                $scope.approveOnly.status = false;
            }
            $scope.includeAll.status = false;
        }
    };

    $scope.allsendlanguages = function () {
        if ($scope.allexportlanguages.status == true) {
            $('.exportLanguages:not(:checked)').each(function (id, value) {
                $(this).prop('checked', true);
            });

        } else {
            $('.exportLanguages:checked').each(function (id, value) {
                $(this).prop('checked', false);
            });
        }

    };

    $scope.checkLanguageStatus = function () {
        var count = 0;
        $('.exportLanguages:not(:checked)').each(function (id, value) {
            count++;

        });

        if (count > 0) {
            $scope.allexportlanguages.status = false;
        } else {
            $scope.allexportlanguages.status = true;
        }
    };

    $scope.allsendsection = function () {
        if ($scope.allexportsection.status == true) {
            $('.exportCategories:not(:checked)').each(function (id, value) {
                $(this).prop('checked', true);
            });
        } else {
            $('.exportCategories:checked').each(function (id, value) {
                $(this).prop('checked', false);
            });
        }
    };

    $scope.checSectionStatus = function () {
        var count = 0;
        $('.exportCategories:not(:checked)').each(function (id, value) {
            count++;
        });

        if (count > 0) {
            $scope.allexportsection.status = false;
        } else {
            $scope.allexportsection.status = true;
        }
    };

    $scope.allExportxlslanguages = function () {
        if ($scope.allExportxslslanguagecheck.status == true) {
            $('.languages:not(:checked)').each(function (id, value) {
                $(this).prop('checked', true);
            });
        } else {
            $('.languages:checked').each(function (id, value) {
                $(this).prop('checked', false);
            });
        }
    };

    $scope.checExportLanguagesStatus = function () {
        var count = 0;
        $('.languages:not(:checked)').each(function (id, value) {
            count++;
        });

        if (count > 0) {
            $scope.allExportxslslanguagecheck.status = false;
        } else {
            $scope.allExportxslslanguagecheck.status = true;
        }
    };

    $scope.allExportxlsSection = function () {
        if ($scope.allExportxslsSectioncheck.status == true) {
            $('.categories:not(:checked)').each(function (id, value) {
                $(this).prop('checked', true);
            });
        } else {
            $('.categories:checked').each(function (id, value) {
                $(this).prop('checked', false);
            });
        }
    };

    $scope.checExportSectionStatus = function () {
        var count = 0;
        $('.categories:not(:checked)').each(function (id, value) {
            count++;
        });

        if (count > 0) {
            $scope.allExportxslsSectioncheck.status = false;
        } else {
            $scope.allExportxslsSectioncheck.status = true;
        }
    };

    /* Ends -- Functions for tabs in export glossary function . This is for clicking of checkboxes of languages and sections along with all buttons in language and section dropdown */

    // Cancel button in export button modal popup
    $scope.cancelExport = function () {
        $scope.exportSend = {};
        $scope.validationMsg = "";
        $scope.isValidField = false;
        $scope.allexportsection.status = false;
        $scope.allexportlanguages.status = false;
        $scope.isValidExport = false;
        $scope.allCategories.status = false;
        $scope.allLanguages.status = false;
        $('input:checkbox').each(function () {
            $(this).prop("checked", false);
            $(this).prop("disabled", false);
        });
        $('#exportSettings').modal('hide');
        $scope.exportPass = '';
        $(".exp-password").attr("type", "password");
        $(".exp-Sferapassword").attr("type", "password");
        $('#showHide').prop('checked', false);
        $('#showHideSfera').prop('checked', false);

    };

    //show-hide password GLMGR-203
    $("#showHide").click(function () {
        if ($(".exp-password").attr("type") == "password") {
            $(".exp-password").attr("type", "text");

        } else {
            $(".exp-password").attr("type", "password");
        }
    });
   
    //show hide password Sfera
    $scope.showPasswordSfera = function () {
        if ($(".exp-Sferapassword").attr("type") == "password") {
            $(".exp-Sferapassword").attr("type", "text");

        } else {
            $(".exp-Sferapassword").attr("type", "password");
        }
    };

    //sFeraValidation
    var sFeraValidation = function () {
        if ($('.allLanguage:checked').length === 0 && $('.englishOnly:checked').length === 0 && $('.exportSferaLanguages:checked').length === 0) {
            $scope.ValidationMsgSfera = "At least one Language need to be selected";
            $scope.isValidSferaExport = true;
            return false;
        } else if (!$scope.sferaEnglishOnly && !($scope.includeAll.status || $scope.approveOnly.status )) {
            $scope.ValidationMsgSfera = "Translations is required field";
            $scope.isValidSferaExport = true;
            return false
        } else if (!$scope.sferaExportPass.pass) {
            $scope.ValidationMsgSfera = "Password cannot be empty";
            $scope.isValidSferaExport = true;
            return false;
        } else {
            return true;
        }
    };

    //sfera export
    $scope.sferaExport = function () {
        if (sFeraValidation()) {
            $scope.showLoader = true;
            var status = {};
            var languages = [];
            $('.exportSferaLanguages:checked').each(function (id, value) {
                languages.push(this.value);
            });
            status['ProjectLanguageId'] = languages;
            status['ProjectId'] = $scope.projectId;
            status['UserId'] = commonService.getLocalData('userDetails').UserId;
            status['IsAllLanguages'] = $scope.allSferaLangSelected.status;
            if ($scope.allSferaLangSelected.status)
                status['IsOnlyEnglish'] = false;
            else
                status['IsOnlyEnglish'] = $scope.sferaEnglishOnly;

            status['password'] = $scope.sferaExportPass.pass;
            status['TranslationIncludeAll'] = $scope.includeAll.status;
            status['TranslationApprovedOnly'] = $scope.approveOnly.status;
            status['UserRoleName'] = commonService.getLocalData('userDetails').UserRoles[0].UserRoleName;

            console.log("status--", status);
           Glossary.exportSFeraKNP(status, function (data) {
               $scope.isValidSferaExport = false;
               $scope.ValidationMsgSfera = "";
               $('input:checkbox').each(function () {
                   $(this).prop("checked", false);
                   $(this).prop("disabled", false);
               });
               $scope.showLoader = false;
               $scope.sferaExportPass.pass = '';
               $(".exp-Sferapassword").attr("type", "password");
               $('#showHideSfera').prop('checked', false);
           });
           $('#exportSettings').modal('hide');
        }
    };

    // Export functionality in Export tab in export button
    $scope.exportData = function () {
        $scope.showLoader = true;
        $('#exportSettings').modal({ backdrop: 'static', keyboard: false });

        var status = {};
        $('.status:checked').each(function (id) {
            status[this.id] = true;

        });
        $('.status:not(:checked)').each(function (id, value) {
            status[this.id] = false;

        });

        var categories = [];
        $('.categories:checked').each(function (id, value) {
            categories.push(this.value);

        });
        var languages = [];
        $('.languages:checked').each(function (id, value) {
            languages.push(this.value);

        });
        status['ProjectCategoryId'] = categories;
        status['ProjectLanguageId'] = languages;
        status['ProjectId'] = $scope.projectId;
        status['UserId'] = commonService.getLocalData('userDetails').UserId;
        status['Password'] = $scope.exportPass;
       
        if ($('#IsExportKNP:checkbox:checked').length > 0) {
            exportKNP = true;
        } else {
            exportKNP = false;
        }
        if ($('#IsTranslationNotes:checkbox:checked').length > 0) {
            IsTranslationNotes = true;
        } else {
            IsTranslationNotes = false;
        }
        status['IsExoprtKNP'] = exportKNP;
        status['IsNotes'] = IsTranslationNotes;
        if ($scope.adminUser) {
            status['OriginalUserId'] = $scope.adminUser.UserId;
        } else {
            status['OriginalUserId'] = null;
        }
        //Mandatory validation
        if (IsAllCategories === false  || (IsAllLanguages === false || status.ProjectLanguageId.length == 0)) {
            $scope.isValidExport = true;
            $scope.showLoader = false;
            $scope.validationMsgSaveAsExcel = 'At least one Language need to be selected';
            return true;
        } else if (!$scope.exportPass || $scope.exportPass.length == 0) { //Export to excel password validation GLMGR-203
            $scope.isValidExport = true;
            $scope.showLoader = false;
            $scope.validationMsgSaveAsExcel = 'Password cannot be empty';
            return false;
        } else if ($scope.exportPass.length > 15 || $scope.exportPass.length < 3 || $scope.exportPass.indexOf(' ') >= 0) {
            $scope.isValidExport = true;
            $scope.showLoader = false;
            $scope.validationMsgSaveAsExcel = 'Password length should be minimum 3 and maximum 15 characters, no blank space allowed.';
            return false;
        } else {
            $scope.isValidExport = false;
            $scope.showLoader = true;
        }
        console.log("pe--", status);
        //glossary service for exporting data
        Glossary.postExportSettings(status, function (status) {
            $scope.isValidExport = false;
            $scope.allCategories.status = false;
            $scope.allLanguages.status = false;
            $('input:checkbox').each(function () {
                $(this).prop("checked", false);
                $(this).prop("disabled", false);
            });
            $scope.showLoader = false;
            $scope.exportPass = '';
            $(".exp-password").attr("type", "password");
            $('#showHide').prop('checked', false);
        });
        $('#exportSettings').modal('hide');

    };

    //function call on load of page
    /* Here many variables are set to local storage and also values retrived from local storage.*/
    var glossaryInitialData = function (glossaryInitialTerms) {
        $scope.noData = false;
        $scope.showLoader = true;

        if (glossaryInitialTerms == 'error') {
            $('#serverError').modal('show');
            $scope.showLoader = false;
        }

        sessionStorage.setItem('AllsectionProjectTitle', JSON.stringify(glossaryInitialTerms.ProjectTitle));
        sessionStorage.setItem('AllsectionSecureTitle', JSON.stringify(glossaryInitialTerms.SecureTitle));
        sessionStorage.setItem('AllsectionAllLanguages', JSON.stringify(glossaryInitialTerms.ProjectLanguages));
        if (commonService.getLocalData('userDetails').UserRoles[0].UserRoleName == 'Client User') {
            $scope.HasTranslationPrivilege = true;
        } else {
            $scope.HasTranslationPrivilege = glossaryInitialTerms.HasTranslationPrivilege;
        }

        //Date Time Picker for Send Glossary
        $('#datepicker1').datetimepicker();
        $('#datepicker1').datetimepicker('setEndDate', null);
        $("#exportSettings").scroll(function () {
            $('#datepicker1').datetimepicker('hide');
            $('#datepicker1').blur();
        });


        //hide Export Glossary button for Translator and Approver
        if ($scope.userDetails.UserRoles[0].UserRoleName === 'Translator' || $scope.userDetails.UserRoles[0].UserRoleName === 'Approver') {
            $scope.hideForTranslatorApprover = true;
        } else {
            $scope.hideForTranslatorApprover = false;
        }

        $scope.GlossaryInitialTerms = glossaryInitialTerms;


        //GLMGR 656
        if ($scope.userDetails.UserRoles[0].UserRoleName === 'Translator' || $scope.userDetails.UserRoles[0].UserRoleName === 'Approver' || $scope.userDetails.UserRoles[0].UserRoleName === 'Client User' || ($scope.userDetails.UserRoles[0].UserRoleName === 'Admin' && $scope.GlossaryInitialTerms.UserPermissionList.AddEditSourceSetup == false)) {
            $scope.hideGotoSourceSetup = true;
        } else {
            $scope.hideGotoSourceSetup = false;
        }

        sessionStorage.setItem("PageId", $scope.GlossaryInitialTerms.PageId);
        $scope.exportSections = [];
        angular.copy($scope.GlossaryInitialTerms.ProjectHeaders, $scope.exportSections);
        for (var i = 0; i < $scope.exportSections.length; i++) {
            if ($scope.exportSections[i].IsSecret == true) {
                $scope.exportSections.splice(i, 1);
                i--;
            }
        }
        /* Populating various scope varaibles for different tabs in glossary page ex- translation tab , approver tab according to permissions and user type*/
        $scope.IsLocked = glossaryInitialTerms.IsLocked;
        $scope.addTranslationlanguages = [];
        $scope.addApprovelanguages = [];
        $scope.FilterLanglist = [];
        $scope.FilterLanglist = $scope.GlossaryInitialTerms.ProjectLanguages;
        for (var j = 0; j < $scope.GlossaryInitialTerms.ProjectLanguages.length; j++) {
            if (commonService.getLocalData('userDetails').UserRoles[0].UserRoleName == 'Approver') {
                if ($scope.GlossaryInitialTerms.ProjectLanguages[j].WritePrivilege == true &&
                    $scope.GlossaryInitialTerms.ProjectLanguages[j].HasTranslationPrivilege == true) {
                    $scope.addTranslationlanguages.push($scope.GlossaryInitialTerms.ProjectLanguages[j]);
                }
                if ($scope.GlossaryInitialTerms.ProjectLanguages[j].HasApproveRejectPrivilege == true) {
                    $scope.addApprovelanguages.push($scope.GlossaryInitialTerms.ProjectLanguages[j]);
                }
            }
            else if (commonService.getLocalData('userDetails').UserRoles[0].UserRoleName == 'Translator')
            {
                if ($scope.GlossaryInitialTerms.ProjectLanguages[j].WritePrivilege == true &&
                                    $scope.GlossaryInitialTerms.ProjectLanguages[j].HasTranslationPrivilege == true) {
                    $scope.addTranslationlanguages.push($scope.GlossaryInitialTerms.ProjectLanguages[j]);
                }
                if ($scope.GlossaryInitialTerms.ProjectLanguages[j].HasApproveRejectPrivilege == true) {
                    $scope.addApprovelanguages.push($scope.GlossaryInitialTerms.ProjectLanguages[j]);
                }
            }
            else {
                $scope.addApprovelanguages.push($scope.GlossaryInitialTerms.ProjectLanguages[j]);
                if ($scope.GlossaryInitialTerms.ProjectLanguages[j].WritePrivilege == true) {
                    $scope.addTranslationlanguages.push($scope.GlossaryInitialTerms.ProjectLanguages[j]);
                }
            }

        }

        if ($scope.addApprovelanguages.length < 1) {
            $scope.NoApproveRejectLanguage = true;
        }

        if ($scope.GlossaryInitialTerms.ProjectHeaders.length > 0) {
            $scope.facdata = [];
            $scope.defdata = [];
            //checking for the redirect from search tab using 'Goto Glossary' button and setting variables(such as section id , section name  to be displayed on glossary) according to conditions
            if (commonService.getSessionData('searchTermGlossaryredirect') == true) {
                var flag = false;
                for (var i = 0; i < $scope.GlossaryInitialTerms.ProjectHeaders.length; i++) {
                    if ($scope.GlossaryInitialTerms.ProjectHeaders[i].Id == commonService.getSessionData('searchTermGlossaryredirectSectionID')) {
                        $scope.sectionId = $scope.GlossaryInitialTerms.ProjectHeaders[i].Id;
                        $scope.headingsDropdown = $scope.GlossaryInitialTerms.ProjectHeaders[i];
                        //setting the 'searchTermGlossaryredirect' to false as now it already redirected to glossary page
                        sessionStorage.setItem('searchTermGlossaryredirect', false);
                        sessionStorage.setItem('GlossarySection', JSON.stringify($scope.GlossaryInitialTerms.ProjectHeaders[i]));
                        flag = true;
                        break;
                    }

                }
                if (flag === false) {
                    $scope.headingsDropdown = $scope.GlossaryInitialTerms.ProjectHeaders[0];
                    $scope.sectionId = $scope.GlossaryInitialTerms.ProjectHeaders[0].Id;
                    sessionStorage.setItem('GlossarySection', JSON.stringify($scope.GlossaryInitialTerms.ProjectHeaders[0]));
                }
                // now checking whether any info regarding section opened previously in the glossary page or translation or approver page is present or not . this part of context saving on glossary page/translation page/approver page
            } else if (commonService.getSessionData('infoProjectRedirect') === true) {
                var flag = false;

                for (var i = 0; i < $scope.GlossaryInitialTerms.ProjectHeaders.length; i++) {
                    if ($scope.GlossaryInitialTerms.ProjectHeaders[i].Id == commonService.getSessionData('infoProjectRedirectSectionID')) {
                        $scope.sectionId = $scope.GlossaryInitialTerms.ProjectHeaders[i].Id;
                        $scope.headingsDropdown = $scope.GlossaryInitialTerms.ProjectHeaders[i];

                        //setting the 'searchTermGlossaryredirect' to false as now it already redirected to glossary page
                        sessionStorage.setItem('infoProjectRedirect', false);
                        sessionStorage.setItem('GlossarySection', JSON.stringify($scope.GlossaryInitialTerms.ProjectHeaders[i]));
                        flag = true;
                        break;
                    }

                }
                if (flag === false) {
                    $scope.headingsDropdown = $scope.GlossaryInitialTerms.ProjectHeaders[0];
                    $scope.sectionId = $scope.GlossaryInitialTerms.ProjectHeaders[0].Id;
                    sessionStorage.setItem('GlossarySection', JSON.stringify($scope.GlossaryInitialTerms.ProjectHeaders[0]));
                }
                // now checking whether any info regarding section opened previously in the glossary page or translation or approver page is present or not . this part of context saving on glossary page/translation page/approver page
            }

            else if (commonService.getSessionData('GlossarySection')) {
                $scope.headingsDropdown = commonService.getSessionData('GlossarySection');
                $scope.sectionId = $scope.headingsDropdown.Id;
                var flag = false;
                for (var k = 0; k < $scope.GlossaryInitialTerms.ProjectHeaders.length; k++) {
                    if ($scope.GlossaryInitialTerms.ProjectHeaders[k].Id == $scope.sectionId) {
                        flag = true;
                        break;
                    }
                }
                if (flag === false) {
                    $scope.headingsDropdown = $scope.GlossaryInitialTerms.ProjectHeaders[0];
                    $scope.sectionId = $scope.GlossaryInitialTerms.ProjectHeaders[0].Id;
                    sessionStorage.setItem('GlossarySection', JSON.stringify($scope.GlossaryInitialTerms.ProjectHeaders[0]));
                }

            } else {
                $scope.headingsDropdown = $scope.GlossaryInitialTerms.ProjectHeaders[0];
                $scope.sectionId = $scope.GlossaryInitialTerms.ProjectHeaders[0].Id;
                sessionStorage.setItem('GlossarySection', JSON.stringify($scope.GlossaryInitialTerms.ProjectHeaders[0]));
            }


            Glossary.getGlossaryData($scope.projectId, $scope.sectionId, commonService.getLocalData('userDetails').UserId, glossarySectionData);

            sessionStorage.setItem('headerId', JSON.stringify($scope.sectionId));
        } else {
            $scope.noData = true;
            $scope.showLoader = false;
            $('#noHeader').modal('show');
            $scope.facdata = [];
            $scope.defdata = [];
        }
        $scope.ObjectId1 = [];
        $scope.ClientName_str = '';
        for (var i = 0; i < $scope.GlossaryInitialTerms.ProjectClients.length; i++) {
            $scope.ObjectId1.push($scope.GlossaryInitialTerms.ProjectClients[i].ClientName);
            $scope.ClientName_str = $scope.ClientName_str + $scope.GlossaryInitialTerms.ProjectClients[i].ClientName + ', ';
        }
        $scope.ClientName_str = $scope.ClientName_str.slice(0, -2);
        sessionStorage.setItem('AllsectionClientName', JSON.stringify($scope.ClientName_str));
    };

    $scope.revertTranslationPopup = function (listMasterGlossary, row, selectedLanguage) {
        //object new
        $scope.revertTranslation = {};
        $scope.revertTranslation.LanguageTerm = row.TranslatedTerm;
        $scope.revertTranslation.TranslatorUserId = $scope.userId;;
        $scope.revertTranslation.MasterGlossaryId = listMasterGlossary.MasterGlossaryId;
        $scope.revertTranslation.ProjectLanguageId = selectedLanguage.ProjectLanguageId;
        $scope.revertTranslation.RowVersion = listMasterGlossary.ProjectLanguages[0].RowVersion;
        $scope.revertTranslation.IsRevertedText = true;
        $scope.revertTranslation.GlossaryTranslationId = row.GlossaryTranslationId;
        $scope.revertTranslation.IsTranslationTermUpdate = true;

        if ($scope.adminUser) {
            $scope.revertTranslation.OriginalUserId = $scope.adminUser.UserId;
        } else {
            $scope.revertTranslation.OriginalUserId = null;
        }

        $('#confirmRevertTranslation').modal({ backdrop: 'static', keyboard: false });
        $('#confirmRevertTranslation').modal('show');
    };

    $scope.updateTranslation = function () {
        Glossary.saveRevertedTranslation($scope.revertTranslation, function (status) {
        });
    };

    //call back function of getGlossaryData , used only in glossaryInitialData function
    var glossarySectionData = function (glossaryData) {
        if (glossaryData == 'error') {
            $('#serverError').modal('show');
            $scope.showLoader = false;
        }
        $scope.glossaryData = glossaryData;
        Catsequence = glossaryData.ProjectCategorySequence;
        //GLMGR-1239 if section having atleast one empty column then only check the hideEmptyCol checkbox
        for (var i = 0; i < $scope.glossaryData.SectionCategories.length; i++) {
            if ($scope.glossaryData.SectionCategories[i].IsCategoryEmpty === true) {
                $scope.isCheckedEmptyInfoCols = true;
                $scope.hideEmptyAddInfoCOls = true;
            }
        }

        //GLMGR-1239 check if section has atleast one starred term
        $scope.isHavingStarredTerm = false;
        for (var i = 0; i < glossaryData.MasterGlossaries.length; i++) {
            if (glossaryData.MasterGlossaries[i].IsStarred == true) {
                $scope.isHavingStarredTerm = true;
            }
        }
        if (!$scope.isHavingStarredTerm) {
            $scope.isStarred = true;
            $scope.hideStarredCol = false;
        }
        else {
            $scope.isStarred = false;
            $scope.hideStarredCol = true;
        }

        $scope.showLoader = false;

        //dynamicScreenHeight();
        $('section.container').css('height', window.innerHeight);
        $('.wide-screen-wrapper .ngViewport').css('height', window.innerHeight - 350);
        $('.wide-screen-wrapper .gridStyle').css('height', window.innerHeight - 290);



        $scope.sectionHeader = $scope.glossaryData.HeaderText;


        //$scope.paginate();

        //GLMGR-622 start


        $scope.pendingTranslationsFilterValue = sessionStorage.getItem("pendingTranslationsFilter");
        $scope.filterStatusValue = sessionStorage.getItem("filterStatus");
        $scope.pendingApprovalsFilterValue = sessionStorage.getItem("pendingApprovalsFilter");
        $scope.approvedFilterValue = sessionStorage.getItem("approvedFilter");
        $scope.rejectedFilterValue = sessionStorage.getItem("rejectedFilter");
        $scope.pendingSuggFilterValue = sessionStorage.getItem("pendingSuggFilter");

        if (sessionStorage.getItem("filterOnStatus") === "1") {
            var tempFilterLanguage = commonService.getSessionData('glossaryFilterLang');
            for (var i = 0; i < $scope.FilterLanglist.length; i++) {
                if ($scope.FilterLanglist[i].ProjectLanguageId === tempFilterLanguage.ProjectLanguageId) {
                    $scope.FilterLang = $scope.FilterLanglist[i];
                    break;
                }
            }
            if ($scope.filterStatusValue) {
                $scope.filterStatus = $scope.filterStatusValue;
            }
            if (sessionStorage.getItem("filterImage") !== 'undefined') {
                $scope.filterImage = sessionStorage.getItem("filterImage");
            }
            ($scope.pendingTranslationsFilterValue > 0) ? ($('#pendingTranslationsFilter').attr('checked', 'checked')) : ($('#pendingTranslationsFilter').attr('checked', false));
            ($scope.pendingApprovalsFilterValue > 0) ? ($('#pendingApprovalsFilter').attr('checked', 'checked')) : ($('#pendingApprovalsFilter').attr('checked', false));
            ($scope.approvedFilterValue > 0) ? ($('#approvedFilter').attr('checked', 'checked')) : ($('#approvedFilter').attr('checked', false));
            ($scope.rejectedFilterValue > 0) ? ($('#rejectedFilter').attr('checked', 'checked')) : ($('#rejectedFilter').attr('checked', false));
            ($scope.pendingSuggFilterValue > 0) ? ($('#pendingSuggFilter').attr('checked', 'checked')) : ($('#pendingSuggFilter').attr('checked', false));
            $scope.filterOptions();
        } else {
            GlossaryNgGrid(glossaryData, $scope.headingsDropdown);
        }
        //GLMGR-622 end

    };


    //chech for checkbox on comment popup
    $scope.isAtleastOneCheckboxChecked = function () {
        if ($('#commntCheckbox li input[type=checkbox]:checked').length > 0) {
            $scope.checkboxValid = false;
        }
        else {
            $scope.checkboxValid = true;
        }
    };

    //chech for checkbox on comment popup
    $scope.isAtleastOneCheckboxCheckedEdit = function () {
        if ($('#commntCheckboxEdit li input[type=checkbox]:checked').length > 0) {
            $scope.checkboxValidEdit = false;
        }
        else {
            $scope.checkboxValidEdit = true;
        }
    };

    /* Starts --- Logic for editing of previous comment of user under comment icon in ng-grid table. User can edit his own comment only*/
    $scope.editCmnt = function (cmnt, showtext) {
        if (cmnt.UserId == commonService.getLocalData('userDetails').UserId) {
            if ($scope.editcmnt == true) {
                $scope[showtext] = true;
                $scope.showtext = showtext;
                $scope.cmnt = cmnt;
                $scope.CommentId = $scope.cmnt.CommentId;
                $scope.editcmnt = false;
                $scope.textcmnt = $scope.cmnt.CommentText;
                EditallEmail = false;
                EditselfEmail = false;
                EditapproverEmail = false;
                EditTranslatorEmail = false;
                EditprojectOwnerEmail = false;
                $scope.previouscomment = $scope.cmnt.CommentText;
                $scope.previouscommentId = $scope.cmnt.CommentId;
                $('#commntCheckboxEdit').find('input:checkbox').prop('checked', false);
            } else {
                alert("Please save previous comment");
            }
        }

    };

    $scope.saveEditedCmnt = function (textcmnt, cmnt, showtext) {
       
            $scope.checkboxValidEdit = false;
            var data = {};
            data.UserId = $scope.cmnt.UserId;
            data.CommentId = $scope.CommentId;
            data.CommentText = textcmnt;
            data.Email = null;
            data.InsertedDate = null;

            if ($scope.adminUser) {
                data['OriginalUserId'] = $scope.adminUser.UserId;
            } else {
                data['OriginalUserId'] = null;
            }

            data['EncryptedProjectId'] = $scope.projectId;
            data['ProjectId'] = $scope.unEncryptedProjectId;
            data['UserName'] = commonService.getLocalData('userDetails').FirstName + " " + commonService.getLocalData('userDetails').LastName;
            data['MasterGlossaryId'] = masterGlossaryId;
            data['LanguageName'] = languageName;
            data['ProjectLanguageId'] = projectLangId;
            data['UserEmailId'] = commonService.getLocalData('userDetails').UserName;
            var checkboxes = $('#commntCheckboxEdit li input[type=checkbox]:checked');
            for (var i = 0; i < checkboxes.length; i++) {
                switch (checkboxes[i].value) {
                    case "self":
                        EditselfEmail = true;
                        break;
                    case "approver":
                        EditapproverEmail = true;
                        break;
                    case "translator":
                        EditTranslatorEmail = true;
                        break;
                    case "projectowner":
                        EditprojectOwnerEmail = true;
                        break;
                }
            }
                data['IsSelf'] = EditselfEmail;
                data['IsSendToApprover'] = EditapproverEmail;
                data['IsSendToTranslator'] = EditTranslatorEmail;
                data['IsSendToProjectOwner'] = EditprojectOwnerEmail;
            Glossary.saveEditedCmnt(data, function (data) {
                $scope.hideAddCmtbtn = false;
                $scope.showTextArea = false;
                $scope[showtext] = false;
                $scope.editcmnt = true;
            });
         
    };

    $scope.cancelComment = function () {
        $scope.editcmnt = true;
        $scope[$scope.showtext] = false;
        $scope.textcmnt = "";
        $scope.modal.comments = "";
    };
    
    //cancel edit cmt
    $scope.cancelEditCmt = function (showtext) {
        $('#' + $scope.previouscommentId).text($scope.previouscomment);
        $scope.hideAddCmtbtn = false;
        $scope.showTextArea = false;
        $scope[showtext] = false;
        $scope.editcmnt = true;
    };
    /* Ends --- Logic for editing of previous comment of user under comment icon in ng-grid table. User can edit his own comment only*/

    // to show star icon in 'S' column in the ng-grid
    $scope.checkIsStarred = function (row) {
        if (row.starred) {
            return true;
        } else {
            return false;
        }
    };
    /* Starts -- Starred term pop functionality , logic*/
    $scope.listStarredTerms = function (row, completeRow) {
        if (commonService.getLocalData('userDetails').UserRoles[0].UserRoleName === 'Editorial Staff') {
            return false;
        }
        if (!$scope.isStarred) {
            $scope.initialEnglishTerm = row.MasterText;
            $scope.termBrands = '';
            if (row.starred) {
                Glossary.getStarredItems(row.MasterGlossaryId, commonService.getLocalData('userDetails').UserId, function (starredTerms) {
                    $scope.StarredTerms = starredTerms.StarredNonStarredTermDetailsList[0]; // lang list

                    //set current lang as selected
                    if ($scope.FilterLang) {
                        $scope.StarredTermsByLangObject = $scope.StarredTerms.ProjectTranslationTermDetailsByLanguage[0].projectTranslationTermDetails;
                        $scope.lang = $scope.StarredTerms.AssignedLanguages[0];
                    } else {
                        for (var i = 0; i < $scope.StarredTerms.ProjectTranslationTermDetailsByLanguage.length; i++) {
                            if ($scope.FilterLang.LanguageId === $scope.StarredTerms.ProjectTranslationTermDetailsByLanguage[i].LanguageId) {
                                $scope.StarredTermsByLangObject = $scope.StarredTerms.ProjectTranslationTermDetailsByLanguage[i].projectTranslationTermDetails;
                                $scope.lang = $scope.StarredTerms.AssignedLanguages[i];
                            }
                        }
                    }

                    //Convert status to Approved, Rejected or Pending GLMGR-1127
                    for (var j = 0; j < $scope.StarredTermsByLangObject.length; j++) {
                        for (var i = 0; i < $scope.StarredTermsByLangObject[j].LanguageTermTranslationDetails.length; i++) {
                            if ($scope.StarredTermsByLangObject[j].LanguageTermTranslationDetails[i].TermStatus.includes("APPROVED")) {
                                $scope.StarredTermsByLangObject[j].LanguageTermTranslationDetails[i].TermStatus = 'Approved';
                            } else if ($scope.StarredTermsByLangObject[j].LanguageTermTranslationDetails[i].TermStatus.includes("REJECTED")) {
                                $scope.StarredTermsByLangObject[j].LanguageTermTranslationDetails[i].TermStatus = 'Rejected';
                            } else {
                                $scope.StarredTermsByLangObject[j].LanguageTermTranslationDetails[i].TermStatus = 'Pending';
                            }
                        }
                    }

                    //There is no translation available for this Starred Term
                    $scope.StarredTermIsDataAvailable = true;
                    for (var i = 0; i < $scope.StarredTermsByLangObject.length; i++) {
                        if ($scope.StarredTermsByLangObject[i].LanguageTermTranslationDetails.length > 0) {
                            $scope.StarredTermIsDataAvailable = false;
                        }
                    }

                    //get brands
                    $scope.StarredTermsBrands = starredTerms.StarredNonStarredTermDetailsList[0].CommonBrands;
                    for (var i = 0; i < $scope.StarredTermsBrands.length; i++) {
                        $scope.termBrands = $scope.termBrands + $scope.StarredTermsBrands[i].BrandName + ', ';
                    }
                    $scope.termBrands = $scope.termBrands.slice(0, -2);
                });
                $('#starredPopup').modal('show');
            } else {
                return false;
            }
        }
    };

    /*Starred term by language selection GLMGR-1101*/
    $scope.starredTermLanguage = function (index) {
        //change language
        for (var i = 0; i < $scope.StarredTerms.ProjectTranslationTermDetailsByLanguage.length; i++) {
            if (index.Id === $scope.StarredTerms.ProjectTranslationTermDetailsByLanguage[i].LanguageId) {
                $scope.StarredTermsByLangObject = $scope.StarredTerms.ProjectTranslationTermDetailsByLanguage[i].projectTranslationTermDetails;
                $scope.lang = $scope.StarredTerms.AssignedLanguages[i];
            }
        }

        //Convert status to Approved, Rejected or Pending GLMGR-1127
        for (var j = 0; j < $scope.StarredTermsByLangObject.length; j++) {
            for (var i = 0; i < $scope.StarredTermsByLangObject[j].LanguageTermTranslationDetails.length; i++) {
                if ($scope.StarredTermsByLangObject[j].LanguageTermTranslationDetails[i].TermStatus.includes("APPROVED")) {
                    $scope.StarredTermsByLangObject[j].LanguageTermTranslationDetails[i].TermStatus = 'Approved';
                } else if ($scope.StarredTermsByLangObject[j].LanguageTermTranslationDetails[i].TermStatus.includes("REJECTED")) {
                    $scope.StarredTermsByLangObject[j].LanguageTermTranslationDetails[i].TermStatus = 'Rejected';
                } else {
                    $scope.StarredTermsByLangObject[j].LanguageTermTranslationDetails[i].TermStatus = 'Pending';
                }
            }
        }

        //There is no translation available for this Starred Term
        $scope.StarredTermIsDataAvailable = true;
        for (var i = 0; i < $scope.StarredTermsByLangObject.length; i++) {
            if ($scope.StarredTermsByLangObject[i].LanguageTermTranslationDetails.length > 0) {
                $scope.StarredTermIsDataAvailable = false;
            }
        }
    };

    /* Ends -- Starred term pop functionality , logic*/

    //get master term suggestion history GLMGR-1153
    $scope.getTermSuggestions = function (row) {
        $scope.OriginalTerm = row.MasterText;
        Glossary.getTermSuggestions($scope.projectId, row.MasterGlossaryId, $scope.sectionId, commonService.getLocalData('userDetails').UserId, function (status) {
            $scope.suggestionsHistoryFilter = _.groupBy(status, 'IsApproveReject');
            $scope.suggestionsHistoryTrue = $scope.suggestionsHistoryFilter.true;
            $scope.suggestionsHistoryFalse = $scope.suggestionsHistoryFilter.false;
            $scope.ApproveRejectComment = '';
            $('#TermSuggestionsPopup').modal({ backdrop: 'static', keyboard: false });
            $('#TermSuggestionsPopup').modal('show');
            $scope.IsAccepted = true;
        });
    };

    $scope.showHideHistoryToggle = function (showHideHistory) {
        if (showHideHistory) {
            $scope.showHideHistory = false;
        } else {
            $scope.showHideHistory = true;
        }
    };

    //column defination object for categories(addl. info) columns in ng-grid
    var defObjForCat = function (str, catWidth, index, pin, celltemp, editTemp) {
        var staticName = 'cat';
        if ($scope.hideAddInfoCOls) {
            return {
                field: staticName.concat(str),
                displayName: $scope.catList[index].CategoryName,
                width: catWidth,
                pinned: false,
                cellTemplate: celltemp,
                editableCellTemplate: editTemp,
                visible: false
            };
        } else {
            return {
                field: staticName.concat(str),
                displayName: $scope.catList[index].CategoryName,
                width: catWidth,
                pinned: false,
                cellTemplate: celltemp,
                editableCellTemplate: editTemp,
                visible: true
            };
        }

    };

    //Translation Disabled in Glossary page GLMGR-1380
    $scope.translationDisabled = function (event) {
        if ($.inArray(event.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
            // Allow: Ctrl+A,Ctrl+C,Ctrl+V, Command+A
              ((event.keyCode == 65 || event.keyCode == 86 || event.keyCode == 67) && (event.ctrlKey === true || event.metaKey === true)) ||
            // Allow: home, end, left, right, down, up
              (event.keyCode >= 35 && event.keyCode <= 40)) {
            return;
        } else {
            if (!$scope.IsLocked && $scope.HasWritePrivilege && $scope.HasTranslationPrivilege) {
                $('#translationDisabledPopup').modal('show');
            }
        }
    };

    //GLMGR-1598 translation source on glossary page
    //View Translation Source popup: GLMGR-1598
    $scope.showTranslationSource = function (row) {
        if (row.IsTranslationSourceAdded === true) {
            $scope.MasterGlossaryIdtemp = row.MasterGlossaryId;
            $scope.onlyForTranslationTab = true;
            Glossary.GetTranslationSource($scope.projectId, row.MasterGlossaryId, row.ProjectLanguageId, commonService.getLocalData('userDetails').UserId, function (data) {
                $scope.TranslationSourceData = data;

                //create list objects for Translation Source Option
                $scope.TranslationSourceList = [
                  { "value": 0, "option": "--Select Source--" },
                  { "value": 1, "option": "The original book" },
                  { "value": 2, "option": "Client provided script" },
                  { "value": 3, "option": "Client provided website" },
                  { "value": 4, "option": "Public website" },
                  { "value": 5, "option": "Other" },
                  { "value": 6, "option": "I translated this myself" }
                ];

                //new entry or has history
                if ($scope.TranslationSourceData.GlossaryTranslationSource == null) {
                    $scope.TranslationSourceOption = $scope.TranslationSourceList[5];
                    $scope.SourceComment = '';
                } else {
                    $scope.currentTranslationSourceOption = $scope.TranslationSourceList[$scope.TranslationSourceData.GlossaryTranslationSource.TranslationSourceId];
                    $scope.currentSourceComment = $scope.TranslationSourceData.GlossaryTranslationSource.SourceComment;
                    $scope.TranslationSourceOption = $scope.currentTranslationSourceOption;
                    $scope.SourceComment = $scope.currentSourceComment;
                }
                $('#TranslationSourcePopupOnGlossaryPage').modal({ backdrop: 'static', keyboard: false });
                $('#TranslationSourcePopupOnGlossaryPage').modal('show');
            });
        } else {
            $('#trs').modal('show');
            return;
        }
    };
    //column defination object for Language(translation , version , comment ) columns in ng-grid
    var defObjForLang = function (i, hc_nopin_language, hc_nopin_language_rtl, hc_nopin) {
        var str2 = $scope.langList[i].ProjectLanguageId.toString();
        var staticLang = 'lang';

        //GLMGR-1598 Translation source template
        if ($scope.langList[i].IsTranslationSourceRequired === true) {
            $scope.transSourceDisabled = false;
            transSourceRequired = true;
            $scope.defdata.push({
                field: 'source' + staticLang.concat(str2),
                displayName: 'Trans Source',
                width: 140,
                pinned: false,
                disableColumnMenu: true,
                enableCellEdit: false,
                sortable: false,
                headerCellTemplate: hc_nopin_source,
                cellTemplate: '<div class="ngCellText" ng-click="showTranslationSource(row.getProperty(col.field))" ng-class="{\'source-icon-on\' : row.getProperty(col.field).IsTranslationSourceAdded == true, \'source-icon\' : row.getProperty(col.field).IsTranslationSourceAdded == false}" ng-cell-text></div>',
                visible: !$scope.isTranslationSourceRequired
            });
        }

        if ($scope.langList[i].IsRightToLeft == true) {
            $scope.defdata.push({
                field: staticLang.concat(str2),
                displayName: $scope.langList[i].LanguageName,
                width: 400,
                headerCellTemplate: hc_nopin_language_rtl,
                cellTemplate: '<div  class="ngCellText" ng-keypress="translationDisabled($event)" ng-cell-text>{{row.getProperty(col.field).term}}</div>',
                editableCellTemplate: '<textarea readonly ng-class="\'colt\' + col.index" style="min-width:400px; resize: none; height:70px;" ng-keypress="translationDisabled($event)" ng-model="row.getProperty(col.field).term" ng-input="row.getProperty(col.field).term" class="txtArea"/>',
                cellClass: 'langg'
            });
            $scope.defdata.push({
                field: 'Phonetic' + staticLang.concat(str2),
                displayName: 'Phonetic',
                width: 100,
                disableColumnMenu: true,
                sortable: false,
                headerCellTemplate: hc_nopin,
                cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field).term}}</div>',
                editableCellTemplate: '<textarea readonly ng-class="\'colt\' + col.index" style="min-width:100px; resize: none; height:70px;" ng-model="row.getProperty(col.field).term"  ng-input="row.getProperty(col.field).term" class="txtArea"/>',
                cellClass: 'langg'
            });
            $scope.defdata.push({
                field: 'Plural' + staticLang.concat(str2),
                displayName: 'Plural',
                width: 100,
                disableColumnMenu: true,
                sortable: false,
                headerCellTemplate: hc_nopin,
                cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field).term}}</div>',
                editableCellTemplate: '<textarea readonly ng-class="\'colt\' + col.index" style="min-width:100px; resize: none; height:70px;"  ng-model="row.getProperty(col.field).term" ng-input="row.getProperty(col.field).term" class="txtArea"/>',
                cellClass: 'langg'
            });

        } else {
            $scope.defdata.push({
                field: staticLang.concat(str2),
                displayName: $scope.langList[i].LanguageName,
                width: 400,
                headerCellTemplate: hc_nopin_language,
                cellTemplate: '<div  class="ngCellText" ng-keypress="translationDisabled($event)"   ng-cell-text>{{row.getProperty(col.field).term}}</div>',
                editableCellTemplate: '<textarea readonly ng-class="\'colt\' + col.index" style="min-width:400px; resize: none; height:70px;" ng-keypress="translationDisabled($event)" ng-model="row.getProperty(col.field).term" ng-input="row.getProperty(col.field).term" class="txtArea"/>'
            });
            $scope.defdata.push({
                field: 'Phonetic' + staticLang.concat(str2),
                displayName: 'Phonetic',
                width: 100,
                disableColumnMenu: true,
                sortable: false,
                headerCellTemplate: hc_nopin,
                cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field).term}}</div>',
                editableCellTemplate: '<textarea readonly ng-class="\'colt\' + col.index" style="min-width:100px; resize: none; height:70px;" ng-model="row.getProperty(col.field).term"  ng-input="row.getProperty(col.field).term" class="txtArea"/>'
            });
            $scope.defdata.push({
                field: 'Plural' + staticLang.concat(str2),
                displayName: 'Plural',
                width: 100,
                disableColumnMenu: true,
                sortable: false,
                headerCellTemplate: hc_nopin,
                cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field).term}}</div>',
                editableCellTemplate: '<textarea readonly ng-class="\'colt\' + col.index" style="min-width:100px; resize: none; height:70px;"  ng-model="row.getProperty(col.field).term" ng-input="row.getProperty(col.field).term" class="txtArea"/>'
            });

        }
        $scope.defdata.push({
            field: 'Ver' + staticLang.concat(str2),
            displayName: 'V',
            width: 40,
            disableColumnMenu: true,
            sortable: false,
            headerCellTemplate: hc_nopin,
            cellTemplate: '<div ng-class="{ CLIENT_APPROVED : row.getProperty(col.field).TermStatus == \'CLIENT_APPROVED\'&&!hideColors, APPROVER_APPROVED : row.getProperty(col.field).TermStatus == \'APPROVER_APPROVED\'&&!hideColors, TRANSLATION_COMPLETED : row.getProperty(col.field).TermStatus == \'TRANSLATION_COMPLETED\'&&!hideColors, CLIENT_REJECTED : row.getProperty(col.field).TermStatus == \'CLIENT_REJECTED\'&&!hideColors , APPROVER_REJECTED : row.getProperty(col.field).TermStatus == \'APPROVER_REJECTED\'&&!hideColors }"><div class="ngCellText" ng-hide="row.getProperty(col.field).IsVersionToHide">{{row.getProperty(col.field).Ver}}</div></div>'
        });
        $scope.defdata.push({
            field: 'Status' + staticLang.concat(str2),
            displayName: 'Approval Status',
            width: 120,
            disableColumnMenu: true,
            enableCellEdit: false,
            headerCellTemplate: hc_nopin,
            cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field).Status}}</div>'
        });
        $scope.defdata.push({
            field: 'comment' + staticLang.concat(str2),
            displayName: 'C',
            width: 25,
            pinned: false,
            headerCellTemplate: hc_nopin,
            enableCellEdit: false,
            sortable: false,
            cellTemplate: '<div class="ngCellText"  style=" padding-left:0px; width:25px; height:70px;" ng-click="addComment(row.getProperty(col.field))" ng-class="{\'bgcolor\' : row.getProperty(col.field).cmntcolor == true , \'comment-icon\' : row.getProperty(col.field).cmntcolor == false}" ng-cell-text></div>',
            cellClass: 'cellToolTip'
        });

    };

    // ng-grid data proccessing
    var GlossaryNgGrid = function (glossaryData, headerValue) {
        var uuid = 'a';
        console.log("gl=----", glossaryData.MasterGlossaries);
        $scope.catList = $scope.GlossaryInitialTerms.ProjectCategories;

        if (glossaryData.SectionCategories != null) {
            $scope.catList = glossaryData.SectionCategories; //[{ "CategoryId": 1, "ProjectId": null, "DbProjectId": 0, "ProjectCategoryId": 1677, "GlossaryCategoryId": 0, "MasterGlossaryId": 0, "CategoryName": "Annotations", "CategoryText": null, "UserId": 0, "GlossaryCategoryRowVersion": null, "SectionType": 1, "IsActive": true, "SectionCategoryActiveStatus": false, "IsSectionEmpty": false }, { "CategoryId": 2, "ProjectId": null, "DbProjectId": 0, "ProjectCategoryId": 1678, "GlossaryCategoryId": 0, "MasterGlossaryId": 0, "CategoryName": "Book / Chapter", "CategoryText": null, "UserId": 0, "GlossaryCategoryRowVersion": null, "SectionType": 1, "IsActive": true, "SectionCategoryActiveStatus": false, "IsSectionEmpty": true }, { "CategoryId": 268, "ProjectId": null, "DbProjectId": 0, "ProjectCategoryId": 1679, "GlossaryCategoryId": 0, "MasterGlossaryId": 0, "CategoryName": "11", "CategoryText": null, "UserId": 0, "GlossaryCategoryRowVersion": null, "SectionType": 1, "IsActive": true, "SectionCategoryActiveStatus": false, "IsSectionEmpty": false }]; 
        }

        /*Starts -- creating grid templates*/

        // header template for categories
        var hc_nopin = "<div class=\"ngHeaderSortColumn {{col.headerClass}}\" ng-style=\"{'cursor': col.cursor}\" ng-class=\"{ 'ngSorted': !col.noSortVisible() }\">\r" +
            "\n" +
            " <div ng-click=\"col.sort($event)\" ng-class=\"'colt' + col.index\" class=\"ngHeaderText\">{{col.displayName}}</div>\r" +
            "\n" +
            " <div class=\"ngSortButtonDown\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonDown()\"></div>\r" +
            "\n" +
            " <div class=\"ngSortButtonUp\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonUp()\"></div>\r" +
            "\n" +
            " <div class=\"ngSortPriority\">{{col.sortPriority}}</div>\r" +
            "\n" +
            "</div>\r" +
            "\n" +
            "<div ng-show=\"col.resizable\" class=\"ngHeaderGrip\" ng-click=\"col.gripClick($event)\" ng-mousedown=\"col.gripOnMouseDown($event)\"></div>\r" +
            "\n";

        // header template for Languages(left to right)
        var hc_nopin_language = "<div class=\"ngHeaderSortColumn {{col.headerClass}}\" ng-style=\"{'cursor': col.cursor}\" ng-class=\"{ 'ngSorted': !col.noSortVisible() }\">\r" +
            "\n" +
            " <div ng-click=\"col.sort($event)\" ng-class=\"'colt' + col.index\" class=\"ngHeaderText\">{{col.displayName}}</div>\r" +
            "\n" +
            " <div class=\"ngSortButtonDown\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonDown()\"></div>\r" +
            "\n" +
            " <div class=\"ngSortButtonUp\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonUp()\"></div>\r" +
            "\n" +
            " <div class=\"ngSortPriority\">{{col.sortPriority}}</div>\r" +
            "\n" +
            '<div class="lang-info-icon" ng-click="langInfo(col)" ></div>' +
            '</div>\r' +
            "</div>\r" +
            "\n" +
            "<div ng-show=\"col.resizable\" class=\"ngHeaderGrip\" ng-click=\"col.gripClick($event)\" ng-mousedown=\"col.gripOnMouseDown($event)\"></div>\r" +
            "\n";

        // header template for Languages(right to left)
        var hc_nopin_language_rtl = "<div class=\"ngHeaderSortColumn {{col.headerClass}}\" ng-style=\"{'cursor': col.cursor}\" ng-class=\"{ 'ngSorted': !col.noSortVisible() }\">\r" +
            "\n" +
            " <div ng-click=\"col.sort($event)\" ng-class=\"'colt' + col.index\" class=\"ngHeaderText-rtl\">{{col.displayName}}</div>\r" +
            "\n" +
            " <div class=\"ngSortButtonDown\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonDown()\"></div>\r" +
            "\n" +
            " <div class=\"ngSortButtonUp\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonUp()\"></div>\r" +
            "\n" +
            " <div class=\"ngSortPriority\">{{col.sortPriority}}</div>\r" +
            "\n" +
            '<div class="lang-info-icon-rtl" ng-click="langInfo(col)" ></div>' +
            '</div>\r' +
            "</div>\r" +
            "\n" +
            "<div ng-show=\"col.resizable\" class=\"ngHeaderGrip\" ng-click=\"col.gripClick($event)\" ng-mousedown=\"col.gripOnMouseDown($event)\"></div>\r" +
            "\n";

        // header template for master-language(source term)(right to left)
        var hc_nopin_master_rtl = "<div class=\"ngHeaderSortColumn {{col.headerClass}}\" ng-style=\"{'cursor': col.cursor}\" ng-class=\"{ 'ngSorted': !col.noSortVisible() }\">\r" +
            "\n" +
            " <div ng-click=\"col.sort($event)\" ng-class=\"'colt' + col.index\" class=\"ngHeaderText-rtl\">{{col.displayName}}</div>\r" +
            "\n" +
            " <div class=\"ngSortButtonDown\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonDown()\"></div>\r" +
            "\n" +
            " <div class=\"ngSortButtonUp\" ng-click=\"col.sort($event)\" ng-show=\"col.showSortButtonUp()\"></div>\r" +
            "\n" +
            " <div class=\"ngSortPriority\">{{col.sortPriority}}</div>\r" +
            "\n" +
            " <div ng-class=\"{ ngPinnedIcon: col.pinned, ngUnPinnedIcon: !col.pinned }\" ng-click=\"togglePin(col)\" ng-show=\"col.pinnable\"></div>\r" +
            "\n" +
            "</div>\r" +
            "\n" +
            "<div ng-show=\"col.resizable\" class=\"ngHeaderGrip\" ng-click=\"col.gripClick($event)\" ng-mousedown=\"col.gripOnMouseDown($event)\"></div>\r" +
            "\n";

        // cell template
        var celltemp = '<div class="ngCellText" tooltip={{row.getProperty(col.field).term}} ng-keypress="translationDisabled($event)" tooltip-placement="top" ng-cell-text>{{row.getProperty(col.field).term}}</div>';

        // editable English Description cell template -- used when user double clicks on cell in ng-grid and it becmes editable . Here it is disabled and only used to copy text 
        var editCellTempForEngDescript = '<textarea readonly ng-class="\'colt\' + col.index" style="min-width:400px; resize: none; height:110px;"  ng-model="row.getProperty(col.field).term" ng-input="row.getProperty(col.field).term" class="txtArea"/>';

        // editable other category cell template -- used when user double clicks on cell in ng-grid and it becmes editable . Here it is disabled and only used to copy text 
        var editCellTempForCat = '<textarea readonly ng-class="\'colt\' + col.index" style="min-width:150px; resize: none; height:110px;"  ng-model="row.getProperty(col.field).term" ng-input="row.getProperty(col.field).term" class="txtArea"/>';

        /*Ends -- creating grid templates*/

        var staticName = 'cat';

        var countCat = 0;

        $scope.preSettings = commonService.getSessionData('gridContextInstance');

        //column defn for categories.
        if (Catsequence) {

            for (var j = 0; j < Catsequence.length; j++) {
                for (var i = 0; i < $scope.catList.length; i++) {

                    if (Catsequence[j] == $scope.catList[i].ProjectCategoryId) {
                        //check if hide empty add info checkbox is checked
                        if ($scope.hideEmptyAddInfoCOls) {
                            if ($scope.catList[i].IsCategoryEmpty) {
                                continue;
                            }
                        }
                        var str = $scope.catList[i].ProjectCategoryId.toString();
                        countCat = countCat + 1;

                        //Checking condition so that  first 5 categories pinning can be set true.
                        if (countCat < 5) {

                            /*checking whether category(Addl Info) column is 'English Description' or not . If it then set its width to 400 . 
                            Other categories are set to 150 only.
                            Also 'English Description' column is set to 400 only when it is one of the first 5 categories in category sequence otherwise set to normal 150 */

                            if ($scope.catList[i].CategoryName == 'English Description') {
                                if (commonService.getSessionData('gridContextInstance') != null) {
                                    if (commonService.getSessionData('gridContextSaved') == true && commonService.getSessionData('gridContextInstance').length > 0 && hideCatCols) {
                                        var catflag = false;
                                        for (var f = 0; f < $scope.preSettings.length; f++) {
                                            if ($scope.preSettings[f].field == staticName.concat(str)) {
                                                $scope.defdata.push($scope.preSettings[f]);
                                                catflag = true;
                                                break;
                                            }
                                        }

                                        if (catflag == false) {
                                            $scope.defdata.push(defObjForCat(str, 400, i, true, celltemp, editCellTempForEngDescript));
                                        }

                                    } else {
                                        $scope.defdata.push(defObjForCat(str, 400, i, true, celltemp, editCellTempForEngDescript));
                                    }
                                } else {
                                    $scope.defdata.push(defObjForCat(str, 400, i, true, celltemp, editCellTempForEngDescript));
                                }
                            } else {
                                if (commonService.getSessionData('gridContextInstance') != null) {
                                    if (commonService.getSessionData('gridContextSaved') == true && commonService.getSessionData('gridContextInstance').length > 0 && hideCatCols) {
                                        var catflag = false;
                                        for (var f = 0; f < $scope.preSettings.length; f++) {
                                            if ($scope.preSettings[f].field == staticName.concat(str)) {
                                                $scope.defdata.push($scope.preSettings[f]);
                                                catflag = true;
                                                break;
                                            }
                                        }

                                        if (catflag == false) {
                                            $scope.defdata.push(defObjForCat(str, 150, i, true, celltemp, editCellTempForCat));

                                        }
                                    } else {
                                        $scope.defdata.push(defObjForCat(str, 150, i, true, celltemp, editCellTempForCat));

                                    }
                                } else {
                                    $scope.defdata.push(defObjForCat(str, 150, i, true, celltemp, editCellTempForCat));
                                }
                            }
                        } else {
                            if (commonService.getSessionData('gridContextInstance') != null) {
                                if (commonService.getSessionData('gridContextSaved') == true && commonService.getSessionData('gridContextInstance').length > 0 && hideCatCols) {
                                    var catflag = false;
                                    for (var f = 0; f < $scope.preSettings.length; f++) {
                                        if ($scope.preSettings[f].field == staticName.concat(str)) {
                                            $scope.defdata.push($scope.preSettings[f]);
                                            catflag = true;
                                            break;
                                        }
                                    }
                                    if (catflag == false) {
                                        $scope.defdata.push(defObjForCat(str, 150, i, false, celltemp, editCellTempForCat));
                                    }
                                } else {
                                    $scope.defdata.push(defObjForCat(str, 150, i, false, celltemp, editCellTempForCat));
                                }
                            } else {
                                $scope.defdata.push(defObjForCat(str, 150, i, false, celltemp, editCellTempForCat));
                            }


                        }
                    }

                }
            }
        }

        var masterLangfield = $scope.GlossaryInitialTerms.MasterLanguage.MasterLanguageName;
        masterLangfield = masterLangfield.replace(/ +/g, "");
        masterLangfield = masterLangfield.replace(/\//g, '');

        // master-lang column defination according to conditions (RTL or not)
        if ($scope.GlossaryInitialTerms.MasterLanguage.IsRLT === true) {
            $scope.defdata.push({
                field: masterLangfield,
                displayName: $scope.GlossaryInitialTerms.MasterLanguage.MasterLanguageName,
                width: 300,
                pinned: false,
                enableCellEdit: true,
                headerCellTemplate: hc_nopin_master_rtl,
                cellTemplate: '<div class="ngCellText pull-left width100per"> <div class="pull-left termImgDiv" ng-hide="row.getProperty(col.field).MasterImageUrl == null || isTermImageOn"> <img src="{{row.getProperty(col.field).MasterImageUrl}}" class="termImg"/> </div> <div class="pull-right ngCellText ngCellTextMasterTerm" tooltip={{row.getProperty(col.field).term}}  tooltip-placement="top" ng-cell-text>{{row.getProperty(col.field).term}}<br><br><span style="color:lime;" title="{{row.getProperty(col.field).brandlist}}">{{row.getProperty(col.field).brandcount}}</span></div></div>',
                cellClass: 'cellToolTip',
                editableCellTemplate: '<textarea readonly ng-class="\'colt\' + col.index" style="min-width:200px; resize: none; height:110px;"  ng-model="row.getProperty(col.field).term" ng-input="row.getProperty(col.field).term" class="txtArea"/>',
                cellClass: 'langg'
            });

        } else {
            $scope.defdata.push({
                field: masterLangfield,
                displayName: $scope.GlossaryInitialTerms.MasterLanguage.MasterLanguageName,
                width: 300,
                pinned: false,
                enableCellEdit: true,
                enableColumnResize: false,
                cellTemplate: '<div class="ngCellText pull-left width100per"><div class="pull-left ngCellText ngCellTextMasterTerm" tooltip={{row.getProperty(col.field).term}}  tooltip-placement="top" ng-cell-text>{{row.getProperty(col.field).term}}<br><br><span style="color:lime;" title="{{row.getProperty(col.field).brandlist}}">{{row.getProperty(col.field).brandcount}}</span></div><div class="pull-right termImgDiv" ng-hide="row.getProperty(col.field).MasterImageUrl == null || isTermImageOn"><img src="{{row.getProperty(col.field).MasterImageUrl}}" class="termImg"/> </div></div>',
                cellClass: 'cellToolTip',
                editableCellTemplate: '<textarea readonly ng-class="\'colt\' + col.index" style="min-width:200px; resize: none; height:110px;"  ng-model="row.getProperty(col.field).term" ng-input="row.getProperty(col.field).term" class="txtArea"/>'
            });
        }

        // English Id column defination 
        $scope.defdata.push({
            field: uuid,
            displayName: 'Unique Id',
            width: 150,
            pinned: false,
            enableCellEdit: true,
            cellTemplate: '<div class="ngCellText" tooltip={{row.getProperty(col.field).term}}  tooltip-placement="top" ng-cell-text>{{row.getProperty(col.field).term}}<span ng-click="getTermSuggestions(row.getProperty(col.field))" ng-class="{\'suggestion-on\':row.getProperty(col.field).IsSuggestionExist, \'suggestion-off\': !row.getProperty(col.field).IsSuggestionExist, \'suggestion-null\':row.getProperty(col.field).IsSuggestionExist === null}"></span></div>',
            cellClass: 'cellToolTip',
            editableCellTemplate: '<textarea readonly ng-class="\'colt\' + col.index" style="min-width:200px; resize: none; height:110px;"  ng-model="row.getProperty(col.field).term" ng-input="row.getProperty(col.field).term" class="txtArea"/>'
        });

        // Brand column defination 
        $scope.defdata.push({
            field: "brand",
            displayName: 'Brand',
            width: 150,
            pinned: false,
            enableCellEdit: true,
            visible: false,
            cellTemplate: '<div class="ngCellText" tooltip={{row.getProperty(col.field).term}}  tooltip-placement="top" ng-cell-text>{{row.getProperty(col.field).term}}</div>',
            cellClass: 'cellToolTip',
            editableCellTemplate: '<textarea readonly ng-class="\'colt\' + col.index" style="min-width:200px; resize: none; height:110px;"  ng-model="row.getProperty(col.field).term" ng-input="row.getProperty(col.field).term" class="txtArea"/>'
        });

        // Starred column defination 
        $scope.defdata.push({
            field: 'Starred',
            displayName: 'Starred',
            width: 60,
            pinned: false,
            headerCellTemplate: hc_nopin,
            cellTemplate: '<div class="ngCellText" ng-click="listStarredTerms(row.getProperty(col.field), row)" ng-class="{ \'starred-icon ngCellText\':  checkIsStarred(row.getProperty(col.field))}"  ng-cell-text></div>',
            visible: $scope.hideStarredCol
        });

        $scope.langList = $scope.GlossaryInitialTerms.ProjectLanguages;
        if (filter == true) {
            $scope.langList = [];
            $scope.langList.push($scope.FilterLang);
        }

        // language column defination for secret section under if block and normal section under else block
        if (headerValue.IsSecret == true) {
            for (var i = 0; i < $scope.langList.length; i++) {
                if ($scope.langList[i].SuperAccessPrivilege == true) {
                    defObjForLang(i, hc_nopin_language, hc_nopin_language_rtl, hc_nopin);
                }


            }


        } else {
            for (var i = 0; i < $scope.langList.length; i++) {

                defObjForLang(i, hc_nopin_language, hc_nopin_language_rtl, hc_nopin);

            }


        }



        /*Below logic -- data for columns according to colmn def. Here additional data might be stored inside the column which not shown on ng-grid .This is done to implement certain functionalities and also differntiate different rows 
        For example GlossaryTranslationId will be stored in coment column so that when comment icon is clicked we have the id to send it to backened for further communication*/
        for (var k = 0; k < glossaryData.MasterGlossaries.length; k++) {
            var gridRowDataObj = {};

            //data for Category columns according to colmn def. 
            for (var l = 0; l < glossaryData.MasterGlossaries[k].ProjectCategories.length; l++) {
                var catDataObj = {};
                catDataObj['term'] = glossaryData.MasterGlossaries[k].ProjectCategories[l].CategoryText;
                var str3 = glossaryData.MasterGlossaries[k].ProjectCategories[l].ProjectCategoryId.toString();
                gridRowDataObj[staticName.concat(str3)] = catDataObj;
            }

            //data for Starred column according to colmn def. 
            var starredDataObj = {};
            starredDataObj['MasterText'] = glossaryData.MasterGlossaries[k].MasterText;
            starredDataObj['MasterGlossaryId'] = glossaryData.MasterGlossaries[k].MasterGlossaryId;
            starredDataObj['starred'] = glossaryData.MasterGlossaries[k].IsStarred;

            gridRowDataObj['Starred'] = starredDataObj;
            var masterDataObj = {};
            var uuidDataObj = {};
            var brandobj = {};
            //data for Master-lang column according to colmn def. 
            masterDataObj['term'] = glossaryData.MasterGlossaries[k].MasterText;
            masterDataObj['MasterImageUrl'] = glossaryData.MasterGlossaries[k].MasterImageUrl;

            if (glossaryData.MasterGlossaries[k].BrandCount > 1) {
                masterDataObj['brandcount'] = glossaryData.MasterGlossaries[k].BrandCount.toString() + " brands";
            }

            var brandArray = [];
            var brandListV = 'This term is associated to these brands: \n ';
            if (glossaryData.MasterGlossaries[k].BrandCount > 0) {
                for (var i = 0; i < glossaryData.MasterGlossaries[k].GlossaryAddedBrands.length; i++) {
                    brandArray.push(glossaryData.MasterGlossaries[k].GlossaryAddedBrands[i].BrandName);
                    brandListV = brandListV + (glossaryData.MasterGlossaries[k].GlossaryAddedBrands[i].BrandName) + ' \n ';
                }
            }
            //data for brand column according to colmn def. 
            brandobj['term'] = brandArray.join();
            gridRowDataObj['brand'] = brandobj;

            masterDataObj['brandlist'] = brandListV;
            gridRowDataObj[masterLangfield] = masterDataObj;

            //data for English Id column according to colmn def. 
            uuidDataObj['term'] = glossaryData.MasterGlossaries[k].MasterGlossaryId;
            uuidDataObj['IsSuggestionExist'] = glossaryData.MasterGlossaries[k].IsSuggestionExist;
            uuidDataObj['MasterGlossaryId'] = glossaryData.MasterGlossaries[k].MasterGlossaryId;
            uuidDataObj['MasterText'] = glossaryData.MasterGlossaries[k].MasterText;
            gridRowDataObj[uuid] = uuidDataObj;

            $scope.masterText = glossaryData.MasterGlossaries[k].MasterText;
            $scope.masterText = $scope.masterText.replace(/ +/g, "");

            //data for language columns according to colmn def. Secret section language info in if-block and normal section language info in else block
            if (headerValue.IsSecret == true) {

                for (var m = 0; m < glossaryData.MasterGlossaries[k].ProjectLanguages.length; m++) {
                    if (glossaryData.MasterGlossaries[k].ProjectLanguages[m].SuperAccessPrivilege == true) {
                        var str4 = glossaryData.MasterGlossaries[k].ProjectLanguages[m].ProjectLanguageId.toString();
                        var staticlangString = 'lang';
                        var langTransDataObj = {};
                        var langVerDataObj = {};
                        var langCmntDataObj = {};
                        var langStatusDataObj = {};
                        var langPhoneticDataObj = {};
                        var langPluralDataObj = {};

                        langTransDataObj['term'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].TranslatedTerm;


                        langTransDataObj['TermStatus'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus;
                        langTransDataObj['ProjectLanguageId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].ProjectLanguageId;
                        langTransDataObj['MasterGlossaryId'] = glossaryData.MasterGlossaries[k].MasterGlossaryId;
                        langTransDataObj['GlossaryTranslationId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].GlossaryTranslationId;
                        langTransDataObj['edit'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].IsEditable;
                        gridRowDataObj[staticlangString.concat(str4)] = langTransDataObj;
                        if (glossaryData.MasterGlossaries[k].ProjectLanguages[m].PhoneticTerm != "") {
                            langPhoneticDataObj['term'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].PhoneticTerm;
                            gridRowDataObj['Phonetic' + staticlangString.concat(str4)] = langPhoneticDataObj;
                        }
                        if (glossaryData.MasterGlossaries[k].ProjectLanguages[m].PluralTerm != "") {
                            langPluralDataObj['term'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].PluralTerm;
                            gridRowDataObj['Plural' + staticlangString.concat(str4)] = langPluralDataObj;
                        }

                        langVerDataObj['TermStatus'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus;
                        langVerDataObj['Ver'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].Version;
                        langVerDataObj['IsVersionToHide'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].IsVersionToHide;
                        gridRowDataObj['Ver' + staticlangString.concat(str4)] = langVerDataObj;
                        if (glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'NOT_STARTED') {
                            langStatusDataObj['Status'] = 'N/A';
                            langStatusDataObj['term'] = 'N/A';
                        } else if (glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'APPROVER_APPROVED' || glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'CLIENT_APPROVED') {
                            langStatusDataObj['Status'] = 'Approved';
                            langStatusDataObj['term'] = 'Approved';
                        } else if (glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'APPROVER_REJECTED' || glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'CLIENT_REJECTED') {
                            langStatusDataObj['Status'] = 'Rejected';
                            langStatusDataObj['term'] = 'Rejected';
                        } else if (glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'TRANSLATION_COMPLETED') {
                            langStatusDataObj['Status'] = 'Pending';
                            langStatusDataObj['term'] = 'Pending';
                        } else if (glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'APPROVER_APPROVED_IN_PROGRESS' || glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'APPROVER_REJECTED_IN_PROGRESS' || glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'CLIENT_APPROVER_IN_PROGRESS' || glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'CLIENT_REJECTED_IN_PROGRESS') {
                            langStatusDataObj['Status'] = 'In Progress';
                            langStatusDataObj['term'] = 'In Progress';
                        }
                        gridRowDataObj['Status' + staticlangString.concat(str4)] = langStatusDataObj;
                        langCmntDataObj['GlossaryTranslationId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].GlossaryTranslationId;
                        langCmntDataObj['MasterGlossaryId'] = glossaryData.MasterGlossaries[k].MasterGlossaryId;
                        langCmntDataObj['MasterGlossaryId'] = glossaryData.MasterGlossaries[k].MasterGlossaryId;
                        langCmntDataObj['LanguageName'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].LanguageName;
                        langCmntDataObj['ProjectLanguageId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].ProjectLanguageId;
                        langCmntDataObj['cmntcolor'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].IsCommented;
                        gridRowDataObj['comment' + staticlangString.concat(str4)] = langCmntDataObj;
                    }



                }

            } else {
                for (var m = 0; m < glossaryData.MasterGlossaries[k].ProjectLanguages.length; m++) {
                    var str4 = glossaryData.MasterGlossaries[k].ProjectLanguages[m].ProjectLanguageId.toString();
                    var staticlangString = 'lang';
                    var langTransDataObj = {};
                    var langVerDataObj = {};
                    var langCmntDataObj = {};
                    var langStatusDataObj = {};
                    var langTrnSourceDataObj = {};

                    langTransDataObj['term'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].TranslatedTerm;

                    var langPhoneticDataObj = {};
                    var langPluralDataObj = {};

                    langTransDataObj['TermStatus'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus;
                    langTransDataObj['ProjectLanguageId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].ProjectLanguageId;
                    langTransDataObj['MasterGlossaryId'] = glossaryData.MasterGlossaries[k].MasterGlossaryId;
                    langTransDataObj['GlossaryTranslationId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].GlossaryTranslationId;
                    langTransDataObj['edit'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].IsEditable;
                    gridRowDataObj[staticlangString.concat(str4)] = langTransDataObj;

                    if (glossaryData.MasterGlossaries[k].ProjectLanguages[m].PhoneticTerm != "") {
                        langPhoneticDataObj['term'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].PhoneticTerm;
                        gridRowDataObj['Phonetic' + staticlangString.concat(str4)] = langPhoneticDataObj;
                    }
                    if (glossaryData.MasterGlossaries[k].ProjectLanguages[m].PluralTerm != "") {
                        langPluralDataObj['term'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].PluralTerm;
                        gridRowDataObj['Plural' + staticlangString.concat(str4)] = langPluralDataObj;
                    }

                    langVerDataObj['TermStatus'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus;
                    langVerDataObj['Ver'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].Version;
                    langVerDataObj['IsVersionToHide'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].IsVersionToHide;
                    gridRowDataObj['Ver' + staticlangString.concat(str4)] = langVerDataObj;

                    if (glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'NOT_STARTED') {
                        langStatusDataObj['Status'] = 'N/A';
                        langStatusDataObj['term'] = 'N/A';
                    } else if (glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'APPROVER_APPROVED' || glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'CLIENT_APPROVED') {
                        langStatusDataObj['Status'] = 'Approved';
                        langStatusDataObj['term'] = 'Approved';
                    } else if (glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'APPROVER_REJECTED' || glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'CLIENT_REJECTED') {
                        langStatusDataObj['Status'] = 'Rejected';
                        langStatusDataObj['term'] = 'Rejected';
                    } else if (glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'TRANSLATION_COMPLETED') {
                        langStatusDataObj['Status'] = 'Pending';
                        langStatusDataObj['term'] = 'Pending';
                    } else if (glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'APPROVER_APPROVED_IN_PROGRESS' || glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'APPROVER_REJECTED_IN_PROGRESS' || glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'CLIENT_APPROVER_IN_PROGRESS' || glossaryData.MasterGlossaries[k].ProjectLanguages[m].TermStatus === 'CLIENT_REJECTED_IN_PROGRESS') {
                        langStatusDataObj['Status'] = 'In Progress';
                        langStatusDataObj['term'] = 'In Progress';
                    }
                    gridRowDataObj['Status' + staticlangString.concat(str4)] = langStatusDataObj;
                    langCmntDataObj['GlossaryTranslationId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].GlossaryTranslationId;
                    langCmntDataObj['MasterGlossaryId'] = glossaryData.MasterGlossaries[k].MasterGlossaryId;
                    langCmntDataObj['LanguageName'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].LanguageName;
                    langCmntDataObj['ProjectLanguageId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].ProjectLanguageId;
                    langCmntDataObj['cmntcolor'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].IsCommented;
                    gridRowDataObj['comment' + staticlangString.concat(str4)] = langCmntDataObj;

                    //Translation Source GLMGR-1598
                    langTrnSourceDataObj['MasterGlossaryId'] = glossaryData.MasterGlossaries[k].MasterGlossaryId;
                    langTrnSourceDataObj['IsTranslationSourceAdded'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].IsTranslationSourceAdded;
                    langTrnSourceDataObj['IsTranslationSourceRequired'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].IsTranslationSourceRequired;
                    langTrnSourceDataObj['GlossaryTranslationId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].GlossaryTranslationId;
                    langTrnSourceDataObj['ProjectLanguageId'] = glossaryData.MasterGlossaries[k].ProjectLanguages[m].ProjectLanguageId;
                    gridRowDataObj['source' + staticlangString.concat(str4)] = langTrnSourceDataObj;
                }

            }

            $scope.facdata.push(gridRowDataObj);
        }



        if (isVisible == false) {
            $('.wide-screen-wrapper .ngViewport').css('height', window.innerHeight - 550);
            $('.wide-screen-wrapper .gridStyle').css('height', window.innerHeight - 515);
        } else {
            $('.wide-screen-wrapper .ngViewport').css('height', window.innerHeight - 220);
            $('.wide-screen-wrapper .gridStyle').css('height', window.innerHeight - 210);
        }

    };

    /* Status filter starts */
    //GLMGR-1227 Select all checkbox
    $scope.selectAllLangFilters = function () {
        if ($('#selectAll:checkbox:checked').length > 0) {
            $('#pendingTranslationsFilter').prop('checked', true);
            $('#pendingApprovalsFilter').prop('checked', true);
            $('#approvedFilter').prop('checked', true);
            $('#rejectedFilter').prop('checked', true);
        } else {
            $('#pendingTranslationsFilter').prop('checked', false);
            $('#pendingApprovalsFilter').prop('checked', false);
            $('#approvedFilter').prop('checked', false);
            $('#rejectedFilter').prop('checked', false);
        }
    };

    //Called when you filter the grid using filter-options button
    $scope.filterOptions = function () {
        $scope.showLoader = true;
        $scope.glossaryCopy = {};
        var count = 0;

        //empty language model to be pushed inside in case of pending translation
        var langModel = {
            GlossaryTranslationId: 0,
            IsEditable: true,
            LanguageId: 0,
            LanguageName: "",
            ProjectId: 0,
            PhoneticTerm: "",
            PluralTerm: "",
            IsCommented: false,
            ProjectLanguageId: 0,
            TermStatus: "",
            TranslatedTerm: "Translation Pending",
            Version: ""
        };
        //Making copy of glossay i.e. glossaryCopy
        angular.copy($scope.glossaryData, $scope.glossaryCopy);
        //emtying the language data from glossaryCopy
        for (var i = 0; i < $scope.glossaryCopy.MasterGlossaries.length; i++) {
            $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages = [];
        }

        //Calculating for no of filter checkboxes checked
        $('.filter-checkboxes:checked').each(function (id, value) {
            count++;

        });
        //checking whether language is selected or not . If-block contains language selected logic else-block throws an error message
        if ($scope.FilterLang) {
            $('#filterOption').modal('hide');
            // if  filter checkboxes are checked 
            if (count > 0) {
                $('#filterOptionsButton').css("border-style", "ridge");
                $('#filterOptionsButton').css("border-color", "red");

                $('#filterOptionsButton').css("background-image", "url('../../../Content/Common/Assets/Images/export_s.png')");
                $('#filterOptionsButton').css("color", "red");

                //flag to check if any language status filter is set
                var islangStatusSet = false;
                /*checking whether pending Translations checkbox is checked or not. If checked then applying the filter logic for that
                Backened Jason contain no language data for translations which are not started hence we push langModel for those terms
                but when there is no translation in the whole glossary section then they send language data with null values then we have push the language data sent by backened*/
                if ($('#pendingTranslationsFilter:checkbox:checked').length > 0) {
                    var islangStatusSet = true;
                    for (var i = 0; i < $scope.glossaryData.MasterGlossaries.length; i++) {
                        var flag = false;
                        for (var k = 0; k < $scope.glossaryData.MasterGlossaries[i].ProjectLanguages.length; k++) {
                            if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].ProjectLanguageId == $scope.FilterLang.ProjectLanguageId) {
                                if ($('#pendingSuggFilter:checkbox:checked').length > 0) {
                                    if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TranslatedTerm == null && $scope.glossaryData.MasterGlossaries[i].IsSuggestionExist === false) {
                                        // null values in language data
                                        flag = true;
                                        $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages.push($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k]);
                                        break;
                                    } else {
                                        //translation present hence skip it
                                        flag = true;
                                        break;
                                    }
                                }
                                else {
                                    if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TranslatedTerm != null) {
                                        //translation present hence skip it
                                        flag = true;
                                        break;
                                    } else {
                                        // null values in language data
                                        flag = true;
                                        $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages.push($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k]);
                                        break;
                                    }
                                }
                            }
                        }
                        if (flag == false) {
                            // no langauge data in backened jason
                            $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages.push(langModel);
                        }
                    }
                    filter = true;
                }

                /*checking whether approved Translations checkbox is checked or not. If checked then applying the filter logic for that*/
                if ($('#approvedFilter:checkbox:checked').length > 0) {
                    var islangStatusSet = true;
                    for (var i = 0; i < $scope.glossaryData.MasterGlossaries.length; i++) {
                        var flag = false;
                        for (var k = 0; k < $scope.glossaryData.MasterGlossaries[i].ProjectLanguages.length; k++) {
                            if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].ProjectLanguageId == $scope.FilterLang.ProjectLanguageId) {
                                if ($('#pendingSuggFilter:checkbox:checked').length > 0) {
                                    if (($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'APPROVER_APPROVED' || $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'CLIENT_APPROVED') && $scope.glossaryData.MasterGlossaries[i].IsSuggestionExist === false) {
                                        $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages.push($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k]);
                                    }
                                } else {
                                    if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'APPROVER_APPROVED' || $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'CLIENT_APPROVED') {
                                        $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages.push($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k]);
                                    }
                                }
                            }
                        }
                    }
                    filter = true;
                }

                /*checking whether rejected Translations checkbox is checked or not. If checked then applying the filter logic for that*/
                if ($('#rejectedFilter:checkbox:checked').length > 0) {
                    var islangStatusSet = true;
                    for (var i = 0; i < $scope.glossaryData.MasterGlossaries.length; i++) {
                        var flag = false;
                        for (var k = 0; k < $scope.glossaryData.MasterGlossaries[i].ProjectLanguages.length; k++) {
                            if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].ProjectLanguageId == $scope.FilterLang.ProjectLanguageId) {
                                if ($('#pendingSuggFilter:checkbox:checked').length > 0) {
                                    if (($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'APPROVER_REJECTED' || $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'CLIENT_REJECTED') && $scope.glossaryData.MasterGlossaries[i].IsSuggestionExist === false) {
                                        $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages.push($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k]);
                                    }
                                } else {
                                    if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'APPROVER_REJECTED' || $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'CLIENT_REJECTED') {
                                        $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages.push($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k]);
                                    }
                                }
                            }
                        }
                    }
                    filter = true;
                }

                /*checking whether pending Approvals checkbox is checked or not. If checked then applying the filter logic for that*/
                if ($('#pendingApprovalsFilter:checkbox:checked').length > 0) {
                    var islangStatusSet = true;
                    for (var i = 0; i < $scope.glossaryData.MasterGlossaries.length; i++) {
                        var flag = false;
                        for (var k = 0; k < $scope.glossaryData.MasterGlossaries[i].ProjectLanguages.length; k++) {
                            if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].ProjectLanguageId == $scope.FilterLang.ProjectLanguageId) {
                                if ($('#pendingSuggFilter:checkbox:checked').length > 0) {
                                    if (($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'TRANSLATION_COMPLETED' || $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'APPROVER_APPROVED_IN_PROGRESS' || $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'APPROVER_REJECTED_IN_PROGRESS' || $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'CLIENT_APPROVER_IN_PROGRESS' || $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'CLIENT_REJECTED_IN_PROGRESS') && $scope.glossaryData.MasterGlossaries[i].IsSuggestionExist === false) {
                                        $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages.push($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k]);
                                    }
                                } else {
                                    if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'TRANSLATION_COMPLETED' || $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'APPROVER_APPROVED_IN_PROGRESS' || $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'APPROVER_REJECTED_IN_PROGRESS' || $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'CLIENT_APPROVER_IN_PROGRESS' || $scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].TermStatus == 'CLIENT_REJECTED_IN_PROGRESS') {
                                        $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages.push($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k]);
                                    }
                                }
                            }
                        }
                    }
                    filter = true;
                }

                /*checking whether pending Suggestion checkbox is checked or not. If checked then applying the filter logic for that*/
                if (!islangStatusSet) {
                    if ($('#pendingSuggFilter:checkbox:checked').length > 0) {
                        for (var i = 0; i < $scope.glossaryData.MasterGlossaries.length; i++) {
                            var flag = false;
                            for (var k = 0; k < $scope.glossaryData.MasterGlossaries[i].ProjectLanguages.length; k++) {
                                if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].ProjectLanguageId == $scope.FilterLang.ProjectLanguageId) {
                                    if ($scope.glossaryData.MasterGlossaries[i].IsSuggestionExist === false) {
                                        $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages.push($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k]);
                                    }
                                }
                            }
                        }
                        filter = true;
                    }
                }


                /*deleting terms in glossaryCopy where no langauge data is present after applying filter*/
                for (var k = 0; k < $scope.glossaryCopy.MasterGlossaries.length; k++) {
                    if ($scope.glossaryCopy.MasterGlossaries[k].ProjectLanguages.length < 1) {
                        $scope.glossaryCopy.MasterGlossaries.splice(k, 1);
                        k--;
                    }
                }
                /*Comment filter '1' for commented terms '2' for un-commented terms . Here filter is applied on glossaryCopy after other filters is applied*/
                if ($scope.filterStatus == '1') {
                    for (var k = 0; k < $scope.glossaryCopy.MasterGlossaries.length; k++) {
                        if ($scope.glossaryCopy.MasterGlossaries[k].ProjectLanguages[0].IsCommented == false) {
                            $scope.glossaryCopy.MasterGlossaries.splice(k, 1);
                            k--;
                        }
                    }
                }
                if ($scope.filterStatus == '2') {
                    for (var k = 0; k < $scope.glossaryCopy.MasterGlossaries.length; k++) {

                        if ($scope.glossaryCopy.MasterGlossaries[k].ProjectLanguages[0].IsCommented == true) {
                            $scope.glossaryCopy.MasterGlossaries.splice(k, 1);
                            k--;
                        }
                    }
                }
                /*Image filter 'withImage' for  terms with image 'withoutImage' for terms without terms . Here filter is applied on glossaryCopy after other filters is applied*/
                if ($scope.filterImage == 'withImage') {
                    for (var k = 0; k < $scope.glossaryCopy.MasterGlossaries.length; k++) {
                        if ($scope.glossaryCopy.MasterGlossaries[k].MasterImageUrl == null) {
                            $scope.glossaryCopy.MasterGlossaries.splice(k, 1);
                            k--;
                        }
                    }
                }
                if ($scope.filterImage == 'withoutImage') {
                    for (var k = 0; k < $scope.glossaryCopy.MasterGlossaries.length; k++) {
                        if ($scope.glossaryCopy.MasterGlossaries[k].MasterImageUrl != null) {
                            $scope.glossaryCopy.MasterGlossaries.splice(k, 1);
                            k--;
                        }
                    }
                }
                sessionStorage.setItem('glossaryFilterLang', JSON.stringify($scope.FilterLang));
                sessionStorage.setItem("filterStatus", $scope.filterStatus);
                sessionStorage.setItem("filterImage", $scope.filterImage);
                sessionStorage.setItem("pendingTranslationsFilter", $('#pendingTranslationsFilter:checkbox:checked').length);
                sessionStorage.setItem("pendingApprovalsFilter", $('#pendingApprovalsFilter:checkbox:checked').length);
                sessionStorage.setItem("approvedFilter", $('#approvedFilter:checkbox:checked').length);
                sessionStorage.setItem("rejectedFilter", $('#rejectedFilter:checkbox:checked').length);
                sessionStorage.setItem("pendingSuggFilter", $('#pendingSuggFilter:checkbox:checked').length);
                sessionStorage.setItem("filterOnStatus", "1");
                $scope.showLoader = false;
                $scope.facdata = [];
                $scope.defdata = [];
                GlossaryNgGrid($scope.glossaryCopy, commonService.getSessionData('GlossarySection'));
                $(window).resize();
            }
                // if no filter checkboxes are checked but language is selected
            else {
                if ($scope.filterStatus || $scope.filterImage) {
                    $('#filterOptionsButton').css("border-style", "ridge");
                    $('#filterOptionsButton').css("border-color", "red");
                    $('#filterOptionsButton').css("background-image", "url('../../../Content/Common/Assets/Images/export_s.png')");
                    $('#filterOptionsButton').css("color", "red");
                    filter = true;
                    for (var i = 0; i < $scope.glossaryData.MasterGlossaries.length; i++) {
                        for (var k = 0; k < $scope.glossaryData.MasterGlossaries[i].ProjectLanguages.length; k++) {
                            if ($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k].ProjectLanguageId == $scope.FilterLang.ProjectLanguageId) {

                                $scope.glossaryCopy.MasterGlossaries[i].ProjectLanguages.push($scope.glossaryData.MasterGlossaries[i].ProjectLanguages[k]);

                                break;
                            }
                        }
                    }


                    if ($scope.filterStatus == '1') {
                        for (var k = 0; k < $scope.glossaryCopy.MasterGlossaries.length; k++) {
                            if (!$scope.glossaryCopy.MasterGlossaries[k].ProjectLanguages[0] || $scope.glossaryCopy.MasterGlossaries[k].ProjectLanguages[0].IsCommented == false) {
                                $scope.glossaryCopy.MasterGlossaries.splice(k, 1);
                                k--;
                            }
                        }
                    }
                    if ($scope.filterStatus == '2') {
                        for (var k = 0; k < $scope.glossaryCopy.MasterGlossaries.length; k++) {
                            if ($scope.glossaryCopy.MasterGlossaries[k].ProjectLanguages[0] && $scope.glossaryCopy.MasterGlossaries[k].ProjectLanguages[0].IsCommented == true) {
                                $scope.glossaryCopy.MasterGlossaries.splice(k, 1);
                                k--;
                            }
                        }
                    }
                    /*Image filter 'withImage' for  terms with image 'withoutImage' for terms without terms . Here filter is applied on glossaryCopy after other filters is applied*/
                    if ($scope.filterImage == 'withImage') {
                        for (var k = 0; k < $scope.glossaryCopy.MasterGlossaries.length; k++) {
                            if ($scope.glossaryCopy.MasterGlossaries[k].MasterImageUrl == null) {
                                $scope.glossaryCopy.MasterGlossaries.splice(k, 1);
                                k--;
                            }
                        }
                    }
                    if ($scope.filterImage == 'withoutImage') {
                        for (var k = 0; k < $scope.glossaryCopy.MasterGlossaries.length; k++) {
                            if ($scope.glossaryCopy.MasterGlossaries[k].MasterImageUrl != null) {
                                $scope.glossaryCopy.MasterGlossaries.splice(k, 1);
                                k--;
                            }
                        }
                    }
                    $('#filterOption').modal('hide');
                    sessionStorage.setItem('glossaryFilterLang', JSON.stringify($scope.FilterLang));
                    sessionStorage.setItem("filterStatus", $scope.filterStatus);
                    sessionStorage.setItem("filterImage", $scope.filterImage);
                    sessionStorage.setItem("pendingTranslationsFilter", $('#pendingTranslationsFilter:checkbox:checked').length);
                    sessionStorage.setItem("pendingApprovalsFilter", $('#pendingApprovalsFilter:checkbox:checked').length);
                    sessionStorage.setItem("approvedFilter", $('#approvedFilter:checkbox:checked').length);
                    sessionStorage.setItem("rejectedFilter", $('#rejectedFilter:checkbox:checked').length);
                    sessionStorage.setItem("pendingSuggFilter", $('#pendingSuggFilter:checkbox:checked').length);
                    sessionStorage.setItem("filterOnStatus", "1");
                    $scope.facdata = [];
                    $scope.defdata = [];
                    GlossaryNgGrid($scope.glossaryCopy, commonService.getSessionData('GlossarySection'));
                    $scope.showLoader = false;
                    $(window).resize();
                } else {
                    $('#filterOptionsButton').css("border-style", "none");
                    $('#filterOptionsButton').css("border-color", "none");
                    $('#filterOptionsButton').css("background-image", "url('../../../Content/Common/Assets/Images/export_n.png')");
                    $('#filterOptionsButton').css("color", "white");
                    $('#filterOption').modal('hide');
                    filter = false;
                    sessionStorage.setItem("filterStatus", "undefined");
                    sessionStorage.setItem("filterImage", "undefined");
                    sessionStorage.setItem("pendingTranslationsFilter", "0");
                    sessionStorage.setItem("pendingApprovalsFilter", "0");
                    sessionStorage.setItem("approvedFilter", "0");
                    sessionStorage.setItem("rejectedFilter", "0");
                    sessionStorage.setItem("pendingSuggFilter", "0");
                    sessionStorage.setItem("filterOnStatus", "0");
                    alert('No filter Selected');
                    $scope.facdata = [];
                    $scope.defdata = [];
                    GlossaryNgGrid($scope.glossaryData, commonService.getSessionData('GlossarySection'));
                    $scope.showLoader = false;
                    $(window).resize();
                }

            }

        } else {
            $scope.showLoader = false;
            $('#failValidationMsgDiv').css('display', 'block');
            $timeout(function () { $('#failValidationMsgDiv').css('display', 'none') }, 3000);

        }

    };

    $scope.showFilter = function () {
        $('#filterOption').modal({
            backdrop: 'static',
            keyboard: false
        })
        $('#filterOption').modal('show');
    };

    $scope.clearFilterOptions = function () {
        //GLMGR-622 start
        sessionStorage.setItem("filterStatus", "undefined");
        sessionStorage.setItem("filterImage", "undefined");
        sessionStorage.setItem("pendingTranslationsFilter", "0");
        sessionStorage.setItem("pendingApprovalsFilter", "0");
        sessionStorage.setItem("approvedFilter", "0");
        sessionStorage.setItem("rejectedFilter", "0");
        sessionStorage.setItem("pendingSuggFilter", "0");
        sessionStorage.setItem("filterOnStatus", "0");

        $('#filterOptionsButton').css("border-style", "none");
        $('#filterOptionsButton').css("border-color", "none");
        $('#filterOptionsButton').css("background-image", "url('../../../Content/Common/Assets/Images/export_n.png')");
        $('#filterOptionsButton').css("color", "white");
        //GLMGR-622 end
        location.reload();
    };

    /* Status filter ends */

    //change of path on button clicks
    $scope.changeView = function (new_path) {
        //GLMGR-1239 uncheck hide add info col on view change
        sessionStorage.setItem('hideAddInfoCols', false);
        switch (new_path) {
            case "translation":
                $location.search('projectlanguageid', $scope.translationProjectLanguageId);
                $location.path('/glossary/translation');
                break;

            case "approve":
                $location.search('projectlanguageid', $scope.approveProjectLanguageId);
                $location.path('/glossary/approve');
                break;

            case "GlossaryAllsection":
                $location.path('/glossary/glossaryAllSection');
                break;

                //GLMGR-656 
            case "sourceSetup":
                if ($scope.defaultGlossarySectionType === true) {
                    sessionStorage.setItem("ActiveSectionType", "1");
                } else {
                    sessionStorage.setItem("ActiveSectionType", "2");
                }
                sessionStorage.setItem('SourceSetupActiveSection', '');
                sessionStorage.setItem('isShowRemovedTermsFlag', '0');
                $location.path('/glossary/sourceSetup');
                $scope.clearFilterOptions();
                break;
        }

    };

    $scope.addGlossaryTranslation = function () {
        if (sessionStorage.getItem("filterOnStatus") === "1") {
            sessionStorage.setItem('glossaryFilterLang', JSON.stringify($scope.FilterLang));
            $scope.translateTerms($scope.FilterLang);
        } else {
            $('#addTranslation').modal('show');
        }
    };

    //change of view to add translation 
    $scope.translateTerms = function (language) {
        $scope.newLang = language;
        sessionStorage.setItem('glossaryNewLang', JSON.stringify(language));
        sessionStorage.setItem('ResourceId', JSON.stringify(language.ProjectLanguageId));
        GlossaryCheck.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
        GlossaryCheck.ResourceId = language.ProjectLanguageId.toString();
        GlossaryCheck.PageId = 2;

        commonService.checkSourceSetup(GlossaryCheck, function (status) {
            if (status == "error") {
                $('#serverError').modal('show');
            } else if (status.IsLocked === true) {

                $scope.projectTransLanguageid = language.ProjectLanguageId;
                $('#translationLanguageWarning').modal('show');
            } else {

                $scope.projectTransLanguageid = language.ProjectLanguageId;
                sessionStorage.setItem('translationProjectLanguageId', JSON.stringify(language.ProjectLanguageId));
                $scope.translationProjectLanguageId = commonService.getSessionData('translationProjectLanguageId');
                $('.modal-backdrop').css('display', 'none');
                $scope.changeView('translation');
            }
        });

    };


    $scope.continueToTranslationPage = function () {
        sessionStorage.setItem('translationProjectLanguageId', JSON.stringify($scope.projectTransLanguageid));
        $scope.translationProjectLanguageId = commonService.getSessionData('translationProjectLanguageId');
        $('.modal-backdrop').css('display', 'none');
        $scope.changeView('translation');
    };

    $scope.addGlossaryApproveTranslation = function () {
        if (sessionStorage.getItem("filterOnStatus") === "1") {
            sessionStorage.setItem('glossaryFilterLang', JSON.stringify($scope.FilterLang));
            $scope.ApproveTerms($scope.FilterLang);
        } else {
            $('#ApproveTranslation').modal('show');
        }
    };

    //change of view to approve translation 
    $scope.ApproveTerms = function (language) {
        $scope.newLang = language;
        sessionStorage.setItem('glossaryNewLang', JSON.stringify(language));
        GlossaryCheck.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
        GlossaryCheck.ResourceId = language.ProjectLanguageId.toString();
        GlossaryCheck.PageId = 3;

        sessionStorage.setItem('ResourceId', JSON.stringify(language.ProjectLanguageId));

        commonService.checkSourceSetup(GlossaryCheck, function (status) {
            if (status == "error") {
                $('#serverError').modal('show');
            } else if (status.IsLocked === true) {

                $scope.projectApproveLanguageid = language.ProjectLanguageId;
                $('#approveLanguageWarning').modal('show');

            } else {
                $scope.projectApproveLanguageid = language.ProjectLanguageId;
                sessionStorage.setItem('approveProjectLanguageId', JSON.stringify(language.ProjectLanguageId));
                $scope.approveProjectLanguageId = commonService.getSessionData('approveProjectLanguageId');
                $('.modal-backdrop').css('display', 'none');
                $scope.changeView('approve');
            }

        });

    };

    $scope.continueToApprovePage = function () {
        sessionStorage.setItem('approveProjectLanguageId', JSON.stringify($scope.projectApproveLanguageid));
        $scope.approveProjectLanguageId = commonService.getSessionData('approveProjectLanguageId');
        $('.modal-backdrop').css('display', 'none');
        $scope.changeView('approve');
    };

    //banner toggle functionality
    $scope.bannerToggle = function () {
        if (isVisible == true) {
            $('.container-header, .navbar-default, .glossary-header-wrapper, footer').show();
            $('section.container.wide-screen-section').css('height', window.innerHeight);
            $('.wide-screen-wrapper .ngViewport').css('height', window.innerHeight - 550);
            $('.wide-screen-wrapper .gridStyle').css('height', window.innerHeight - 515);
            isVisible = false;
            sessionStorage.setItem('isVisible', false);
        } else {
            $('.container-header, .navbar-default, .glossary-header-wrapper, footer').hide();
            $('section.container.wide-screen-section').css('height', window.innerHeight);
            $('.wide-screen-wrapper .ngViewport').css('height', window.innerHeight - 230);
            $('.wide-screen-wrapper .gridStyle').css('height', window.innerHeight - 260);
            isVisible = true;
            sessionStorage.setItem('isVisible', true);
        }
    };

    // Glossary search data after clicking of hyperlink in search result
    $scope.viewSectionResult = function (sectionSelected, index) {
        $scope.showLoader = true;
        var d = document.getElementById(index);
        d.setAttribute('class', 'aTagClicked');
        $scope.facdata = [];
        $scope.defdata = [];
        var data = {};
        var data = {};
        data.projectId = $scope.projectId;
        data.headerId = sectionSelected.ProjectHeaderId;
        sessionStorage.setItem('headerId', JSON.stringify(sectionSelected.ProjectHeaderId));
        data.userId = commonService.getLocalData('userDetails').UserId;
        data.roleName = commonService.getLocalData('userDetails').UserRoles[0].UserRoleName;
        data.projectLanguageId = 0;
        data.pageId = 1;
        data.term = $scope.glossarySearchText;
        data.searchedCategory = $scope.glossarySearchCategory;

        Glossary.getSectionData(data, function (glossaryData) {
            $scope.glossaryData = glossaryData;
            for (var i = 0; i < $scope.GlossaryInitialTerms.ProjectHeaders.length; i++) {
                if ($scope.GlossaryInitialTerms.ProjectHeaders[i].Id == sectionSelected.ProjectHeaderId) {
                    $scope.sectionId = $scope.GlossaryInitialTerms.ProjectHeaders[i].Id;

                    sessionStorage.setItem('GlossarySection', JSON.stringify($scope.GlossaryInitialTerms.ProjectHeaders[i]));
                    break;
                }
            }
            if ($scope.headingsDropdown) {
                sessionStorage.setItem('headerId', JSON.stringify(sectionSelected.ProjectHeaderId));
            }

            Catsequence = glossaryData.ProjectCategorySequence;
            $scope.facdata = [];
            $scope.defdata = [];

            GlossaryNgGrid(glossaryData, sectionSelected);

            $scope.showLoader = false;
            $scope.searchResult = false;
            $scope.resultTable = true;


            $(window).resize();

        });

    };

    // Language History feature start
    $scope.getLanguageNamePopup = function () {

        $scope.languageHistory = [];
        $scope.categories = [];
        $scope.ProjectLanguages = [];
        getSectionList();
        $scope.historyLogFlag = true;

        if (sessionStorage.getItem("filterOnStatus") === "1") {
            $scope.selectedLanguageId = $scope.FilterLang.ProjectLanguageId;
            $scope.selectedLanguage = $scope.FilterLang;
            $scope.getLanguageHistory($scope.selectedLanguage, commonService.getSessionData('headerId'));
        } else if ($scope.GlossaryInitialTerms.ProjectLanguages.length == 1) {
            $scope.selectedLanguageId = $scope.GlossaryInitialTerms.ProjectLanguages[0].ProjectLanguageId;
            $scope.selectedLanguage = $scope.GlossaryInitialTerms.ProjectLanguages[0];
            $scope.getLanguageHistory($scope.selectedLanguage, commonService.getSessionData('headerId'));
        } else {
            $('#languageHistory').modal('show');
        }
    };

    $scope.getLanguageName = function (language) {
        $('#languageHistory').modal('hide');
        $('.modal-backdrop').css('display', 'none');
        $scope.selectedLanguageId = language.ProjectLanguageId;
        $scope.selectedLanguage = language.LanguageName;
        $scope.getLanguageHistory($scope.selectedLanguage, commonService.getSessionData('headerId'));
    };

    //To get the Language History Information according to the selected language
    $scope.getLanguageHistory = function (selectedLaguageObj, sectionSelectedObjId) {
        $scope.selectedLanguageId = selectedLaguageObj.ProjectLanguageId;
        $scope.headerId = sectionSelectedObjId;
        $scope.showLoader = true;
        $scope.historyLogFlag = true;
        //Call Service for getting Project History Information
        Glossary.getProjectHistory($scope.projectId, $scope.headerId, $scope.userId, $scope.userRole, $scope.selectedLanguageId, function (languageHistory) {

            //set revert rights for ApproverAsTranslator having different assigned languages
            $scope.revertTranslationApproverAsTranslator = false;
            for (var i = 0; i < $scope.addTranslationlanguages.length; i++) {
                if ($scope.addTranslationlanguages[i].ProjectLanguageId === $scope.selectedLanguageId) {
                    $scope.revertTranslationApproverAsTranslator = true;
                    break;
                }
            }

            $scope.languageHistory = languageHistory;
            var catEmpty = {
                CategoryId: "",
                CategoryName: "",
                CategoryText: "",
                DbProjectId: 0,
                GlossaryCategoryId: 0,
                MasterGlossaryId: 0,
                ProjectCategoryId: 0,
                ProjectId: null
            };
            $scope.categories = $scope.languageHistory.Categories;
            for (var i = 0; i < $scope.languageHistory.MasterGlossaries.length; i++) {
                if ($scope.languageHistory.MasterGlossaries[i].ProjectCategories.length < $scope.categories.length) {

                    for (var j = 0; j < $scope.categories.length; j++) {
                        var flag = 0;
                        for (var k = 0; k < $scope.languageHistory.MasterGlossaries[i].ProjectCategories.length; k++) {
                            if ($scope.languageHistory.MasterGlossaries[i].ProjectCategories[k].CategoryName == $scope.categories[j].CategoryName) {
                                flag = 1;
                                break;
                            }
                        }
                        if (flag == 0) {
                            if (j < $scope.languageHistory.MasterGlossaries[i].ProjectCategories.length) {
                                $scope.languageHistory.MasterGlossaries[i].ProjectCategories.splice(j, 0, catEmpty);
                            }
                            else {
                                $scope.languageHistory.MasterGlossaries[i].ProjectCategories.push(catEmpty);
                            }
                        }

                    }

                }

            }

            //open popup
            $('#languageHistoryPopup').modal({ backdrop: 'static', keyboard: false });
            $('#languageHistoryPopup').modal('show');

            $scope.showLoader = false;
        });
    };


    $scope.toggleHistoryLogForTerm = function (termIndex) {
        $('.term' + termIndex).toggle('fast');
    };

    var getSectionList = function () {
        var sectionType = 1;
        if (commonService.getSessionData('glossaryTab') && commonService.getSessionData('glossaryTab') === 'default') {
            sectionType = 1;
        } else if (commonService.getSessionData('glossaryTab') && commonService.getSessionData('glossaryTab') === 'ntl') {
            sectionType = 2;
        }
        Glossary.getGlossaryInitialData($scope.projectId, commonService.getLocalData('userDetails').UserId, sectionType, function (data) {
            $scope.SectionList = data;
            $scope.sectionId = commonService.getSessionData('headerId');
            for (var i = 0; i < data.ProjectHeaders.length; i++) {
                if (commonService.getSessionData('headerId') == data.ProjectHeaders[i].Id) {
                    $scope.sectionSelected = data.ProjectHeaders[i];
                    $scope.headerId = data.ProjectHeaders[i].Id;
                }
            }
            $scope.ObjectId1 = [];
            $scope.ClientName_str = '';
            for (var i = 0; i < data.ProjectClients.length; i++) {
                $scope.ObjectId1.push(data.ProjectClients[i].ClientName);
                $scope.ClientName_str = $scope.ClientName_str + data.ProjectClients[i].ClientName + ', ';
            }
            $scope.ClientName_str = $scope.ClientName_str.slice(0, -2);
        });
    }
    // Language History feature end

    var init = function () {
        //GLMGR-1239 Retain hide Add info column checkbox on refresh 
        $scope.isCheckedAddInfoCols = JSON.parse(sessionStorage.getItem('hideAddInfoCols'));
        $scope.hideAddInfoCOls = JSON.parse(sessionStorage.getItem('hideAddInfoCols'));
        if (!$scope.hideAddInfoCOls) {
            hideCatCols = false;
        } else {
            hideCatCols = true;
        }

        //GLMGR-1239 Retain hide starred column checkbox on refresh 
        $scope.isStarred = JSON.parse(sessionStorage.getItem('hideStarredCol'));
        if ($scope.isStarred) {
            $scope.hideStarredCol = false;
        }

        //to check if page is redirected from search page
        var isRedirectedFromSearch = JSON.parse(sessionStorage.getItem('SearchToTranslation'));
        if (isRedirectedFromSearch) {
            sessionStorage.setItem('SearchToTranslation', false);
            var language = JSON.parse(sessionStorage.getItem('glossaryNewLang'));
            var userRole = commonService.getLocalData('userDetails').UserRoles[0].UserRoleName;
            var PrivilegeIdInDb = JSON.parse(sessionStorage.getItem('PrivilegeIdInDb'));
            switch (userRole) {
                case "Translator":
                    if (language.IsHasWriteAccess) {
                        if (PrivilegeIdInDb == "6" || PrivilegeIdInDb == "6,9" || PrivilegeIdInDb == "9,6") {
                            $scope.translateTerms(language);
                        }
                        else if (PrivilegeIdInDb == "9") {
                            $scope.ApproveTerms(language);
                        }
                        
                    } else {
                        init();
                    }
                    break;
                case "Approver":
                    if (language.IsHasWriteAccess) {
                        if (PrivilegeIdInDb == "9" || PrivilegeIdInDb == "6,9" || PrivilegeIdInDb == "9,6") {
                            $scope.ApproveTerms(language);
                        }
                        else if (PrivilegeIdInDb == "6") {
                            $scope.translateTerms(language);
                        }
                    } else {
                        init();
                    }
                    break;

                case "Client Admin":
                    if (language.IsHasWriteAccess) {
                        $scope.translateTerms(language);
                    } else {
                        init();
                    }
                    break;

                case "Admin":
                case "Super Admin":
                case "Client User":
                    $scope.translateTerms(language);
                    break;
                case "Editorial Staff":
                    init();
                    break;

            }

        }

        if (sessionStorage.getItem('navigateToAllGlossary') === 'true') {//GLMGR-231 navigate to AllGlossary Page from Project Landing page
            FilterLang = {};
            FilterLang.ProjectLanguageId = sessionStorage.getItem('AllglossaryLangList');
            sessionStorage.setItem('glossaryFilterLang', JSON.stringify(FilterLang));

            $('#filterOptionsButton').css("border-style", "ridge");
            $('#filterOptionsButton').css("border-color", "red");

            $('#filterOptionsButton').css("background-image", "url('../../../Content/Common/Assets/Images/export_s.png')");
            $('#filterOptionsButton').css("color", "red");
            sessionStorage.setItem("filterOnStatus", "1");

            if (sessionStorage.getItem("approvedFilter") === "1") {
                $('#approvedFilter').prop('checked', true);
            } else if (sessionStorage.getItem("rejectedFilter") === "1") {
                $('#rejectedFilter').prop('checked', true)
            } else {
                $('#pendingApprovalsFilter').prop('checked', true);
            }

            $scope.changeView('GlossaryAllsection');
        }

        $scope.showGlossaryPage = false;
        $scope.showSaveButton = false;
        $scope.submitshow = true;
        $scope.projectId = commonService.getSessionData('projectIBreadCrumb');
        $scope.unEncryptedProjectId = commonService.getSessionData('unEncriptedProjectId');
        $scope.userId = commonService.getLocalData('userDetails').UserId;
        //$('#pageload').modal({ backdrop: 'static', keyboard: false })
        $scope.showLoader = true;
        var searchTableApproverPage = false;
        sessionStorage.setItem('searchTableApproverPage', JSON.stringify(searchTableApproverPage));
        var resorceIdx = 1;
        sessionStorage.setItem('resourcePageId', JSON.stringify(resorceIdx));
        //commonService.getUserRecordDeleted(commonService.getLocalData('userDetails').UserId, resorceIdx, function (status) {

        //});

        $scope.userRole = commonService.getLocalData('userDetails').UserRoles[0].UserRoleName;
        $scope.HasWritePrivilege = commonService.getSessionData('HasWritePrivilege');
        if (commonService.getSessionData('InstanceSettingProjectId') == null) {

            sessionStorage.setItem('InstanceSettingProjectId', JSON.stringify(commonService.getSessionData('unEncriptedProjectId')));

        } else if (commonService.getSessionData('InstanceSettingProjectId') != commonService.getSessionData('unEncriptedProjectId')) {

            var temp = [];
            sessionStorage.setItem('gridContextInstance', JSON.stringify(temp));
            sessionStorage.setItem('GlossarySection', JSON.stringify(null));
            sessionStorage.setItem('gridContextSaved', JSON.stringify(false));
            sessionStorage.setItem('InstanceSettingProjectId', JSON.stringify(commonService.getSessionData('unEncriptedProjectId')));
        }
        if (commonService.getSessionData('glossaryTab') && commonService.getSessionData('glossaryTab') === 'default') {
            $scope.defaultGlossarySectionType = true;
            $scope.ntlGlossarySectionType = false;
            Glossary.getGlossaryInitialData($scope.projectId, commonService.getLocalData('userDetails').UserId, 1, glossaryInitialData);
        } else if (commonService.getSessionData('glossaryTab') && commonService.getSessionData('glossaryTab') === 'ntl') {
            $scope.defaultGlossarySectionType = false;
            $scope.ntlGlossarySectionType = true;
            Glossary.getGlossaryInitialData($scope.projectId, commonService.getLocalData('userDetails').UserId, 2, glossaryInitialData);
        } else {
            Glossary.getGlossaryInitialData($scope.projectId, commonService.getLocalData('userDetails').UserId, 1, glossaryInitialData);
        }


        //watch for change in headerdropdown
        $scope.$watch('headingsDropdown', function (new_value, old_value) {

            if (old_value !== undefined && new_value !== undefined) {
                $scope.showLoader = true;
                if (new_value == null) {
                    AllSection();
                } else {
                    Glossary.getGlossaryData($scope.projectId, new_value.Id, commonService.getLocalData('userDetails').UserId, function (glossaryData) {
                        if (glossaryData == 'error') {
                            $('#serverError').modal('show');
                            $scope.showLoader = false;
                        }
                        $scope.showLoader = false;
                        $scope.glossaryData = glossaryData;
                        Catsequence = glossaryData.ProjectCategorySequence;

                        //GLMGR-1239 if section having atleast one empty column then only check the hideEmptyCol checkbox
                        $scope.isCheckedEmptyInfoCols = false;
                        $scope.hideEmptyAddInfoCOls = false;
                        for (var i = 0; i < $scope.glossaryData.SectionCategories.length; i++) {
                            if ($scope.glossaryData.SectionCategories[i].IsCategoryEmpty === true) {
                                $scope.isCheckedEmptyInfoCols = true;
                                $scope.hideEmptyAddInfoCOls = true;
                            }
                        }

                        sessionStorage.setItem('headerId', JSON.stringify(new_value.Id));

                        $scope.headingsDropdown.Id = new_value.Id;
                        $scope.sectionId = $scope.headingsDropdown.Id;

                        sessionStorage.setItem('GlossarySection', JSON.stringify(new_value));

                        hideCatCols = true;

                        //GLMGR-1239 check if section has atleast one starred term
                        $scope.isHavingStarredTerm = false;
                        for (var i = 0; i < glossaryData.MasterGlossaries.length; i++) {
                            if (glossaryData.MasterGlossaries[i].IsStarred == true) {
                                $scope.isHavingStarredTerm = true;
                            }
                        }
                        if (!$scope.isHavingStarredTerm) {
                            $scope.isStarred = true;
                            $scope.hideStarredCol = false;
                        }
                        else {
                            $scope.isStarred = false;
                            $scope.hideStarredCol = true;
                        }

                        $scope.facdata = [];
                        $scope.defdata = [];

                        if (filter == true) {
                            $scope.filterOptions();
                        } else {
                            GlossaryNgGrid(glossaryData, new_value);
                        }
                    });
                }
            }
        });

        // Function to get attachments list on user Id
        Glossary.getAttachmentList($scope.projectId, commonService.getLocalData('userDetails').UserId, function (AttachmentList) {
            $scope.attachmentList = AttachmentList;
        });

        //open attachment popup if attachment is present.
        $scope.downloadAttachmentPopup = function () {
            if ($scope.attachmentList.AttachementInfo.length === 0) {
                $scope.errorMessage = 'No attachment available for this project.';
                $scope.errorTitle = 'No Attachment';
                $('#errorModal').modal('show');
                return true;
            } else {
                $('#downloadAttachment').modal('show');
            }
        };

    }
    init();

    //event on any change in ng-grid table
    $scope.$on('ngGridEventColumns', function (event, newColumns) {
        if (newColumns.length > 0) {
            sessionStorage.setItem('gridContextInstance', JSON.stringify(newColumns));
        }
        sessionStorage.setItem('gridContextSaved', JSON.stringify(true));
    });

    //backend call for deleting the locked user from the current page (commented during code refactoring)
    //$scope.callDeleteLockedUserService = function (pageId) {

    //    var dataForDeleteLockedUser = {};
    //    dataForDeleteLockedUser.UserId = JSON.parse(localStorage.getItem('userDetails')).UserId;
    //    dataForDeleteLockedUser.PageId = pageId;
    //    dataForDeleteLockedUser.ResourceId = JSON.parse(sessionStorage.getItem('ResourceId'));
    //    commonService.deleteLockRecordsForPageResources(dataForDeleteLockedUser, function (status) {
    //        return true;
    //    });
    //};

    //To gradually reduce the size of the image upto a limit on column resize
    $scope.$watch('gridOptions.$gridScope.isColumnResizing', function (newValue, oldValue) {
        if (newValue === false && oldValue === true) {
            //on stop resizing
            var max_size = 110;
            $(".width100per").each(function (i) {
                x = $(this).width();
                $(".ngCellTextMasterTerm").each(function (i) {

                    var h = max_size;
                    var w = Math.ceil(x - 120);

                    $(this).css({ height: h + 'px', width: w + 'px' });


                });

            });

        }
    }, true);

}]);