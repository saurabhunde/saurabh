/**
* @ngdoc directive
* @name common.directive:searchDropDown
* @restrict 'E'
* @element select 
* @scope
* @description 
* This is custom directive for multi select dropdowns on seach page.
**/
Common.directive('searchDropDown', ['$rootScope', function ($rootScope) {
    return {
        restrict: 'E',
        scope: {
            allcolumns: '=',
            addinfcolist: '=',
            sectioncollist: '=',
            sourcetermlist: '=',
            languagelist: '=',
            alllangcolumns: '=',
            importfunc: '&',
            allselect:'&',
            clientitems: '=',
            branditems: '=',
            projectitems: '=',
            langitems: '=',
            transitems: '=',
            prop: '@',
            func: '&',
            clist: '=',
            blist: '=',
            plist: '=',
            tlist: '=',
            status: '=',
            id: '@',
            buttonlabel: '=',
            selecttype: '@'
        },
        template: "<div class='btn-group' data-ng-class='{open: open, divPaddingForNetflix : netflix}'>" +
         "<button class='client_str btn btn-small btn-width ms-dropdown-style ms-dropdown-style-search' data-ng-class='{widthfornetflix : netflix}' data-ng-mouseleave='open=!open;' data-ng-mouseenter='open=!open;' >{{buttonlabel}}</button>" +
         "<button class='btn btn-small dropdown-toggle' data-ng-mouseleave='open=!open;' data-ng-mouseenter='open=!open;'><span class='caret'></span></button>" +
         "<ul id='{{id}}' class='dropdown-menu' aria-labelledby='dropdownMenu' data-ng-mouseleave='open=!open;'>" +
                     "<li data-ng-hide='singleSelect'><a data-ng-click='selectAll()'><i class='icon-ok-sign'></i>  Check All</a></li>" +
                     "<li data-ng-hide='singleSelect'><a data-ng-click='deselectAll();'><i class='icon-remove-sign'></i>  Uncheck All</a></li>" +
                     "<li><a data-ng-class='{inputPaddingTop: singleSelect}' ><input ng-model='propFilter' type='text' /></a></li>" +
                     "<li class='divider'></li>" +
                     "<li data-ng-repeat='item in items | filter:propFilter' >" +
                     "<a data-ng-click='pushItem(item);' title={{item[prop]}}>{{item[prop]}}<span data-ng-class='isChecked(item)'></span></a>" +
                    "</li>" +
                 "</ul>" +
             "</div>",

        controller: ['$scope', function ($scope) {
            $scope.clist = [];
            $scope.blist = [];
            $scope.plist = [];
            $scope.tlist = [];
            $scope.items = [];
            //for dropdowns of netflix KNP import
            $scope.addinfcolist = [];
            $scope.sectioncollist = [];
            $scope.sourcetermlist = [];
            $scope.languagelist = [];
            $scope.singleSelect = false;
            $scope.netflix = false;
        }],

        link: function (scope, elem, attrs) {

            //hide select all and deselect all options for single select dropdown
            if (attrs.selecttype && attrs.selecttype == "single") {
                scope.singleSelect = true;
            }

            //set dropdown width different for netflix
            if (["addInfoColumnNames", "sectionColumnName", "sourceTermColumnName", "languageColumnNames"].includes(attrs.prop)) {
                scope.netflix = true;
            }
                var arrayToBeUpdated = [];
                //check for which dropdown user is on
                switch (attrs.prop) {
                    case "ClientName":
                        arrayToBeUpdated = scope["clist"];
                       
                        scope.$watch('clientitems', function (newValue, oldValue, scope) {
                            scope.items = newValue;
                        }); 
                        
                        break;

                    case "BrandName":
                        arrayToBeUpdated = scope["blist"];
                        
                        scope.$watch('branditems', function (newValue, oldValue, scope) {
                            scope.items = newValue;
                        });
                        break;

                    case "ProjectTitle":
                        arrayToBeUpdated = scope["plist"];
                        scope.$watch('projectitems', function (newValue, oldValue, scope) {
                            scope.items = newValue;
                        });
                        
                        break;

                    case "LanguageName":
                        arrayToBeUpdated = scope["tlist"];
                        scope.$watch('langitems', function (newValue, oldValue, scope) {
                            scope.items = newValue;
                        });
                        
                        break;

                    case "TranslationStatusText":
                        arrayToBeUpdated = scope["status"];

                        scope.$watch('transitems', function (newValue, oldValue, scope) {
                            scope.items = newValue;
                        });
                        break;

                        //for dropdowns of netflix KNP import
                    case "addInfoColumnNames":
                        arrayToBeUpdated = scope["addinfcolist"];
                        
                        scope.$watch('allcolumns', function (newValue, oldValue, scope) {
                            scope.items = newValue;

                            //below code is to check/tick in dropdown if SOURCE TERM NOTES and FREQUENCY column is present in excel file 
                            if (scope.items && arrayToBeUpdated.length === 0) {
                                let sourceNotesCol = { addInfoColumnNames: "SOURCE TERM NOTES", sectionColumnName: "SOURCE TERM NOTES", sourceTermColumnName: "SOURCE TERM NOTES", languageColumnNames:"SOURCE TERM NOTES"};
                                let frequencyCol = { addInfoColumnNames: "FREQUENCY", sectionColumnName: "FREQUENCY", sourceTermColumnName: "FREQUENCY", languageColumnNames:"FREQUENCY"};
                                for (var i = 0; i < scope.items.length; i++) {
                                    if (angular.equals(scope.items[i], sourceNotesCol) || angular.equals(scope.items[i], frequencyCol)) {
                                        arrayToBeUpdated.push(scope.items[i]);
                                    }
                                }
                            }

                            //check only selected items
                            checkSelectedItems();
                        });
                        
                        break;

                    case "sectionColumnName":
                        arrayToBeUpdated = scope["sectioncollist"];

                        scope.$watch('allcolumns', function (newValue, oldValue, scope) {
                            scope.items = newValue;

                            //below code is to check/tick in dropdown if TYPE column is present in excel file 
                            if (scope.items && arrayToBeUpdated.length === 0) {
                                let typeCol = { addInfoColumnNames: "TYPE", sectionColumnName: "TYPE", sourceTermColumnName: "TYPE",languageColumnNames: "TYPE"};
                                for (var i = 0; i < scope.items.length; i++) {
                                    if (angular.equals(scope.items[i], typeCol)) {
                                        arrayToBeUpdated.push(scope.items[i]);
                                    }
                                }
                            }

                            //check only selected items
                            checkSelectedItems();
                        });
                        break;

                    case "sourceTermColumnName":
                        arrayToBeUpdated = scope["sourcetermlist"];

                        scope.$watch('allcolumns', function (newValue, oldValue, scope) {
                            scope.items = newValue;

                            //below code is to check/tick in dropdown if NAME column is present in excel file 
                            if (scope.items && arrayToBeUpdated.length === 0) {
                                let nameCol = { addInfoColumnNames: "NAME", sectionColumnName: "NAME", sourceTermColumnName: "NAME",languageColumnNames: "NAME" };
                                for (var i = 0; i < scope.items.length; i++) {
                                    if (angular.equals(scope.items[i], nameCol)) {
                                        arrayToBeUpdated.push(scope.items[i]);
                                    }
                                }
                            }

                            //check only selected items
                            checkSelectedItems();
                        });
                        break;

                    case "languageColumnNames":
                        arrayToBeUpdated = scope["languagelist"];

                        scope.$watch('alllangcolumns', function (newValue, oldValue, scope) {
                            scope.items = newValue;
                        });
                        break; 

                }

            //function to check/tick selected items
                var checkSelectedItems = function () {
                    //check only selected items
                    $('#' + scope.id + ' .dropdown-menu li a span').each(function () {
                        for (var i = 0; i < arrayToBeUpdated.length; i++) {
                            if (arrayToBeUpdated[scope.prop] === $(this).parent().text()) {
                                $(this).addClass('icon-ok pull-right');
                            }
                        }
                    });
                    //set button label for alredy tiked items
                    setButtonLabel();
                };

            //sets button label
                var setButtonLabel = function () {
                    //button label-show selected items on button label
                    if (arrayToBeUpdated.length > 0) {
                        scope.buttonlabel = "";
                        for (var i = 0; i < arrayToBeUpdated.length; i++) {
                            if (scope.buttonlabel.length === 0) {
                                scope.buttonlabel = arrayToBeUpdated[i][scope.prop];
                            } else if (scope.buttonlabel.length > 0) {
                                scope.buttonlabel += ", " + arrayToBeUpdated[i][scope.prop];
                            }

                        }
                    }
                };


               

           

            //cancel close function
            scope.cancelClose = function ($event) {
                $event.stopPropagation();
            };

            
           
            //select/unselct item function
            scope.pushItem = function (item) {
                
                //select/unselect item from dropdown list
                var isFound = false;
                var index = -1;
                for (var i = 0; i < arrayToBeUpdated.length; i++) {
                    if (angular.equals(arrayToBeUpdated[i], item)) {
                        isFound = true;
                        index = i;
                        break;
                    }
                }
                if (isFound) {
                    arrayToBeUpdated.splice(index, 1);
                    checkSelectedItems();
                } else {
                    if (["addInfoColumnNames", "sectionColumnName", "sourceTermColumnName","languageColumnNames"].includes(attrs.prop)) {
                        if (scope.importfunc()(item, attrs.prop) === false) {
                            return;
                        } 
                    }

                    if (attrs.selecttype == "single") {
                        if (arrayToBeUpdated.length > 0) {
                            arrayToBeUpdated.length = 0;
                        } 
                    }
                    arrayToBeUpdated.push(item);
                }

                //call set button label
                setButtonLabel();

                //call func only when its present in attribute
                if (attrs.func) {
                    scope.func()(attrs.prop);
                }
            };

            //select all function
            scope.selectAll = function () {
                arrayToBeUpdated.length = 0;

                //function if user checks select all from addtional info column those options will not be ticked which are already in other dropdowns
                if (attrs.prop === "addInfoColumnNames" || attrs.prop === "languageColumnNames") {
                    //creating new items array which does not contain already selected items in other two dropdowns
                    let newItems = scope.allselect()(scope.items, attrs.prop);
                    angular.copy(newItems, arrayToBeUpdated);
                } else {
                    angular.copy(scope.items, arrayToBeUpdated);
                }

                //call set button label
                setButtonLabel();

                if (attrs.func) {
                    scope.func()(attrs.prop);
                }

            };

            //unselect all function
            scope.deselectAll = function () {
                arrayToBeUpdated.length = 0;
                $('#' + scope.id + ' .dropdown-menu li a span').each(function () {
                    $(this).removeClass('icon-ok pull-right');
                });
               
                if (attrs.func) {
                    scope.func()(attrs.prop);
                }
            };

            //ischecked function
            scope.isChecked = function (item) {
                //select/unselect item from dropdown list
                var isFound = false;
                for (var i = 0; i < arrayToBeUpdated.length; i++) {
                    if (angular.equals(arrayToBeUpdated[i], item)) {
                        isFound = true;
                        break;
                    }
                }

                if (isFound) {
                    return 'icon-ok pull-right';
                }
                return false;
            };

        }
    }

}]);