
//<a downloadPDF type="application/pdf" filetodownload="ppcperformancesnapshot_{{ accountId }}/ppcperformancesnapshot_{{item.ReportId}}.pdf" filename="{{ item.StartDate | date }}-{{ item.EndDate | date }}.pdf"  url="{{reportsRestPath}}" >{{ item.StartDate | date }} &ndash; {{ item.EndDate | date }}</a>


/*
GetPDF directive - sends image of given element to given rest service for conversion
to pdf and opens-up the pdf in a windows or downloads to browser-download bin.
*/


/*** Service ***
//inject saveBlob in service then use is as below

        accessUserReport: function (exportReportInputs, callback) {
            var updateUserLockData = {};
            var forgerytoken;
            commonService.getToken(function (token) {
                forgerytoken = token;
                $http({
                    method: "post",
                    url: "Projects/AccessUsersReport",
                    data: exportReportInputs,
                    responseType: 'blob',
                    headers: {
                        '__RequestVerificationToken': forgerytoken
                    }
                })
                .
                    success(function (data, status, headers, config) {
                        saveBlob.save(data, 'GlossaryManagerExportFile.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8');
                            callback(true);
                    }).
                    error(function (data, status, headers, config) { })
            });
        }
*/
/*** Directives ***/

Projects.factory('saveBlob', function () {

    var showSave,
           URL = window.URL || window.webkitURL,
           browserSupportedMimeTypes = {
               "image/jpeg": true,
               "image/png": true,
               "image/gif": true,
               "image/svg+xml": true,
               "image/bmp": true,
               "image/x-windows-bmp": true,
               "image/webp": true,
               "audio/wav": true,
               "audio/mpeg": true,
               "audio/webm": true,
               "audio/ogg": true,
               "video/mpeg": true,
               "video/webm": true,
               "video/ogg": true,
               "text/plain": true,
               "text/html": true,
               "text/xml": true,
               "application/xhtml+xml": true,
               "application/json": true,
               "application/pdf": true,
               "application/xls": true
           },
           downloadAttributeSupport = 'download' in document.createElement('a'),
           supported = true,

           saveBlob = navigator.saveBlob || navigator.msSaveOrOpenBlob || navigator.msSaveBlob || navigator.mozSaveBlob || navigator.webkitSaveBlob,
           saveAs = window.saveAs || window.webkitSaveAs || window.mozSaveAs || window.msSaveAs;

    if ((typeof Blob !== 'undefined') && (saveAs || saveBlob)) {
        showSave = function (data, name, mimetype) {

            var blob = new Blob([data], { type: mimetype || "application/excel" });

            if (!name) name = "Download.bin";
            if (saveAs) {
                saveAs(blob, name);
            }
            else {
                saveBlob(blob, name);
            }
        };
    }
    else if ((typeof Blob !== 'undefined') && URL) {
        showSave = function (data, name, mimetype) {

            var blob = new Blob([data], { type: mimetype || "application/octet-stream" })
            url = URL.createObjectURL(blob);

            if (downloadAttributeSupport) {

                var link = document.createElement("a");
                link.setAttribute("href", url);
                link.setAttribute("download", name || "Download.bin");

                var event = document.createEvent('MouseEvents');
                event.initMouseEvent('click', true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
                link.dispatchEvent(event);
                //window.open(url, '','location=no');

            }
            else {
                if (browserSupportedMimeTypes[mimetype.split(";")[0]] === true) {
                    mimetype = "application/excel";
                }

                window.open(url, '_blank', '');
            }

            setTimeout(function () {
                URL.revokeObjectURL(url);
            }, 250);
        };
    }
    else if (!/\bMSIE\b/.test(navigator.userAgent)) {
        showSave = function (data, name, mimetype) {
            if (!mimetype) mimetype = "application/octet-stream";
            // Again I need to filter the mime type so a download is forced.
            if (browserSupportedMimeTypes[mimetype.split(";")[0]] === true) {
                mimetype = "application/octet-stream";
            }
            window.open("data:" + mimetype + "," + encodeURIComponent(data), '_blank', '');
        };
    }
    else {
        showSave = function () {
        }
        supported = false;
    }

    return {
        supported: supported,
        save: showSave
    }
})
