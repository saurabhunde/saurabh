﻿Search.controller('searchController', ['$scope', '$http', '$location', 'SearchTermService', 'commonService', function ($scope, $http, $location, SearchTermService, commonService) {
    $scope.showBrands = false;
    var currentUserRoleName = commonService.getLocalData('userDetails').UserRoles[0].UserRoleName;
    var currentUserId = commonService.getLocalData('userDetails').UserId;
    //search feature GLMGR-678
    $scope.DisplayAsTitle = "Display As List";
    $scope.isListview = false;
    $scope.listViewResult = [];
    $scope.gridViewResult = [];
    $scope.searchTypeList = [];
    $scope.translationStatusList = [];
    $scope.searchTermBrandData = [];
    $scope.searchTermProjectData = [];
    $scope.langDropList = [];
    $scope.ProjectList = [];
    $scope.approvalStatus = [];
    $scope.LanguageLists = [];
    var InputSearchClientData = {};
    InputSearchClientData.ClientIds = [];
    InputSearchClientData.BrandIds = [];
    InputSearchClientData.ProjectIds = [];
    InputSearchClientData.UserId = currentUserId;
    InputSearchClientData.Role = currentUserRoleName;
    InputSearchClientData.Inconsistencies = false;
    InputSearchClientData.Translation = false;
    $scope.transLangColumns = [];
    $scope.listViewHeading = false;
    $scope.searchTextNotRequired = true;
    $scope.hideApproverStatus = true;
    $scope.showLoader = false;
    $scope.searchWord = "";

    $scope.clientLable = "Select Client(s)";
    $scope.brnadLable = "Select Brand(s)";
    $scope.projectLable = "Select Project(s)";
    $scope.languageLable = "Select Language(s)";
    $scope.statusLable = "Select Status";
    $scope.noDataAvailable = false;
    $scope.showBackButton = false;
    
    //validation object
    $scope.searchValidObj = {
        "isSearchTypeRequired": false,
        "isClientRequired": false,
        "isSearchTextRequired": false,
        "isisLanguageRequired": false
    };
    var SearchInputInfoDetails = {};

      //set hashURL for GLMGR-1189
    sessionStorage.setItem('hashURL',null);

    //toggle search view
    $scope.toggleSearchView = function () {
     
            //if (_.isEmpty(SearchInputInfoDetails)) {
                $scope.showBackButton = false;
                if ($scope.isListview) {
                    $scope.isListview = false;
                    $scope.hideApproverStatus = true;
                    $scope.DisplayAsTitle = "Display As List";
                    //$scope.search();
                } else {
                    $scope.isListview = true;
                    $scope.hideApproverStatus = false;
                    $scope.DisplayAsTitle = "Display As Grid";
                    //$scope.search();
                }
                if (!_.isEmpty(SearchInputInfoDetails)) {
                    SearchInputInfoDetails.IsListView = $scope.isListview;
                    $scope.listViewResult = [];
                    $scope.gridViewResult = [];
                    $scope.showLoader = true;
                    SearchTermService.searchButtonMethod(SearchInputInfoDetails, function (data) {
                        $scope.listViewResult = data;
                        if ($scope.listViewResult.length === 0 || ($scope.listViewResult[0].ProjectMasterGlossaries && $scope.listViewResult[0].ProjectMasterGlossaries.length === 0)) {
                            $scope.noDataAvailable = true;
                        } else {
                            $scope.noDataAvailable = false;
                        }
                        if ($scope.isListview) {
                            $scope.searchWord = SearchInputInfoDetails.Term;
                            $scope.projectCount = $scope.listViewResult.length;
                            $scope.listViewHeading = true;
                            $scope.hideApproverStatus = false;
                            $scope.showLoader = false;
                        }
                        //language column count
                        if (!$scope.isListview) {
                            $scope.gridViewResult = $scope.listViewResult[0].ProjectMasterGlossaries;
                            //creating distinct langs for <th>
                            for (var i = 0; i < $scope.gridViewResult.length; i++) {
                                if ($scope.gridViewResult[i].TranslationDetails && $scope.gridViewResult[i].TranslationDetails.length > 0) {
                                    for (var j = 0; j < $scope.gridViewResult[i].TranslationDetails.length; j++) {
                                        if ($scope.transLangColumns.filter(function (e) { return e.LanguageId == $scope.gridViewResult[i].TranslationDetails[j].LanguageId; }).length > 0) {
                                            continue;
                                        } else {
                                            $scope.transLangColumns.push($scope.gridViewResult[i].TranslationDetails[j]);
                                        }
                                    }
                                }
                            }
                            $scope.showLoader = false;
                        }
                        setTimeout(function () { dynamicScreenHeight(); }, 500); // to set height of tbody
                    });
                }
    };

    //Validation function
    $scope.isSearchValid = function (field) {
        var isSearchTypeValid = true;
        var isSearchTextValid = true;
        var isClientValid = true;
        var isLanguageValid = true;
        var isAllvalid = true;
        if (!$scope.searchType) {
            $scope.searchValidObj.isSearchTypeRequired = true;
            isSearchTypeValid = false;
            if (field === 'searchType') {
                return;
            }

        } else {
            if ($scope.searchType.SearchText === "Inconsistencies") {
                $scope.searchTextNotRequired = false;
            } else {
                $scope.searchTextNotRequired = true;
            }
            $scope.searchValidObj.isSearchTypeRequired = false;
            isSearchTypeValid = true;
            if (field === 'searchType') {
                return;
            }

            
        if ($scope.searchType.SearchText !== "Inconsistencies") {
            if (!$scope.searchText) {
                $scope.numberRequired = false;
                $scope.searchValidObj.isSearchTextRequired = true;
                isSearchTextValid = false;
                if (field === 'searchText') {
                    return;
                }
            } else {
                if ($scope.searchType.SearchText === "UniqueId") {
                    if (!(/^\d+$/.test($scope.searchText))) {
                        $scope.searchValidObj.isSearchTextRequired = false;
                        $scope.numberRequired = true;
                        isSearchTextValid = false;
                    } else {
                        $scope.searchValidObj.isSearchTextRequired = false;
                        $scope.numberRequired = false;
                        isSearchTextValid = true;
                    }
                } else {
                    $scope.numberRequired = false;
                    $scope.searchValidObj.isSearchTextRequired = false;
                    isSearchTextValid = true;
                }
                if (field === 'searchText') {
                    return;
                }
            }
        } else {
            $scope.searchValidObj.isSearchTextRequired = false;
            isSearchTextValid = true;
            if (field === 'searchText') {
                return;
            }
        }

        if (!$scope.ClientLists || $scope.ClientLists.length === 0) {
            $scope.searchValidObj.isClientRequired = true;
            isClientValid = false;
            if (field === 'client') {
                return;
            }
        } else {
            $scope.searchValidObj.isClientRequired = false;
            isClientValid = true;
            if (field === 'client') {
                return;
            }
        }

        if (!$scope.LanguageLists || $scope.LanguageLists.length === 0) {
            $scope.searchValidObj.isisLanguageRequired = true;
            isLanguageValid = false;
        } else {
            $scope.searchValidObj.isisLanguageRequired = false;
            isLanguageValid = true;
        }
        }


        if (isSearchTypeValid && isSearchTextValid && isClientValid && isLanguageValid) {
            isAllvalid = true;
        } else {
            isAllvalid = false;
        }
        return isAllvalid;
    };

    //GLMGR-678 search button function
    $scope.search = function (btn) {
        if (btn === 'back') {
            $scope.showBackButton = false;
            $scope.isListview = true;
        }
        if ($scope.isSearchValid("")) {
             $scope.showBackButton = false;
            //make trasnlation columns empty for gridveiw
            $scope.transLangColumns = [];
            //search button info details
            SearchInputInfoDetails.UserId = currentUserId;
            SearchInputInfoDetails.Role = currentUserRoleName;
            SearchInputInfoDetails.ClientIdlist = [];
            SearchInputInfoDetails.LanguageId = [];
            SearchInputInfoDetails.ProjectId = [];
            SearchInputInfoDetails.BrandIdList = [];
            SearchInputInfoDetails.ProjectIdList = [];
            SearchInputInfoDetails.TranslationStatusId = [];
            SearchInputInfoDetails.Term = $scope.searchText;
            SearchInputInfoDetails.SerachType = $scope.searchType.SearchText;
            SearchInputInfoDetails.IsListView = $scope.isListview;
            SearchInputInfoDetails.IsHavingPermission = true;


            //set MasterGlossaryId
            if ($scope.searchType.SearchText === "UniqueId") {
                SearchInputInfoDetails.MasterGlossaryId = $scope.searchText;
            } else {
                SearchInputInfoDetails.MasterGlossaryId = 0;
            }

            //set ismastersearch
            if ($scope.LanguageLists) {
                if ($scope.LanguageLists.length == 1 && $scope.LanguageLists[0].LanguageName === "English") {
                    SearchInputInfoDetails.IsMasterSearch = true;
                } else {
                    SearchInputInfoDetails.IsMasterSearch = false;
                }
            } else {
                SearchInputInfoDetails.IsMasterSearch = false;
            }

            //client ids
            for (var i = 0; i < $scope.ClientLists.length; i++) {
                SearchInputInfoDetails.ClientIdlist.push($scope.ClientLists[i].ClientId);
            }

            //brand ids
            if ($scope.BrandList) {
                for (var i = 0; i < $scope.BrandList.length; i++) {
                    SearchInputInfoDetails.BrandIdList.push($scope.BrandList[i].BrandId);
                }
            }

            //project ids
            if ($scope.ProjectList && $scope.ProjectList.length > 0) {
                for (var i = 0; i < $scope.ProjectList.length; i++) {
                    SearchInputInfoDetails.ProjectId.push($scope.ProjectList[i].ProjectEncriptValue);
                }
            } else {
                for (var i = 0; i < $scope.searchTermProjectData.length; i++) {
                    SearchInputInfoDetails.ProjectId.push($scope.searchTermProjectData[i].ProjectEncriptValue);
                }
            }

            //lang ids

            if ($scope.LanguageLists) {
                for (var i = 0; i < $scope.LanguageLists.length; i++) {
                    SearchInputInfoDetails.LanguageId.push($scope.LanguageLists[i].Id);
                }
            }


            //trasn status
            if ($scope.approvalStatus && $scope.approvalStatus.length !== 0) {
                for (var i = 0; i < $scope.approvalStatus.length; i++) {
                    SearchInputInfoDetails.TranslationStatusId.push($scope.approvalStatus[i].TranslationStatusValue)
                }
            } else if (!$scope.approvalStatus || $scope.approvalStatus.length == 0) {
                for (var i = 0; i < $scope.translationStatusList.length; i++) {
                    SearchInputInfoDetails.TranslationStatusId.push($scope.translationStatusList[i].TranslationStatusValue)
                }
            }

            //for inconsistencies send all language ids and trans status ids
            if ($scope.searchType.SearchText === "Inconsistencies") {
                if (!$scope.LanguageLists || $scope.LanguageLists.length == 0) {
                    SearchInputInfoDetails.LanguageId = [];
                    for (var i = 0; i < $scope.langDropList.length; i++) {
                        SearchInputInfoDetails.LanguageId.push($scope.langDropList[i].Id);
                    }
                }

                if (!$scope.approvalStatus || $scope.approvalStatus.length == 0) {
                    SearchInputInfoDetails.TranslationStatusId = [];
                    for (var i = 0; i < $scope.translationStatusList.length; i++) {
                        SearchInputInfoDetails.TranslationStatusId.push($scope.translationStatusList[i].TranslationStatusValue)
                    }
                }
            }
            $scope.listViewResult = [];
            $scope.gridViewResult = [];
            $scope.showLoader = true;
            SearchTermService.searchButtonMethod(SearchInputInfoDetails, function (data) {
                console.log("data--", data);
                $scope.listViewResult = data;
                if ($scope.listViewResult.length === 0 || ($scope.listViewResult[0].ProjectMasterGlossaries && $scope.listViewResult[0].ProjectMasterGlossaries.length === 0)) {
                    $scope.noDataAvailable = true;
                } else {
                    $scope.noDataAvailable = false;
                }
                if ($scope.isListview) {
                    $scope.searchWord = SearchInputInfoDetails.Term;
                    $scope.projectCount = $scope.listViewResult.length;
                    $scope.listViewHeading = true;
                    $scope.hideApproverStatus = false;
                    $scope.showLoader = false;
                }
                //language column count
                if (!$scope.isListview) {
                    $scope.gridViewResult = $scope.listViewResult[0].ProjectMasterGlossaries;
                    //creating distinct langs for <th>
                    for (var i = 0; i < $scope.gridViewResult.length; i++) {
                        if ($scope.gridViewResult[i].TranslationDetails && $scope.gridViewResult[i].TranslationDetails.length > 0) {
                            for (var j = 0; j < $scope.gridViewResult[i].TranslationDetails.length; j++) {
                                if ($scope.transLangColumns.filter(function (e) { return e.LanguageId == $scope.gridViewResult[i].TranslationDetails[j].LanguageId; }).length > 0) {
                                    continue;
                                } else {
                                    $scope.transLangColumns.push($scope.gridViewResult[i].TranslationDetails[j]);
                                }
                            }
                        }
                    }
                    $scope.showLoader = false;
                }
                setTimeout(function () { dynamicScreenHeight(); }, 500); // to set height of tbody
            });
        }

    };
    //reset on change of search type
    $scope.resetOnChange = function () {
        $scope.listViewResult = [];
        $scope.gridViewResult = [];
        $scope.searchText = "";
        $scope.ClientLists.length = 0;
        $scope.BrandList.length = 0;
        $scope.ProjectList.length = 0;
        $scope.LanguageLists.length = 0;
        $scope.approvalStatus.length = 0;

        $scope.clientLable = "Select Client(s)";
        $scope.brnadLable = "Select Brand(s)";
        $scope.projectLable = "Select Project(s)";
        $scope.languageLable = "Select Language(s)";
        $scope.statusLable = "Select Status";
    };

    //onselect of status
    $scope.onSelectStatus = function () {
        resetButtonLabel();
    };

    //on select of language
    $scope.onSelectLangauge = function () {
        $scope.approvalStatus.length = 0;
        resetButtonLabel();

        $scope.isSearchValid("");
        if (($scope.searchType.SearchText === "UniqueId" || $scope.searchType.SearchText === "Term") && $scope.LanguageLists && $scope.LanguageLists.length === 1 && $scope.LanguageLists[0].LanguageName === "English") {
            $scope.hideApproverStatus = false;
        }
    };

    var resetButtonLabel = function () {
        //set button labels
        if (!$scope.ClientLists || $scope.ClientLists.length === 0) {
            $scope.clientLable = "Select Client(s)";
        }
        if (!$scope.BrandList || $scope.BrandList.length === 0) {
            $scope.brnadLable = "Select Brand(s)";
        }
        if (!$scope.ProjectList || $scope.ProjectList.length === 0) {
            $scope.projectLable = "Select Project(s)";
        }
        if (!$scope.LanguageLists || $scope.LanguageLists.length === 0) {
            $scope.languageLable = "Select Language(s)";
        }
        if (!$scope.approvalStatus || $scope.approvalStatus.length === 0) {
            $scope.statusLable = "Select Status";
        }
    };

    //GLMGR-678 on chnege of client populate brands
    $scope.onSelectClient = function () {
        $scope.isSearchValid("client");

        //reset other dropdowns
        $scope.BrandList.length = 0;
        $scope.ProjectList.length = 0;
        $scope.LanguageLists.length = 0;
        $scope.approvalStatus.length = 0;

        resetButtonLabel();

        InputSearchClientData.ClientIds = [];
        InputSearchClientData.BrandIds = [];
        InputSearchClientData.ProjectIds = [];


        //isConsistence check
        if ($scope.searchType.SearchText === "Inconsistencies") {
            InputSearchClientData.Inconsistencies = true;
        } else {
            InputSearchClientData.Inconsistencies = false;
        }

        //is translation check
        if ($scope.searchType.SearchText === "Translation") {
            InputSearchClientData.Translation = true;
        } else {
            InputSearchClientData.Translation = false;
        }

        //client ids
        for (var i = 0; i < $scope.ClientLists.length; i++) {
            InputSearchClientData.ClientIds.push($scope.ClientLists[i].ClientId);
        }
        InputSearchClientData.BrandIds = [];
        InputSearchClientData.ProjectIds = [];

        SearchTermService.searchClientsBrandProjectLanguagePopulatedData(InputSearchClientData, function (data) {
            $scope.searchTermBrandData = data.ClientBrandList;
            $scope.searchTermProjectData = data.ClientUserProjectList;
            $scope.langDropList = data.ClientUserLanguageList;

        });
    };

    //GLMGR-678 on select of brands get project
    $scope.onSelectBrands = function () {
        //reset other dropdowns
        $scope.ProjectList.length = 0;
        $scope.LanguageLists.length = 0;
        $scope.approvalStatus.length = 0;

        resetButtonLabel();

        InputSearchClientData.ClientIds = [];
        InputSearchClientData.BrandIds = [];
        InputSearchClientData.ProjectIds = [];

        //isConsistence check
        if ($scope.searchType.SearchText === "Inconsistencies") {
            InputSearchClientData.Inconsistencies = true;
        } else {
            InputSearchClientData.Inconsistencies = false;
        }

        //isTranslation check
        if ($scope.searchType.SearchText === "Translation") {
            InputSearchClientData.Translation = true;
        } else {
            InputSearchClientData.Translation = false;
        }

        for (var i = 0; i < $scope.ClientLists.length; i++) {
            InputSearchClientData.ClientIds.push($scope.ClientLists[i].ClientId);
        }

        for (var i = 0; i < $scope.BrandList.length; i++) {
            InputSearchClientData.BrandIds.push($scope.BrandList[i].BrandId);
        }
        InputSearchClientData.ProjectIds = [];
        SearchTermService.searchBrandsProjectLanguagePopulatedData(InputSearchClientData, function (data) {
            $scope.searchTermProjectData = data.ClientUserProjectList;
            $scope.langDropList = data.ClientUserLanguageList;
        });
    };

    //GLMGR-678 on select of project
    $scope.onSelectProject = function () {
        $scope.LanguageLists.length = 0;
        $scope.approvalStatus.length = 0;

        resetButtonLabel();

        InputSearchClientData.ClientIds = [];
        InputSearchClientData.BrandIds = [];
        InputSearchClientData.ProjectIds = [];

        //isConsistence check
        if ($scope.searchType.SearchText === "Inconsistencies") {
            InputSearchClientData.Inconsistencies = true;
        } else {
            InputSearchClientData.Inconsistencies = false;
        }

        //isTranslation check
        if ($scope.searchType.SearchText === "Translation") {
            InputSearchClientData.Translation = true;
        } else {
            InputSearchClientData.Translation = false;
        }

        for (var i = 0; i < $scope.ClientLists.length; i++) {
            InputSearchClientData.ClientIds.push($scope.ClientLists[i].ClientId);
        }

        if ($scope.BrandList) {
            for (var i = 0; i < $scope.BrandList.length; i++) {
                InputSearchClientData.BrandIds.push($scope.BrandList[i].BrandId);
            }
        }

        for (var i = 0; i < $scope.ProjectList.length; i++) {
            InputSearchClientData.ProjectIds.push($scope.ProjectList[i].ProjectEncriptValue);
        }
        SearchTermService.searchProjectsLanguagePopulatedData(InputSearchClientData, function (data) {
            $scope.langDropList = data.ClientUserLanguageList;
        });
    };

    //list view onclick of project
    $scope.projectResultClick = function (project) {
        if ($scope.searchType.SearchText === "Inconsistencies" || $scope.searchType.SearchText === "Translation") {
            SearchInputInfoDetails.IsListView = false;
            SearchInputInfoDetails.ProjectId = [];
            SearchInputInfoDetails.ProjectId.push(project.ProjectIdEncrypted);
            SearchTermService.searchDetailsOnProjectClick(SearchInputInfoDetails, function (data) {
                $scope.gridViewResult = data[0].ProjectMasterGlossaries;
                for (var i = 0; i < $scope.gridViewResult.length; i++) {
                    if ($scope.gridViewResult[i].TranslationDetails && $scope.gridViewResult[i].TranslationDetails.length > 0) {
                        for (var j = 0; j < $scope.gridViewResult[i].TranslationDetails.length; j++) {
                            if ($scope.transLangColumns.filter(function (e) { return e.LanguageId == $scope.gridViewResult[i].TranslationDetails[j].LanguageId; }).length > 0) {
                                continue;
                            } else {
                                $scope.transLangColumns.push($scope.gridViewResult[i].TranslationDetails[j]);
                            }
                        }
                    }
                }
                $scope.isListview = false;
                $scope.showBackButton = true;
            });
        } else {
            if (project.IsSelectedLanguagePresent || SearchInputInfoDetails.IsMasterSearch) {
                SearchInputInfoDetails.IsListView = false;
                SearchInputInfoDetails.ProjectId = [];
                SearchInputInfoDetails.ProjectId.push(project.ProjectIdEncrypted);
                SearchTermService.searchDetailsOnProjectClick(SearchInputInfoDetails, function (data) {
                    $scope.gridViewResult = data[0].ProjectMasterGlossaries;
                    for (var i = 0; i < $scope.gridViewResult.length; i++) {
                        if ($scope.gridViewResult[i].TranslationDetails && $scope.gridViewResult[i].TranslationDetails.length > 0) {
                            for (var j = 0; j < $scope.gridViewResult[i].TranslationDetails.length; j++) {
                                if ($scope.transLangColumns.filter(function (e) { return e.LanguageId == $scope.gridViewResult[i].TranslationDetails[j].LanguageId; }).length > 0) {
                                    continue;
                                } else {
                                    $scope.transLangColumns.push($scope.gridViewResult[i].TranslationDetails[j]);
                                }
                            }
                        }
                    }
                    $scope.isListview = false;
                    $scope.showBackButton = true;
                });
            } else {
                $('#listViewNoLanguage').modal('show');
            }
        }
    };

    //grid view on click of result
    $scope.gridResultClick = function (colData, rowData) {
        sessionStorage.setItem('projectIBreadCrumb', JSON.stringify(rowData.ProjectIdEncrypted));
        sessionStorage.setItem('unEncriptedProjectId', JSON.stringify(rowData.ProjectId));
        sessionStorage.setItem('projectId', JSON.stringify(rowData.ProjectIdEncrypted));
        sessionStorage.setItem('headerId', JSON.stringify(rowData.GroupId));
        sessionStorage.setItem('HasWritePrivilege', JSON.stringify(rowData.IsHavingProjectLevelPermission));
        sessionStorage.setItem('PrivilegeIdInDb', JSON.stringify(colData.PrivilegeIdInDB));
        //GlossarySection of session
        var Glossarysection = {};
        Glossarysection.GlossaryGroupHeader = rowData.GroupName;
        Glossarysection.GlossaryGroupRowVersion = [];
        Glossarysection.Id = rowData.GroupId;
        Glossarysection.IsSecret = false; //has to come from backend
        Glossarysection.IsSectionComplete = true; //has to come from backend
        Glossarysection.ProjectId = rowData.ProjectId;
        Glossarysection.SectionId = rowData.GroupId;
        sessionStorage.setItem('GlossarySection', JSON.stringify(Glossarysection));
        sessionStorage.setItem('InstanceSettingProjectId', JSON.stringify(commonService.getSessionData('unEncriptedProjectId')));

        //set section type in session
        var temp;
        if (rowData.SectionType === 1) {
            temp = 'default';
        } else if (rowData.SectionType === 2) {
            temp = 'ntl';
        }
        sessionStorage.setItem('glossaryTab', JSON.stringify(temp));
        if (!colData) {
        return;
        }
        //clicked on translation
        if (colData !== 'section' && colData !== 'source_term' && colData !== 'project_title') {
            if ('LanguageId' in colData) {
                sessionStorage.setItem('translationProjectLanguageId', JSON.stringify(colData.ProjectLanguageId));
                sessionStorage.setItem('glossaryNewLang', JSON.stringify(colData));
                sessionStorage.setItem('SearchToTranslation', true);
                window.location = "Projects#/glossary";
            }
        }


        //clicked on section or source term
        if (colData === 'section' || colData === 'source_term') {
            window.location = "Projects#/glossary";
        }

        //clicked on project title
        if (colData === 'project_title') {
            sessionStorage.setItem('SearchToProjects', true);
            window.location = "Projects#/";
        }

    };

    var init = function () {
        $scope.projectId = commonService.getSessionData('projectIBreadCrumb');

        $scope.HasWritePrivilege = commonService.getSessionData('HasWritePrivilege');

        var resorceIdx = 0;
        sessionStorage.setItem('resourcePageId', JSON.stringify(resorceIdx));
        sessionStorage.setItem("filterStatus", "undefined");
        sessionStorage.setItem("filterImage", "undefined");
        sessionStorage.setItem("pendingTranslationsFilter", "0");
        sessionStorage.setItem("pendingApprovalsFilter", "0");
        sessionStorage.setItem("approvedFilter", "0");
        sessionStorage.setItem("rejectedFilter", "0");
        sessionStorage.setItem("filterOnStatus", "0");

        //GLMGR-678 SearchTypePopulatedData service on page load
        SearchTermService.searchTypePopulatedData(function (searchTypeData) {
            $scope.searchTypeList = searchTypeData;
        });

        //GLMGR-678 Approval status data on page load
        SearchTermService.searchTranslationStatusPopulatedData(function (translationStatusData) {
            $scope.translationStatusList = translationStatusData;
        });

        SearchTermService.getSearchTermPrePopulatedData(currentUserId, currentUserRoleName, function (initialdata) {
            hideColors = false;
            $scope.searchTermInitialData = initialdata;
            dynamicScreenHeight();
        });

        dynamicScreenHeight();

    };

    init();
}]);