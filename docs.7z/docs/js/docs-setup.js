NG_DOCS={
  "sections": {
    "api": "Glossary Manager Docs"
  },
  "pages": [
    {
      "section": "api",
      "id": "adminModule",
      "shortName": "adminModule",
      "type": "directive",
      "moduleName": "adminModule",
      "shortDescription": "Resize textarea automatically to the size of its text content.",
      "keywords": "admin adminmodule api automatically content directive div getcomputedstyle html module ng-app polyfill resize size text textarea window"
    },
    {
      "section": "api",
      "id": "AngularJS",
      "shortName": "AngularJS",
      "type": "object",
      "moduleName": "AngularJS",
      "shortDescription": "This section contains all inbuilt in functionalities of angualr js.",
      "keywords": "angualr angularjs api click details functionalities https inbuilt js link object org reference respective sections"
    },
    {
      "section": "api",
      "id": "AngularJS.$http",
      "shortName": "AngularJS.$http",
      "type": "service",
      "moduleName": "AngularJS",
      "shortDescription": "This built in AngularJS API (service) .",
      "keywords": "$http angularjs api built click details https link org service"
    },
    {
      "section": "api",
      "id": "AngularJS.$httpProvider",
      "shortName": "AngularJS.$httpProvider",
      "type": "service",
      "moduleName": "AngularJS",
      "shortDescription": "This AngularJS in built module which is used to change the default behavior of the $http service.",
      "keywords": "$http $httpprovider angularjs api behavior built change click default details https link module org service"
    },
    {
      "section": "api",
      "id": "AngularJS.$interval",
      "shortName": "AngularJS.$interval",
      "type": "service",
      "moduleName": "AngularJS",
      "shortDescription": "This AngularJS routing provider module.",
      "keywords": "$interval angularjs api click details https link module org provider routing service"
    },
    {
      "section": "api",
      "id": "AngularJS.$location",
      "shortName": "AngularJS.$location",
      "type": "service",
      "moduleName": "AngularJS",
      "shortDescription": "This built in AngularJS API (service) .",
      "keywords": "$location angularjs api built click details https link org service"
    },
    {
      "section": "api",
      "id": "AngularJS.$locationProvider",
      "shortName": "AngularJS.$locationProvider",
      "type": "service",
      "moduleName": "AngularJS",
      "shortDescription": "This AngularJS routing provider module.",
      "keywords": "$locationprovider angularjs api click details https link module org provider routing service"
    },
    {
      "section": "api",
      "id": "AngularJS.$rootScope",
      "shortName": "AngularJS.$rootScope",
      "type": "service",
      "moduleName": "AngularJS",
      "shortDescription": "This AngularJS routing provider module.",
      "keywords": "$rootscope angularjs api click details https link module org provider routing service"
    },
    {
      "section": "api",
      "id": "AngularJS.$route",
      "shortName": "AngularJS.$route",
      "type": "service",
      "moduleName": "AngularJS",
      "shortDescription": "This AngularJS routing provider module.",
      "keywords": "$route angularjs api click details https link module org provider routing service"
    },
    {
      "section": "api",
      "id": "AngularJS.$routeProvider",
      "shortName": "AngularJS.$routeProvider",
      "type": "service",
      "moduleName": "AngularJS",
      "shortDescription": "This AngularJS routing provider module.",
      "keywords": "$routeprovider angularjs api click details https link module org provider routing service"
    },
    {
      "section": "api",
      "id": "AngularJS.$scope",
      "shortName": "AngularJS.$scope",
      "type": "service",
      "moduleName": "AngularJS",
      "shortDescription": "This built in AngularJS API (service) .",
      "keywords": "$scope angularjs api built click details https link org service"
    },
    {
      "section": "api",
      "id": "AngularJS.ng-breadcrumbs",
      "shortName": "AngularJS.ng-breadcrumbs",
      "type": "service",
      "moduleName": "AngularJS",
      "shortDescription": "",
      "keywords": "angularjs api better breadcrumb-style help ian js kennington navigation ng-breadcrumb ng-breadcrumbs service v0 views walter"
    },
    {
      "section": "api",
      "id": "AngularJS.ngRoute",
      "shortName": "AngularJS.ngRoute",
      "type": "service",
      "moduleName": "AngularJS",
      "shortDescription": "This AngularJS in built module which s used for routing.",
      "keywords": "angularjs api built click details https link module ngroute org routing service"
    },
    {
      "section": "api",
      "id": "common",
      "shortName": "common",
      "type": "object",
      "moduleName": "common",
      "shortDescription": "This is common module for all modules.",
      "keywords": "angularjs api common html module modules ng-breadcrumbs object"
    },
    {
      "section": "api",
      "id": "common.commonService",
      "shortName": "common.commonService",
      "type": "service",
      "moduleName": "common",
      "shortDescription": "This is a common service used by all controllers in application.This service contains all the common functions eg.gerUserGuide method is used to download help document. ",
      "keywords": "$http angularjs api application common commonservice controllers document download functions geruserguide help method service"
    },
    {
      "section": "api",
      "id": "Login",
      "shortName": "Login",
      "type": "object",
      "moduleName": "Login",
      "shortDescription": "This is login module, which will contain controller for login page. ",
      "keywords": "$locationprovider $routeprovider angularjs api controller html login module ngroute object users"
    },
    {
      "section": "api",
      "id": "Login.controller:LoginController",
      "shortName": "LoginController",
      "type": "controller",
      "moduleName": "Login",
      "shortDescription": "This Controller is responsible for showing Login page and handling requests made on Login page ",
      "keywords": "$http $location $scope accept acceptdeclinehandler accepted angularjs api authenticateuser backend button called change check class clicked clicks condition conditions controller database decline details div email empty entered entries error false field forgetpasswordemail form function getuserdetails glmgr-498 handling hash link logged login login-controller-logincontroller-page login-controller-page logincontroller loginerrormessage match message method ng-show object onhashchange pass password property recived requests reset response responsible send server session showing solution status storage stores string terms tracked url user userauthenticateservice userauthorizationservice userdeatails userdetails username users valid wheather"
    },
    {
      "section": "api",
      "id": "Projects",
      "shortName": "Projects",
      "type": "object",
      "moduleName": "Projects",
      "shortDescription": "This is Projects module, which will contain controller for project page. ",
      "keywords": "$httpprovider $locationprovider $routeprovider angularjs api common controller html module ngroute object project projects"
    },
    {
      "section": "api",
      "id": "Projects.controller:ProjectsController",
      "shortName": "ProjectsController",
      "type": "controller",
      "moduleName": "Projects",
      "shortDescription": "This Controller is responsible for showing Login page and handling requests made on Login page ",
      "keywords": "$http $interval $location $route $scope 39 acoording add admin angularjs api array assigned backend boolean bound button called carousel chanages change changeview check class column columnmapping common commonservice controller corousaldata current currentprojectid currentuserid currentuserrolename div drop dropdown dropdows edit element encrypated excel false file fuction function glossary handling html info isalreadyselected isvalidforpreview knp labels landingpagedata list loads logged loggin login mapping method netflix new_path number object option parameter passed permissions prepared preview priview project projectlistvertical projects projects-controller-page projects-controller-projectscontroller-page projectscontroller prop property recived requests reset resetbuttonlabels respective responsible return role selected selects setup showing source sourcepreview stores string super toggle toggleprojectlistclick true upload uploadattachments uploadfilewizard user userdeatails userdetails validation view views wizard"
    },
    {
      "section": "api",
      "id": "Projects.directive:optionsClass",
      "shortName": "optionsClass",
      "type": "directive",
      "moduleName": "Projects",
      "shortDescription": "This is custom directive created for highlighting the secret section in dropdown of all sections on source setup page.",
      "keywords": "api created custom directive dropdown highlighting optionsclass projects secret sections select setup source"
    },
    {
      "section": "api",
      "id": "Projects.directive:optionsClassLangOrder",
      "shortName": "optionsClassLangOrder",
      "type": "directive",
      "moduleName": "Projects",
      "shortDescription": "This is custom directive created for putting selected languages in an alphabetical order.",
      "keywords": "add alphabetical api box created custom directive language languages option optionsclasslangorder order project projects putting select selected"
    },
    {
      "section": "api",
      "id": "Projects.directive:optionsClassOrder",
      "shortName": "optionsClassOrder",
      "type": "directive",
      "moduleName": "Projects",
      "shortDescription": "This is custom directive created for putting addtional info options in an alphabetical order.",
      "keywords": "add addtional alphabetical api box created custom directive info option options optionsclassorder order project projects putting select"
    },
    {
      "section": "api",
      "id": "Projects.directive:optionsClassSections",
      "shortName": "optionsClassSections",
      "type": "directive",
      "moduleName": "Projects",
      "shortDescription": "This is custom directive created for coloring the selected secret section in dropdown of all sections on source setup page.",
      "keywords": "api coloring created custom directive dropdown option optionsclasssections projects secret sections selected setup source"
    },
    {
      "section": "api",
      "id": "rfx.directive:rAutogrow",
      "shortName": "rAutogrow",
      "type": "directive",
      "moduleName": "rfx",
      "shortDescription": "Resize textarea automatically to the size of its text content.",
      "keywords": "api automatically class content directive getcomputedstyle html input-block-level module ng-model polyfill rautogrow resize rfx rx-autogrow size text textarea window"
    },
    {
      "section": "api",
      "id": "Users",
      "shortName": "Users",
      "type": "object",
      "moduleName": "Users",
      "shortDescription": "This is Users module, which constains usersController for users menu to show all users in system. ",
      "keywords": "$httpprovider $locationprovider $routeprovider angularjs api common constains html menu module ngroute object system users userscontroller"
    },
    {
      "section": "api",
      "id": "Users.UserAuthenticateService",
      "shortName": "Users.UserAuthenticateService",
      "type": "service",
      "moduleName": "Users",
      "shortDescription": "This is service in users module. It contains methods which areuser to authenticate user while logging in to system. ",
      "keywords": "$http accepts angularjs api areuser authenticate authenticated check checks database doesn email entered field forgot function getuserauthenticate input link logging login method methods module pass password popup reset return send sendforgotpasswordemail service system user userauthenticateservice useremailid username users"
    },
    {
      "section": "api",
      "id": "Users.UserAuthorizationService",
      "shortName": "Users.UserAuthorizationService",
      "type": "service",
      "moduleName": "Users",
      "shortDescription": "This is service in users module. It contains methods which areuser to authenticate user while logging in to system.",
      "keywords": "$http accepted accepts action admin angularjs api areuser authenticate called common commonservice conditions database depending details entered false field flag function getuserauthorization input logging login method methods module object properties returns role service set super system terms true updateusertermaccepted user userauthentication userauthorizationservice userid username users"
    }
  ],
  "apis": {
    "api": true
  },
  "__file": "_FAKE_DEST_/js/docs-setup.js",
  "__options": {
    "startPage": "/api",
    "scripts": [
      "js/angular.min.js",
      "js/angular-animate.min.js",
      "js/marked.js",
      "app.min.js"
    ],
    "styles": [],
    "title": "Glossary Manager Docs",
    "html5Mode": true,
    "editExample": true,
    "navTemplate": false,
    "navContent": "",
    "navTemplateData": {},
    "image": "img/home.png",
    "imageLink": "/",
    "titleLink": "/",
    "loadDefaults": {
      "angular": true,
      "angularAnimate": true,
      "marked": true
    }
  },
  "html5Mode": true,
  "editExample": true,
  "startPage": "/api",
  "scripts": [
    "js/angular.min.js",
    "js/angular-animate.min.js",
    "js/marked.js",
    "app.min.js"
  ]
};